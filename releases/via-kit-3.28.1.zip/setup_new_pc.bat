@echo off
rem ════════════════════════════════════════════════════════════════════════════════════════════
rem  Via Studios Kit — NEW PC SETUP. Run ONCE after cloning the kit: right-click → Run as administrator.
rem  1 panel permissions + Adobe debug mode · 2 Python 3.12 · 3 all libraries (+ Rust/C++ tools for
rem  DeepFilterNet) · 4 Claude Code. Safe to run again: every step skips what is already there. (L-026)
rem ════════════════════════════════════════════════════════════════════════════════════════════
chcp 65001 >nul
title Via Studios Kit - New PC setup
net session >nul 2>&1
if errorlevel 1 (echo. & echo  Right-click setup_new_pc.bat and choose "Run as administrator". & echo. & pause & exit /b 1)
set "KIT=%~dp0"
set "KITD=%KIT:~0,-1%"
echo.
echo  [1/4] Panel permissions + Adobe extensions debug mode
icacls "%KITD%" /grant *S-1-5-32-545:(OI)(CI)M /T /Q >nul && echo   permissions OK
for %%v in (9 10 11 12 13) do reg add HKCU\Software\Adobe\CSXS.%%v /v PlayerDebugMode /t REG_SZ /d 1 /f >nul
echo   debug mode OK
echo.
echo  [2/4] Python
set "PY="
for %%P in ("%LOCALAPPDATA%\Programs\Python\Python312\python.exe" "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" "%LOCALAPPDATA%\Programs\Python\Python313\python.exe" "C:\Program Files\Python312\python.exe") do if not defined PY if exist %%P set "PY=%%~P"
if defined PY goto havepy
echo   not found - downloading Python 3.12 from python.org ...
powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol='Tls12'; Invoke-WebRequest -UseBasicParsing 'https://www.python.org/ftp/python/3.12.10/python-3.12.10-amd64.exe' -OutFile $env:TEMP\via_py312.exe"
"%TEMP%\via_py312.exe" /quiet InstallAllUsers=0 PrependPath=1 Include_pip=1 Include_launcher=1 Include_test=0
set "PY=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if not exist "%PY%" (echo   Python install failed - install it from python.org with "Add to PATH", then run this again. & pause & exit /b 1)
:havepy
echo   %PY%
echo.
echo  [3/4] Libraries (first time 20-60 min: PyTorch CUDA + C++ tools are big)
call "%KIT%audio_enhance\install_libs.bat" "%PY%" cuda
echo.
echo  [4/4] Claude Code (for Claude Montage)
where claude >nul 2>nul || if exist "%USERPROFILE%\.local\bin\claude.exe" (echo   already installed) else (powershell -NoProfile -ExecutionPolicy Bypass -Command "irm https://claude.ai/install.ps1 | iex")
echo.
echo  ════════════════════════════════════════════════════════════
echo   Done. Two things left, by hand:
echo   - After Effects: Edit - Preferences - Scripting and Expressions:
echo     tick "Allow Scripts to Write Files and Access Network", restart AE.
echo   - Open a NEW Command Prompt, type  claude  once and log in (Claude subscription).
echo   CorridorKey (AI Keyer) installs from its own card.
echo  ════════════════════════════════════════════════════════════
echo.
pause
