// ── PANEL LOG (panel) · 3.27.0 — docs/AUDIT-2026-11.md A-15 ─────────────────────────────────────────────────
// Errors used to vanish (152 empty catch blocks) → debugging from screenshots. Everything that goes wrong now lands in
// %APPDATA%\Via Studios Kit\logs\panel.log (1 MB, then panel.log.1): uncaught errors, rejected promises,
// "EvalScript error" from After Effects, ⚠ toasts and error statuses. Settings › Maintenance › Copy debug info.
// Loaded right after CSInterface.js so it sees errors from every other module.
window.viaLog = (function () {
  var MAX = 1024 * 1024, file = null, mem = [];
  function logPath() {
    if (file !== null) return file;
    try {
      var p = require('path'), os = require('os'), fs = require('fs');
      var d = p.join(process.env.APPDATA || os.homedir(), 'Via Studios Kit', 'logs');
      fs.mkdirSync(d, { recursive: true });
      file = p.join(d, 'panel.log');
    } catch (e) { file = ''; }
    return file;
  }
  function write(level, where, msg) {
    var line = new Date().toISOString().replace('T', ' ').slice(0, 19) + ' ' + level + ' [' + where + '] ' +
               String(msg == null ? '' : msg).replace(/\s+/g, ' ').slice(0, 2000);
    mem.push(line); if (mem.length > 300) mem.shift();
    var f = logPath(); if (!f) return;
    try {
      var fs = require('fs');
      try { if (fs.statSync(f).size > MAX) { try { fs.unlinkSync(f + '.1'); } catch (e1) {} fs.renameSync(f, f + '.1'); } } catch (e2) {}
      fs.appendFileSync(f, line + '\r\n', 'utf8');
    } catch (e) {}
  }
  window.addEventListener('error', function (e) {
    write('ERROR', 'window', (e.message || 'error') + ' @ ' + String(e.filename || '').split('/').pop().split('?')[0] + ':' + (e.lineno || 0));
  });
  window.addEventListener('unhandledrejection', function (e) {
    var r = e.reason; write('ERROR', 'promise', r && r.stack ? r.stack : (r && r.message) || r);
  });
  function tail(n) {
    try { return require('fs').readFileSync(logPath(), 'utf8').split(/\r?\n/).filter(Boolean).slice(-n); }
    catch (e) { return mem.slice(-n); }
  }
  // wrap the toast once every module is loaded: "⚠ …" toasts are failures the user saw
  function hookToast() {
    var t = window.showToast;
    if (typeof t === 'function' && !t._viaLog) {
      var w = function (m) { try { if (/^\s*(⚠|✗|Script error)/.test(String(m))) write('WARN', 'toast', m); } catch (e) {} return t.apply(this, arguments); };
      w._viaLog = true; window.showToast = w;
    }
    // every card's status line (.ae-status) that turns red is logged once per message
    try {
      new MutationObserver(function (muts) {
        muts.forEach(function (m) {
          var el = m.target.nodeType === 1 ? m.target : m.target.parentElement;
          if (!el || !el.classList || !el.classList.contains('ae-status') || !el.classList.contains('is-error')) return;
          var t = (el.textContent || '').trim();
          if (t && el._viaLogged !== t) { el._viaLogged = t; write('ERROR', el.id || 'status', t); }
        });
      }).observe(document.body, { subtree: true, attributes: true, attributeFilter: ['class'], childList: true, characterData: true });
    } catch (e) {}
    write('INFO', 'start', 'panel started');
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', hookToast); else setTimeout(hookToast, 0);
  return {
    info: function (where, m) { write('INFO', where, m); },
    warn: function (where, m) { write('WARN', where, m); },
    error: function (where, m) { write('ERROR', where, m); },
    tail: tail, path: logPath
  };
})();
