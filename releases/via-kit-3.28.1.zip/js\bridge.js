(function() {
  var cs = new CSInterface();
  var v = new Vulcan();
  var EXT = cs.getSystemPath(SystemPath.EXTENSION).replace(/\\/g, '/');
  var IS_AI = cs.getApplicationID() === 'ILST';
  var IS_AE = cs.getApplicationID() === 'AEFT';
  var DEBUG = false; // true → writes %TEMP%\welo_overlord.log

  function logBridge(tag, txt) {
    if (!DEBUG) return;
    try {
      var line = new Date().toISOString() + ' [' + (IS_AI ? 'AI' : 'AE') + '] ' + tag + ': ' + txt;
      var code = "try { var f = new File(Folder.temp.fsName + \"/welo_overlord.log\"); f.open('a'); f.writeln(" + JSON.stringify(line) + "); f.close(); } catch(e) {}";
      cs.evalScript(code, function() {});
    } catch(e) {
      try { console.error('logBridge error:', e); } catch(e2) {}
    }
  }

  function evalHost(fn, cb) {
    try {
      cs.evalScript(fn, function(r) {
        if (cb) cb(r && r.indexOf('EvalScript error') !== 0 ? r : null);
      });
    } catch(e) { console.error('bridge eval error:', e); }
  }

  // Load Overlord ExtendScript if not already loaded
  evalHost("typeof overlord", function(r) {
    logBridge('init', 'typeof overlord = ' + r);
    // 3.27.0 (A-17): in After Effects Overlord.jsx (2,400 lines) is loaded only when a message needs it
    if (IS_AE) { afterLoad(); return; }
    if (!r || r === 'undefined') {
      var olPath = EXT + '/jsx/Overlord.jsx';
      evalHost("try { $.evalFile('" + olPath + "'); } catch(e) {}", function() {
        afterLoad();
      });
    } else {
      afterLoad();
    }
  });

  function afterLoad() {
    // Register Vulcan listener
    VulcanInterface.addMessageListener(
      VulcanMessage.TYPE_PREFIX + 'com.overlord.vulcan',
      function(e) {
        var raw = VulcanInterface.getPayload(e);
        if (!raw) return;
        var msg = JSON.parse(raw);
        var cmd = msg.cmd;
        if (!cmd) return;
        logBridge('recv', cmd);

        // ── Messages handled by AI host ──
        if (IS_AI) {
          switch (cmd) {
            case 'ai_new':
              evalHost("overlord.ai_newShapes(" + JSON.stringify(msg) + ")");
              break;
            case 'pullNewAiShapes':
              evalHost("overlord.ai_getSelection({prefs:" + JSON.stringify(msg.prefs || {}) + "})", function(r) {
                if (r) {
                  try {
                    var shapes = JSON.parse(r);
                    sendVulcan({ cmd:'newShapes', shapes:shapes, altKey:false, shiftKey:false, prefs:msg.prefs || {} });
                  } catch(e) {}
                }
              });
              break;
            case 'newArtboard':
              evalHost("overlord.ai_newArtboard(" + JSON.stringify(msg) + ")");
              break;
            case 'ae_newShapes':
              evalHost("overlord.ai_newShapes(" + JSON.stringify({shapes: msg.shapes}) + ")");
              break;
            case 'pushSwatches':
              evalHost("overlord.ai_swatches(" + JSON.stringify({swatches: msg.swatches, prefs: msg.prefs}) + ")");
              break;
            case 'pushGuides':
              evalHost("overlord.ai_guides(" + JSON.stringify({guides: msg.guides, prefs: msg.prefs}) + ")");
              break;
            case 'pullArtboardToComp':
              logBridge('recv', 'pullArtboardToComp on AI host');
              sendVulcan({ cmd:'showMessage', txt: 'Reading artboard from Illustrator...' });
              evalHost("overlord.ai_getArtboard({prefs:" + JSON.stringify(msg.prefs || {}) + "})", function(r) {
                logBridge('ai_getArtboard', r ? 'returned data' : 'returned null/error');
                if (r) {
                  try {
                    sendVulcan({ cmd:'newComp', artboard: JSON.parse(r) });
                  } catch(e) {
                    sendVulcan({ cmd:'showMessage', txt: 'Artboard failed — bad artboard data from Illustrator' });
                  }
                } else {
                  sendVulcan({ cmd:'showMessage', txt: 'No response from Illustrator — is a document open?' });
                }
              });
              break;
            case 'breakSymbols':
              evalHost("overlord.ai_breakSymbols()", function(r) {
                var count = r ? parseInt(r) : 0;
                sendVulcan({ cmd:'showMessage', txt: count > 0 ? 'Broken ' + count + ' symbols' : 'Select symbols first' });
              });
              break;
          }
        }

        // ── Messages handled by AE host ──
        if (IS_AE) {
          if (cmd !== 'switchToAe' && cmd !== 'switchToAi')     // evalScript runs in order → loaded before the call below
            evalHost("if (typeof overlord === 'undefined') { try { $.evalFile(" + JSON.stringify(EXT + '/jsx/Overlord.jsx') + "); } catch(e) {} } 'ok'");
          switch (cmd) {
            case 'newShapes':
              // Set prefs from the message before creating shapes
              if (msg.prefs) {
                evalHost("overlordPrefs = " + JSON.stringify(msg.prefs));
              }
              evalHost("overlord.ae_newShapes(" + JSON.stringify(msg) + ")", function(r) {
                if (!msg.silent) {
                  sendVulcan({ cmd:'showMessage', txt: r ? 'Shapes created from Ai' : 'Create a comp in AE first' });
                }
              });
              break;
            case 'pullNewAeShapes':
              evalHost("overlord.ae_getSelection()", function(r) {
                if (r) {
                  try {
                    var shapes = JSON.parse(r);
                    if (shapes && shapes.length > 0) {
                      sendVulcan({ cmd:'ae_newShapes', shapes:shapes, altKey:false, shiftKey:false, prefs:msg.prefs || {} });
                    }
                  } catch(e) {}
                }
              });
              break;
            case 'newComp':
              logBridge('recv', 'newComp on AE host');
              if (msg.prefs) {
                evalHost("overlordPrefs = " + JSON.stringify(msg.prefs));
              }
              evalHost("overlord.ae_newComp(" + JSON.stringify(msg.artboard) + ")", function(r) {
                sendVulcan({ cmd:'showMessage', txt: (r && r.indexOf('OK') !== -1) ? 'Artboard → Comp created' : 'Artboard → Comp failed — is Illustrator open?' });
              });
              break;
            case 'switchToAe':
              switchApp('aftereffects');
              break;
            case 'switchToAi':
              switchApp('illustrator');
              break;
          }
        }
      }
    );

    console.log('Bridge ready — ' + (IS_AI ? 'AI' : 'AE'));
    logBridge('init', 'bridge ready, listener registered');
  }

  function sendVulcan(payload) {
    try {
      var m = new VulcanMessage(VulcanMessage.TYPE_PREFIX + 'com.overlord.vulcan');
      m.setPayload(JSON.stringify(payload));
      VulcanInterface.dispatchMessage(m);
    } catch(e) { console.error('Vulcan send error:', e); }
  }

  function switchApp(app) {
    try {
      var target = app === 'illustrator' ? 'ILST' : 'AEFT';
      var specs = v.getTargetSpecifiersEx().filter(function(s) { return s.indexOf(target + '-') >= 0; });
      if (specs.length > 0) {
        var targetSpec = specs[0];
        for (var i = 0; i < specs.length; i++) {
          if (v.isAppRunningEx(specs[i])) { targetSpec = specs[i]; break; }
        }
        v.launchAppEx(targetSpec, true);
      }
    } catch(e) { console.error('Switch error:', e); }
  }
})();
