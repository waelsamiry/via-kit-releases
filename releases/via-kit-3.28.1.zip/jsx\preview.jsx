// ── BOX PREVIEW (ExtendScript, ES3) · 3.25.1 — docs/BOX-PREVIEW-SPEC.md P1 ─────────────────────────────────
// Renders the subtitle box + text exactly as After Effects does (real font, Arabic shaping, effects) into a PNG,
// using a TEMPORARY comp — the user's comp, selection and time are never touched. Panel side: js/preview.js.
// saveFrameToPng writes the file AFTER this script returns → the panel waits for the file, then calls pvRelease(id).

var PV_COMP = '__via_preview__', PV_SRC = '__via_preview_src__', PV_FOLDER = '__Via_Preview__', PV_BG = '__via_pv_bg__';

function pvSupported() {
    try {
        var c = getComp();
        if (c) return typeof c.saveFrameToPng === 'function' ? 'OK' : 'ERR:NO_SNAPSHOT';
        // no comp open: test on a throw-away comp would add undo noise — assume supported, snapshot re-checks
        return 'OK';
    } catch (e) { return 'ERR:' + e.toString(); }
}

function pv__isTemp(it) {
    return (it instanceof CompItem && (it.name === PV_COMP || it.name === PV_SRC)) ||
           (it instanceof FootageItem && it.name === PV_BG);        // the background solid
}

function pv__folder(create) {
    for (var i = 1; i <= app.project.numItems; i++) {
        var it = app.project.item(i);
        if (it instanceof FolderItem && it.name === PV_FOLDER) return it;
    }
    return create ? app.project.items.addFolder(PV_FOLDER) : null;
}

function pv__removeTemps() {
    var n = 0;
    for (var i = app.project.numItems; i >= 1; i--) {
        var it = app.project.item(i);
        if (pv__isTemp(it)) { it.remove(); n++; }
    }
    var f = pv__folder(false);
    if (f && f.numItems === 0) { f.remove(); n++; }
    return n;
}

function pvCleanupAll() {
    try {
        var any = false;
        for (var i = 1; i <= app.project.numItems && !any; i++) {
            var it = app.project.item(i);
            if (pv__isTemp(it) || (it instanceof FolderItem && it.name === PV_FOLDER)) any = true;
        }
        if (!any) return 'OK:0';
        app.beginUndoGroup('Via: Preview cleanup');
        var n = pv__removeTemps();
        app.endUndoGroup();
        return 'OK:' + n;
    } catch (e) { return 'ERR:' + e.toString() + ' line ' + e.line; }
}

function pvRelease(id) {
    try {
        app.beginUndoGroup('Via: Preview');
        for (var i = app.project.numItems; i >= 1; i--) {
            var it = app.project.item(i);
            if (it.id === +id && pv__isTemp(it)) { it.remove(); break; }
        }
        pv__removeTemps();                                       // src comp + empty folder (and any leftover)
        app.endUndoGroup();
        return 'OK';
    } catch (e) {
        try { app.endUndoGroup(); } catch (e2) {}
        return 'ERR:' + e.toString() + ' line ' + e.line;
    }
}

// first selected text layer, else the same pick Generate uses
function pv__sample(comp, st) {
    for (var i = 1; i <= comp.numLayers; i++) {
        var l = comp.layer(i);
        if (l.selected && l instanceof TextLayer) return l;
    }
    var all = getTextLayers(comp, st.autoDetect !== false, st.keywords || 'sub,subtitle,txt,caption');
    for (var k = 0; k < all.length; k++) if (all[k].name.indexOf('_SSBG_') !== 0) return all[k];
    return null;
}

// approximate comp-space box of the subtitle (text rect + padding), rotation ignored
function pv__bounds(L, t, st, W, H) {
    var r = L.sourceRectAtTime(t, false);
    var tr = L.property('ADBE Transform Group');
    var p = tr.property('ADBE Position').valueAtTime(t, false);
    var a = tr.property('ADBE Anchor Point').valueAtTime(t, false);
    var s = tr.property('ADBE Scale').valueAtTime(t, false);
    var sx = s[0] / 100, sy = s[1] / 100;
    var pad = (st.padding !== undefined ? +st.padding : 30) + (st.strokeEnabled ? +st.strokeWidth || 0 : 0) +
              (st.blur ? +st.blur * 2 : 0) + (st.shadowEnabled ? (+st.shadowBlur || 8) * 2 : 0);
    var x0 = p[0] + (r.left - a[0]) * sx - pad * Math.abs(sx), y0 = p[1] + (r.top - a[1]) * sy - pad * Math.abs(sy);
    var x1 = p[0] + (r.left + r.width - a[0]) * sx + pad * Math.abs(sx), y1 = p[1] + (r.top + r.height - a[1]) * sy + pad * Math.abs(sy);
    var m = 40;
    x0 = Math.max(0, Math.floor(Math.min(x0, x1) - m)); y0 = Math.max(0, Math.floor(Math.min(y0, y1) - m));
    x1 = Math.min(W, Math.ceil(Math.max(x0, x1) + m)); y1 = Math.min(H, Math.ceil(Math.max(y0, y1) + m));
    if (x1 - x0 < 16 || y1 - y0 < 16) return null;
    return { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
}

// A transcript line as Generate would make it: AE Character panel style (charPanel) or the kit font, centred,
// at posY of the frame height. Same steps as whisperGenerateLayers (host.jsx).
function pv__textLayer(src, o, st) {
    var C = src.layers.addText(String(o.text));
    C.name = 'SUB_preview';
    var tp = C.property('Source Text'), td = tp.value;
    td.justification = ParagraphJustification.CENTER_JUSTIFY;
    if (!o.charPanel) {
        try { td.fontSize = +o.fontSize || 28; } catch (e1) {}
        try { td.font = o.fontFamily || 'Arial'; } catch (e2) {}
    }
    tp.setValue(td);
    var r = C.sourceRectAtTime(0, false), scx = r.left + r.width / 2, scy = r.top + r.height / 2;
    var ap = C.property('Transform').property('Anchor Point'), pp = C.property('Transform').property('Position'), a0 = ap.value;
    ap.setValue([a0[0] + scx, a0[1] + scy]);
    pp.setValue([src.width / 2 + scx, src.height * (o.posY !== undefined ? +o.posY : 0.85) + scy]);
    return C;
}

// json = { state, bg: 'dark'|'light', scale: 0.5, purpose: 'preview'|'thumb', crop: true,
//          text?: 'a transcript line', posY?, charPanel?, fontSize?, fontFamily?, box? }
function pvSnapshot(json) {
    var undo = false;
    try {
        var o = JSON.parse(json), st = o.state || {};
        var textMode = o.text !== undefined && o.text !== null;   // 3.25.1: a transcript line, styled like Generate does
        var comp = getComp();
        if (!comp && !textMode) return 'ERR:NO_COMP';
        var CW = comp ? comp.width : 1920, CH = comp ? comp.height : 1080, PA = comp ? comp.pixelAspect : 1,
            FPS = comp ? comp.frameRate : 25;
        var fd = 1 / FPS, t, L = null;
        if (!textMode) {
            if (typeof comp.saveFrameToPng !== 'function') return 'ERR:NO_SNAPSHOT';
            L = pv__sample(comp, st);
            if (!L) return 'ERR:NO_LAYERS';
            t = comp.time;
            if (!(t >= L.inPoint && t < L.outPoint)) {             // after the in-animation has finished
                var animF = (+st.duration || 8) + (+st.offset || 0);
                t = Math.min(L.inPoint + animF * fd + fd, L.outPoint - fd);
            }
            t = Math.max(0, Math.round(t / fd) * fd);
        } else {
            if (!String(o.text).replace(/\s/g, '')) return 'ERR:NO_TEXT';
            t = fd;
        }

        app.beginUndoGroup('Via: Preview'); undo = true;
        pv__removeTemps();
        var folder = pv__folder(true);
        var dur = Math.max(comp ? comp.duration : 1, t + 2 * fd);
        var src = app.project.items.addComp(PV_SRC, CW, CH, PA, dur, FPS);
        src.parentFolder = folder;
        if (typeof src.saveFrameToPng !== 'function') throw new Error('NO_SNAPSHOT');

        var C;
        if (!textMode) {
            L.copyToComp(src);
            C = src.layer(1);                                   // same NAME → box expressions find it
            try { C.parent = null; } catch (e1) {}
            try { if (C.hasTrackMatte) { if (C.setTrackMatte) C.setTrackMatte(null, TrackMatteType.NO_TRACK_MATTE); else C.trackMatteType = TrackMatteType.NO_TRACK_MATTE; } } catch (e2) {}
            C.enabled = true;
            if (!(t >= C.inPoint && t < C.outPoint)) { C.inPoint = Math.max(0, t - fd); C.outPoint = t + fd; }
            createBoxForLayer(src, C, st);                      // the REAL box code → preview == result
        } else {
            C = pv__textLayer(src, o, st);                      // same steps as whisperGenerateLayers
            if (o.box) createBoxForLayer(src, C, st);
        }

        var bgc = o.bg === 'light' ? [0.88, 0.88, 0.88] : [0.04, 0.04, 0.05];   // comp area; the panel draws its edge (3.25.2)
        var W = CW, H = CH, box = null;
        if (o.crop !== false) { try { box = pv__bounds(C, t, st, W, H); } catch (e3) { box = null; } }
        var cw = box ? box.w : W, ch = box ? box.h : H;
        var out = app.project.items.addComp(PV_COMP, cw, ch, PA, dur, FPS);
        out.parentFolder = folder;
        var bgL = out.layers.addSolid(bgc, PV_BG, cw, ch, PA, dur);
        try { bgL.source.parentFolder = folder; } catch (e7) {}
        var P = out.layers.add(src);
        if (box) P.property('ADBE Transform Group').property('ADBE Position').setValue([W / 2 - box.x, H / 2 - box.y]);
        bgL.moveToEnd();
        var sc = o.scale !== undefined ? +o.scale : 0.5;
        out.resolutionFactor = sc <= 0.25 ? [4, 4] : sc <= 0.5 ? [2, 2] : [1, 1];

        var dir = new Folder(Folder.temp.fsName + '/via-preview');
        if (!dir.exists) dir.create();
        var old = dir.getFiles('pv-*.png');
        for (var k = 0; k < old.length; k++) { try { old[k].remove(); } catch (e4) {} }
        var file = new File(dir.fsName + '/pv-' + out.id + '-' + new Date().getTime() + '.png');
        out.saveFrameToPng(t, file);                            // written AFTER we return — do not remove `out` here
        app.endUndoGroup(); undo = false;

        var fps = FPS, fr = Math.round(t * fps);
        return 'OK:' + JSON.stringify({ path: file.fsName, id: out.id, w: cw, h: ch, t: t,
            tc: Math.floor(fr / fps / 60) + ':' + ('0' + Math.floor(fr / fps) % 60).slice(-2) + ':' + ('0' + fr % Math.round(fps)).slice(-2),
            layer: L ? L.name : 'line', crop: !!box });
    } catch (e) {
        if (undo) { try { pv__removeTemps(); } catch (e5) {} try { app.endUndoGroup(); } catch (e6) {} }
        if (String(e.message) === 'NO_SNAPSHOT') return 'ERR:NO_SNAPSHOT';
        return 'ERR:' + e.toString() + ' line ' + e.line;
    }
}
