// Minimal JSON polyfill for ExtendScript (ES3). Only defines what is missing.
if (typeof JSON !== 'object' || !JSON) { JSON = {}; }
(function () {
    function quote(s) {
        return '"' + String(s).replace(/[\\"\u0000-\u001f\u007f-\u009f\u2028\u2029]/g, function (c) {
            switch (c) {
                case '"': return '\\"';
                case '\\': return '\\\\';
                case '\n': return '\\n';
                case '\r': return '\\r';
                case '\t': return '\\t';
                case '\b': return '\\b';
                case '\f': return '\\f';
            }
            var h = c.charCodeAt(0).toString(16);
            while (h.length < 4) h = '0' + h;
            return '\\u' + h;
        }) + '"';
    }
    function str(v) {
        var t = typeof v, i, out, k;
        if (v === null || t === 'undefined' || t === 'function') return t === 'undefined' || t === 'function' ? undefined : 'null';
        if (t === 'string') return quote(v);
        if (t === 'number') return isFinite(v) ? String(v) : 'null';
        if (t === 'boolean') return String(v);
        if (v instanceof Date) return quote(v.toString());
        if (v instanceof Array) {
            out = [];
            for (i = 0; i < v.length; i++) { var e = str(v[i]); out.push(e === undefined ? 'null' : e); }
            return '[' + out.join(',') + ']';
        }
        out = [];
        for (k in v) {
            if (Object.prototype.hasOwnProperty.call(v, k)) {
                var s = str(v[k]);
                if (s !== undefined) out.push(quote(k) + ':' + s);
            }
        }
        return '{' + out.join(',') + '}';
    }
    if (typeof JSON.stringify !== 'function') {
        JSON.stringify = function (v) { return str(v); };
    }
    if (typeof JSON.parse !== 'function') {
        JSON.parse = function (text) {
            text = String(text);
            // Crockford json2 safety check: only allow JSON tokens before eval
            var t = text.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g, '@')
                        .replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, ']')
                        .replace(/(?:^|:|,)(?:\s*\[)+/g, '');
            if (!/^[\],:{}\s]*$/.test(t)) throw new SyntaxError('JSON.parse');
            return eval('(' + text + ')');
        };
    }
}());
