// weloTools — find / download ffmpeg, ffprobe, yt-dlp (LESSONS L-012).
// Every ffmpeg/ffprobe/yt-dlp call in the panel goes through weloTools.find(name, cb) / weloTools.get(name).
// Search order: weloCfg.tools.<name> > <ext>\ytdl > %APPDATA%\Via Studios Kit\bin > PATH (where) > common installs.
// Needs Node (CEP --enable-nodejs). Paths are cached in weloCfg key 'tools' and re-checked with existsSync.
window.weloTools = (function () {
  var NAMES = ['ffmpeg', 'ffprobe', 'yt-dlp'];
  var found = {};          // name -> validated absolute path
  var versions = {};       // name -> version string
  var busy = {};           // name -> download/update running

  function nodeOk() { return typeof require === 'function'; }
  function cfg() { try { return window.weloCfg; } catch (e) { return null; } }

  function extDir() {
    try {
      var p = new CSInterface().getSystemPath(SystemPath.EXTENSION);
      if (p) { try { p = decodeURI(p); } catch (e) {} return String(p).replace(/\//g, '\\').replace(/\\+$/, ''); }
    } catch (e) {}
    try {   // fallback: panel URL (file:///C:/.../index.html)
      var u = decodeURI(location.href).replace(/^file:\/\/\//, '').replace(/[?#].*$/, '');
      return u.substring(0, u.lastIndexOf('/')).replace(/\//g, '\\');
    } catch (e) {}
    return '';
  }
  function binDir() {
    var path = require('path'), os = require('os');
    return path.join(process.env.APPDATA || os.homedir(), 'Via Studios Kit', 'bin');
  }
  function exeName(name) { return name + '.exe'; }
  function saved() { var c = cfg(), t = null; try { t = c && c.get('tools'); } catch (e) {} return (t && typeof t === 'object') ? t : {}; }
  function saveTool(name, p) {
    var c = cfg(); if (!c) return;
    var t = saved(); if (p) t[name] = p; else delete t[name];
    try { c.set('tools', t); } catch (e) {}
  }

  function candidates(name) {
    var path = require('path'), env = process.env, list = [], e = extDir(), x = exeName(name);
    var s = saved();
    if (s[name]) list.push(s[name]);
    if (e) list.push(path.join(e, 'ytdl', x));
    list.push(path.join(binDir(), x));
    return list;
  }
  function fallbackDirs() {
    var path = require('path'), env = process.env, d = [];
    if (env.LOCALAPPDATA) d.push(path.join(env.LOCALAPPDATA, 'Microsoft', 'WinGet', 'Links'));
    if (env.USERPROFILE) d.push(path.join(env.USERPROFILE, 'scoop', 'shims'));
    d.push('C:\\ProgramData\\chocolatey\\bin', 'C:\\ffmpeg\\bin', 'C:\\Program Files\\ffmpeg\\bin');
    return d;
  }

  function validate(name, exe, cb) {
    var cp = require('child_process');
    var arg = name === 'yt-dlp' ? '--version' : '-version';
    try {
      cp.execFile(exe, [arg], { windowsHide: true, timeout: 5000 }, function (err, out) {
        if (err) { cb(false, ''); return; }
        var first = String(out || '').split(/\r?\n/)[0].trim();
        var m = first.match(/version\s+(\S+)/i);
        cb(true, m ? m[1] : first);
      });
    } catch (e) { cb(false, ''); }
  }

  function tryList(name, list, i, cb) {
    var fs = require('fs');
    if (i >= list.length) { cb(null); return; }
    var p = list[i];
    if (!p || !fs.existsSync(p)) { tryList(name, list, i + 1, cb); return; }
    validate(name, p, function (ok, ver) {
      if (ok) { versions[name] = ver; cb(p); } else tryList(name, list, i + 1, cb);
    });
  }

  function whereFind(name, cb) {
    var cp = require('child_process');
    try {
      cp.execFile('where', [name], { windowsHide: true, timeout: 5000 }, function (err, out) {
        if (err) { cb([]); return; }
        cb(String(out || '').split(/\r?\n/).map(function (s) { return s.trim(); }).filter(Boolean));
      });
    } catch (e) { cb([]); }
  }

  function find(name, cb, force) {
    if (!nodeOk()) { if (cb) cb(null); return; }
    var fs = require('fs'), path = require('path');
    if (!force && found[name] && fs.existsSync(found[name])) { if (cb) cb(found[name]); return; }
    delete found[name];
    function done(p) {
      if (p) { found[name] = p; saveTool(name, p); } else saveTool(name, null);
      if (cb) cb(p);
    }
    tryList(name, candidates(name), 0, function (p) {
      if (p) { done(p); return; }
      whereFind(name, function (hits) {
        tryList(name, hits, 0, function (p2) {
          if (p2) { done(p2); return; }
          var list = fallbackDirs().map(function (d) { return path.join(d, exeName(name)); });
          tryList(name, list, 0, done);
        });
      });
    });
  }

  // sync accessor: last resolved path ('' if unknown). Call ready() once before using it.
  function get(name) { return found[name] || ''; }
  function dirOf(name) { var p = get(name); return p ? require('path').dirname(p) : ''; }
  function ready(cb) {
    var n = 0;
    NAMES.forEach(function (nm) { find(nm, function () { if (++n === NAMES.length && cb) cb(); }); });
  }
  // find one tool or toast + open Settings card; cb(path|null)
  function need(name, cb) {
    find(name, function (p) {
      if (!p) {
        try { toast(name + ' not found - Settings > External tools'); } catch (e) {}
        render();
      }
      cb(p);
    });
  }
  // env for child processes (Python reads WELO_FFMPEG_DIR)
  function env() {
    var e = {}, k; for (k in process.env) e[k] = process.env[k];
    var d = dirOf('ffmpeg'); if (d) { e.WELO_FFMPEG_DIR = d; e.PATH = d + ';' + (e.PATH || ''); }
    return e;
  }

  // ── download ──
  function httpGet(url, dest, onPct, cb, hops) {
    var https = require('https'), fs = require('fs');
    hops = hops || 0;
    if (hops > 6) { cb('too many redirects'); return; }
    var req = https.get(url, { headers: { 'User-Agent': 'welo-tools' } }, function (res) {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        res.resume(); httpGet(res.headers.location, dest, onPct, cb, hops + 1); return;
      }
      if (res.statusCode !== 200) { res.resume(); cb('HTTP ' + res.statusCode); return; }
      var total = parseInt(res.headers['content-length'] || '0', 10), got = 0, out = fs.createWriteStream(dest);
      res.on('data', function (c) { got += c.length; if (total && onPct) onPct(Math.round(got * 100 / total)); });
      res.pipe(out);
      out.on('finish', function () { out.close(function () { cb(null); }); });
      out.on('error', function (e) { cb(e.message); });
      res.on('error', function (e) { cb(e.message); });
    });
    req.on('error', function (e) { cb(e.message); });
    req.setTimeout(30000, function () { req.destroy(new Error('timeout')); });
  }

  function download(name, onPct, cb) {
    if (!nodeOk()) { cb('Node.js is off'); return; }
    if (busy[name]) return;
    var fs = require('fs'), path = require('path'), cp = require('child_process'), os = require('os');
    var bin = binDir();
    try { fs.mkdirSync(bin, { recursive: true }); } catch (e) { cb(e.message); return; }
    busy[name] = true;
    function fin(err) {
      delete busy[name];
      if (err) { cb(err); return; }
      var names = name === 'yt-dlp' ? ['yt-dlp'] : ['ffmpeg', 'ffprobe'], n = 0, bad = null;
      names.forEach(function (nm) {
        find(nm, function (p) {
          if (!p || p.toLowerCase().indexOf(bin.toLowerCase()) !== 0) { if (!p) bad = nm + ' failed -version check'; }
          if (++n === names.length) cb(bad);
        }, true);
      });
    }
    if (name === 'yt-dlp') {
      var tmp = path.join(bin, 'yt-dlp.exe.part');
      httpGet('https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe', tmp, onPct, function (err) {
        if (err) { try { fs.unlinkSync(tmp); } catch (e) {} fin(err); return; }
        try { fs.renameSync(tmp, path.join(bin, 'yt-dlp.exe')); fin(null); } catch (e) { fin(e.message); }
      });
      return;
    }
    var zip = path.join(os.tmpdir(), 'welo_ffmpeg.zip'), ex = path.join(os.tmpdir(), 'welo_ffmpeg_x');
    httpGet('https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip', zip, onPct, function (err) {
      if (err) { fin(err); return; }
      if (onPct) onPct(100);
      var ps = "$ErrorActionPreference='Stop';Remove-Item -Recurse -Force -LiteralPath '" + ex + "' -ErrorAction SilentlyContinue;" +
        "Expand-Archive -LiteralPath '" + zip + "' -DestinationPath '" + ex + "' -Force;" +
        "$b=Get-ChildItem -LiteralPath '" + ex + "' -Recurse -Filter ffmpeg.exe | Select-Object -First 1;" +
        "Copy-Item $b.FullName '" + bin + "\\ffmpeg.exe' -Force;" +
        "Copy-Item (Join-Path $b.DirectoryName 'ffprobe.exe') '" + bin + "\\ffprobe.exe' -Force";
      var p = cp.spawn('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', ps], { windowsHide: true });
      var errTxt = '';
      p.stderr.on('data', function (d) { errTxt += d; });
      p.on('error', function (e) { fin(e.message); });
      p.on('close', function (code) {
        try { fs.unlinkSync(zip); } catch (e) {}
        try { cp.spawn('powershell', ['-NoProfile', '-Command', "Remove-Item -Recurse -Force -LiteralPath '" + ex + "'"], { windowsHide: true }); } catch (e) {}
        fin(code === 0 ? null : ('unzip failed ' + errTxt.substring(0, 120)));
      });
    });
  }

  function update(name, cb) {
    if (name !== 'yt-dlp') { cb('only yt-dlp can self-update'); return; }
    find(name, function (p) {
      if (!p) { cb('not found'); return; }
      try {
        require('child_process').execFile(p, ['-U'], { windowsHide: true, timeout: 120000 }, function (err, out) {
          find(name, function () { cb(err ? String(out || err.message).split(/\r?\n/).pop() : null); }, true);
        });
      } catch (e) { cb(e.message); }
    });
  }

  function browse(name, cb) {
    try {
      var r = window.cep.fs.showOpenDialog(false, false, 'Select ' + exeName(name), '', ['exe']);
      var f = r && r.data && r.data[0];
      if (!f) { cb(null); return; }
      f = String(f).replace(/\//g, '\\');
      validate(name, f, function (ok, ver) {
        if (!ok) { cb('Not a working ' + name); return; }
        found[name] = f; versions[name] = ver; saveTool(name, f); cb(null);
      });
    } catch (e) { cb(e.message); }
  }

  // ── Settings card ──
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function render() {
    var host = document.getElementById('toolsCardBody');
    if (!host) return;
    var html = '';
    NAMES.forEach(function (nm) {
      var p = get(nm);
      html += '<div style="padding:4px 0;border-bottom:1px solid var(--border)">' +
        '<div style="display:flex;gap:6px;align-items:center"><span class="control-label" style="min-width:52px">' + nm + '</span>' +
        (p ? '<span style="color:var(--success,#7fd99a);font-size:10px">&#10003; ' + esc(versions[nm] || '') + '</span>'
           : '<span style="color:#f07178;font-size:10px">&#10007; Not found</span>') +
        '<span style="flex:1"></span>' +
        '<button class="btn-secondary" data-act="dl" data-n="' + nm + '" style="padding:2px 8px">' + (p ? 'Reinstall' : 'Download') + '</button>' +
        '<button class="btn-secondary" data-act="br" data-n="' + nm + '" style="padding:2px 8px">Browse...</button>' +
        (nm === 'yt-dlp' && p ? '<button class="btn-secondary" data-act="up" data-n="' + nm + '" style="padding:2px 8px">Update</button>' : '') +
        '</div>' +
        '<div style="font-size:8px;color:var(--text-muted);font-family:Consolas,monospace;word-break:break-all">' + esc(p || '') + '</div>' +
        '<div style="height:3px;background:var(--bg-card);margin-top:3px;display:none" id="toolProgWrap_' + nm + '"><div id="toolProg_' + nm + '" style="height:3px;width:0;background:var(--accent)"></div></div>' +
        '</div>';
    });
    host.innerHTML = html;
    var btns = host.querySelectorAll('button[data-act]');
    for (var i = 0; i < btns.length; i++) btns[i].onclick = onBtn;
  }
  function onBtn() {
    var act = this.getAttribute('data-act'), nm = this.getAttribute('data-n');
    var wrap = document.getElementById('toolProgWrap_' + nm), bar = document.getElementById('toolProg_' + nm);
    function after(err) {
      if (wrap) wrap.style.display = 'none';
      try { toast(err ? nm + ': ' + err : nm + ' ready'); } catch (e) {}
      if (nm !== 'yt-dlp' && !err) { find('ffprobe', function () { render(); }, true); } else render();
    }
    if (act === 'br') { browse(nm, after); return; }
    if (act === 'up') { try { toast('Updating yt-dlp...'); } catch (e) {} update(nm, after); return; }
    if (wrap) wrap.style.display = 'block';
    try { toast('Downloading ' + nm + '...'); } catch (e) {}
    download(nm, function (pct) { if (bar) bar.style.width = pct + '%'; }, after);
  }
  function init() {
    // tell host.jsx the real extension folder (Program Files or Program Files (x86)) — LESSONS L-013
    try { var d = extDir(); if (d) new CSInterface().evalScript('weloSetExtDir(' + JSON.stringify(d.replace(/\\/g, '/')) + ')'); } catch (e) {}
    showVersion();
    ready(render);
  }
  // header/home badges said "v3.0" forever; read the real bundle version from CSXS/manifest.xml
  function showVersion() {
    try {
      var xml = require('fs').readFileSync(require('path').join(extDir(), 'CSXS', 'manifest.xml'), 'utf8');
      var m = xml.match(/ExtensionBundleVersion="([^"]+)"/); if (!m) return;
      document.querySelectorAll('.home-version,.version-badge').forEach(function (el) { el.textContent = 'v' + m[1]; });
    } catch (e) {}
  }

  return { find: find, get: get, dirOf: dirOf, ready: ready, need: need, env: env, download: download,
           update: update, browse: browse, render: render, init: init, binDir: function () { return binDir(); } };
}());
if (window.WeloInit) window.WeloInit.add(function () { window.weloTools.init(); });
