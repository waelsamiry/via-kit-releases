// ── PYTHON SETUP (panel) · 3.21.2 — one-click Python install when it is missing (new PC / fresh Windows) ──
// Downloads the official python.org installer and runs it silently for the current user with "Add to PATH"
// (no admin). Fallback: winget. Button lives in Settings › Python Setup and is also added under
// the System Check error "Python not found". After the CMD window closes: Auto Detect + Check Everything.
window.weloPySetup = (function () {
  var VER = '3.12.10';
  var URL = 'https://www.python.org/ftp/python/' + VER + '/python-' + VER + '-amd64.exe';
  var busy = false;
  function node() { return { fs: require('fs'), path: require('path'), cp: require('child_process'), os: require('os') }; }
  function toast(m) { try { window.showToast(m); } catch (e) {} }
  function install() {
    if (busy) return;
    if (typeof require !== 'function') { toast('⚠ Node.js is off — restart After Effects'); return; }
    busy = true;
    var n = node(), bat = n.path.join(n.os.tmpdir(), 'welo_python_install.bat');
    var lines = [
      '@echo off', 'chcp 65001 > nul', 'title Via Studios Kit - Install Python ' + VER,
      'set "PYI=%TEMP%\\via_python_' + VER + '.exe"',
      'echo Downloading Python ' + VER + ' from python.org ...',
      'powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference=\'Stop\'; [Net.ServicePointManager]::SecurityProtocol=\'Tls12\'; Invoke-WebRequest -UseBasicParsing \'' + URL + '\' -OutFile $env:PYI"',
      'if errorlevel 1 goto winget',
      'echo Installing for this user (adds Python to PATH, no admin needed) ...',
      '"%PYI%" /quiet InstallAllUsers=0 PrependPath=1 Include_pip=1 Include_launcher=1 Include_test=0',
      'if errorlevel 1 goto winget',
      'goto done',
      ':winget',
      'echo python.org download/install failed - trying winget ...',
      'winget install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements --override "/quiet InstallAllUsers=0 PrependPath=1 Include_pip=1"',
      'if errorlevel 1 (echo Python install failed. Install it from python.org and tick "Add python.exe to PATH". & pause & exit /b 1)',
      ':done',
      'echo.', 'echo Python installed. This window closes in 5 seconds...', 'timeout /t 5 > nul'
    ];
    n.fs.writeFileSync(bat, lines.join('\r\n') + '\r\n', 'utf8');
    toast('⬇ Installing Python — watch the CMD window');
    setStatus('Installing Python ' + VER + ' in the CMD window…', 'var(--accent-4)');
    n.cp.spawn('cmd.exe', ['/c', 'start', '""', '/wait', 'cmd.exe', '/c', bat]).on('close', function () {
      busy = false;
      setTimeout(function () {
        try { window.settingsDetectPython(); } catch (e) {}
        setTimeout(function () { try { window.settingsCheckAll(); } catch (e) {} }, 1500);
      }, 500);
    });
  }
  function setStatus(t, color) { var el = document.getElementById('pythonPathStatus'); if (el) { el.style.color = color || ''; el.textContent = t; } }
  // add an Install button under the System Check error when it says Python is missing
  function watch() {
    var g = document.getElementById('chkSystemGrid');
    if (!g || !window.MutationObserver) return;
    new MutationObserver(function () {
      if (g.querySelector('.welo-py-install')) return;
      if (!/Python not found/i.test(g.textContent || '')) return;
      var b = document.createElement('button');
      b.className = 'btn-secondary welo-py-install'; b.style.cssText = 'width:100%;margin-top:6px';
      b.textContent = 'Install Python ' + VER + ' (adds to PATH)';
      b.onclick = install;
      g.appendChild(b);
    }).observe(g, { childList: true, subtree: true });
  }
  if (window.WeloInit) window.WeloInit.add(watch);
  return { install: install };
})();
