@echo off
echo ============================================
echo  Via Studios Kit — Fix Presets Folder Permissions
echo ============================================
echo.

set "EXT_DIR=%~dp0"
set "PRESETS=%EXT_DIR%presets"

echo Granting full access to: %PRESETS%
echo.

icacls "%PRESETS%" /grant "%USERNAME%":(OI)(CI)F /T /Q
icacls "%EXT_DIR%audio_enhance" /grant "%USERNAME%":(OI)(CI)F /T /Q

if %errorlevel% == 0 (
    echo  Done! You can close this window.
) else (
    echo  Failed. Try right-clicking this file
    echo  and choosing "Run as Administrator".
)

echo.
pause
