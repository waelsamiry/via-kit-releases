@echo off
rem Via Studios Kit — every Python library the kit uses, in versions that work together (constraints.txt).
rem Usage: install_libs.bat "<python.exe>" [cuda|cpu]      Called by setup_new_pc.bat and Settings › Install all.
setlocal
chcp 65001 >nul
set "PY=%~1"
if "%PY%"=="" set "PY=python"
set "MODE=%~2"
if "%MODE%"=="" set "MODE=cuda"
set "HERE=%~dp0"
set "CON=%HERE%constraints.txt"
set "PATH=%USERPROFILE%\.cargo\bin;%PATH%"
echo.
echo  [libs 1/5] pip
"%PY%" -m pip install --upgrade pip --quiet
echo  [libs 2/5] PyTorch (%MODE%)
"%PY%" -c "import torch,sys; sys.exit(0 if ('%MODE%'=='cpu' or torch.cuda.is_available()) else 1)" >nul 2>nul
if not errorlevel 1 goto torchok
rem 3.27.0 (A-24): keep in sync with VIA_TORCH_PIP in js/script.js (same index, torch + torchvision + torchaudio)
set "TIDX=https://download.pytorch.org/whl/cu121"
if /i "%MODE%"=="cpu" set "TIDX=https://download.pytorch.org/whl/cpu"
"%PY%" -m pip install torch torchaudio torchvision -c "%CON%" --index-url %TIDX%
goto torchdone
:torchok
echo   already installed - kept
:torchdone
echo  [libs 3/5] Rust + C++ build tools (to compile DeepFilterNet once)
call "%HERE%install_build_tools.bat"
echo  [libs 4/5] Audio, voice and transcription libraries
"%PY%" -m pip install soundfile demucs deepfilternet audio-separator onnxruntime silero-vad transformers huggingface_hub openai-whisper -c "%CON%"
"%PY%" -m pip install clearvoice -c "%CON%"
echo  [libs 5/5] Check
"%PY%" -c "import importlib.util;[print('   %%-16s %%s'%%(n,'OK' if importlib.util.find_spec(m) else 'MISSING')) for n,m in [('torch','torch'),('DeepFilterNet','df'),('audio-separator','audio_separator'),('onnxruntime','onnxruntime'),('silero-vad','silero_vad'),('transformers','transformers'),('whisper','whisper'),('demucs','demucs'),('clearvoice','clearvoice')]]"
"%PY%" -c "import torch;print('   CUDA:', torch.cuda.is_available(), torch.cuda.get_device_name(0) if torch.cuda.is_available() else '')" 2>nul
"%PY%" -c "import numpy;print('   numpy', numpy.__version__)"
endlocal
exit /b 0
