// ── BOX PREVIEW (panel) · 3.25.1 — docs/BOX-PREVIEW-SPEC.md P1 ──────────────────────────────────────────────
// "Preview in AE": After Effects renders the box + text in a temporary comp (jsx/preview.jsx) → PNG → shown here.
// Also makes preset thumbnails. The HTML preview (updatePreview) stays: instant but approximate; this one is true.
window.viaPreview = (function () {
  var busy = false, pending = null, supported = true, bg = 'dark';
  function $(id) { return document.getElementById(id); }
  function node() { return { fs: require('fs'), path: require('path'), os: require('os') }; }
  function jsx(code) { return new Promise(function (res) { new CSInterface().evalScript(code, function (r) { res(String(r || '')); }); }); }
  function esc(o) { return (window.safeJSON || JSON.stringify)(o); }
  function status(msg, kind) { var el = $('pvStatus'); if (el) { el.textContent = msg || ''; el.className = 'ae-status' + (kind ? ' is-' + kind : ''); el.style.display = msg ? '' : 'none'; } }
  var CALM = { NO_COMP: 'Open a comp with a subtitle text layer', NO_LAYERS: 'Select a text layer (or name it sub / caption)',
               NO_SNAPSHOT: 'This After Effects version cannot render a preview frame', NO_TEXT: 'This line is empty' };

  // wait until AE has finished writing the PNG: size > 0 and unchanged on 2 polls (100 ms), max 5 s
  function waitFile(p) {
    var fs = node().fs, last = -1, t0 = Date.now();
    return new Promise(function (res, rej) {
      (function poll() {
        var sz = -1; try { sz = fs.statSync(p).size; } catch (e) {}
        if (sz > 0 && sz === last) return res(p);
        last = sz;
        if (Date.now() - t0 > 5000) return rej(new Error('After Effects did not write the preview frame in 5 s'));
        setTimeout(poll, 100);
      })();
    });
  }

  // snap(state, {bg, scale, purpose}) → Promise<{dataUrl, path, info}>. Several fast clicks → one extra run (latest wins).
  function snap(state, opts) {
    opts = opts || {};
    if (busy) {
      return new Promise(function (res, rej) {
        if (pending) pending.rej(new Error('superseded'));
        pending = { state: state, opts: opts, res: res, rej: rej };
      });
    }
    busy = true;
    var info = null;
    var req = { state: state, bg: opts.bg || bg, scale: opts.scale || 0.5, purpose: opts.purpose || 'preview', crop: opts.crop !== false };
    ['text', 'posY', 'charPanel', 'fontSize', 'fontFamily', 'box'].forEach(function (k) { if (opts[k] !== undefined) req[k] = opts[k]; });
    return jsx("pvSnapshot('" + esc(req) + "')").then(function (r) {
      if (r.indexOf('OK:') !== 0) {
        var code = r.replace(/^ERR:/, '');
        if (code === 'NO_SNAPSHOT') { supported = false; showUI(); }
        var e = new Error(CALM[code] || code); e.code = code; throw e;
      }
      info = JSON.parse(r.slice(3));
      return waitFile(info.path);
    }).then(function (p) {
      var b64 = node().fs.readFileSync(p).toString('base64');       // data URL: no CEF image cache
      return { dataUrl: 'data:image/png;base64,' + b64, path: p, info: info };
    }).then(function (out) { return finish(info).then(function () { return out; }); },
            function (err) { return finish(info).then(function () { throw err; }); });
  }
  function finish(info) {
    var rel = info && info.id ? jsx('pvRelease(' + (+info.id) + ')') : Promise.resolve('');
    return rel.then(function () {
      busy = false;
      if (pending) { var p = pending; pending = null; snap(p.state, p.opts).then(p.res, p.rej); }
    });
  }

  // ── UI in tab-design: one preview area, switch Live (HTML, instant) ↔ After Effects (real render, full frame) ──
  var mode = 'live';
  function setMode(m) {
    mode = m === 'ae' && supported ? 'ae' : 'live';
    ['live', 'ae'].forEach(function (k) { var c = $('pvMode_' + k); if (c) c.classList.toggle('active', k === mode); });
    var live = $('pvLiveArea'), ae = $('pvAeArea');
    if (live) live.style.display = mode === 'live' ? '' : 'none';
    if (ae) ae.style.display = mode === 'ae' ? '' : 'none';
    try { window.weloCfg.set('pv_mode', mode); } catch (e) {}
    if (mode === 'ae') preview();
  }
  function preview() {
    if (typeof CSInterface === 'undefined' || typeof require !== 'function') { status('Open in After Effects', 'warn'); return; }
    var btn = $('pvBtn'); if (btn) btn.classList.add('is-working');
    status('Rendering in After Effects…', 'working');
    // full frame: shows the real font, the position in the frame and the box settings together
    snap(window.state || {}, { bg: bg, crop: false }).then(function (o) {
      var img = $('pvImg'); if (img) { img.src = o.dataUrl; img.style.display = 'block'; }
      var tl = $('pvTime'); if (tl) tl.textContent = o.info.w + '×' + o.info.h + ' · ' + o.info.tc + ' · ' + o.info.layer;
      status('');
    }).catch(function (e) {
      if (e.message === 'superseded') return;
      status(e.message, e.code ? 'warn' : 'error');
    }).then(function () { if (!busy && btn) btn.classList.remove('is-working'); });
  }
  // ── Transcription tab: the current line as Generate will make it (Character panel or kit font, Vertical Pos, box) ──
  function previewLine() {
    if (typeof CSInterface === 'undefined' || typeof require !== 'function') { lstatus('Open in After Effects', 'warn'); return; }
    var txt = '', idx = 1;
    try {
      if (typeof window.wlCommitAll === 'function') window.wlCommitAll();
      var paras = window.whisperParagraphs || [];
      idx = Math.max(1, Math.min(paras.length, parseInt(($('whisperTimingLine') || {}).value, 10) || 1));
      if (paras.length && typeof window.wlParaText === 'function') txt = window.wlParaText(paras[idx - 1]) || '';
    } catch (e) {}
    if (!txt) txt = 'معاينة شكل الترجمة — Subtitle preview';
    var btn = $('pvLineBtn'); if (btn) btn.classList.add('is-working');
    lstatus('Rendering line ' + idx + ' in After Effects…', 'working');
    var cp = $('whisperCharPanel'), st = window.state || {};
    snap(st, { bg: bg, crop: false, text: txt, posY: (+(($('whisperPosSlider') || {}).value) || 85) / 100,
               charPanel: cp ? cp.checked : true, fontSize: st.previewFontSize || 28, fontFamily: st.previewFont || 'Arial',
               box: !!(($('whisperAutoBox') || {}).checked) }).then(function (o) {
      var img = $('pvLineImg'); if (img) { img.src = o.dataUrl; img.style.display = 'block'; }
      var tl = $('pvLineTime'); if (tl) tl.textContent = 'line ' + idx + ' · ' + o.info.w + '×' + o.info.h;
      lstatus('');
    }).catch(function (e) {
      if (e.message === 'superseded') return;
      lstatus(e.message, e.code ? 'warn' : 'error');
    }).then(function () { if (!busy && btn) btn.classList.remove('is-working'); });
  }
  function lstatus(msg, kind) { var el = $('pvLineStatus'); if (el) { el.textContent = msg || ''; el.className = 'ae-status' + (kind ? ' is-' + kind : ''); el.style.display = msg ? '' : 'none'; } }

  function setBg(v) {
    bg = v === 'light' ? 'light' : 'dark';
    ['dark', 'light'].forEach(function (k) { var c = $('pvBg_' + k); if (c) c.classList.toggle('active', k === bg); });
    try { window.weloCfg.set('pv_bg', bg); } catch (e) {}
    if (mode === 'ae' && $('pvImg') && $('pvImg').style.display === 'block') preview();
  }
  function showUI() {
    ['pvMode_ae', 'pvLineWrap'].forEach(function (id) { var w = $(id); if (w) w.style.display = supported ? '' : 'none'; });
    if (!supported && mode === 'ae') setMode('live');
  }

  // ── preset thumbnails: %APPDATA%\Via Studios Kit\thumbs\<id>.png ──
  function thumbDir() {
    var n = node(), d = n.path.join(process.env.APPDATA || n.os.homedir(), 'Via Studios Kit', 'thumbs');
    try { n.fs.mkdirSync(d, { recursive: true }); } catch (e) {}
    return d;
  }
  function thumb(state, presetId) {               // → Promise<file name | ''>; never rejects (saving a preset must not fail)
    if (!supported || typeof CSInterface === 'undefined' || typeof require !== 'function') return Promise.resolve('');
    return snap(state, { bg: 'dark', scale: 0.5, purpose: 'thumb' }).then(function (o) {
      var n = node(), name = String(presetId).replace(/[^\w.-]/g, '_') + '.png';
      n.fs.writeFileSync(n.path.join(thumbDir(), name), n.fs.readFileSync(o.path));
      return name;
    }).catch(function () { return ''; });
  }
  function thumbUrl(name) {
    if (!name || typeof require !== 'function') return '';
    var n = node(), p = n.path.join(thumbDir(), name);
    try { var st = n.fs.statSync(p); return 'file:///' + p.replace(/\\/g, '/') + '?v=' + st.mtimeMs; } catch (e) { return ''; }
  }
  function dropThumb(name) {
    if (!name || typeof require !== 'function') return;
    try { node().fs.unlinkSync(node().path.join(thumbDir(), name)); } catch (e) {}
  }

  function init() {
    if (!$('pvAeArea')) return;
    try { bg = window.weloCfg.get('pv_bg') === 'light' ? 'light' : 'dark'; } catch (e) {}
    setBg(bg);
    var m0 = 'live'; try { m0 = window.weloCfg.get('pv_mode') === 'ae' ? 'ae' : 'live'; } catch (e) {}
    mode = m0; ['live', 'ae'].forEach(function (k) { var c = $('pvMode_' + k); if (c) c.classList.toggle('active', k === mode); });
    if ($('pvLiveArea')) $('pvLiveArea').style.display = mode === 'live' ? '' : 'none';
    $('pvAeArea').style.display = mode === 'ae' ? '' : 'none';     // AE render happens on demand (refresh / switch), not at start
    var cp = $('whisperCharPanel');
    if (cp) { try { cp.checked = window.weloCfg.get('wh_charpanel') !== '0'; } catch (e) {} cp.addEventListener('change', function () { try { window.weloCfg.set('wh_charpanel', cp.checked ? '1' : '0'); } catch (e) {} }); }
    if (typeof CSInterface === 'undefined') return;
    jsx('pvCleanupAll()');                        // leftovers from a panel closed mid-snapshot
    jsx('pvSupported()').then(function (r) { supported = r !== 'ERR:NO_SNAPSHOT'; showUI(); });
  }
  function onOpen() { var im = $('pvImg'); if (mode === 'ae' && supported && im && im.style.display !== 'block') preview(); }
  return { init: init, onOpen: onOpen, snap: snap, preview: preview, previewLine: previewLine, setMode: setMode, setBg: setBg, thumb: thumb, thumbUrl: thumbUrl, dropThumb: dropThumb,
           isSupported: function () { return supported; } };
})();
if (window.WeloInit) window.WeloInit.add(function () { window.viaPreview.init(); });

// ── Collapsible sections (3.25.1): <div class="section [collapsed]" data-collapse="key"> — header click toggles,
// the open/closed state is remembered in settings.json (weloCfg 'collapsed' = {key: 1|0}).
(function () {
  function load() { try { return JSON.parse(window.weloCfg.get('collapsed') || '{}') || {}; } catch (e) { return {}; } }
  function init() {
    var saved = load();
    Array.prototype.forEach.call(document.querySelectorAll('.section[data-collapse]'), function (sec) {
      var k = sec.getAttribute('data-collapse'), hd = sec.querySelector('.section-header');
      if (saved[k] !== undefined) sec.classList.toggle('collapsed', !!saved[k]);
      if (!hd) return;
      hd.addEventListener('click', function (ev) {
        if (ev.target && /^(INPUT|BUTTON|SELECT|LABEL|A)$/.test(ev.target.tagName)) return;
        sec.classList.toggle('collapsed');
        var s = load(); s[k] = sec.classList.contains('collapsed') ? 1 : 0;
        try { window.weloCfg.set('collapsed', JSON.stringify(s)); } catch (e) {}
      });
    });
  }
  if (window.WeloInit) window.WeloInit.add(init);
})();
