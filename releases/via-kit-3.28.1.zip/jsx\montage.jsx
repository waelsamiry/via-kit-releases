// ── CLAUDE MONTAGE (ExtendScript, ES3) · 3.19.0 — panel side js/montage.js, plan docs/CLAUDE-MONTAGE-PLAN.md ──

function montagePickFolder() {
    try {
        var f = Folder.selectDialog('Choose the shooting-day folder (one sub-folder per episode)');
        return f ? f.fsName : 'cancelled';
    } catch (e) { return 'ERR:' + e.toString(); }
}

// paths JSON array → {"<path>": {id,w,h,fps,dur}} ; reuses footage already in the project, else imports into folder `bin`
function montageImport(json) {
    app.beginUndoGroup('Welo: Montage import');
    try {
        var d = JSON.parse(json), paths = d.paths, out = {}, i, k, it, bin = null;
        var have = {};
        for (i = 1; i <= app.project.numItems; i++) {
            it = app.project.item(i);
            if (it instanceof FootageItem && it.mainSource && it.mainSource.file) have[it.mainSource.file.fsName.toLowerCase()] = it;
        }
        for (k = 0; k < paths.length; k++) {
            var p = paths[k], f = new File(p);
            it = have[f.fsName.toLowerCase()];
            if (!it) {
                if (!f.exists) return 'ERR:File not found: ' + p;
                if (!bin) { bin = app.project.items.addFolder(d.bin || 'Montage'); }
                it = app.project.importFile(new ImportOptions(f));
                it.parentFolder = bin;
                have[f.fsName.toLowerCase()] = it;
            }
            out[p] = { id: it.id, w: it.width || 1920, h: it.height || 1080, fps: it.frameRate || 25, dur: it.duration, video: !!it.hasVideo };
        }
        return JSON.stringify(out);
    } catch (e) {
        return 'ERR:' + e.toString() + ' line ' + e.line;
    } finally {
        app.endUndoGroup();
    }
}

// comps built by Claude Montage are tagged in their comment; a rebuild of the same name replaces only those (3.20.0)
function montageDropComps(json) {
    app.beginUndoGroup('Welo: Montage replace');
    try {
        var d = JSON.parse(json), n = 0, i, it;
        for (i = app.project.numItems; i >= 1; i--) {
            it = app.project.item(i);
            if (it instanceof CompItem && it.name === d.name && it.comment === 'via-montage') { it.remove(); n++; }
        }
        return 'OK:' + n;
    } catch (e) { return 'ERR:' + e.toString(); } finally { app.endUndoGroup(); }
}
function montageTagComp(json) {
    try {
        var d = JSON.parse(json), i, it;
        for (i = app.project.numItems; i >= 1; i--) {
            it = app.project.item(i);
            if (it instanceof CompItem && it.name === d.name && it.comment === '') { it.comment = 'via-montage'; return 'OK'; }
        }
        return 'OK:not found';
    } catch (e) { return 'ERR:' + e.toString(); }
}
