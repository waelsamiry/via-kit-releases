﻿/**
 * Welo Preset Maker — host_wpm.jsx
 * Add this file to: com.welo.tools/jsx/
 * Then add this line at the VERY END of your existing jsx/host.jsx:
 *     //@include "host_wpm.jsx"
 *
 * All functions are prefixed wpm_ — zero conflict with existing tools.
 */

var _wpm_extPath = '';
var _wpm_args = null;
var _wpm_lastStep = 'init';

var _wpm_DEBUG = false; // set true to log to %TEMP%\welo_preset.log
var _wpm_logFile = new File(Folder.temp.fsName + '/welo_preset.log');
function wpm_step(msg) {
    _wpm_lastStep = msg;
    if (!_wpm_DEBUG) return;
    try {
        _wpm_logFile.open('a');
        _wpm_logFile.encoding = 'UTF-8';
        var d = new Date();
        _wpm_logFile.writeln(
            (d.getHours()<10?'0':'')+d.getHours()+':'+(d.getMinutes()<10?'0':'')+d.getMinutes()+':'+(d.getSeconds()<10?'0':'')+d.getSeconds()+'.'+d.getMilliseconds()+'  ' + msg
        );
        _wpm_logFile.close();
    } catch (e) {}
}

function wpm_readSmallFile(path, max) {
    try {
        var f = new File(path);
        if (!f.exists) return '(no output file)';
        max = max || 400;
        f.open('r');
        var txt = ''; 
        while (!f.eof && txt.length < max) { txt += f.readln() + ' | '; }
        f.close();
        return txt;
    } catch (e) { return '(read err)'; }
}

// Runs a shell command via a temp .bat (avoids cmd /c "quoted first token" breaks,
// wich silently swallowed ffmpeg calls with spaces in the path). Output captured.
function wpm_runOS(cmdLine, label) {
    var tDir   = Folder.temp.fsName.replace(/\//g, '\\');
    var batPath = tDir + '\\welo_run_' + label + '.bat';
    var outPath = tDir + '\\welo_run_' + label + '.txt';
    try { new File(outPath).remove(); } catch (e) {}
    try {
        var bat = new File(batPath);
        bat.encoding = 'UTF-8';
        bat.open('w');
        bat.writeln('@echo off');
        bat.writeln(cmdLine.replace(/%/g, '%%') + ' > "' + outPath + '" 2>&1');
        bat.writeln('call echo EXITCODE:%errorlevel%>> "' + outPath + '"');
        bat.close();
    } catch (e) {
        wpm_step('  RUNOS bat write failed: ' + e.toString());
    }
    system.callSystem('cmd /c ""' + batPath + '""');
    try { new File(batPath).remove(); } catch (e) {}
    return wpm_readSmallFile(outPath);
}

// Working folder for a preset job — always inside the user TEMP, never Program Files.
function wpm_workRoot(name) {
    return Folder.temp.fsName.replace(/\\/g, '/') + '/welo_pm_' + name;
}
function wpm_frameDir(name) {
    return wpm_workRoot(name) + '/frames';
}

// Copy a finished artifact (gif/png) first to temp, then into presets with fallbacks.
function wpm_writeFinal(tmpSrc, finalPath) {
    try {
        var dst = new File(finalPath);
        try { dst.parent.create(); } catch (e) {}
        var src = new File(tmpSrc);
        if (!src.exists) return false;
        var ok = false;
        try { ok = src.copy(dst.fsName); } catch (e) { ok = false; }
        if (!ok || !dst.exists) {
            wpm_step('  FINALCOPY fallback cmd copy  ' + tmpSrc + ' -> ' + finalPath + '  out=' + wpm_runOS('copy /Y "' + src.fsName.replace(/\//g, '\\') + '" "' + dst.fsName.replace(/\//g, '\\') + '"', 'finalcopy'));
        }
        if (!dst.exists) return false;
        dst.readonly = false;
        return true;
    } catch (e) { return false; }
}

function wpm_setExtensionPath(path) {
    _wpm_extPath = path.replace(/\\/g, '/').replace(/\/$/, '');
    return _wpm_extPath;
}

function wpm_getPresetsRoot() {
    return _wpm_extPath + '/presets';
}

function wpm_getPresetsRootForJS() {
    return JSON.stringify({ success: true, root: _wpm_extPath + '/presets' });
}

function wpm_fixPermissions() {
    try {
        var presetsPath = (_wpm_extPath + '/presets').replace(/\//g, '\\');
        wpm_step('  FIXPERM start: icacls ' + presetsPath);
        var out = system.callSystem('icacls "' + presetsPath + '" /grant "*S-1-5-32-545:(OI)(CI)F" /T /Q /C');
        wpm_step('  FIXPERM done  callSystemOutput=' + (out ? out.toString().substring(0, 200) : '(empty)'));
        return JSON.stringify({ success: true });
    } catch (e) {
        wpm_step('  FIXPERM error: ' + e.toString());
        return JSON.stringify({ success: false, error: e.toString() });
    }
}

function wpm_getCategoryFolder(category) {
    var cats = ['text', 'shape', 'photo', 'transition', 'effects'];
    var root = wpm_getPresetsRoot();
    for (var i = 0; i < cats.length; i++) {
        if (cats[i] === category) return root + '/' + category;
    }
    return root + '/text';
}

function wpm_ensureFolder(path) {
    var f = new Folder(path);
    if (!f.exists) f.create();
    return f.exists;
}

// ── Resolve the bundled ffmpeg.exe (ytdl folder) with fallbacks ──
function wpm_ffmpeg(pHint) {
    var cands = [];
    if (pHint) cands.push(pHint);
    cands.push(_wpm_extPath + '/ytdl/ffmpeg.exe');
    cands.push(_wpm_extPath + '/ffmpeg.exe');
    for (var c = 0; c < cands.length; c++) {
        try { if (cands[c] && new File(cands[c]).exists) return cands[c]; } catch (e) {}
    }
    return 'ffmpeg';
}

// ── Get all presets ───────────────────────────────────────
function wpm_getPresets() {
    try {
        var root = wpm_getPresetsRoot();
        wpm_ensureFolder(root);
        var cats = ['text', 'shape', 'photo', 'transition', 'effects'];
        var all  = [];
        for (var ci = 0; ci < cats.length; ci++) {
            var catPath = root + '/' + cats[ci];
            wpm_ensureFolder(catPath);
            var folder   = new Folder(catPath);
            var ffxFiles = folder.getFiles('*.ffx');
            for (var fi = 0; fi < ffxFiles.length; fi++) {
                var ffx  = ffxFiles[fi];
                var base = ffx.name.replace(/\.ffx$/i, '');
                var png  = new File(catPath + '/' + base + '.png');
                var gif  = new File(catPath + '/' + base + '.gif');
                all.push({
                    name    : base,
                    category: cats[ci],
                    file    : ffx.fsName.replace(/\\/g, '/'),
                    png     : png.exists ? png.fsName.replace(/\\/g, '/') : null,
                    gif     : gif.exists ? gif.fsName.replace(/\\/g, '/') : null
                });
            }
        }
        all.sort(function (a, b) { return a.name.localeCompare(b.name); });
        return JSON.stringify({ success: true, presets: all, root: root });
    } catch (e) {
        return JSON.stringify({ success: false, error: e.toString() });
    }
}

// ── Shape presets: keep ONLY the operators (Trim Paths, Repeater, Offset, Zig Zag…) ──
// Saving the layer as-is also saves its paths (star/rect…), so applying the preset to another
// shape adds that star/rect too. Instead we save a throw-away duplicate whose Contents holds just
// the operators, hoisted to the Contents root (a root-level Trim Paths affects every shape above it).
function wpm_copyProps(src, dst) {
    for (var i = 1; i <= src.numProperties; i++) {
        var sp = src.property(i), dp = null;
        try { dp = dst.property(i); } catch (e) {}
        if (!dp) continue;
        try {
            if (sp.propertyType === PropertyType.PROPERTY) {
                if (sp.numKeys > 0) {
                    for (var k = 1; k <= sp.numKeys; k++) {
                        try { dp.setValueAtTime(sp.keyTime(k), sp.keyValue(k)); } catch (e1) {}
                    }
                    for (var k2 = 1; k2 <= sp.numKeys; k2++) {
                        try { dp.setInterpolationTypeAtKey(k2, sp.keyInInterpolationType(k2), sp.keyOutInterpolationType(k2)); } catch (e2) {}
                        try { dp.setTemporalEaseAtKey(k2, sp.keyInTemporalEase(k2), sp.keyOutTemporalEase(k2)); } catch (e3) {}
                    }
                } else {
                    try { dp.setValue(sp.value); } catch (e4) {}
                }
                try { if (sp.expression && sp.expression !== '') dp.expression = sp.expression; } catch (e5) {}
            } else {
                wpm_copyProps(sp, dp);
            }
        } catch (e) {}
    }
}

function wpm_collectOperators(group, out) {
    for (var i = 1; i <= group.numProperties; i++) {
        var p = group.property(i), mn = '';
        try { mn = p.matchName || ''; } catch (e) {}
        if (mn.indexOf('ADBE Vector Filter') === 0) { out.push(p); continue; }
        if (mn.indexOf('ADBE Vector Shape') === 0 || mn.indexOf('ADBE Vector Graphic') === 0 || mn === 'ADBE Vector Transform Group') continue;
        try { if (p.numProperties && p.numProperties > 0) wpm_collectOperators(p, out); } catch (e) {}
    }
}

// Returns a duplicate of shapeLayer whose Contents has only the hoisted operators (or null if none).
function wpm_makeOperatorOnlyDup(shapeLayer) {
    var ops = [];
    wpm_collectOperators(shapeLayer.property('ADBE Root Vectors Group'), ops);
    if (ops.length === 0) return null;
    var dup = shapeLayer.duplicate();
    var dc = dup.property('ADBE Root Vectors Group');
    for (var r = dc.numProperties; r >= 1; r--) { try { dc.property(r).remove(); } catch (e) {} }
    for (var o = 0; o < ops.length; o++) {
        try {
            var nw = dc.addProperty(ops[o].matchName);
            wpm_copyProps(ops[o], nw);
        } catch (e) { wpm_step('  hoist op failed: ' + ops[o].matchName + ' ' + e.toString()); }
    }
    return dup;
}

function wpm_dropDup(dup) { try { if (dup) dup.remove(); } catch (e) {} }
// ── Setup Comp ────────────────────────────────────────────
function wpm__setup() {
    try {
        var args     = _wpm_args;
        var name     = args.name;
        var type     = args.type;
        var duration = args.duration || 3;
        var K = args.keep || {};
        function keepOn(k) { return K[k] !== false; }
        var finalFfxPath = args.ffxPath || (_wpm_extPath + '/presets/' + type + '/' + name + '.ffx');
        wpm_step('SETUP start  name=' + name + ' type=' + type + ' dur=' + duration);
        wpm_step('  ffxPath=' + finalFfxPath);
        wpm_step('  extPath=' + _wpm_extPath);

        if (!app.project) { wpm_step('  SETUP abort: no project'); return JSON.stringify({ success: false, error: 'No project open' }); }
        wpm_step('  [1] project ok');

        var srcComp  = app.project.activeItem;
        var selLayer = null;
        if (srcComp && srcComp instanceof CompItem) {
            for (var li = 1; li <= srcComp.numLayers; li++) {
                if (srcComp.layer(li).selected) { selLayer = srcComp.layer(li); break; }
            }
        }
        if (!selLayer) { wpm_step('  SETUP abort: no selected layer'); return JSON.stringify({ success: false, error: 'No layer selected' }); }
        wpm_step('  [2] layer selected: ' + selLayer.name + '  activeItem=' + (srcComp ? srcComp.name : 'NONE'));

        var catFolder    = finalFfxPath.substring(0, finalFfxPath.lastIndexOf('/'));
        var catF = new Folder(catFolder);
        if (!catF.exists) catF.create();
        wpm_step('  [3] category folder ensured  exists=' + catF.exists + '  fsName=' + catF.fsName);

        wpm_step('  [4] before icacls...');
        wpm_fixPermissions();
        wpm_step('  [4] icacls done');

        var tmpPath = Folder.temp.fsName + '/wpm_preset.ffx';
        var tmpFile = new File(tmpPath);
        if (tmpFile.exists) tmpFile.remove();

        // ── Deselect everything first ──
        function wpm_deselectAll(propGroup) {
            for (var pi = 1; pi <= propGroup.numProperties; pi++) {
                var prop = propGroup.property(pi);
                try { prop.selected = false; } catch (e) {}
                try { if (prop.numProperties) wpm_deselectAll(prop); } catch (e) {}
            }
        }

        // ── Recursively select ALL animatable properties ──
        // Skip shape GEOMETRY ("ADBE Vector Shape - *") so the saved preset only
        // carries Trim Paths / Stroke / Fill / Transform. Applying it then animates
        // whatever shape it's dropped onto instead of importing an extra star/rect.
        var _wpm_skippedShapes = 0;
        function wpm_selectAnimated(propGroup) {
            for (var pi = 1; pi <= propGroup.numProperties; pi++) {
                var prop = propGroup.property(pi);
                var mn = '';
                try { mn = prop.matchName || ''; } catch (e) {}
                if (mn === 'ADBE Transform Group') continue; /* handled explicitly below (per-property choices) */
                if (mn === 'ADBE Effect Parade' || mn === 'ADBE Mask Parade' || mn === 'ADBE Text Properties') continue; /* handled below */
                if (mn === 'ADBE Root Vectors Group') {
                    if (keepOn('ops')) { for (var ri = 1; ri <= prop.numProperties; ri++) { try { var rp = prop.property(ri); if ((rp.matchName || '').indexOf('ADBE Vector Filter') === 0) rp.selected = true; } catch (e) {} } }
                    continue;
                }
                if (mn.indexOf('ADBE Vector Filter') === 0) { if (keepOn('ops')) { try { prop.selected = true; } catch (e) {} } continue; }
                if (mn.indexOf('ADBE Vector Shape') === 0) {
                    _wpm_skippedShapes++;
                    continue;
                }
                // Select properties that have keyframes
                try { if (prop.numKeys !== undefined && prop.numKeys > 0) prop.selected = true; } catch (e) {}
                // Select properties that have expressions
                try { if (prop.expression && prop.expression !== '') prop.selected = true; } catch (e) {}
                // Select properties whose value differs from default (modified statics)
                try {
                    if (prop.isModified) prop.selected = true;
                } catch (e) {}
                // Recurse into sub-groups
                try { if (prop.numProperties && prop.numProperties > 0) wpm_selectAnimated(prop); } catch (e) {}
            }
        }

        // Shape layers: save an operators-only duplicate so no star/rect geometry travels with the preset
        var saveLayer = selLayer, dupLayer = null;
        try { if (selLayer instanceof ShapeLayer && keepOn('ops')) { dupLayer = wpm_makeOperatorOnlyDup(selLayer); if (dupLayer) saveLayer = dupLayer; } } catch (dupErr) { wpm_step('  dup failed: ' + dupErr.toString()); dupLayer = null; saveLayer = selLayer; }
        wpm_deselectAll(saveLayer);
        wpm_selectAnimated(saveLayer);

        // ── Explicitly select Transform properties if any are animated ──
        var xform = null;
        try { xform = saveLayer.property('ADBE Transform Group'); } catch (e) {}
        if (xform) {
            var xKeep = { 'ADBE Anchor Point': keepOn('anchor'), 'ADBE Position': keepOn('pos'), 'ADBE Position_0': keepOn('pos'), 'ADBE Position_1': keepOn('pos'), 'ADBE Scale': keepOn('scale'), 'ADBE Rotate Z': keepOn('rot'), 'ADBE Rotate X': keepOn('rot'), 'ADBE Rotate Y': keepOn('rot'), 'ADBE Opacity': keepOn('opacity') };
            var xformNames = ['ADBE Anchor Point', 'ADBE Position', 'ADBE Scale',
                              'ADBE Rotate Z', 'ADBE Rotate X', 'ADBE Rotate Y',
                              'ADBE Opacity', 'ADBE Position_0', 'ADBE Position_1'];
            for (var xi = 0; xi < xformNames.length; xi++) {
                if (!xKeep[xformNames[xi]]) continue;
                try {
                    var xp = xform.property(xformNames[xi]);
                    if (xp && (xp.numKeys > 0 || xp.isModified || (xp.expression && xp.expression !== ''))) {
                        xp.selected = true;
                    }
                } catch (e) {}
            }
        }
        wpm_step('  [5] selection pass done  skippedShapeGeo=' + _wpm_skippedShapes);

        // ── Select ALL effects and their sub-properties ──
        var fx = null;
        try { fx = saveLayer.property('ADBE Effect Parade'); } catch (e) {}
        if (keepOn('fx') && fx && fx.numProperties > 0) {
            for (var ei = 1; ei <= fx.numProperties; ei++) {
                try { fx.property(ei).selected = true; } catch (e) {}
                // Also select individual effect properties (keyframes, etc.)
                try {
                    var effect = fx.property(ei);
                    for (var epi = 1; epi <= effect.numProperties; epi++) {
                        try { effect.property(epi).selected = true; } catch (e) {}
                    }
                } catch (e) {}
            }
        }

        // ── Select Text Animators ──
        if (keepOn('text')) { try { saveLayer.property('ADBE Text Properties').property('ADBE Text Animators').selected = true; } catch (e) {} }
        // Also select individual animators
        try {
            var animators = keepOn('text') ? saveLayer.property('ADBE Text Properties').property('ADBE Text Animators') : { numProperties: 0 };
            for (var ai = 1; ai <= animators.numProperties; ai++) {
                try { animators.property(ai).selected = true; } catch (e) {}
            }
        } catch (e) {}

        // ── Select Masks if any ──
        try {
            var masks = saveLayer.property('ADBE Mask Parade');
            if (keepOn('masks') && masks && masks.numProperties > 0) {
                for (var mi = 1; mi <= masks.numProperties; mi++) {
                    try { masks.property(mi).selected = true; } catch (e) {}
                }
            }
        } catch (e) {}

        try {
            saveLayer.savePreset(tmpFile);
        } catch (saveErr) {
            wpm_dropDup(dupLayer);
            wpm_step('  [7] savePreset THREW: ' + saveErr.toString());
            return JSON.stringify({ success: false, error: 'savePreset error: ' + saveErr.toString() });
        }
        wpm_dropDup(dupLayer);
        wpm_step('  [7] savePreset returned');
        if (!tmpFile.exists) {
            wpm_step('  [7] tmp FFX missing');
            return JSON.stringify({ success: false, error: 'FFX not created — layer needs keyframes, text animators, or effects' });
        }
        wpm_step('  [7] tmp FFX exists  size=' + tmpFile.length);

        var ffxFile = new File(finalFfxPath);
        var dstParent = ffxFile.parent;
        wpm_step('  [8] dst=' + ffxFile.fsName + '  dstParentExists=' + dstParent.exists + '  dstParentFS=' + dstParent.fsName + '  tmpExists=' + tmpFile.exists + '  tmp=' + tmpFile.fsName);

        // Try 1: ExtendScript File.copy
        var cp1 = false;
        try { cp1 = tmpFile.copy(ffxFile.fsName); } catch (e) { wpm_step('  [8] copy1 threw: ' + e.toString()); }
        wpm_step('  [8] copy1 File.copy returned=' + cp1 + '  exists=' + ffxFile.exists);

        // Try 2: cmd copy /Y with full output + exit code
        if (!ffxFile.exists) {
            var cDst = ffxFile.fsName.replace(/\//g, '\\');
            var cSrc = tmpFile.fsName.replace(/\//g, '\\');
            wpm_step('  [8] copy2 out=' + wpm_runOS('copy /Y "' + cSrc + '" "' + cDst + '"', 'copy2'));
            wpm_step('  [8] copy2 cmd copy  exists=' + ffxFile.exists);
        }

        // Try 3: PowerShell Copy-Item via .ps1 file (zero quote issues)
        if (!ffxFile.exists) {
            var ps1Path = Folder.temp.fsName + '\\welo_copy.ps1';
            var ps1Src  = tmpFile.fsName.replace(/\//g, '\\');
            var ps1Dst  = ffxFile.fsName.replace(/\//g, '\\');
            var ps1File = new File(ps1Path);
            ps1File.encoding = 'UTF-8';
            ps1File.open('w');
            ps1File.write('$ErrorActionPreference="Stop"; Copy-Item -LiteralPath "' + ps1Src + '" -Destination "' + ps1Dst + '" -Force; Write-Output OK');
            ps1File.close();
            wpm_step('  [8] copy3 out=' + wpm_runOS('powershell -NoProfile -ExecutionPolicy Bypass -File "' + ps1Path + '"', 'copy3'));
            try { ps1File.remove(); } catch(e) {}
            wpm_step('  [8] copy3 powershell  exists=' + ffxFile.exists);
        }

        tmpFile.remove();

        if (!ffxFile.exists) {
            return JSON.stringify({ success: false, error: 'Cannot write FFX to: ' + finalFfxPath + ' — try running AE as Admin' });
        }
        wpm_step('  [9] FFX written to disk: ' + ffxFile.fsName);

        for (var ci = app.project.items.length; ci >= 1; ci--) {
            var chk = app.project.items[ci];
            if (chk instanceof CompItem && chk.name === 'WP_temp_render') { chk.remove(); break; }
        }

        var tempComp = app.project.items.addComp('WP_temp_render', 1280, 720, 1, duration, 30);
        tempComp.bgColor = [0, 0, 0];
        wpm_step('  [10] temp comp added: ' + tempComp.name);

        var targetLayer = null;
        if (type === 'shape') {
            var sl   = tempComp.layers.addShape();
            sl.name  = 'Shape Preview';
            var cont = sl.property('Contents');
            var grp  = cont.addProperty('ADBE Vector Group');
            var rc   = grp.property('Contents').addProperty('ADBE Vector Shape - Rect');
            rc.property('Size').setValue([300, 300]);
            var fl  = grp.property('Contents').addProperty('ADBE Vector Graphic - Fill');
            fl.property('Color').setValue([1, 1, 1]);
            var stk  = grp.property('Contents').addProperty('ADBE Vector Graphic - Stroke');
            stk.property('Color').setValue([1, 1, 1]);
            stk.property('Stroke Width').setValue(4);
            sl.property('Position').setValue([640, 360]);
            sl.property('Anchor Point').setValue([0, 0]);
            targetLayer = sl;
        } else {
            var tl = tempComp.layers.addText();
            var td = tl.sourceText.value;
            td.text          = 'Preview Text';
            td.fontSize      = 95;
            td.fillColor     = [1, 1, 1];
            td.font          = 'ArialMT';
            td.justification = ParagraphJustification.CENTER_JUSTIFY;
            tl.sourceText.setValue(td);
            tl.property('Position').setValue([640, 360]);
            tl.property('Anchor Point').setValue([0, 0]);
            targetLayer = tl;
        }
        wpm_step('  [11] preview layer created: ' + (targetLayer ? targetLayer.name : 'NONE'));

        for (var di = 1; di <= tempComp.numLayers; di++) { tempComp.layer(di).selected = false; }
        targetLayer.selected = true;
        targetLayer.applyPreset(ffxFile);
        wpm_step('  [12] ffx applied to preview layer');

        var midTime = Math.round((duration / 2) * 30) / 30;
        var mkv     = new MarkerValue('thumbnail');
        mkv.comment = 'THUMBNAIL — move to best frame';
        tempComp.markerProperty.setValueAtTime(midTime, mkv);

        var guide = tempComp.layers.addText(
            '\u2605  Move the marker to pick thumbnail frame  \u2605\n   Tweak animation  |  Then press  Create Preset'
        );
        guide.name       = '[ Guide — not rendered ]';
        guide.guideLayer = true;
        var gd = guide.sourceText.value;
        gd.fontSize      = 16;
        gd.fillColor     = [1, 0.75, 0];
        gd.justification = ParagraphJustification.CENTER_JUSTIFY;
        guide.sourceText.setValue(gd);
        guide.property('Position').setValue([640, 680]);

        tempComp.openInViewer();
        wpm_step('  [15] openInViewer done');
        var resPkg = { success: true, ffxPath: ffxFile.fsName, midTime: midTime, type: type };
        wpm_step('  SETUP OK, returning ' + JSON.stringify(resPkg));
        return JSON.stringify(resPkg);

    } catch (e) {
        wpm_step('  SETUP EXCEPTION after step [' + _wpm_lastStep + ']: ' + e.toString() + '  line=' + (e.line ? e.line : '?'));
        return JSON.stringify({ success: false, error: e.toString() + '  (step ' + _wpm_lastStep + ')' });
    }
}

// ── Render to PNG sequence (via AVI + ffmpeg fallback) ────
function wpm__renderToPngSequence() {
    try {
        var args       = _wpm_args;
        var workRoot   = wpm_workRoot(args.name);
        var seqFolder  = wpm_frameDir(args.name);
        var ffmpegPath = wpm_ffmpeg(args.ffmpegPath || (args.catPath + '/../ffmpeg.exe'));
        wpm_step('  RENDER start  work=' + workRoot + '  frames=' + seqFolder);

        if (!app.project) return JSON.stringify({ success: false, error: 'No project' });

        var tempComp = null;
        for (var i = 1; i <= app.project.items.length; i++) {
            if (app.project.items[i] instanceof CompItem &&
                app.project.items[i].name === 'WP_temp_render') {
                tempComp = app.project.items[i]; break;
            }
        }
        if (!tempComp) return JSON.stringify({ success: false, error: 'WP_temp_render not found — run Setup first' });

        var outFolder = new Folder(seqFolder);
        if (!outFolder.exists) outFolder.create();
        wpm_step('  RENDER: frame dir exists=' + outFolder.exists);
        wpm_fixPermissions();

        // ── prepare render queue: keep user jobs, render only ours ──
        var rq = app.project.renderQueue;
        for (var ri = rq.items.length; ri >= 1; ri--) {
            var s = rq.items[ri].status;
            if (s === RQItemStatus.DONE || s === RQItemStatus.ERR_STOPPED) {
                rq.items[ri].remove();
            }
        }
        var rqItem = rq.items.add(tempComp);
        rqItem.render = true;
        try { rqItem.applyTemplate('Best Settings'); } catch (e) {}
        for (var rqi = 1; rqi <= rq.items.length; rqi++) {
            var qi = rq.items[rqi];
            try { if (qi.comp && qi.comp.name !== tempComp.name) qi.render = false; } catch (e2) {}
        }
        rqItem.render = true;

        var om = rqItem.outputModules[1];

        // ── Strategy 1: PNG Sequence (template, then manual format) ──
        var usedVideo = false;
        var tempVideoPath = seqFolder + '/../_wpm_temp_render.avi';
        var pngOK = false;
        var pngErr = '';
        try {
            om.applyTemplate('PNG Sequence');
            pngOK = true;
        } catch (e1) {
            pngErr = e1.toString();
            try {
                var st1 = om.getSettings(GetSettingsFormat.STRING_SETTABLE);
                st1['Format'] = 'PNG Sequence';
                om.setSettings(st1);
                pngOK = true;
            } catch (e4) {
                pngErr += ' / manual: ' + e4.toString();
            }
        }
        if (pngOK) {
            var seqFile = new File(seqFolder + '/frame_[####].png');
            om.file = seqFile;
            wpm_step('  RENDER: using PNG Sequence output');
        } else {
            // ── Strategy 2: render as Lossless AVI, then ffmpeg → PNG ──
            usedVideo = true;
            wpm_step('  RENDER: PNG Sequence unavailable (' + pngErr + '), using AVI fallback');
            try { om.applyTemplate('Lossless'); } catch (e2) {
                try { om.applyTemplate('Lossless with Alpha'); } catch (e3) {
                    // last resort: set AVI format manually
                    var stA = om.getSettings(GetSettingsFormat.STRING_SETTABLE);
                    stA['Format'] = 'AVI';
                    om.setSettings(stA);
                }
            }
            var aviFile = new File(tempVideoPath);
            om.file = aviFile;
        }

        if (!om.file) return JSON.stringify({ success: false, error: 'Could not set output path' });

        // ── render ──
        try { rq.render(); } catch (renderErr) {
            return JSON.stringify({ success: false, error: 'rq.render() failed: ' + renderErr.toString() });
        }

        // ── if we rendered video, convert to PNG sequence via ffmpeg ──
        if (usedVideo) {
            var videoFile = new File(tempVideoPath);
            if (!videoFile.exists) {
                return JSON.stringify({ success: false, error: 'Video render produced no file' });
            }
            var ff = new File(ffmpegPath);
            var ffCmd = ff.exists ? ffmpegPath : 'ffmpeg';
            var cmd = '"' + ffCmd + '" -y -i "' + tempVideoPath + '" "' + seqFolder + '/frame_%04d.png"';
            wpm_step('  RENDER avi2png out=' + wpm_runOS(cmd, 'avi2png'));
            // cleanup temp video only if frames were produced
            var pngs = new Folder(seqFolder).getFiles('*.png');
            if (pngs && pngs.length > 0) {
                try { videoFile.remove(); } catch (e) {}
            }
        }

        var files = outFolder.getFiles('*.png');
        wpm_step('  RENDER done  pngCount=' + (files ? files.length : 0));
        if (!files || files.length === 0) {
            return JSON.stringify({ success: false, error: 'No PNG frames after render. Check output path: ' + seqFolder });
        }

        return JSON.stringify({ success: true, seqFolder: seqFolder, frameCount: files.length, fps: tempComp.frameRate });

    } catch (e) {
        return JSON.stringify({ success: false, error: e.toString() });
    }
}

// ── Get marker time ───────────────────────────────────────
function wpm_getMarkerTime() {
    try {
        var tempComp = null;
        for (var i = 1; i <= app.project.items.length; i++) {
            if (app.project.items[i] instanceof CompItem && app.project.items[i].name === 'WP_temp_render') {
                tempComp = app.project.items[i]; break;
            }
        }
        if (!tempComp) return JSON.stringify({ success: false, error: 'Comp not found' });
        var markers = tempComp.markerProperty;
        if (markers.numKeys === 0) return JSON.stringify({ success: false, error: 'No markers' });
        var t = markers.keyTime(markers.numKeys);
        return JSON.stringify({ success: true, time: t });
    } catch (e) {
        return JSON.stringify({ success: false, error: e.toString() });
    }
}

// ── Convert PNG sequence → GIF via ffmpeg ────────────────
// ── Extract thumbnail PNG at marker ──────────────────────
function wpm_extractPng() {
    try {
        var args      = _wpm_args;
        var workRoot  = wpm_workRoot(args.name);
        var seqFolder = wpm_frameDir(args.name);
        var pngPath   = args.pngPath;
        var fps       = args.fps || 30;
        var markerRes = null;
        try {
            var mComp = null;
            for (var mi2 = 1; mi2 <= app.project.items.length; mi2++) {
                if (app.project.items[mi2] instanceof CompItem && app.project.items[mi2].name === 'WP_temp_render') { mComp = app.project.items[mi2]; break; }
            }
            if (mComp && mComp.markerProperty.numKeys > 0) markerRes = { success: true, time: mComp.markerProperty.keyTime(mComp.markerProperty.numKeys) };
        } catch (e) {}
        var thumbTime = (markerRes && markerRes.success) ? markerRes.time : 1.5;
        var frameNum  = Math.round(thumbTime * fps);
        var srcFile   = null;
        var frameNames = ['frame_' + ('000' + frameNum).slice(-4) + '.png',
                          'frame_' + ('000' + (frameNum + 1)).slice(-4) + '.png',
                          'frame_' + ('000' + (frameNum - 1)).slice(-4) + '.png'];
        for (var fnc = 0; fnc < frameNames.length; fnc++) {
            var candF = new File(seqFolder + '/' + frameNames[fnc]);
            if (candF.exists) { srcFile = candF; break; }
        }

        if (!srcFile) {
            var files = new Folder(seqFolder).getFiles('*.png');
            if (files && files.length > 0) srcFile = files[Math.floor(files.length / 2)];
        }
        if (!srcFile || !srcFile.exists) {
            return JSON.stringify({ success: false, error: 'Thumbnail frame not found in ' + seqFolder });
        }

        var tempPng = workRoot + '/thumb_' + args.name + '.png';
        var tPngFile = new File(tempPng);
        if (tPngFile.exists) tPngFile.remove();
        srcFile.copy(tPngFile.fsName);
        if (!tPngFile.exists) return JSON.stringify({ success: false, error: 'Could not stage thumbnail' });

        var ok = wpm_writeFinal(tempPng, pngPath);
        wpm_step('  THUMB final copy=' + ok + '  -> ' + pngPath);
        if (!ok) return JSON.stringify({ success: false, error: 'Cannot write PNG into presets: ' + pngPath });

        return JSON.stringify({ success: true, pngPath: pngPath, frame: frameNum });

    } catch (e) {
        return JSON.stringify({ success: false, error: e.toString() });
    }
}

// ── Cleanup temp files + comp ─────────────────────────────
function wpm__cleanup() {
    try {
        var args      = _wpm_args;
        var workRoot  = wpm_workRoot(args.name);

        var folder = new Folder(workRoot);
        if (folder.exists) {
            var files = folder.getFiles();
            for (var fi = 0; fi < files.length; fi++) {
                try { files[fi].remove(); } catch (e) {}
            }
            folder.remove();
        }

        try {
            var palFile = new File(args.catPath + '/' + args.name + '_pal.png');
            if (palFile.exists) palFile.remove();
        } catch (e) {}

        for (var i = app.project.items.length; i >= 1; i--) {
            var item = app.project.items[i];
            if (item instanceof CompItem && item.name === 'WP_temp_render') {
                item.remove(); break;
            }
        }

        return JSON.stringify({ success: true });
    } catch (e) {
        return JSON.stringify({ success: false, error: e.toString() });
    }
}

// ── Apply preset to selected layer ───────────────────────
function wpm__applyPreset() {
    try {
        var args = _wpm_args;
        if (!app.project) return JSON.stringify({ success: false, error: 'No project' });
        var comp = app.project.activeItem;
        if (!comp || !(comp instanceof CompItem)) return JSON.stringify({ success: false, error: 'No active comp' });

        var selLayer = null;
        for (var i = 1; i <= comp.numLayers; i++) {
            if (comp.layer(i).selected) { selLayer = comp.layer(i); break; }
        }
        if (!selLayer) return JSON.stringify({ success: false, error: 'No layer selected' });

        var ffxFile = new File(args.file);
        if (!ffxFile.exists) return JSON.stringify({ success: false, error: 'FFX not found: ' + args.file });

        selLayer.applyPreset(ffxFile);
        return JSON.stringify({ success: true, layer: selLayer.name });

    } catch (e) {
        return JSON.stringify({ success: false, error: e.toString() });
    }
}

// ── Delete preset files ───────────────────────────────────
function wpm_deletePreset() {
    try {
        var args     = _wpm_args;
        var folder   = wpm_getCategoryFolder(args.category);
        var deleted  = [];
        var exts     = ['.ffx', '.gif', '.png', '.mp4'];
        for (var i = 0; i < exts.length; i++) {
            var f = new File(folder + '/' + args.name + exts[i]);
            if (f.exists) { f.remove(); deleted.push(args.name + exts[i]); }
        }
        // Also remove _seq folder if left over
        var seqFolder = new Folder(folder + '/' + args.name + '_seq');
        if (seqFolder.exists) {
            var files = seqFolder.getFiles();
            for (var fi = 0; fi < files.length; fi++) { try { files[fi].remove(); } catch(e) {} }
            seqFolder.remove();
            deleted.push(args.name + '_seq/');
        }
        return JSON.stringify({ success: true, deleted: deleted, folder: folder });
    } catch (e) {
        return JSON.stringify({ success: false, error: e.toString() });
    }
}

// ── Undo-group wrappers (every AE-modifying entry point is one undo step) ──
function wpm_setup() {
    app.beginUndoGroup('Preset Maker: setup');
    try { return wpm__setup(); }
    catch (e) { return JSON.stringify({ success: false, error: e.toString() }); }
    finally { app.endUndoGroup(); }
}
function wpm_renderToPngSequence() {
    app.beginUndoGroup('Preset Maker: renderToPngSequence');
    try { return wpm__renderToPngSequence(); }
    catch (e) { return JSON.stringify({ success: false, error: e.toString() }); }
    finally { app.endUndoGroup(); }
}
function wpm_cleanup() {
    app.beginUndoGroup('Preset Maker: cleanup');
    try { return wpm__cleanup(); }
    catch (e) { return JSON.stringify({ success: false, error: e.toString() }); }
    finally { app.endUndoGroup(); }
}
function wpm_applyPreset() {
    app.beginUndoGroup('Preset Maker: applyPreset');
    try { return wpm__applyPreset(); }
    catch (e) { return JSON.stringify({ success: false, error: e.toString() }); }
    finally { app.endUndoGroup(); }
}
