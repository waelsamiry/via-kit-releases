// ── SMART CROP (ExtendScript, ES3) · 3.18.0 ───────────────────────────────────
// Precompose the selected layers (or take a selected precomp layer) and crop the precomp to the area its
// content really covers, without anything moving on screen. Panel side: tab-smartcrop in index.html.
// Exact bounds: a temporary probe null gets 4 Point Controls per layer whose expressions return
// toComp() of the layer's sourceRectAtTime corners → scale, rotation, parents and animation all count.
// Returns "OK:..." or "ERR:...".

// does a shape group draw anything? (an enabled Fill / Stroke / Gradient that isn't fixed at 0 opacity / 0 width)
// Empty shapes used as controllers / parents only have paths → they must not count.
function sc__shapeDraws(g) {
    for (var i = 1; i <= g.numProperties; i++) {
        var p = g.property(i);
        try { if (!p.enabled) continue; } catch (e0) {}
        var mn = p.matchName;
        if (/^ADBE Vector Graphic - (Fill|Stroke|G-Fill|G-Stroke)$/.test(mn)) {
            var op = null, wd = null;
            try { op = p.property(mn === 'ADBE Vector Graphic - Fill' ? 'ADBE Vector Fill Opacity' : mn === 'ADBE Vector Graphic - Stroke' ? 'ADBE Vector Stroke Opacity' : 'ADBE Vector Grad Opacity'); } catch (e1) {}
            try { if (/Stroke/.test(mn)) wd = p.property('ADBE Vector Stroke Width'); } catch (e2) {}
            if (op && op.numKeys === 0 && !op.expressionEnabled && op.value <= 0) continue;
            if (wd && wd.numKeys === 0 && !wd.expressionEnabled && wd.value <= 0) continue;
            return true;
        }
        if (p.propertyType !== PropertyType.PROPERTY && p.numProperties && sc__shapeDraws(p)) return true;
    }
    return false;
}
function sc__eligible(L) {
    if (!L.enabled || L.guideLayer || L.adjustmentLayer || L.nullLayer) return false;
    if (L instanceof CameraLayer || L instanceof LightLayer) return false;
    if (L.isTrackMatte || !L.hasVideo) return false;            // a matte only cuts the layer below; its own pixels are hidden
    if (L instanceof ShapeLayer) { try { if (!sc__shapeDraws(L.property('ADBE Root Vectors Group'))) return false; } catch (e) {} }
    return true;
}
function sc__sub(v, d) { var o = []; for (var i = 0; i < v.length; i++) o.push(v[i] - (i < d.length ? d[i] : 0)); return o; }
function sc__dvec(len, dx, dy) { return len === 3 ? [dx, dy, 0] : [dx, dy]; }

// shift a Position / Anchor value (all keys) by d; expressions that ignore `value` get the offset appended
function sc__shiftProp(p, d) {
    var i, v;
    if (p.numKeys > 0) {
        for (i = 1; i <= p.numKeys; i++) { v = p.keyValue(i); p.setValueAtKey(i, (v instanceof Array) ? sc__sub(v, d) : v - d[0]); }
    } else {
        v = p.value; p.setValue((v instanceof Array) ? sc__sub(v, d) : v - d[0]);
    }
    if (p.expressionEnabled && p.expression && !/\bvalue\b/.test(p.expression)) {
        var dd = (p.value instanceof Array) ? sc__dvec(p.value.length, d[0], d[1] || 0) : [d[0]];
        p.expression = 'var __scD = [' + dd.join(',') + '];\nvar __scV = eval(' + JSON.stringify(p.expression) + ');\n' +
                       ((p.value instanceof Array) ? '__scV - __scD' : '__scV - __scD[0]');
    }
}
function sc__shiftPosition(L, dx, dy) {
    var tg = L.property('ADBE Transform Group'), pos = tg.property('ADBE Position');
    if (pos.dimensionsSeparated) {
        sc__shiftProp(tg.property('ADBE Position_0'), [dx]);
        sc__shiftProp(tg.property('ADBE Position_1'), [dy]);
    } else {
        sc__shiftProp(pos, sc__dvec(pos.value.length, dx, dy));
    }
}

// masks of one layer → which ones limit what is visible: union of Add masks (not inverted) ∩ Intersect masks.
// Inverted Add / Lighten / Darken / Difference = no limit from Add masks (we stay conservative); Subtract only removes.
function sc__maskPlan(L) {
    var add = [], inter = [], limit = true, ms = L.property('ADBE Mask Parade');
    if (!ms) return { add: add, inter: inter };
    for (var i = 1; i <= ms.numProperties; i++) {
        var m = ms.property(i), md = m.maskMode, inv = m.inverted;
        if (md === MaskMode.NONE || md === MaskMode.SUBTRACT) continue;
        if (md === MaskMode.ADD) { if (inv) limit = false; else add.push(i); }
        else if (md === MaskMode.INTERSECT) { if (!inv) inter.push(i); }
        else limit = false;
    }
    if (!limit) add = [];
    return { add: add, inter: inter };
}
// expression: corner c (0..3) of the layer's VISIBLE box (source rect ∩ its masks, incl. expansion + feather/2) in comp space
function sc__cornerExpr(k, plan, extents, c) {
    var X = ['x0', 'x1', 'x0', 'x1'], Y = ['y0', 'y0', 'y1', 'y1'], i, s;
    s = 'function pb(m){var P=m.maskPath,p=P.points(),a=P.inTangents(),b=P.outTangents(),' +
        'e=m.maskExpansion+Math.max(m.maskFeather[0],m.maskFeather[1])/2,q=[1e9,1e9,-1e9,-1e9];' +
        'for(var i=0;i<p.length;i++){var xs=[p[i][0],p[i][0]+a[i][0],p[i][0]+b[i][0]],ys=[p[i][1],p[i][1]+a[i][1],p[i][1]+b[i][1]];' +
        'for(var j=0;j<3;j++){q[0]=Math.min(q[0],xs[j]);q[1]=Math.min(q[1],ys[j]);q[2]=Math.max(q[2],xs[j]);q[3]=Math.max(q[3],ys[j]);}}' +
        'return [q[0]-e,q[1]-e,q[2]+e,q[3]+e];}\n' +
        'try { var L = thisComp.layer(' + k + '); var r = L.sourceRectAtTime(time, ' + (extents ? 'true' : 'false') + ');' +
        ' var x0 = r.left, y0 = r.top, x1 = r.left + r.width, y1 = r.top + r.height, b;';
    if (plan.add.length) {
        s += ' var u = [1e9, 1e9, -1e9, -1e9];';
        for (i = 0; i < plan.add.length; i++)
            s += ' b = pb(L.mask(' + plan.add[i] + ')); u = [Math.min(u[0], b[0]), Math.min(u[1], b[1]), Math.max(u[2], b[2]), Math.max(u[3], b[3])];';
        s += ' x0 = Math.max(x0, u[0]); y0 = Math.max(y0, u[1]); x1 = Math.min(x1, u[2]); y1 = Math.min(y1, u[3]);';
    }
    for (i = 0; i < plan.inter.length; i++)
        s += ' b = pb(L.mask(' + plan.inter[i] + ')); x0 = Math.max(x0, b[0]); y0 = Math.max(y0, b[1]); x1 = Math.min(x1, b[2]); y1 = Math.min(y1, b[3]);';
    s += ' var out = [-987654, -987654]; if (x1 > x0 && y1 > y0) { var q = L.toComp([' + X[c] + ', ' + Y[c] + ']); out = [q[0], q[1]]; } out; }' +
         ' catch (e) { [-987654, -987654]; }';
    return s;
}
// matte of a layer (AE 2023+: trackMatteLayer; older: the layer above). null = no matte or inverted (no limit)
function sc__matteOf(comp, L) {
    var t = L.trackMatteType;
    try { if (L.hasTrackMatte === false) return null; } catch (eh) {}
    if (t === TrackMatteType.NO_TRACK_MATTE || t === TrackMatteType.ALPHA_INVERTED || t === TrackMatteType.LUMA_INVERTED) return null;
    try { if (L.trackMatteLayer) return L.trackMatteLayer; } catch (e) {}
    return L.index > 1 ? comp.layer(L.index - 1) : null;
}
// union of what is really SEEN in `comp` between t0 and t1: masks, track mattes and opacity 0 all count
function sc__bounds(comp, t0, t1, extents) {
    var i, k, c, list = [], need = {}, L, M;
    for (i = 1; i <= comp.numLayers; i++) {
        L = comp.layer(i);
        if (!sc__eligible(L)) continue;
        M = sc__matteOf(comp, L);
        list.push({ i: i, m: M ? M.index : 0 });
        need[i] = 1; if (M) need[M.index] = 1;
    }
    if (!list.length) return null;
    var N = comp.layers.addNull();                              // goes on top: every other index +1
    N.name = '__smartcrop_probe';
    var fx = N.property('ADBE Effect Parade'), slot = {}, n = 0;
    for (i = 1; i <= comp.numLayers; i++) {
        if (!need[i - 1] || i === 1) continue;                  // i = index with the null on top → original index i-1
        var plan = sc__maskPlan(comp.layer(i));
        slot[i - 1] = n;
        for (c = 0; c < 4; c++) { fx.addProperty('ADBE Point Control').property(1).expression = sc__cornerExpr(i, plan, extents, c); n++; }
    }
    var fr = comp.frameDuration, cnt = Math.max(1, Math.floor((t1 - t0) / fr) + 1), step = Math.max(1, Math.ceil(cnt / 240));
    var times = [];
    for (i = 0; i < cnt; i += step) times.push(t0 + i * fr);
    times.push(Math.max(t0, t1 - fr * 0.5));
    var b = { x0: 1e9, y0: 1e9, x1: -1e9, y1: -1e9 }, any = false;
    function box(origIdx, t) {                                    // comp-space box of one layer at t, or null if nothing visible
        var Ly = comp.layer(origIdx + 1);
        if (!Ly.activeAtTime(t)) return null;
        var q = { x0: 1e9, y0: 1e9, x1: -1e9, y1: -1e9 }, ok = false, s0 = slot[origIdx];
        for (var cc = 0; cc < 4; cc++) {
            var v = N.property('ADBE Effect Parade').property(s0 + cc + 1).property(1).valueAtTime(t, false);
            if (v[0] === -987654) continue;
            ok = true;
            if (v[0] < q.x0) q.x0 = v[0]; if (v[0] > q.x1) q.x1 = v[0];
            if (v[1] < q.y0) q.y0 = v[1]; if (v[1] > q.y1) q.y1 = v[1];
        }
        return ok ? q : null;
    }
    try {
        for (var ti = 0; ti < times.length; ti++) {
            var t = times[ti];
            for (k = 0; k < list.length; k++) {
                L = comp.layer(list[k].i + 1);
                try { if (L.property('ADBE Transform Group').property('ADBE Opacity').valueAtTime(t, false) <= 0) continue; } catch (eo) {}
                var q = box(list[k].i, t);
                if (!q) continue;
                if (list[k].m) {                                      // seen only where its matte is
                    var mq = box(list[k].m, t);
                    if (!mq) continue;
                    q = { x0: Math.max(q.x0, mq.x0), y0: Math.max(q.y0, mq.y0), x1: Math.min(q.x1, mq.x1), y1: Math.min(q.y1, mq.y1) };
                    if (q.x1 <= q.x0 || q.y1 <= q.y0) continue;
                }
                if (!any) { b.ref = { li: list[k].i, c: 0, t: t }; b.who = {}; }
                any = true;
                var nm = L.name;
                if (q.x0 < b.x0) { b.x0 = q.x0; b.who.left = nm; } if (q.x1 > b.x1) { b.x1 = q.x1; b.who.right = nm; }
                if (q.y0 < b.y0) { b.y0 = q.y0; b.who.top = nm; } if (q.y1 > b.y1) { b.y1 = q.y1; b.who.bottom = nm; }
            }
        }
    } finally { try { N.remove(); } catch (e2) {} }           // never leave the probe behind
    return any ? b : null;
}

// evaluate one point expression in `comp` at time t (temporary null; `@L` = index of layer obj after the null is added)
function sc__probe(comp, layerObj, exprBody, t) {
    var N = comp.layers.addNull(), v = null;
    try {
        N.name = '__smartcrop_probe';
        var p = N.property('ADBE Effect Parade').addProperty('ADBE Point Control').property(1);
        p.expression = 'try { var L = thisComp.layer(' + layerObj.index + '); ' + exprBody + ' } catch (e) { [-987654, -987654]; }';
        v = N.property('ADBE Effect Parade').property(1).property(1).valueAtTime(t, false);
        if (v[0] === -987654) v = null;
    } finally { try { N.remove(); } catch (e2) {} }
    return v;
}
var SC_CX = ['r.left', 'r.left+r.width', 'r.left', 'r.left+r.width'], SC_CY = ['r.top', 'r.top', 'r.top+r.height', 'r.top+r.height'];
function sc__refPoint(pre, ref, extents) {
    return sc__probe(pre, pre.layer(ref.li), 'var r = L.sourceRectAtTime(time, ' + (extents ? 'true' : 'false') + '); var q = L.toComp([' + SC_CX[ref.c] + ', ' + SC_CY[ref.c] + ']); [q[0], q[1]];', ref.t);
}

// opts JSON: {name, forceNew, range:'visible'|'workarea', pad, extents, center, even}
function smartCropRun(json) {
    app.beginUndoGroup('Welo: Smart Crop');
    try {
        var o = JSON.parse(json);
        var comp = app.project.activeItem;
        if (!(comp instanceof CompItem)) return 'ERR:Open a comp and select layers first';
        var sel = comp.selectedLayers, i, L, made = false;
        if (!sel.length) return 'ERR:Select the layers to precompose, or one precomp layer';
        var target, pre;
        if (sel.length === 1 && sel[0].source instanceof CompItem && !o.forceNew) {
            target = sel[0]; pre = target.source;
        } else {
            var ids = []; for (i = 0; i < sel.length; i++) ids.push(sel[i].index);
            ids.sort(function (a, b) { return a - b; });
            pre = comp.layers.precompose(ids, o.name || 'Smart PreComp', true);
            for (i = 1; i <= comp.numLayers; i++) if (comp.layer(i).source === pre) { target = comp.layer(i); break; }
            if (!target) return 'ERR:Precompose failed';
            made = true;
        }
        // 3D content: resizing the comp moves its default camera centre → perspective would change
        for (i = 1; i <= pre.numLayers; i++) {
            L = pre.layer(i);
            if (L instanceof CameraLayer) return 'ERR:"' + pre.name + '" has a camera — Smart Crop works on 2D content only' + (made ? ' (Ctrl+Z to undo the precompose)' : '');
            if (L.threeDLayer && sc__eligible(L)) return 'ERR:"' + L.name + '" is a 3D layer — Smart Crop works on 2D content only' + (made ? ' (Ctrl+Z to undo the precompose)' : '');
        }
        // time range in precomp time: the part of the precomp layer that is visible (∩ work area if asked)
        var a = target.inPoint, z = target.outPoint;
        if (o.range === 'workarea') { a = Math.max(a, comp.workAreaStart); z = Math.min(z, comp.workAreaStart + comp.workAreaDuration); }
        var t0 = 0, t1 = pre.duration;
        if (!target.timeRemapEnabled && target.stretch) {
            var m0 = (a - target.startTime) * 100 / target.stretch, m1 = (z - target.startTime) * 100 / target.stretch;
            t0 = Math.max(0, Math.min(m0, m1)); t1 = Math.min(pre.duration, Math.max(m0, m1));
        }
        if (t1 <= t0) { t0 = 0; t1 = pre.duration; }
        var bb = sc__bounds(pre, t0, t1, !!o.extents);
        if (!bb) return 'ERR:Nothing visible to crop in that time range';
        bb.ref.v = sc__refPoint(pre, bb.ref, !!o.extents);         // a fixed point of one layer (unclipped corner) to track the shift
        if (!bb.ref.v) return 'ERR:Could not measure the content';
        var pad = Math.max(0, +o.pad || 0);
        var x0 = Math.floor(bb.x0 - pad), y0 = Math.floor(bb.y0 - pad);
        var w = Math.ceil(bb.x1 + pad) - x0, h = Math.ceil(bb.y1 + pad) - y0;
        if (o.even) { if (w % 2) w++; if (h % 2) h++; }
        w = Math.max(4, Math.min(30000, w)); h = Math.max(4, Math.min(30000, h));
        if (x0 === 0 && y0 === 0 && w === pre.width && h === pre.height) return 'OK:Already tight — ' + w + '×' + h;

        // where one content point sits in the PARENT comp now — must be the same at the end (nothing moves)
        var fd = comp.frameDuration;
        var tp = Math.max(target.inPoint, Math.min(comp.time, target.outPoint - fd));
        var want = [bb.ref.v[0] - x0, bb.ref.v[1] - y0];               // that point's coords inside the cropped precomp
        var Q0 = sc__probe(comp, target, 'L.toComp([' + bb.ref.v[0] + ', ' + bb.ref.v[1] + ']);', tp);
        if (!Q0) return 'ERR:Could not measure the precomp layer position';

        // 1) resize the precomp, then measure where the content really is (AE may re-centre layers on resize)
        var oldW = pre.width, oldH = pre.height;
        pre.width = w; pre.height = h;
        var now = sc__refPoint(pre, bb.ref, !!o.extents);
        var sx = now ? now[0] - want[0] : x0, sy = now ? now[1] - want[1] : y0;
        // 2) move the content so the box starts at 0,0 (only unparented layers: children follow; hidden layers too)
        if (Math.abs(sx) > 0.001 || Math.abs(sy) > 0.001) {
            for (i = 1; i <= pre.numLayers; i++) {
                L = pre.layer(i);
                if (L.parent || L instanceof CameraLayer) continue;
                var lk = L.locked; L.locked = false;
                try { sc__shiftPosition(L, sx, sy); } catch (e1) {}
                L.locked = lk;
            }
        }
        // 3) every layer that uses this precomp (any comp): anchor correction measured on the target layer
        var users = [], ci, it;
        for (ci = 1; ci <= app.project.numItems; ci++) {
            it = app.project.item(ci);
            if (!(it instanceof CompItem)) continue;
            for (i = 1; i <= it.numLayers; i++) if (it.layer(i).source === pre) users.push(it.layer(i));
        }
        var F = sc__probe(comp, target, 'L.fromComp([' + Q0[0] + ', ' + Q0[1] + ']);', tp);   // precomp point that now sits at Q0
        var ax = F ? F[0] - want[0] : x0, ay = F ? F[1] - want[1] : y0;
        if (Math.abs(ax) > 0.001 || Math.abs(ay) > 0.001) {
            for (i = 0; i < users.length; i++) {
                var U = users[i], ul = U.locked; U.locked = false;
                try { sc__shiftProp(U.property('ADBE Transform Group').property('ADBE Anchor Point'), [ax, ay, 0]); } catch (e3) {}
                U.locked = ul;
            }
        }
        // 4) optional: anchor to the centre of the new box on the target layer (only when nothing is animated)
        var note = '';
        var tg = target.property('ADBE Transform Group'), ap = tg.property('ADBE Anchor Point'), ps = tg.property('ADBE Position');
        var animated = ap.numKeys || ps.numKeys || ap.expressionEnabled || ps.expressionEnabled || ps.dimensionsSeparated || target.threeDLayer;
        if (o.center) {
            if (animated) note = ' · anchor kept (layer is animated / 3D)';
            else {
                var tl = target.locked; target.locked = false;
                var A = ap.value;
                ap.setValue(A.length === 3 ? [w / 2, h / 2, A[2]] : [w / 2, h / 2]);
                target.locked = tl;
            }
        }
        // 5) final check on the target: the same content point must be back at Q0 → fix the position if not
        var Q1 = sc__probe(comp, target, 'L.toComp([' + want[0] + ', ' + want[1] + ']);', tp);
        if (Q1 && (Math.abs(Q1[0] - Q0[0]) > 0.01 || Math.abs(Q1[1] - Q0[1]) > 0.01)) {
            if (!animated) {
                var P = ps.value, tl2 = target.locked; target.locked = false;
                ps.setValue(P.length === 3 ? [P[0] + Q0[0] - Q1[0], P[1] + Q0[1] - Q1[1], P[2]] : [P[0] + Q0[0] - Q1[0], P[1] + Q0[1] - Q1[1]]);
                target.locked = tl2;
            } else note += ' · check position (' + Math.round(Q1[0] - Q0[0]) + ', ' + Math.round(Q1[1] - Q0[1]) + ' px)';
        }
        var wh = bb.who || {}, edges = {};
        var ek = ['left', 'right', 'top', 'bottom'];
        for (i = 0; i < 4; i++) if (wh[ek[i]]) edges[wh[ek[i]]] = (edges[wh[ek[i]]] ? edges[wh[ek[i]]] + '/' : '') + ek[i];
        var edgeTxt = ''; for (var en in edges) if (edges.hasOwnProperty(en)) edgeTxt += (edgeTxt ? ', ' : '') + en + ' (' + edges[en] + ')';
        note += edgeTxt ? '\nBox edges set by: ' + edgeTxt : '';
        return 'OK:' + pre.name + ' ' + oldW + '×' + oldH + ' → ' + w + '×' + h + (made ? ' (new precomp)' : '') +
               (users.length > 1 ? ' · ' + users.length + ' layers use it' : '') + note;
    } catch (e) {
        return 'ERR:' + e.toString() + ' line ' + e.line;
    } finally {
        app.endUndoGroup();
    }
}

function smartCropSelInfo() {
    try {
        var comp = app.project.activeItem;
        if (!(comp instanceof CompItem)) return 'none';
        var s = comp.selectedLayers;
        if (!s.length) return 'none';
        if (s.length === 1 && s[0].source instanceof CompItem) return 'precomp:' + s[0].source.width + 'x' + s[0].source.height + ':' + s[0].name;
        return 'layers:' + s.length;
    } catch (e) { return 'none'; }
}
