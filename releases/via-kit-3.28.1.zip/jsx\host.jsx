﻿// ============================================================
//  Smart Subtitle Box Generator — host.jsx
//  ExtendScript for Adobe After Effects CC 2022+
//  Called from CEP panel via CSInterface.evalScript()
// ============================================================

//@include "json2.js"

// ── Extension root (LESSONS L-013) ─────────────────────────
// File-name of this script is reliable only while it loads; inside functions called later via
// evalScript it can point somewhere else. Capture it once here; the panel also pushes the real
// path (CSInterface EXTENSION) via weloSetExtDir() at init (js/tools.js).
var WELO_EXT_DIR = (function () { try { return new File($.fileName).parent.parent.fsName; } catch (e) { return ''; } })();
function weloSetExtDir(p) {
    try { var f = new Folder(p); if (f.exists) { WELO_EXT_DIR = f.fsName; return 'OK:' + f.fsName; } } catch (e) {}
    return 'ERR:not found ' + p;
}
function weloExtDir() { return WELO_EXT_DIR; }

// ── Overlord.jsx is loaded by the bridge (bridge.js via SystemPath.EXTENSION)

// ── ENTRY POINTS (called from script.js) ──────────────────
// generateBoxes(paramsJSON)
// updateBoxes(paramsJSON)
// deleteBoxes()
// selectAllBoxes()
// getLayerInfo()


// ─────────────────────────────────────────────────────────────
//  HELPERS
// ─────────────────────────────────────────────────────────────

/**
 * Parse hex color "#rrggbb" → [r, g, b] normalized 0-1
 */
function hexToRGB(hex) {
    hex = hex.replace('#', '');
    return [
        parseInt(hex.substring(0, 2), 16) / 255,
        parseInt(hex.substring(2, 4), 16) / 255,
        parseInt(hex.substring(4, 6), 16) / 255
    ];
}

/**
 * Find the active composition
 */
function getComp() {
    var comp = app.project.activeItem;
    if (!comp || !(comp instanceof CompItem)) {
        return null;
    }
    return comp;
}

/**
 * Find layers that are Text layers.
 * If layers are selected → use selection.
 * Otherwise → scan all layers for text / keyword match.
 */
function getTextLayers(comp, autoDetect, keywords) {
    var layers = [];
    var kw = keywords ? keywords.toLowerCase().split(',') : ['sub', 'subtitle', 'txt', 'caption'];
    for (var i = 0; i < kw.length; i++) kw[i] = kw[i].replace(/\s/g, '');

    // Check selected layers first
    for (var i = 1; i <= comp.numLayers; i++) {
        var layer = comp.layer(i);
        if (layer.selected && layer instanceof TextLayer) {
            layers.push(layer);
        }
    }

    // If nothing selected and autoDetect on → grab by keyword
    if (layers.length === 0 && autoDetect) {
        for (var i = 1; i <= comp.numLayers; i++) {
            var layer = comp.layer(i);
            if (!(layer instanceof TextLayer)) continue;
            var name = layer.name.toLowerCase();
            for (var k = 0; k < kw.length; k++) {
                if (name.indexOf(kw[k]) !== -1) {
                    layers.push(layer);
                    break;
                }
            }
        }
    }

    // Last resort — all text layers
    if (layers.length === 0) {
        for (var i = 1; i <= comp.numLayers; i++) {
            var layer = comp.layer(i);
            if (layer instanceof TextLayer) layers.push(layer);
        }
    }

    return layers;
}

/**
 * Check if a BG box already exists for a text layer
 */
function findExistingBox(comp, textLayer) {
    var tag = '_SSBG_' + textLayer.name;
    for (var i = 1; i <= comp.numLayers; i++) {
        if (comp.layer(i).name === tag) return comp.layer(i);
    }
    return null;
}

/**
 * Build the layer name for a BG box
 */
function boxName(textLayer) {
    return '_SSBG_' + textLayer.name;
}

/**
 * Remove all BG boxes created by this tool
 */
function removeAllBoxes(comp) {
    var removed = 0;
    for (var i = comp.numLayers; i >= 1; i--) {
        if (comp.layer(i).name.indexOf('_SSBG_') === 0) {
            comp.layer(i).remove();
            removed++;
        }
    }
    return removed;
}

// ─────────────────────────────────────────────────────────────
//  CORE — CREATE ONE BOX BEHIND ONE TEXT LAYER
// ─────────────────────────────────────────────────────────────

function createBoxForLayer(comp, textLayer, params) {

    // ── 1. Remove existing box if any ──
    var existing = findExistingBox(comp, textLayer);
    if (existing) existing.remove();

    var padding = params.padding !== undefined ? params.padding : 30;
    var rgb     = hexToRGB(params.color || '#000000');
    var opacity = (params.opacity !== undefined) ? params.opacity : 80;
    var radius  = params.radius  !== undefined ? params.radius : 8;
    var shape   = params.shape   || 'rect';

    // ── 2. CENTER text layer anchor point (idempotent) ──
    // When called from Generate the anchor is already centered (Anchor Point
    // == rect center).  Only re-center when it drifted (user moved anchor):
    // the rect center relative to the CURRENT anchor is added, never used
    // as an absolute value — this never resets a centered anchor to [0,0].
    var t          = textLayer.inPoint;
    var src        = textLayer.sourceRectAtTime(t, false);
    var anchorProp = textLayer.property('Transform').property('Anchor Point');
    var posProp    = textLayer.property('Transform').property('Position');
    var oldAnchor  = anchorProp.value;
    var scx        = src.left + src.width  / 2;
    var scy        = src.top  + src.height / 2;
    if (Math.abs(scx) > 0.5 || Math.abs(scy) > 0.5) {
        var oldPos = posProp.value;
        anchorProp.setValue([oldAnchor[0] + scx, oldAnchor[1] + scy]);
        posProp.setValue([oldPos[0] + scx, oldPos[1] + scy]);
    }

    // Re-read bounding box after anchor change
    var src2 = textLayer.sourceRectAtTime(t, false);
    var boxW  = src2.width  + padding * 2;
    var boxH  = src2.height + padding * 2;

    // ── 3. Add Shape Layer ──
    var shapeLayer = comp.layers.addShape();
    shapeLayer.name      = boxName(textLayer);
    shapeLayer.startTime = textLayer.startTime;
    shapeLayer.inPoint   = textLayer.inPoint;
    shapeLayer.outPoint  = textLayer.outPoint;

    // ── 4. Build Rectangle ──
    var contents    = shapeLayer.property('ADBE Root Vectors Group');
    var grp         = contents.addProperty('ADBE Vector Group');
    grp.name        = 'BG Box';
    var grpContents = grp.property('ADBE Vectors Group');

    var rectProp = grpContents.addProperty('ADBE Vector Shape - Rect');
    rectProp.property('ADBE Vector Rect Size').setValue([boxW, boxH]);
    rectProp.property('ADBE Vector Rect Roundness').setValue(
        shape === 'pill' ? Math.min(boxW, boxH) / 2 : radius
    );
    // Rectangle Path Position — centers rect on the text bounding box via
    // name-based reference (parent/group has no sourceRectAtTime in AE)
    rectProp.property('ADBE Vector Rect Position').expression =
        'var L = thisComp.layer(\'' + escLayerName(textLayer.name) + '\');\ntry {\n  var r = L.sourceRectAtTime(time, false);\n  [r.left + r.width/2, r.top + r.height/2];\n} catch(e) { [0,0]; }';

    // Stroke FIRST (renders behind fill in AE stack — add before fill)
    if (params.strokeEnabled && params.strokeWidth > 0) {
        var stroke = grpContents.addProperty('ADBE Vector Graphic - Stroke');
        stroke.property('ADBE Vector Stroke Color').setValue(hexToRGB(params.strokeColor || '#ffffff'));
        stroke.property('ADBE Vector Stroke Width').setValue(params.strokeWidth || 2);
    }

    // Fill
    var fill = grpContents.addProperty('ADBE Vector Graphic - Fill');
    fill.property('ADBE Vector Fill Color').setValue(rgb);

    // ── 5. Opacity / Blend Mode / Shadow ──
    shapeLayer.property('Transform').property('Opacity').setValue(opacity);

    var blendMap = {
        'normal':     BlendingMode.NORMAL,
        'multiply':   BlendingMode.MULTIPLY,
        'screen':     BlendingMode.SCREEN,
        'overlay':    BlendingMode.OVERLAY,
        'hard-light': BlendingMode.HARD_LIGHT,
        'color-dodge':BlendingMode.COLOR_DODGE
    };
    shapeLayer.blendingMode = blendMap[params.blendMode] || BlendingMode.NORMAL;

    if (params.shadowEnabled) {
        try {
            var fx = shapeLayer.property('ADBE Effect Parade');
            var shadow = fx.addProperty('ADBE Drop Shadow');
            shadow.property(2).setValue(60);
            shadow.property(4).setValue(0);
            shadow.property(5).setValue(params.shadowBlur || 8);
        } catch(e) {}
    }

    // ── Gaussian Blur Legacy ──
    if (params.blur && params.blur > 0) {
        try {
            var fxBlur = shapeLayer.property('ADBE Effect Parade');
            var gb = fxBlur.addProperty('ADBE Gaussian Blur');
            gb.property('ADBE Gaussian Blur-0001').setValue(params.blur);
            try { gb.property('ADBE Gaussian Blur-0002').setValue(1); } catch(e) {}
        } catch(e) {}
    }

    shapeLayer.motionBlur = textLayer.motionBlur;

    // ── 6. PARENT box to text layer ──
    // This makes the box FOLLOW the text automatically — position, scale, rotation
    shapeLayer.parent = textLayer;

    // ── 7. Position box at text anchor (= visual center after step 2) ──
    // Box is parented to text. After anchor centering: anchor is at text center.
    var src3  = textLayer.sourceRectAtTime(t, false);
    var initX = src3.left + src3.width  / 2;  // ≈ 0 after centering
    var initY = src3.top  + src3.height / 2;  // ≈ 0 after centering
    shapeLayer.property('Transform').property('Position').setValue([initX, initY]);

    // ── 8. Size Expression — updates when text content changes ──
    addSizeExpression(shapeLayer, textLayer, padding, shape, radius);

    // ── 9. Position Expression — keeps box centered on text at all times ──
    addPositionExpression(shapeLayer, textLayer);

    // ── 10. Move box BELOW text layer ──
    shapeLayer.moveAfter(textLayer);

    return shapeLayer;
}

// ─────────────────────────────────────────────────────────────
//  EXPRESSIONS
// ─────────────────────────────────────────────────────────────

function escLayerName(n) {
    return String(n).replace(/\\/g, '\\\\').replace(/'/g, "\\'").replace(/[\r\n]+/g, ' ');
}

function addSizeExpression(shapeLayer, textLayer, padding, shape, radius) {
    try {
        var sizeProp = shapeLayer
            .property('ADBE Root Vectors Group')
            .property('BG Box')
            .property('ADBE Vectors Group')
            .property('ADBE Vector Shape - Rect')
            .property('ADBE Vector Rect Size');

        var pad      = padding;

        // Reference the text layer by NAME, not index: layers added while the
        // script runs shift every index, breaking index-based expressions
        // until an update re-writes them.
        var exprLines = [
            'var L   = thisComp.layer(\'' + escLayerName(textLayer.name) + '\');',
            'var pad = ' + pad + ';',
            'try {',
            '  var r = L.sourceRectAtTime(time, false);',
            '  [r.width + pad * 2, r.height + pad * 2];',
            '} catch(e) { value; }'
        ];
        sizeProp.expression = exprLines.join('\n');

        // Rectangle Path Position — tracks actual text bounding box center
        try {
            var posProp = shapeLayer
                .property('ADBE Root Vectors Group')
                .property('BG Box')
                .property('ADBE Vectors Group')
                .property('ADBE Vector Shape - Rect')
                .property('ADBE Vector Rect Position');
            posProp.expression =
                'var L = thisComp.layer(\'' + escLayerName(textLayer.name) + '\');\ntry {\n  var r = L.sourceRectAtTime(time, false);\n  [r.left + r.width/2, r.top + r.height/2];\n} catch(e) { [0,0]; }';
        } catch(ep) {}
    } catch (e) {}
}

function addPositionExpression(shapeLayer, textLayer) {
    try {
        var posProp  = shapeLayer.property('Transform').property('Position');

        // Child position is in PARENT'S LAYER SPACE. The parent's layer-space
        // origin (0,0) sits at the PARENT's anchor point, which after centering
        // is exactly the text's visual center. The rect path position already
        // resolves to that center in the child's layer space, so the child's
        // anchor point must coincide with the parent's origin. That means the
        // child position must equal the child's OWN anchor value: P - A = 0.
        // Using the child's own anchor (not the text's) keeps the box centered
        // no matter what anchor value the user sets on either layer.
        var exprLines = [
            'try {',
            '  var a = transform.anchorPoint;',
            '  [a[0], a[1]];',
            '} catch(e) { value; }'
        ];
        posProp.expression = exprLines.join('\n');
    } catch (e) {}
}

// ─────────────────────────────────────────────────────────────
//  ANIMATION — Apply keyframes
// ─────────────────────────────────────────────────────────────

function applyAnimationToBox(shapeLayer, textLayer, animStyle, duration, offset, easing, mirrorOut) {

    var fps      = shapeLayer.containingComp.frameRate;
    var frameSec = 1 / fps;
    var durSec   = duration * frameSec;
    var offSec   = offset  * frameSec;

    var inPt  = textLayer.inPoint;
    var outPt = textLayer.outPoint;

    var opacProp = shapeLayer.property('Transform').property('Opacity');
    var scaleProp= shapeLayer.property('Transform').property('Scale');
    var posProp  = shapeLayer.property('Transform').property('Position');

    // ── Easing preset ──
    var easeOut  = new KeyframeEase(0.5, 66);
    var easeIn   = new KeyframeEase(0.5, 33);
    var linear   = new KeyframeEase(0, 0);

    function applyEase(prop, idx) {
        try {
            if (easing === 'Ease Out') {
                prop.setTemporalEaseAtKey(idx, [easeIn], [easeOut]);
            } else if (easing === 'Ease In Out') {
                prop.setTemporalEaseAtKey(idx, [easeOut], [easeOut]);
            }
        } catch(e) {}
    }

    if (animStyle === 'fade') {
        // Opacity 0 → 100
        opacProp.setValueAtTime(inPt - offSec, 0);
        opacProp.setValueAtTime(inPt - offSec + durSec, shapeLayer.property('Transform').property('Opacity').value);
        applyEase(opacProp, 1);
        if (mirrorOut) {
            opacProp.setValueAtTime(outPt - durSec, shapeLayer.property('Transform').property('Opacity').value);
            opacProp.setValueAtTime(outPt, 0);
        }
    }

    else if (animStyle === 'scale') {
        var finalScale = scaleProp.value;
        scaleProp.setValueAtTime(inPt - offSec, [0, 0]);
        scaleProp.setValueAtTime(inPt - offSec + durSec, finalScale);
        applyEase(scaleProp, 1);
        if (mirrorOut) {
            scaleProp.setValueAtTime(outPt - durSec, finalScale);
            scaleProp.setValueAtTime(outPt, [0, 0]);
        }
    }

    else if (animStyle === 'slide-up') {
        var basePos = posProp.value;
        posProp.setValueAtTime(inPt - offSec, [basePos[0], basePos[1] + 40]);
        posProp.setValueAtTime(inPt - offSec + durSec, basePos);
        opacProp.setValueAtTime(inPt - offSec, 0);
        opacProp.setValueAtTime(inPt - offSec + durSec, opacProp.value);
        applyEase(posProp, 1);
        if (mirrorOut) {
            posProp.setValueAtTime(outPt - durSec, basePos);
            posProp.setValueAtTime(outPt, [basePos[0], basePos[1] + 40]);
            opacProp.setValueAtTime(outPt - durSec, opacProp.value);
            opacProp.setValueAtTime(outPt, 0);
        }
    }

    else if (animStyle === 'slide-left') {
        var basePos2 = posProp.value;
        posProp.setValueAtTime(inPt - offSec, [basePos2[0] + 60, basePos2[1]]);
        posProp.setValueAtTime(inPt - offSec + durSec, basePos2);
        opacProp.setValueAtTime(inPt - offSec, 0);
        opacProp.setValueAtTime(inPt - offSec + durSec, opacProp.value);
        applyEase(posProp, 1);
        if (mirrorOut) {
            posProp.setValueAtTime(outPt - durSec, basePos2);
            posProp.setValueAtTime(outPt, [basePos2[0] + 60, basePos2[1]]);
            opacProp.setValueAtTime(outPt - durSec, opacProp.value);
            opacProp.setValueAtTime(outPt, 0);
        }
    }

    else if (animStyle === 'wipe') {
        // Scale X: 0 → 100
        var finalScale2 = scaleProp.value;
        scaleProp.setValueAtTime(inPt - offSec, [0, finalScale2[1]]);
        scaleProp.setValueAtTime(inPt - offSec + durSec, finalScale2);
        applyEase(scaleProp, 1);
        if (mirrorOut) {
            scaleProp.setValueAtTime(outPt - durSec, finalScale2);
            scaleProp.setValueAtTime(outPt, [0, finalScale2[1]]);
        }
    }

    else if (animStyle === 'bounce') {
        var bounceEase = new KeyframeEase(0.8, 80);
        var finalScale3 = scaleProp.value;
        scaleProp.setValueAtTime(inPt - offSec, [0, 0]);
        scaleProp.setValueAtTime(inPt - offSec + durSec, [finalScale3[0] * 1.1, finalScale3[1] * 1.1]);
        scaleProp.setValueAtTime(inPt - offSec + durSec * 1.4, finalScale3);
        try {
            scaleProp.setTemporalEaseAtKey(2, [bounceEase], [bounceEase]);
        } catch(e) {}
        if (mirrorOut) {
            scaleProp.setValueAtTime(outPt - durSec, finalScale3);
            scaleProp.setValueAtTime(outPt, [0, 0]);
        }
    }
}

// ─────────────────────────────────────────────────────────────
//  PUBLIC — generateBoxes(paramsJSON)
// ─────────────────────────────────────────────────────────────

function generateBoxes(paramsJSON) {
    var params;
    try { params = JSON.parse(paramsJSON); }
    catch(e) { return '0'; }

    var comp = getComp();
    if (!comp) return 'NO_COMP';

    var autoDetect = params.autoDetect !== false;
    var keywords   = params.keywords || 'sub,subtitle,txt,caption';
    var textLayers = getTextLayers(comp, autoDetect, keywords);

    if (textLayers.length === 0) {
        return 'NO_LAYERS';
    }

    app.beginUndoGroup('Generate Subtitle Boxes');

    var created = 0;
    for (var i = 0; i < textLayers.length; i++) {
        try {
            createBoxForLayer(comp, textLayers[i], params);
            created++;
        } catch(e) {
            // Continue to next layer
        }
    }

    app.endUndoGroup();
    return String(created);
}

// ─────────────────────────────────────────────────────────────
//  PUBLIC — updateBoxes(paramsJSON)
//  Updates existing boxes without recreating them
// ─────────────────────────────────────────────────────────────

function updateBoxes(paramsJSON) {
    var params;
    try { params = JSON.parse(paramsJSON); }
    catch(e) { return 'error'; }

    var comp = getComp();
    if (!comp) return 'NO_COMP';

    var allLayers = params._allLayers !== false; // default true for backwards compat

    app.beginUndoGroup('Update Subtitle Boxes');

    var updated = 0;
    for (var i = 1; i <= comp.numLayers; i++) {
        var layer = comp.layer(i);
        if (layer.name.indexOf('_SSBG_') !== 0) continue;

        // If not allLayers, only update selected boxes
        if (!allLayers && !layer.selected) continue;

        try {
            // ── Heal: re-center the parent TEXT layer's anchor on its
            // bounding box (idempotent).  Boxes generated before the
            // anchor fix have their anchor reset to [0,0] which sags the
            // box below the text — this fixes them without moving anything.
            try {
                var healParent = layer.parent;
                if (healParent) {
                    var haP = healParent.property('Transform').property('Anchor Point');
                    var hpP = healParent.property('Transform').property('Position');
                    var haV = haP.value;
                    var hsr = healParent.sourceRectAtTime(healParent.inPoint, false);
                    var hcx = hsr.left + hsr.width  / 2;
                    var hcy = hsr.top  + hsr.height / 2;
                    if (Math.abs(hcx) > 0.5 || Math.abs(hcy) > 0.5) {
                        var hpV = hpP.value;
                        haP.setValue([haV[0] + hcx, haV[1] + hcy]);
                        hpP.setValue([hpV[0] + hcx, hpV[1] + hcy]);
                    }
                }
            } catch(eHeal) {}

            // ── Update Fill Color ──
            var rgb = hexToRGB(params.color || '#000000');
            var fill = layer
                .property('ADBE Root Vectors Group')
                .property('BG Box')
                .property('ADBE Vectors Group')
                .property('ADBE Vector Graphic - Fill');
            fill.property('ADBE Vector Fill Color').setValue(rgb);

            // ── Update Corner Radius ──
            var rect = layer
                .property('ADBE Root Vectors Group')
                .property('BG Box')
                .property('ADBE Vectors Group')
                .property('ADBE Vector Shape - Rect');
            rect.property('ADBE Vector Rect Roundness').setValue(params.radius || 8);

            // ── Update Size Expression (padding changed) ──
            try {
                var sizeProp = layer
                    .property('ADBE Root Vectors Group')
                    .property('BG Box')
                    .property('ADBE Vectors Group')
                    .property('ADBE Vector Shape - Rect')
                    .property('ADBE Vector Rect Size');
                var txtLayer = null;
                if (layer.parent) {
                    txtLayer = layer.parent;
                } else {
                    var boxN = layer.name.replace('_SSBG_', '');
                    for (var j = 1; j <= comp.numLayers; j++) {
                        if (comp.layer(j).name === boxN) { txtLayer = comp.layer(j); break; }
                    }
                }
                if (txtLayer) {
                    var pad2 = params.padding !== undefined ? params.padding : 30;
                    var newExpr = [
                        'var L   = thisComp.layer(\'' + escLayerName(txtLayer.name) + '\');',
                        'var pad = ' + pad2 + ';',
                        'try {',
                        '  var r = L.sourceRectAtTime(time, false);',
                        '  [r.width + pad * 2, r.height + pad * 2];',
                        '} catch(e) { value; }'
                    ].join('\n');
                    sizeProp.expression = newExpr;
                }
            } catch(eSize) {}

            // ── Update Opacity ──
            layer.property('Transform').property('Opacity').setValue(params.opacity || 80);

            // ── Update Blend Mode ──
            var blendMap = {
                'normal':      BlendingMode.NORMAL,
                'multiply':    BlendingMode.MULTIPLY,
                'screen':      BlendingMode.SCREEN,
                'overlay':     BlendingMode.OVERLAY,
                'hard-light':  BlendingMode.HARD_LIGHT,
                'color-dodge': BlendingMode.COLOR_DODGE
            };
            layer.blendingMode = blendMap[params.blendMode] || BlendingMode.NORMAL;

            // ── Update Stroke ──
            try {
                var grpContents2 = layer
                    .property('ADBE Root Vectors Group')
                    .property('BG Box')
                    .property('ADBE Vectors Group');
                // Find existing stroke by iterating (more reliable than .property())
                var strokeLayer = null;
                for (var si = 1; si <= grpContents2.numProperties; si++) {
                    if (grpContents2.property(si).matchName === 'ADBE Vector Graphic - Stroke') {
                        strokeLayer = grpContents2.property(si); break;
                    }
                }
                if (params.strokeEnabled && params.strokeWidth > 0) {
                    if (!strokeLayer) {
                        strokeLayer = grpContents2.addProperty('ADBE Vector Graphic - Stroke');
                    }
                    strokeLayer.property('ADBE Vector Stroke Color').setValue(hexToRGB(params.strokeColor || '#ffffff'));
                    strokeLayer.property('ADBE Vector Stroke Width').setValue(params.strokeWidth || 2);
                    strokeLayer.enabled = true;
                } else if (strokeLayer) {
                    strokeLayer.enabled = false;
                }
            } catch(eStroke) {}

            // ── Update Drop Shadow ──
            try {
                var fx = layer.property('ADBE Effect Parade');
                var shadow = null;
                for (var ei = 1; ei <= fx.numProperties; ei++) {
                    if (fx.property(ei).matchName === 'ADBE Drop Shadow') {
                        shadow = fx.property(ei); break;
                    }
                }
                if (params.shadowEnabled) {
                    if (!shadow) shadow = fx.addProperty('ADBE Drop Shadow');
                    shadow.enabled = true;
                    shadow.property(2).setValue(60);
                    shadow.property(4).setValue(0);
                    shadow.property(5).setValue(params.shadowBlur || 8);
                } else {
                    if (shadow) shadow.enabled = false;
                }
            } catch(eShadow) {}

            // ── Update Gaussian Blur Legacy (background blur) ──
            try {
                var fxP = layer.property('ADBE Effect Parade');
                var gblur = null;
                for (var gi = 1; gi <= fxP.numProperties; gi++) {
                    var mn = fxP.property(gi).matchName;
                    if (mn === 'ADBE Gaussian Blur' || mn === 'ADBE Gaussian Blur 2') {
                        gblur = fxP.property(gi); break;
                    }
                }
                if (params.blur && params.blur > 0) {
                    if (!gblur) gblur = fxP.addProperty('ADBE Gaussian Blur');
                    gblur.enabled = true;
                    gblur.property('ADBE Gaussian Blur-0001').setValue(params.blur);
                    // Repeat edge pixels
                    try { gblur.property('ADBE Gaussian Blur-0002').setValue(1); } catch(e) {}
                } else {
                    if (gblur) gblur.enabled = false;
                }
            } catch(eBlur) {}

            updated++;
        } catch(e) { /* continue */ }
    }

    app.endUndoGroup();
    return String(updated);
}

// ─────────────────────────────────────────────────────────────
//  PUBLIC — applyAnimations(paramsJSON)
// ─────────────────────────────────────────────────────────────

function applyAnimations(paramsJSON) {
    var params;
    try { params = JSON.parse(paramsJSON); }
    catch(e) { return 'error'; }

    var comp = getComp();
    if (!comp) return 'error';

    app.beginUndoGroup('Apply Box Animations');

    var animStyle = params.animStyle  || 'fade';
    var duration  = params.duration   || 8;
    var offset    = params.offset     || 2;
    var easing    = params.easing     || 'Ease Out';
    var mirrorOut = params.mirrorOut  !== false;

    // Collect selected layers first, fallback to all boxes
    var targets = [];
    for (var i = 1; i <= comp.numLayers; i++) {
        if (comp.layer(i).selected) targets.push(comp.layer(i));
    }
    // If nothing selected, animate all _SSBG_ layers
    if (targets.length === 0) {
        for (var i = 1; i <= comp.numLayers; i++) {
            if (comp.layer(i).name.indexOf('_SSBG_') === 0) targets.push(comp.layer(i));
        }
    }

    var count = 0;
    for (var ti = 0; ti < targets.length; ti++) {
        var layer = targets[ti];
        // Find the text layer above the box (should be directly above)
        var txtLayer = null;
        // Try to find by matching name (remove _SSBG_ prefix)
        var textName = layer.name.replace('_SSBG_', '');
        for (var j = 1; j <= comp.numLayers; j++) {
            if (comp.layer(j).name === textName) { txtLayer = comp.layer(j); break; }
        }
        // Fallback: layer directly above
        if (!txtLayer && layer.index > 1) {
            txtLayer = comp.layer(layer.index - 1);
        }
        try {
            applyAnimationToBox(layer, txtLayer, animStyle, duration, offset, easing, mirrorOut);
            count++;
        } catch(e) {}
    }

    app.endUndoGroup();
    return String(count);
}

// ─────────────────────────────────────────────────────────────
//  PUBLIC — deleteBoxes()
// ─────────────────────────────────────────────────────────────

function deleteBoxes() {
    var comp = getComp();
    if (!comp) return 'NO_COMP';

    app.beginUndoGroup('Delete Subtitle Boxes');
    var removed = removeAllBoxes(comp);
    app.endUndoGroup();

    return String(removed);
}

// ─────────────────────────────────────────────────────────────
//  PUBLIC — selectAllBoxes()
// ─────────────────────────────────────────────────────────────

function selectAllBoxes() {
    var comp = getComp();
    if (!comp) return 'NO_COMP';

    // Deselect all first
    for (var i = 1; i <= comp.numLayers; i++) {
        comp.layer(i).selected = false;
    }

    var count = 0;
    for (var i = 1; i <= comp.numLayers; i++) {
        var layer = comp.layer(i);
        if (layer.name.indexOf('_SSBG_') === 0) {
            layer.selected = true;
            count++;
        }
    }

    return String(count);
}

function selectAllTextLayers() {
    var comp = getComp();
    if (!comp) return 'NO_COMP';

    for (var i = 1; i <= comp.numLayers; i++) {
        comp.layer(i).selected = false;
    }

    var count = 0;
    for (var i = 1; i <= comp.numLayers; i++) {
        var layer = comp.layer(i);
        if (layer.name.indexOf('SUB_') === 0) {
            layer.selected = true;
            count++;
        }
    }

    return String(count);
}

// ─────────────────────────────────────────────────────────────
//  PUBLIC — getLayerInfo()
//  Returns JSON with counts for the Settings stats panel
// ─────────────────────────────────────────────────────────────

function getLayerInfo() {
    var comp = getComp();
    if (!comp) return '{"text":0,"boxes":0}';

    var textCount = 0, boxCount = 0;
    try {
        for (var i = 1; i <= comp.numLayers; i++) {
            var layer = comp.layer(i);
            if (layer instanceof TextLayer) textCount++;
            if (layer.name.indexOf('_SSBG_') === 0) boxCount++;
        }
    } catch(e) {}

    return '{"text":' + textCount + ',"boxes":' + boxCount + '}';
}

// ═══════════════════════════════════════════════════════════
//  WHISPER AI FUNCTIONS
// ═══════════════════════════════════════════════════════════

/**
 * Setup render queue for Whisper
 */
function whisperSetupRender(dir) {
    var comp = getComp();
    if (!comp) return 'NO_COMP';
    try {
        var whisperDir = dir || 'C:\\Via Studios Kit\\Audio\\work\\';
        var outFolder = new Folder(whisperDir);
        if (!outFolder.exists) outFolder.create();
        var rq = app.project.renderQueue;
        // Remove only our own previous WhisRend items (never wipe the user's queue)
        for (var q = rq.numItems; q >= 1; q--) {
            try {
                var qi = rq.item(q);
                if (qi.status === RQItemStatus.QUEUED && qi.outputModule(1).file &&
                    qi.outputModule(1).file.displayName.indexOf('WhisRend') === 0) qi.remove();
            } catch (qe) {}
        }
        var rqItem = rq.items.add(comp);
        var om = rqItem.outputModule(1);
        // Scripts cannot set the output Format; only apply a template by name (3.26.1).
        // 1) the kit's own template 'via-wave-transcript'  2) any template with WAV in its name
        var list = om.templates, pick = '', i;
        for (i = 0; i < list.length; i++) if (String(list[i]).toLowerCase() === 'via-wave-transcript') { pick = list[i]; break; }
        if (!pick) for (i = 0; i < list.length; i++) if (/wav/i.test(String(list[i]))) { pick = list[i]; break; }
        if (!pick) {
            try { rqItem.remove(); } catch (er) {}
            return 'NO_TEMPLATE:' + JSON.stringify(list);
        }
        om.applyTemplate(pick);
        om = rqItem.outputModule(1);                 // re-fetch: changing settings can invalidate the object
        om.file = new File(whisperDir + 'WhisRend.wav'); // path AFTER the template (a template can reset it)
        om = rqItem.outputModule(1);
        var fmt = '';
        try { fmt = String(om.getSettings(GetSettingsFormat.STRING)['Format']); } catch (ef) {}
        var out = '';
        try { out = om.file.fsName; } catch (eo) {}
        return 'OK:' + JSON.stringify({ template: pick, format: fmt, file: out });
    } catch(e) {
        return 'ERR:' + e.toString() + ' line ' + e.line;
    }
}

/**
 * Portable models folder — fixed default C:\Via Studios Kit\Audio\models so
 * the whole Audio folder can be copied to another machine at the same path.
 * Falls back to %APPDATA%\Via Studios Kit\Audio\models if C:\ is not writable.
 */
function whisperModelsDir() {
    try {
        var root = new Folder('C:\\Via Studios Kit');
        if (root.exists || root.create()) {
            var md = new Folder('C:\\Via Studios Kit\\Audio\\models');
            md.create();
            return 'C:\\Via Studios Kit\\Audio\\models';
        }
    } catch(e) {}
    var base = $.getenv('APPDATA') || Folder.userData.fsName;
    return base.replace(/\//g, '\\') + '\\Via Studios Kit\\Audio\\models';
}

/**
 * Let the user pick a custom models folder (stored on the panel side).
 */
function whisperPickModelsDir() {
    try {
        var d = Folder.selectDialog('Choose AI models folder');
        if (!d) return 'CANCEL';
        return 'OK:' + d.fsName;
    } catch(e) { return 'ERR:' + e.toString(); }
}

/**
 * Return paths needed to run Whisper (no blocking)
 */
function whisperGetRunPaths(dir, model, extDir) {
    var bs = function(p) { return p.replace(/\//g, '\\'); };
    if (!extDir) { try { extDir = weloExtDir(); } catch(e) {} }
    var pyExe = getPythonPath();
    var scriptPath = bs(extDir) + '\\audio_enhance\\run_whisper.py';
    var wavPath = bs(dir) + 'WhisRend.wav';
    var jsonPath = bs(dir) + 'WhisRend.json';
    return JSON.stringify({
        python: pyExe || '',
        script: new File(scriptPath).exists ? scriptPath : '',
        wav: new File(wavPath).exists ? wavPath : '',
        json: jsonPath,
        model: model || 'base',
        models: whisperModelsDir(),
        error: !pyExe ? 'Python not found' : !new File(scriptPath).exists ? 'run_whisper.py not found' : !new File(wavPath).exists ? 'WhisRend.wav not found' : ''
    });
}

/**
 * Return paths from uploaded file (convert to WAV first if needed)
 */
function whisperGetRunPathsFromFile(filePath, model, extDir, ffmpegPath) {
    var bs = function(p) { return p.replace(/\//g, '\\'); };
    if (!extDir) { try { extDir = weloExtDir(); } catch(e) {} }
    var pyExe = getPythonPath();
    var scriptPath = bs(extDir) + '\\audio_enhance\\run_whisper.py';
    var wavPath = filePath;
    var ext = filePath.split('.').pop().toLowerCase();
    var conversion = '';
    if (ext !== 'wav') {
        wavPath = filePath.replace(/\.\w+$/, '.wav');
        var tmp = bs($.getenv('TEMP') || 'C:\\Windows\\Temp');
        var bat = new File(tmp + '\\welo_convert.bat');
        bat.encoding = 'UTF-8'; bat.open('w');
        var ffExe = new File(ffmpegPath ? bs(ffmpegPath) : bs(extDir) + '\\ytdl\\ffmpeg.exe'); // ffmpegPath from panel weloTools
        var ffCmd = ffExe.exists ? '"' + ffExe.fsName + '"' : 'ffmpeg';
        bat.write('@echo off\r\n' + ffCmd + ' -y -i "' + bs(filePath) + '" -ac 1 -ar 16000 "' + bs(wavPath) + '"\r\n');
        bat.close();
        conversion = bat.fsName;
    }
    var jsonPath = filePath.replace(/\.\w+$/, '.json');
    return JSON.stringify({
        python: pyExe || '',
        script: new File(scriptPath).exists ? scriptPath : '',
        wav: wavPath,
        json: jsonPath,
        model: model || 'base',
        models: whisperModelsDir(),
        conversion: conversion,
        error: !pyExe ? 'Python not found' : !new File(scriptPath).exists ? 'run_whisper.py not found' : ''
    });
}

/**
 * Read a file and return its content (used after async Whisper)
 */
function whisperReadFile(path) {
    try {
        var f = new File(path);
        if (!f.exists) return '';
        f.encoding = 'UTF-8'; f.open('r');
        var raw = f.read(); f.close();
        return raw;
    } catch(e) { return ''; }
}

/**
 * Load JSON file via dialog
 */
function whisperLoadJSON(startDir) {
    try {
        // open the dialog in the default JSON folder (where Whisper writes its output)
        try { if (startDir) { var sd = new Folder(startDir); if (sd.exists) Folder.current = sd; } } catch(e) {}
        var f = File.openDialog('Select Whisper JSON', 'JSON:*.json,All:*.*');
        if (!f) return 'cancelled';
        $.global.weloLastJsonDir = f.parent.fsName; // panel reads this to remember the folder
        f.encoding = 'UTF-8';
        f.open('r');
        var raw = f.read();
        f.close();
        return raw;
    } catch(e) {
        return 'error';
    }
}

function secondsToSrtTime(sec) {
    var tot = Math.round((sec > 0 ? sec : 0) * 1000);
    var h = Math.floor(tot / 3600000);
    var m = Math.floor((tot % 3600000) / 60000);
    var s = Math.floor((tot % 60000) / 1000);
    var ms = tot % 1000;
    return zeroPad(h,2) + ':' + zeroPad(m,2) + ':' + zeroPad(s,2) + ',' + zeroPad(ms,3);
}
function zeroPad(n, len) {
    var s = String(n);
    while (s.length < len) s = '0' + s;
    return s;
}

function whisperExportSRT(linesDataJSON) {
    try {
        var data = JSON.parse(linesDataJSON);
        var srt = '';
        for (var i = 0; i < data.length; i++) {
            var ln = data[i];
            srt += (i+1) + '\n' + secondsToSrtTime(ln.inPt) + ' --> ' + secondsToSrtTime(ln.outPt) + '\n' + ln.text + '\n\n';
        }
        var f = File.saveDialog('Export SRT', 'SRT files:*.srt');
        if (!f) return 'cancelled';
        if (!/\.srt$/i.test(f.name)) f = new File(f.fsName + '.srt');
        f.encoding = 'UTF-8';
        if (!f.open('w')) return 'error:Cannot write to ' + f.fsName;
        f.write(srt);
        f.close();
        return 'ok:' + f.fsName;
    } catch(e) {
        return 'error:' + e.message;
    }
}

function whisperImportSRT() {
    try {
        var f = File.openDialog('Import SRT', 'SRT files:*.srt');
        if (!f) return 'cancelled';
        f.encoding = 'UTF-8';
        f.open('r');
        var text = f.read(); f.close();
        if (!text || text.length < 10) return 'error:File is empty or too short';
        text = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n');
        text = text.replace(/^\uFEFF/, ''); // strip BOM
        var rawBlocks = text.split(/\n\n+/);
        var lines = [];
        for (var i = 0; i < rawBlocks.length; i++) {
            if (typeof rawBlocks[i] !== 'string') continue;
            var block = rawBlocks[i].replace(/^\s+|\s+$/g, '');
            if (!block) continue;
            var parts = block.split('\n');
            if (parts.length < 3) continue;
            var timeLine = parts[1];
            // Try multiple timecode patterns
            var timeMatch = timeLine.match(/(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})\s*-->\s*(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})/);
            if (!timeMatch) continue;
            var inPt = parseInt(timeMatch[1],10)*3600 + parseInt(timeMatch[2],10)*60 + parseInt(timeMatch[3],10) + parseInt(timeMatch[4],10)/1000;
            var outPt = parseInt(timeMatch[5],10)*3600 + parseInt(timeMatch[6],10)*60 + parseInt(timeMatch[7],10) + parseInt(timeMatch[8],10)/1000;
            var lineText = parts.slice(2).join('\n').replace(/^\s+|\s+$/g, '');
            if (!lineText) continue;
            lines.push({text: lineText, inPt: inPt, outPt: outPt});
        }
        return JSON.stringify({lines: lines, count: lines.length});
    } catch(e) {
        return 'error:' + e.message;
    }
}

/**
 * Generate text layers from whisper data
 * payload = { lines:[{text,inPt,outPt}], posY, isRTL, autoBox, boxParams }
 */
function whisperGenerateLayers(payloadJSON) {
    var payload;
    try { payload = JSON.parse(payloadJSON); }
    catch(e) { return '0'; }

    var comp = getComp();
    if (!comp) return 'NO_COMP';

    var lines    = payload.lines   || [];
    var posY     = payload.posY    || 0.85;
    var isRTL    = payload.isRTL   || false;
    var autoBox  = payload.autoBox || false;
    var fontSize = payload.fontSize   || 28;
    var fontFamily = payload.fontFamily || 'Arial';
    var boxParams= payload.boxParams || {};

    app.beginUndoGroup('Whisper Generate Layers');

    var count = 0;
    for (var i = 0; i < lines.length; i++) {
        var item  = lines[i];
        if (!item.text || item.outPt <= item.inPt) continue;

        try {
            // Add text layer
            var layer = comp.layers.addText(item.text);
            layer.name     = 'SUB_' + (i + 1) + '_' + item.text.substring(0, 20);
            layer.inPoint  = item.inPt;
            layer.outPoint = item.outPt;

            // Text formatting FIRST (before reading sourceRect)
            var textProp = layer.property('Source Text');
            var textDoc  = textProp.value;
            // Always center the paragraph — Arabic or English alike
            textDoc.justification = ParagraphJustification.CENTER_JUSTIFY;
            if (!payload.charPanel) {                         // 3.25.1: on = keep AE's Character panel style
                try { textDoc.fontSize = fontSize; } catch(e) {}
                try { textDoc.font = fontFamily; } catch(e) {}
            }
            textProp.setValue(textDoc);

            // Center anchor point on text bounding box (robust to any
            // initial anchor position — the text stays exactly at target)
            var src        = layer.sourceRectAtTime(item.inPt, false);
            var scx        = src.left + src.width  / 2;
            var scy        = src.top  + src.height / 2;
            var anchorProp = layer.property('Transform').property('Anchor Point');
            var posProp    = layer.property('Transform').property('Position');
            var oldAnchor  = anchorProp.value;
            anchorProp.setValue([oldAnchor[0] + scx, oldAnchor[1] + scy]);
            posProp.setValue([
                comp.width / 2 + scx,
                comp.height * posY + scy
            ]);

            // Auto-generate box if requested
            if (autoBox) {
                try { createBoxForLayer(comp, layer, boxParams); } catch(e) {}
            }

            count++;
        } catch(e) { /* skip */ }
    }

    app.endUndoGroup();
    return String(count);
}

// ─────────────────────────────────────────────────────────────
//  TEXT ANIMATION — applies keyframes to selected text layers
// ─────────────────────────────────────────────────────────────

function applyTextAnimations(paramsJSON) {
    var params;
    try { params = JSON.parse(paramsJSON); }
    catch(e) { return '0'; }

    var comp = getComp();
    if (!comp) return 'NO_COMP';

    var animStyle = params.animStyle  || 'fade';
    var duration  = params.duration   || 8;
    var offset    = params.offset     || 2;
    var easing    = params.easing     || 'Ease Out';
    var mirrorOut = params.mirrorOut  !== false;

    // Get selected text layers — fallback to all text layers
    var layers = [];
    for (var i = 1; i <= comp.numLayers; i++) {
        var l = comp.layer(i);
        if (l instanceof TextLayer && l.selected) layers.push(l);
    }
    if (layers.length === 0) {
        for (var i = 1; i <= comp.numLayers; i++) {
            var l = comp.layer(i);
            if (l instanceof TextLayer) layers.push(l);
        }
    }
    if (layers.length === 0) return '0';

    app.beginUndoGroup('Apply Text Animation');

    var fps      = comp.frameRate;
    var frameSec = 1 / fps;
    var durSec   = duration  * frameSec;
    var offSec   = offset    * frameSec;
    var count    = 0;

    var easeOut = new KeyframeEase(0.5, 66);
    var easeIn  = new KeyframeEase(0.5, 33);

    function applyEase(prop, idx) {
        try {
            if (easing === 'Ease Out') prop.setTemporalEaseAtKey(idx, [easeIn],  [easeOut]);
            else if (easing === 'Ease In Out') prop.setTemporalEaseAtKey(idx, [easeOut], [easeOut]);
        } catch(e) {}
    }

    for (var li = 0; li < layers.length; li++) {
        var layer = layers[li];
        var inPt  = layer.inPoint;
        var outPt = layer.outPoint;

        var opacProp  = layer.property('Transform').property('Opacity');
        var scaleProp = layer.property('Transform').property('Scale');
        var posProp   = layer.property('Transform').property('Position');

        try {
            if (animStyle === 'fade') {
                opacProp.setValueAtTime(inPt - offSec, 0);
                opacProp.setValueAtTime(inPt - offSec + durSec, 100);
                applyEase(opacProp, 1);
                if (mirrorOut) {
                    opacProp.setValueAtTime(outPt - durSec, 100);
                    opacProp.setValueAtTime(outPt, 0);
                }
            }
            else if (animStyle === 'scale') {
                scaleProp.setValueAtTime(inPt - offSec, [0, 0]);
                scaleProp.setValueAtTime(inPt - offSec + durSec, [100, 100]);
                applyEase(scaleProp, 1);
                if (mirrorOut) {
                    scaleProp.setValueAtTime(outPt - durSec, [100, 100]);
                    scaleProp.setValueAtTime(outPt, [0, 0]);
                }
            }
            else if (animStyle === 'slide-up') {
                var basePos = posProp.value;
                posProp.setValueAtTime(inPt - offSec, [basePos[0], basePos[1] + 40]);
                posProp.setValueAtTime(inPt - offSec + durSec, basePos);
                opacProp.setValueAtTime(inPt - offSec, 0);
                opacProp.setValueAtTime(inPt - offSec + durSec, 100);
                applyEase(posProp, 1);
                if (mirrorOut) {
                    posProp.setValueAtTime(outPt - durSec, basePos);
                    posProp.setValueAtTime(outPt, [basePos[0], basePos[1] + 40]);
                    opacProp.setValueAtTime(outPt - durSec, 100);
                    opacProp.setValueAtTime(outPt, 0);
                }
            }
            else if (animStyle === 'slide-left') {
                var basePos2 = posProp.value;
                posProp.setValueAtTime(inPt - offSec, [basePos2[0] + 60, basePos2[1]]);
                posProp.setValueAtTime(inPt - offSec + durSec, basePos2);
                opacProp.setValueAtTime(inPt - offSec, 0);
                opacProp.setValueAtTime(inPt - offSec + durSec, 100);
                applyEase(posProp, 1);
                if (mirrorOut) {
                    posProp.setValueAtTime(outPt - durSec, basePos2);
                    posProp.setValueAtTime(outPt, [basePos2[0] + 60, basePos2[1]]);
                    opacProp.setValueAtTime(outPt - durSec, 100);
                    opacProp.setValueAtTime(outPt, 0);
                }
            }
            else if (animStyle === 'wipe') {
                scaleProp.setValueAtTime(inPt - offSec, [0, 100]);
                scaleProp.setValueAtTime(inPt - offSec + durSec, [100, 100]);
                applyEase(scaleProp, 1);
                if (mirrorOut) {
                    scaleProp.setValueAtTime(outPt - durSec, [100, 100]);
                    scaleProp.setValueAtTime(outPt, [0, 100]);
                }
            }
            else if (animStyle === 'bounce') {
                var bounceEase = new KeyframeEase(0.8, 80);
                scaleProp.setValueAtTime(inPt - offSec, [0, 0]);
                scaleProp.setValueAtTime(inPt - offSec + durSec, [110, 110]);
                scaleProp.setValueAtTime(inPt - offSec + durSec * 1.4, [100, 100]);
                try { scaleProp.setTemporalEaseAtKey(2, [bounceEase], [bounceEase]); } catch(e) {}
                if (mirrorOut) {
                    scaleProp.setValueAtTime(outPt - durSec, [100, 100]);
                    scaleProp.setValueAtTime(outPt, [0, 0]);
                }
            }
            count++;
        } catch(e) { /* skip */ }
    }

    app.endUndoGroup();
    return String(count);
}


// ═══════════════════════════════════════════════════════════
//  AUDIO ENHANCE FUNCTIONS
// ═══════════════════════════════════════════════════════════

// 3.27.0 (A-07): the chosen python.exe is per PC → %APPDATA%\Via Studios Kit\python_path.txt (not in the kit/git).
// The old file in audio_enhance\ is still read once (and copied over) so nothing has to be set again.
function weloPyCfgFile() {
    var d = new Folder(Folder.userData.fsName + '\\Via Studios Kit');
    if (!d.exists) d.create();
    return new File(d.fsName + '\\python_path.txt');
}
function weloReadLine(f) {
    try {
        if (!f.exists) return '';
        f.encoding = 'UTF-8'; f.open('r');
        var p = f.read().replace(/[\r\n]/g, ''); f.close();
        return p;
    } catch (e) { try { f.close(); } catch (e2) {} return ''; }
}
function audioGetPythonPath() {
    try {
        var p = weloReadLine(weloPyCfgFile());
        if (p && new File(p).exists) return p;
        var old = weloReadLine(new File(weloExtDir() + '\\audio_enhance\\python_path.txt'));
        if (old && new File(old).exists) { audioSavePythonPath(old); return old; }
        return '';
    } catch(e) { return ''; }
}

function audioSavePythonPath(pyPath) {
    try {
        var cfgFile = weloPyCfgFile();
        cfgFile.encoding = 'UTF-8'; cfgFile.open('w');
        cfgFile.write(pyPath); cfgFile.close();
        return 'ok';
    } catch(e) { return 'error:' + e.message; }
}

function getPythonPath() {
    var home = $.getenv('USERPROFILE') || 'C:\\Users\\user';
    var saved = audioGetPythonPath();
    var cands = [
        saved,
        // User install (default)
        // 3.26.2 (A-07): 3.12 first — the kit's libraries are installed there (setup_new_pc.bat); 3.13 often has none
        home + '\\AppData\\Local\\Programs\\Python\\Python312\\python.exe',
        home + '\\AppData\\Local\\Programs\\Python\\Python311\\python.exe',
        home + '\\AppData\\Local\\Programs\\Python\\Python313\\python.exe',
        home + '\\AppData\\Local\\Programs\\Python\\Python310\\python.exe',
        home + '\\AppData\\Local\\Programs\\Python\\Python39\\python.exe',
        // Machine install (winget --scope machine)
        'C:\\Program Files\\Python312\\python.exe',
        'C:\\Program Files\\Python311\\python.exe',
        'C:\\Program Files\\Python313\\python.exe',
        'C:\\Program Files\\Python310\\python.exe',
        'C:\\Program Files (x86)\\Python311\\python.exe',
        // Root installs
        'C:\\Python312\\python.exe',
        'C:\\Python313\\python.exe',
        'C:\\Python311\\python.exe',
        // Conda
        home + '\\anaconda3\\python.exe',
        home + '\\miniconda3\\python.exe'
    ];
    for (var i = 0; i < cands.length; i++) {
        if (cands[i] && cands[i].length > 4 && new File(cands[i]).exists) return cands[i];
    }
    // Last resort: ask Windows where python is
    try {
        var w = system.callSystem('where python');
        if (w) {
            var lines = w.split('\n');
            for (var li = 0; li < lines.length; li++) {
                var p = lines[li].replace(/[\r\n]/g, '');
                if (p && p.indexOf('python.exe') >= 0 && p.toLowerCase().indexOf('windowsapps') < 0 && new File(p).exists) return p;   // skip the Microsoft Store stub
            }
        }
    } catch(e) {}
    return '';
}

function audioPickFile() {
    var f = File.openDialog('Select Audio/Video File');
    return f ? f.fsName : 'cancelled';
}

// Audio Enhance source from AE: selected footage layer in the active comp, else selected Project item (3.13.1)
function audioGetSelectedMedia() {
    try {
        if (!app.project) return 'ERR:No project open';
        var src = null, it, i;
        var comp = app.project.activeItem;
        if (comp && comp instanceof CompItem && comp.selectedLayers.length > 0) {
            it = comp.selectedLayers[0].source;
            if (it && it instanceof FootageItem) src = it;
            else if (it && it instanceof CompItem) return 'ERR:Selected layer is a precomp - select the footage itself';
        }
        if (!src) {
            var sel = app.project.selection;
            for (i = 0; i < sel.length; i++) { if (sel[i] instanceof FootageItem) { src = sel[i]; break; } }
        }
        if (!src) return 'ERR:Select a video/audio layer in the comp, or the file in the Project panel';
        if (!src.mainSource || !src.mainSource.file) return 'ERR:' + src.name + ' is not a file (solid/placeholder)';
        if (!src.hasAudio) return 'ERR:' + src.name + ' has no audio';
        var f = src.mainSource.file;
        if (!f.exists) return 'ERR:File missing on disk: ' + f.fsName;
        return '{"path":"' + f.fsName.replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '","name":"' + src.name.replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '"}';
    } catch (e) { return 'ERR:' + e.toString(); }
}

// Replace audio in the timeline (3.16.0): for every layer in the active comp (and its precomps) that uses the
// ORIGINAL file, add the enhanced file with the same timing (start, stretch, time-remap, in/out) and mute the
// original layer's audio. Works because enhance.py keeps the output sample-exact with the source.
function aur__same(a, b) { return a.replace(/\//g, '\\').toLowerCase() === b.replace(/\//g, '\\').toLowerCase(); }
function aur__footage(path) {
    for (var i = 1; i <= app.project.numItems; i++) {
        var it = app.project.item(i);
        if (it instanceof FootageItem && it.mainSource && it.mainSource.file && aur__same(it.mainSource.file.fsName, path)) return it;
    }
    return app.project.importFile(new ImportOptions(new File(path)));
}
function aur__copyRemap(src, dst) {
    var a = src.property('ADBE Time Remapping'), b;
    dst.timeRemapEnabled = true;
    b = dst.property('ADBE Time Remapping');
    while (b.numKeys > 0) b.removeKey(1);
    for (var k = 1; k <= a.numKeys; k++) {
        b.setValueAtTime(a.keyTime(k), a.keyValue(k));
        try { b.setInterpolationTypeAtKey(k, a.keyInInterpolationType(k), a.keyOutInterpolationType(k)); } catch (e) {}
    }
}
function aur__walk(comp, orig, neu, seen, res) {
    if (seen[comp.id]) return; seen[comp.id] = true;
    var hit = false;
    for (var i = comp.numLayers; i >= 1; i--) {
        var L = comp.layer(i), s = L.source;
        if (!s) continue;
        if (s instanceof CompItem) { aur__walk(s, orig, neu, seen, res); continue; }
        if (!(s instanceof FootageItem) || !s.mainSource || !s.mainSource.file) continue;
        if (!aur__same(s.mainSource.file.fsName, orig) || !L.hasAudio) continue;
        var wasLocked = L.locked; L.locked = false;
        var N = comp.layers.add(neu);
        N.stretch = L.stretch;
        if (L.timeRemapEnabled) aur__copyRemap(L, N);
        N.startTime = L.startTime;
        N.inPoint = L.inPoint;
        N.outPoint = L.outPoint;
        // keep track mattes intact: never insert between a matte and the layer that uses it
        if (L.isTrackMatte) N.moveBefore(L); else if (L.trackMatteType !== TrackMatteType.NO_TRACK_MATTE) N.moveAfter(L); else N.moveBefore(L);
        N.name = L.name + ' [enhanced]';
        try { N.label = L.label; } catch (e1) {}
        try { N.comment = 'Audio Enhance: replaces the audio of "' + L.name + '"'; } catch (e2) {}
        L.audioEnabled = false;
        L.locked = wasLocked;
        res.layers++; hit = true;
    }
    if (hit) res.comps++;
}
function audioReplaceInComp(origPath, newPath) {
    app.beginUndoGroup('Welo: Replace audio with enhanced');
    try {
        var comp = app.project.activeItem;
        if (!(comp instanceof CompItem)) return 'ERR:Open the comp (timeline) that uses this video first';
        if (!new File(newPath).exists) return 'ERR:Enhanced file not found: ' + newPath;
        var neu = aur__footage(newPath);
        var res = { layers: 0, comps: 0 };
        aur__walk(comp, origPath, neu, {}, res);
        if (!res.layers) return 'ERR:No layer in this comp (or its precomps) uses ' + new File(origPath).displayName;
        return 'OK:' + res.layers + ' layer(s) in ' + res.comps + ' comp(s) now use the enhanced audio';
    } catch (e) {
        return 'ERR:' + e.toString() + ' line ' + e.line;
    } finally {
        app.endUndoGroup();
    }
}

function audioShowInExplorer(filePath) {
    try {
        var f = new File(filePath);
        if (f.exists) { system.callSystem('explorer.exe /select,"' + f.fsName + '"'); return 'ok'; }
        return 'not found';
    } catch(e) { return 'error'; }
}

function importAudioToAE(filePath) {
    try {
        var file = new File(filePath);
        if (!file.exists) return 'NOT_FOUND';
        app.beginUndoGroup('Import Enhanced Audio');
        app.project.importFile(new ImportOptions(file));
        app.endUndoGroup();
        return 'ok';
    } catch(e) { return 'ERROR:' + e.message; }
}

function whisperImportToComp(filePath) {
    try {
        var comp = app.project.activeItem;
        if (!comp || comp.typeName !== 'Composition') return 'NO_COMP';
        var file = new File(filePath);
        if (!file.exists) return 'NOT_FOUND';
        app.beginUndoGroup('Import Audio to Comp');
        var footage = app.project.importFile(new ImportOptions(file));
        comp.layers.add(footage);
        app.endUndoGroup();
        return 'ok';
    } catch(e) { return 'ERROR:' + e.message; }
}
// ═══════════════════════════════════════════════════════════
//  WELO TOOLS — FOOTAGE COLLECTOR
//  Functions prefixed with fc_ to avoid conflicts
// ═══════════════════════════════════════════════════════════

function fc_getUniqueName(destFolder, baseName) {
    var ext  = baseName.lastIndexOf(".") > -1 ? baseName.substring(baseName.lastIndexOf(".")) : "";
    var stem = ext ? baseName.slice(0, -ext.length) : baseName;
    var name = baseName, n = 1;
    while (new File(destFolder.fsName + "/" + name).exists) { name = stem + "_" + n + ext; n++; }
    return name;
}

function fc_classifyFile(name) {
    var n = name.toLowerCase();
    if (/\.(mp4|mov|avi|mkv|mxf|r3d|braw|m4v|wmv|flv|webm|mpeg|mpg|mts|m2t|m2ts)$/.test(n)) return "video";
    if (/\.(mp3|wav|aac|aiff|aif|flac|ogg|m4a|wma|caf|ac3|opus)$/.test(n))                   return "audio";
    if (/\.(psd|ai|eps|indd|sketch|fig|xd)$/.test(n))                                          return "design";
    if (/\.(cr2|cr3|nef|arw|orf|rw2|dng|raf|nrw|srw)$/.test(n))                               return "raw";
    if (/\.(jpg|jpeg|png|tif|tiff|bmp|gif|svg|exr|dpx|hdr|webp|tga|iff)$/.test(n))            return "raster";
    return "other";
}

function fc_subFolderName(type) {
    var map = { video:"videos", audio:"audio", raster:"photos", design:"design", raw:"raw", other:"other" };
    return map[type] || "other";
}

function fc_ensureFolder(path) {
    var f = new Folder(path);
    if (!f.exists) f.create();
    return f;
}

function fc_getProjectStats() {
    if (!app.project) return JSON.stringify({ success: false, error: "no project" });
    var items = app.project.items;
    var stats = { video:0, audio:0, raster:0, design:0, raw:0, other:0, missing:0, total:0 };
    var hash  = 0;
    var projFolder = "";
    try { if (app.project.file) projFolder = app.project.file.parent.fsName; } catch(e) {}
    for (var i = 1; i <= items.length; i++) {
        var item = items[i];
        if (!(item instanceof FootageItem)) continue;
        if (!item.mainSource || item.mainSource instanceof SolidSource) continue;
        var src = item.mainSource;
        if (!(src instanceof FileSource)) continue;
        hash += item.id;
        if (!src.file || !src.file.exists) { stats.missing++; }
        else { stats[fc_classifyFile(src.file.displayName)]++; }
        stats.total++;
    }
    // Comp stats — active composition
    var compStats = { video:0, audio:0, raster:0, design:0, raw:0, other:0, missing:0, name:"" };
    try {
        var activeComp = app.project.activeItem;
        if (activeComp && activeComp instanceof CompItem) {
            compStats.name = activeComp.name;
            var seen = {};
            for (var li = 1; li <= activeComp.numLayers; li++) {
                var layer = activeComp.layer(li);
                if (!(layer.source instanceof FootageItem)) continue;
                var fsrc = layer.source;
                if (!fsrc.mainSource || fsrc.mainSource instanceof SolidSource) continue;
                if (!(fsrc.mainSource instanceof FileSource)) continue;
                var ffile = fsrc.mainSource.file;
                if (!ffile) continue;
                if (seen[ffile.absoluteURI]) continue;
                seen[ffile.absoluteURI] = true;
                if (!ffile.exists) { compStats.missing++; }
                else { compStats[fc_classifyFile(ffile.displayName)]++; }
            }
        }
    } catch(e) {}
    return JSON.stringify({ success:true, stats:stats, compStats:compStats, hash:hash, projFolder:projFolder });
}

function fc_isSequence(item) {
    try {
        var src = item.mainSource;
        if (!(src instanceof FileSource)) return false;
        if (src.isStill === false) {
            var n = src.file ? src.file.displayName.toLowerCase() : '';
            if (/\.(jpg|jpeg|png|tif|tiff|bmp|exr|dpx|hdr|webp|tga|iff)$/.test(n)) return true;
        }
        return false;
    } catch(e) { return false; }
}

function fc_seqBaseName(fileName) {
    var base = fileName.replace(/\.[^.]+$/, '');
    base = base.replace(/[\[\(]?\d{2,}[\]\)]?$/, '');
    base = base.replace(/[_\-\s]+$/, '');
    return base || fileName.replace(/\.[^.]+$/, '');
}

function fc_collectSequence(item, destBase, moveFiles, seqGroupMode) {
    var src = item.mainSource;
    var srcFile = src.file;
    var srcFolder = srcFile.parent;
    var seqName = fc_seqBaseName(srcFile.displayName);
    var seqSubDir = seqGroupMode
        ? fc_ensureFolder(destBase + "/sequences/" + seqName)
        : fc_ensureFolder(destBase + "/sequences");
    var allFiles = srcFolder.getFiles();
    var ext = srcFile.displayName.replace(/^.*\./, '.').toLowerCase();
    var collected = [], firstNewFile = null;
    for (var fi = 0; fi < allFiles.length; fi++) {
        var ff = allFiles[fi];
        if (!(ff instanceof File)) continue;
        var ffName = ff.displayName.toLowerCase();
        var ffBase = ffName.replace(/\.[^.]+$/, '').replace(/[\[\(]?\d{2,}[\]\)]?$/, '').replace(/[_\-\s]+$/, '');
        if (ffName.indexOf(ext) === -1) continue;
        if (ffBase.toLowerCase() !== seqName.toLowerCase()) continue;
        var destF = new File(seqSubDir.fsName + "/" + ff.displayName);
        if (destF.exists && destF.length === ff.length) { if (!firstNewFile) firstNewFile = destF; continue; }
        try {
            if (moveFiles) {
                if (!ff.rename(destF.fsName)) { ff.copy(destF.fsName); if (destF.exists) { var orig2 = new File(ff.fsName); orig2.remove(); } }
            } else { ff.copy(destF.fsName); }
            if (!firstNewFile && destF.exists) firstNewFile = destF;
            collected.push(ff.displayName);
        } catch(e) {}
    }
    return { seqDir: seqSubDir, firstFile: firstNewFile, count: collected.length };
}

function fc_collectFootage(destPath, moveFiles, autoRelink, typesJson, seqGroupMode) {
    try {
    if (!app.project) return JSON.stringify({ success:false, error:"no project" });
    var allowedTypes = null;
    try { if (typesJson && typesJson !== "[]") allowedTypes = JSON.parse(typesJson); } catch(e) {}
    if (typeof seqGroupMode === 'undefined') seqGroupMode = true;
    var destDir = fc_ensureFolder(destPath);
    if (!destDir.exists) return JSON.stringify({ success:false, error:"Cannot create folder: " + destPath });
    var items = app.project.items, collected = [], missing = [];
    var stats = { video:0, audio:0, raster:0, sequence:0, design:0, raw:0, other:0 };
    var seenSeqFolders = {};
    var seenSrcURIs    = {};
    app.beginUndoGroup('Via Studios Collector');
    for (var i = 1; i <= items.length; i++) {
        var item = items[i];
        if (!(item instanceof FootageItem)) continue;
        if (!item.mainSource || item.mainSource instanceof SolidSource) continue;
        var src = item.mainSource;
        if (!(src instanceof FileSource)) continue;
        var srcFile = src.file;
        if (!srcFile || !srcFile.exists) {
            missing.push({ name:item.name, originalPath:srcFile ? srcFile.fsName : "(unknown)" });
            continue;
        }

        // ── Image Sequence ──────────────────────────────
        if (fc_isSequence(item)) {
            if (allowedTypes) {
                var okSeq = false;
                for (var ts = 0; ts < allowedTypes.length; ts++) { if (allowedTypes[ts] === "sequence") { okSeq = true; break; } }
                if (!okSeq) continue;
            }
            var seqKey = srcFile.parent.absoluteURI + "|" + fc_seqBaseName(srcFile.displayName);
            if (seenSeqFolders[seqKey]) {
                if (autoRelink && seenSeqFolders[seqKey].firstFile)
                    try { item.replace(seenSeqFolders[seqKey].firstFile); } catch(e) {}
                continue;
            }
            var seqResult = fc_collectSequence(item, destDir.fsName, moveFiles, seqGroupMode);
            seenSeqFolders[seqKey] = seqResult;
            if (autoRelink && seqResult.firstFile && seqResult.firstFile.exists)
                try { item.replace(seqResult.firstFile); } catch(e) {}
            stats.sequence++;
            collected.push({ name:item.name, type:"sequence", originalPath:srcFile.parent.fsName, newPath:seqResult.seqDir.fsName, frames:seqResult.count });
            continue;
        }

        // ── Regular file ────────────────────────────────
        var type      = fc_classifyFile(srcFile.displayName);
        var isLayered = (type === 'design');

        if (allowedTypes) {
            var ok = false;
            for (var t = 0; t < allowedTypes.length; t++) { if (allowedTypes[t] === type) { ok = true; break; } }
            if (!ok) continue;
        }

        // PSD/AI: skip duplicate layer-items pointing to same file
        var srcURI = srcFile.absoluteURI;
        if (isLayered) {
            if (seenSrcURIs[srcURI]) continue;
            seenSrcURIs[srcURI] = true;
        }

        var subDir   = fc_ensureFolder(destDir.fsName + "/" + fc_subFolderName(type));
        var destFile = new File(subDir.fsName + "/" + srcFile.displayName);
        var srcPath  = srcFile.fsName;

        if (destFile.exists && destFile.length === srcFile.length) {
            if (autoRelink && !isLayered) item.replace(destFile);
            stats[type]++;
            collected.push({ name:srcFile.displayName, type:type, originalPath:srcPath, newPath:destFile.fsName, skipped:true });
            continue;
        }

        var finalName = srcFile.displayName;
        if (destFile.exists) {
            finalName = fc_getUniqueName(subDir, srcFile.displayName);
            destFile  = new File(subDir.fsName + "/" + finalName);
        }

        try {
            if (isLayered) {
                // ── PSD/AI special handling ──────────────────
                if (moveFiles) {
                    // Move mode: rename to dest (AE goes offline automatically)
                    if (!srcFile.rename(destFile.fsName)) {
                        srcFile.copy(destFile.fsName);
                        if (destFile.exists) { var origL = new File(srcPath); origL.remove(); }
                    }
                } else {
                    // Copy mode: copy to dest, then rename original → filename_original.ext
                    srcFile.copy(destFile.fsName);
                    if (destFile.exists) {
                        // Rename original to make AE go offline
                        var ext2     = srcFile.displayName.replace(/^.*(\.[^.]+)$/, '$1');
                        var stem2    = srcFile.displayName.slice(0, srcFile.displayName.length - ext2.length);
                        var origName = stem2 + '_original' + ext2;
                        try { srcFile.rename(origName); } catch(e) {}
                    }
                }
                // Track design dest folder for Explorer open later
                stats[type]++;
                collected.push({ name:finalName, type:'design', originalPath:srcPath, newPath:destFile.fsName, layered:true });
            } else {
                // ── Regular file ─────────────────────────────
                if (moveFiles) {
                    if (!srcFile.rename(destFile.fsName)) {
                        srcFile.copy(destFile.fsName);
                        if (destFile.exists) { var orig = new File(srcPath); orig.remove(); }
                    }
                } else {
                    srcFile.copy(destFile.fsName);
                }
                if (autoRelink && destFile.exists) item.replace(destFile);
                stats[type]++;
                collected.push({ name:finalName, type:type, originalPath:srcPath, newPath:destFile.fsName });
            }
        } catch(e) {
            missing.push({ name:item.name, originalPath:srcPath, error:e.toString() });
        }
    }
    if (autoRelink && collected.length > 0) { try { app.project.save(); } catch(e) {} }
    app.endUndoGroup();

    // Open Explorer on design folder if any PSD/AI were collected
    if (stats.design > 0) {
        var designFolder = destDir.fsName + '\\design';
        try { system.callSystem('explorer.exe "' + designFolder + '"'); } catch(e) {}
    }

    return JSON.stringify({ success:true, collected:collected, missing:missing, stats:stats, total:collected.length + missing.length, hasLayered: stats.design > 0 });
    } catch(globalErr) {
        try { app.endUndoGroup(); } catch(e) {}
        return JSON.stringify({ success:false, error: globalErr.toString(), line: globalErr.line || 0 });
    }
}

function fc_selectFolder() {
    var f = Folder.selectDialog("Choose destination folder");
    return f ? f.fsName : "";
}

// ── Python path helpers ──────────────────────────────────
function detectPythonForUI() {
    var p = getPythonPath();
    return JSON.stringify({ found: p ? true : false, path: p || '' });
}

function savePythonPathFromUI(pyPath) {
    var p = pyPath.replace(/[\r\n]/g, '').replace(/^\s+|\s+$/g, '');
    if (!p) return 'error:empty';
    if (!new File(p).exists) return 'error:File not found: ' + p;
    audioSavePythonPath(p);
    return 'ok:' + p;
}

// ── Check all file/folder locations at once (for Settings panel) ──
function checkLocations(modelsDir, workDir) {
    var result = {};
    try {
        // Models folder
        var mdFolder = new Folder(modelsDir);
        result.modelsOk = mdFolder.exists;

        // Count .pt files
        var ptCount = 0;
        var ptNames = [];
        if (mdFolder.exists) {
            var ptFiles = mdFolder.getFiles(/\.pt$/i);
            ptCount = ptFiles ? ptFiles.length : 0;
            for (var i = 0; i < ptCount; i++) ptNames.push(ptFiles[i].displayName);
        }
        result.ptCount = ptCount;
        result.ptNames = ptNames;

        // Work folder
        var wkFolder = new Folder(workDir);
        result.workOk = wkFolder.exists;

        // WhisRend.wav
        var wavFile = new File(workDir + '\\WhisRend.wav');
        result.wavOk = wavFile.exists;
        result.wavAge = wavFile.exists ? Math.round((new Date().getTime() - wavFile.modified.getTime()) / 86400000 * 10) / 10 : null;

        // WhisRend.json
        var jsonFile = new File(workDir + '\\WhisRend.json');
        result.jsonOk = jsonFile.exists;
    } catch(e) {
        result.error = e.toString();
    }
    return JSON.stringify(result);
}

// ── Lib status check ─────────────────────────────────────
// NOTE: We cannot launch Python from inside AE reliably (system.callSystem with
// any external process hangs or silently fails in this environment). Instead we
// scan the Python site-packages folder directly and check extension files/ffmpeg.
// This needs NO external process, so it works 100% inside AE.
function getPythonLibStatus(extPathJson) {
    var pyExe = getPythonPath();
    if (!pyExe) return JSON.stringify({ error: 'Python not found — install Python 3.10+ from python.org or run: winget install Python.Python.3.12', python: '' });

    var bs = function(p) { return p.replace(/\//g, '\\'); };

    // Resolve extension dir RELIABLY from host.jsx location (jsx/.. = extension root).
    // Do NOT trust extPathJson (getSystemPath('extension') may return a different path).
    var extDir = '';
    try { extDir = weloExtDir(); } catch(e) {}
    if (!extDir) {
        try { extDir = JSON.parse(extPathJson); } catch(e) {}
    }
    // Hard fallback to the real fixed install location
    var FIXED = 'C:\\Program Files\\Common Files\\Adobe\\cep\\extensions\\com.welo.tools';
    if (!new Folder(FIXED).exists) FIXED = 'C:\\Program Files (x86)\\Common Files\\Adobe\\cep\\extensions\\com.welo.tools';
    if (!extDir || !new Folder(extDir).exists) extDir = FIXED;

    // Verify the expected subfolders/files exist; if extDir is wrong, walk up to find audio_enhance
    var ff = new File(bs(extDir + '\\ytdl\\ffmpeg.exe'));
    if (!ff.exists && new Folder(extDir + '\\..\\..\\..\\..').exists) {
        // try fixed path as last resort
        if (new File(bs(FIXED + '\\ytdl\\ffmpeg.exe')).exists) extDir = FIXED;
    }

    var root = new File(pyExe).parent.fsName;          // ...\Python312
    var spp  = bs(root + '\\Lib\\site-packages');      // site-packages

    // Collect all top-level names (folders AND files) inside site-packages
    var names = {};
    try {
        var spDir = new Folder(spp);
        if (spDir.exists) {
            var items = spDir.getFiles('*');
            for (var i = 0; i < items.length; i++) {
                var bn = items[i].name;
                names[bn.toLowerCase()] = true;
                var m = bn.match(/^([a-z_]+)/i);
                if (m) names[m[1].toLowerCase()] = true; // strip version/dist-info suffix
            }
        }
    } catch(e) {}

    function hasPkg(base) { return !!names[base.toLowerCase()]; }

    var r = {
        _v: '',
        soundfile: hasPkg('soundfile'),
        numpy: hasPkg('numpy'),
        torch: hasPkg('torch'),
        demucs: hasPkg('demucs'),
        deepfilternet: hasPkg('deepfilternet'),
        clearvoice: hasPkg('clearvoice'),
        audio_separator: hasPkg('audio_separator'),
        silero_vad: hasPkg('silero_vad'),
        transformers: hasPkg('transformers'),
        whisper: hasPkg('whisper'),
        qwen_asr: hasPkg('qwen'),
        cuda: false,
        cuda_ver: '',
        ffmpeg_bin: false,
        run_whisper: false,
        enhance_py: false,
        python: pyExe
    };

    // Python major.minor from install folder name (e.g. Python312 -> 3.12)
    var vm = root.match(/Python(\d)(\d+)$/i);
    if (vm) r._v = vm[1] + '.' + vm[2];

    // ffmpeg: bundled in extension, or in python root
    try { if (new File(bs(extDir + '\\ytdl\\ffmpeg.exe')).exists) r.ffmpeg_bin = true; } catch(e) {}
    try { if (new File(root + '\\ffmpeg\\bin\\ffmpeg.exe').exists) r.ffmpeg_bin = true; } catch(e) {}

    // enhance scripts bundled with extension
    try { if (new File(bs(extDir + '\\audio_enhance\\run_whisper.py')).exists) r.run_whisper = true; } catch(e) {}
    try { if (new File(bs(extDir + '\\audio_enhance\\enhance.py')).exists) r.enhance_py = true; } catch(e) {}

    // CUDA status: we cannot run nvidia-smi; only report torch presence.
    if (r.torch) { r.cuda_ver = 'torch installed (CUDA check runs on Render)'; }

    // ── Permissions probe (reveals if callSystem is allowed at all) ──
    try {
        var ctest = Folder.temp.fsName + '\\welo_calltest.txt';
        try { var co = new File(ctest); if (co.exists) co.remove(); } catch(e) {}
        var cok = false;
        try {
            var cRet = system.callSystem('cmd /c echo CALL_OK > "' + ctest + '"');
            cok = new File(ctest).exists;
        } catch(ce) {
            r.callsys_error = ce.toString();
        }
        r.callsys_ok = cok;
        if (!cok && !r.callsys_error) r.callsys_error = 'callSystem ran but produced no file';
    } catch(e) {
        r.callsys_error = 'probe error: ' + e.toString();
    }

    return JSON.stringify(r);
}


// Read the async check result file (polled by JS)
// Accepts a plain path string (double-escaped backslashes), returns JSON string.
function readCheckResult(outPathStr, pyExeStr) {
    try {
        if (!outPathStr) return JSON.stringify({ pending: true });
        var outFile = new File(outPathStr);
        if (!outFile.exists) return JSON.stringify({ pending: true });
        outFile.encoding = 'UTF-8'; outFile.open('r');
        var raw = outFile.read(); outFile.close();
        try { outFile.remove(); } catch(e) {}
        if (!raw) return JSON.stringify({ pending: true });
        var lns = raw.split('\n');
        var lastRes = null;
        for (var li = lns.length - 1; li >= 0; li--) {
            var line = lns[li].replace(/[\r\n]/g, '');
            if (line && line[0] === '{') {
                try { lastRes = JSON.parse(line); break; } catch(e) {}
            }
        }
        if (lastRes) {
            // Clean up the async temp files now that we have the result
            var base = outPathStr.replace(/welo_check_out\.txt$/, '');
            try { var p = new File(base + 'welo_check.py'); if (p.exists) p.remove(); } catch(e) {}
            try { var b = new File(base + 'welo_chk.bat'); if (b.exists) b.remove(); } catch(e) {}
            try { var v = new File(base + 'welo_chk_run.vbs'); if (v.exists) v.remove(); } catch(e) {}
            lastRes.python = pyExeStr || '';
            return JSON.stringify(lastRes);
        }
        return JSON.stringify({ error: raw.slice(0, 300), python: pyExeStr || '' });
    } catch(e) {
        return JSON.stringify({ error: 'readCheckResult error: ' + e.message });
    }
}

// ── Whisper status ───────────────────────────────────────
function getWhisperStatus(extPathJson) {
    try {
        var extDir = '';
        try { extDir = JSON.parse(extPathJson); } catch(e) {}
        if (!extDir) { try { extDir = weloExtDir(); } catch(e) {} }

        var pyExe  = getPythonPath();
        var scriptPath = extDir + '\\audio_enhance\\run_whisper.py';
        return JSON.stringify({
            python:     pyExe ? true : false,
            pythonPath: pyExe || 'Not found',
            runScript:  new File(scriptPath).exists,
            scriptPath: scriptPath
        });
    } catch(e) { return JSON.stringify({ error: e.message }); }
}

// ── Install single library via CMD ──────────────────────
// Takes 4 plain string args (NOT JSON) because ExtendScript lacks JSON.parse here.
function installSingleLib(key, label, pip, uninstall) {
    try {
        var pyExe = getPythonPath();
        if (!pyExe) return 'error:Python not found';

        var bs = function(p) { return p.replace(/\//g, '\\'); };

        var deskDir = 'C:\\Users\\' + ($.getenv('USERNAME') || 'user') + '\\Desktop';
        try { new Folder(deskDir).create(); } catch(e) {}
        var bat = new File(bs(deskDir + '\\ViaStudios_Install_' + (key||'lib') + '.bat'));
        var py  = bs(pyExe);
        var lines = [
            '@echo off',
            'title Via Studios Kit - Installing ' + label,
            'echo.',
            'echo  Installing ' + label + '...',
            'echo.',
            'set "PATH=%USERPROFILE%\\.cargo\\bin;%PATH%"'   // Rust (DeepFilterNet build) even if AE started before rustup was installed
        ];
        if (uninstall) {
            lines.push('echo  Removing old version first...');
            lines.push('"' + py + '" -m pip uninstall ' + uninstall + ' -y 2>nul');
            lines.push('echo.');
        }
        var aeDir = bs(weloExtDir()) + '\\audio_enhance\\';
        if (key === 'deepfilternet') lines.push('call "' + aeDir + 'install_build_tools.bat"');   // Rust + C++ tools (L-026)
        var con = new File(aeDir + 'constraints.txt').exists ? ' -c "' + aeDir + 'constraints.txt"' : '';
        lines.push('"' + py + '" -m pip install ' + pip + con);   // constraints.txt = versions that work together
        lines.push('echo.');
        lines.push('echo  Done! Then click Check in the extension.');
        lines.push('echo.');
        lines.push('pause');

        // Try writing the bat; catch silent failures (e.g. permission denied).
        var okWrite = false;
        try {
            bat.encoding = 'UTF-8';
            okWrite = bat.open('w');
            if (okWrite) { okWrite = bat.write(lines.join('\r\n')); bat.close(); }
            else { try { bat.close(); } catch(e2) {} }
        } catch(we) {
            okWrite = false;
        }
        if (!okWrite) {
            return 'error:Cannot write install script to Desktop — check AE preference "Allow Scripts to Write Files and Access Network" (Edit › Preferences › Scripting & Expressions), restart AE, and retry.';
        }

        // Auto-launch the bat DETACHED via explorer.exe (uses the .bat default handler,
        // which opens its own CMD console). explorer.exe returns instantly and does NOT
        // inherit the callSystem console handles, so AE never freezes while pip runs.
        try {
            system.callSystem('explorer.exe "' + bat.fsName + '"');
        } catch(ce) {
            return 'error:Failed to launch CMD: ' + ce.toString() + ' — enable "Allow Scripts to Write Files and Access Network" in AE preferences, restart AE, then retry.';
        }
        return 'opened:' + bat.fsName;
    } catch(e) {
        return 'error:' + (e && e.message ? e.message : String(e));
    }
}

// ── pip installer ────────────────────────────────────────
// AE cannot launch external processes here, so we GENERATE a .bat on the Desktop
// and return its path; the user double-clicks it to run the full install.
function runPipInstall(useCuda) {
    // 3.23.0: one shared installer (audio_enhance\install_libs.bat, also used by setup_new_pc.bat) with
    // constraints.txt so every PC gets versions that work together (L-026). This bat only launches it.
    var pyExe = getPythonPath();
    if (!pyExe) return 'error:Python not found';
    var bs  = function(p) { return p.replace(/\//g, '\\'); };
    var lib = bs(weloExtDir()) + '\\audio_enhance\\install_libs.bat';
    if (!new File(lib).exists) return 'error:install_libs.bat not found in ' + bs(weloExtDir()) + '\\audio_enhance';
    var deskDir = 'C:\\Users\\' + ($.getenv('USERNAME') || 'user') + '\\Desktop';
    try { new Folder(deskDir).create(); } catch(e) {}
    var bat = new File(bs(deskDir + '\\ViaStudios_Install_All.bat'));
    var body = [
        '@echo off',
        'title Via Studios Kit - Installing Python Libraries',
        'call "' + lib + '" "' + bs(pyExe) + '" ' + (useCuda ? 'cuda' : 'cpu'),
        'echo.',
        'echo  Done. Close this window, then click Check Everything.',
        'pause'
    ];
    var ok = false;
    try { bat.encoding = 'UTF-8'; ok = bat.open('w'); if (ok) { ok = bat.write(body.join('\r\n')); bat.close(); } } catch (we) { ok = false; }
    if (!ok) return 'error:Cannot write the installer to the Desktop — enable Edit › Preferences › Scripting & Expressions › Allow Scripts to Write Files and Access Network, restart AE';
    try { system.callSystem('explorer.exe "' + bat.fsName + '"'); } catch(e) {}
    return 'opened:' + bat.fsName;
}


// ── Paths for audio enhance ────────────────────────────
function getEnhancePaths(inputPath, extDir) {
    try {
        var pyExe = getPythonPath();
        if (!pyExe) return JSON.stringify({ error: 'Python not found. Go to Settings and set Python path.' });
        var bs = function(p) { return p.replace(/\//g, '\\'); };
        var scriptPath = bs(extDir) + '\\audio_enhance\\enhance.py';
        if (!new File(scriptPath).exists) return JSON.stringify({ error: 'enhance.py not found at: ' + scriptPath });
        var inp     = bs(inputPath);
        var inpFile = new File(inp);
        if (!inpFile.exists) return JSON.stringify({ error: 'Input file not found: ' + inp });
        var outDir  = inpFile.parent.fsName;
        var stem    = inpFile.displayName.replace(/\.[^.]+$/, '');   // .name is URI-encoded (space -> %20) -> wrong output name (L-020)
        // always WAV (24-bit 48k): a video input must never get an audio stream written into .mp4/.mov (3.13.0)
        var output  = outDir + '\\' + stem + '_enhanced.wav';
        var optsFile = bs($.getenv('TEMP') || 'C:\\Windows\\Temp') + '\\welo_opts.json';
        return JSON.stringify({
            python:   pyExe,
            script:   scriptPath,
            input:    inp,
            output:   output,
            optsFile: optsFile,
            extDir:   bs(extDir)
        });
    } catch(e) { return JSON.stringify({ error: e.message }); }
}

function writeOptsFile(optsJson, optsPath) {
    try {
        var f = new File(optsPath);
        f.encoding = 'UTF-8'; f.open('w'); f.write(optsJson); f.close();
        return 'ok';
    } catch(e) { return 'error:' + e.message; }
}

function saveAudioLog(logContent) {
    try {
        var extDir  = weloExtDir();
        var logFile = new File(extDir + '\\audio_enhance\\enhance.log');
        logFile.encoding = 'UTF-8'; logFile.open('w'); logFile.write(logContent); logFile.close();
        return 'ok';
    } catch(e) { return 'error:' + e.message; }
}

function getAudioLog() {
    try {
        var extDir  = weloExtDir();
        var logFile = new File(extDir + '\\audio_enhance\\enhance.log');
        if (!logFile.exists) return 'No log yet.';
        logFile.encoding = 'UTF-8'; logFile.open('r');
        var c = logFile.read(); logFile.close();
        return c || '(empty)';
    } catch(e) { return 'Error: ' + e.message; }
}

// ─────────────────────────────────────────────────────────────
//  VIDEO DOWNLOADER (yt-dlp) — project path & import helper
// ─────────────────────────────────────────────────────────────

function ytdlExtPath() {
    try {
        var root = weloExtDir();
        if (!root) return 'ERR:no ext dir';
        return 'OK:' + root;
    } catch(e) { return 'ERR:' + e.toString(); }
}

function ytdlGetProjectPath() {
    try {
        if (!app.project) return 'ERR:no project';
        if (!app.project.file) return 'UNSAVED';
        return 'OK:' + app.project.file.parent.fsName;
    } catch(e) { return 'ERR:' + e.message; }
}

function ytdlImportFile(p) {
    try {
        if (!app.project) return 'ERR:Open a project first';
        var f = new File(p);
        if (!f.exists) return 'ERR:File not found';
        var io = new ImportOptions(f);
        io.importAs = ImportAsType.FOOTAGE;
        var it = app.project.importFile(io);
        return 'OK:' + it.name;
    } catch(e) { return 'ERR:' + e.toString(); }
}

function ytdlPickFolder() {
    try {
        var d = Folder.selectDialog('Choose download folder');
        if (!d) return 'CANCEL';
        return 'OK:' + d.fsName;
    } catch(e) { return 'ERR:' + e.toString(); }
}

//@include "host_wpm.jsx"
//@include "autoedit.jsx"
//@include "smartcrop.jsx"
//@include "montage.jsx"
//@include "keyer.jsx"
//@include "preview.jsx"
