@echo off
rem Via Studios Kit — Rust + Visual C++ Build Tools: needed ONCE to compile DeepFilterNet (DeepFilterLib has no
rem ready-made wheel for new Python versions). Safe to run again: skips what is already installed.
set "PATH=%USERPROFILE%\.cargo\bin;%PATH%"
where cargo >nul 2>nul && goto vs
echo  Installing Rust (rustup) ...
winget install -e --id Rustlang.Rustup --accept-package-agreements --accept-source-agreements
if exist "%USERPROFILE%\.cargo\bin\rustup.exe" "%USERPROFILE%\.cargo\bin\rustup.exe" default stable
:vs
powershell -NoProfile -Command "$v=Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'; if((Test-Path $v) -and (& $v -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath)){exit 0}else{exit 1}"
if not errorlevel 1 goto ok
echo  Installing Visual C++ Build Tools (one time, 2-5 GB, 10-30 min - a Windows permission prompt may appear) ...
winget install -e --id Microsoft.VisualStudio.2022.BuildTools --accept-package-agreements --accept-source-agreements --override "--quiet --wait --add Microsoft.VisualStudio.Workload.VCTools --includeRecommended"
:ok
where cargo >nul 2>nul && echo  Rust: OK || echo  Rust: NOT FOUND - open a new window and run this again
exit /b 0
