// ── AUTO EDIT (ExtendScript, ES3) ─────────────────────────────
// Included from host.jsx. Panel side: js/autoedit.js. Plan: docs/AUTO-EDIT-PLAN.md
// All functions return a string: JSON on success, "ERR:..." on failure.


// M1: list selected video footage in the Project panel
function ae_getSelectedClips() {
    try {
        if (!app.project) return 'ERR:No project open';
        var sel = app.project.selection;
        var out = [];
        for (var i = 0; i < sel.length; i++) {
            var it = sel[i];
            if (!(it instanceof FootageItem)) continue;
            if (!it.hasVideo) continue;
            if (!it.mainSource || !it.mainSource.file) continue;
            if (it.mainSource.isStill) continue;
            out.push({
                id: it.id,
                name: it.name,
                path: it.mainSource.file.fsName,
                duration: it.duration,
                fps: it.frameRate,
                w: it.width,
                h: it.height,
                hasAudio: it.hasAudio
            });
        }
        if (out.length === 0) return 'ERR:Select video clips in the Project panel first';
        return JSON.stringify(out);
    } catch (e) {
        return 'ERR:' + e.toString() + ' line ' + e.line;
    }
}

// M2: python + whisper script + models dir for the panel's Node pipeline
function ae_getPythonInfo() {
    try {
        var ext = weloExtDir();
        var script = ext + '\\audio_enhance\\run_whisper.py';
        var py = getPythonPath();
        return JSON.stringify({
            python: py || '',
            script: new File(script).exists ? script : '',
            models: whisperModelsDir()
        });
    } catch (e) {
        return 'ERR:' + e.toString() + ' line ' + e.line;
    }
}

// M4: build the cut. data = {name, W, H, fps, dur, items:[{id,inT,outT,at,comment}], broll:[{id,inT,outT,at}]}
function ae__item(id) {
    try { if (app.project.itemByID) { var it = app.project.itemByID(id); if (it) return it; } } catch (e) {}
    for (var i = 1; i <= app.project.numItems; i++) if (app.project.item(i).id === id) return app.project.item(i);
    return null;
}
function ae__place(comp, src, inT, outT, at, W, H) {
    var L = comp.layers.add(src);
    L.moveToEnd();                                   // first clip stays on top of the timeline list
    L.startTime = at - inT;
    L.inPoint = at;
    L.outPoint = at + (outT - inT);
    var s = Math.max(W / src.width, H / src.height) * 100;
    if (Math.abs(s - 100) > 0.01) L.property('ADBE Transform Group').property('ADBE Scale').setValue([s, s]);
    return L;
}
function ae_buildAutoEdit(json) {
    app.beginUndoGroup('Welo: Auto Edit');
    try {
        var d = JSON.parse(json);
        if (!d.items || !d.items.length) return 'ERR:Nothing to build';
        var comp = app.project.items.addComp(d.name, d.W, d.H, 1, Math.max(d.dur, 1), d.fps);
        var i, x, src, L, missing = 0;
        for (i = 0; i < d.items.length; i++) {
            x = d.items[i];
            src = ae__item(x.id);
            if (!src) { missing++; continue; }
            L = ae__place(comp, src, x.inT, x.outT, x.at, d.W, d.H);
            if (x.zoom && x.zoom !== 100) {                  // punch-in to hide a jump cut inside one take (Claude Montage 3.20.0)
                var sp = L.property('ADBE Transform Group').property('ADBE Scale'), sv = sp.value;
                sp.setValue(sv.length === 3 ? [sv[0] * x.zoom / 100, sv[1] * x.zoom / 100, sv[2]] : [sv[0] * x.zoom / 100, sv[1] * x.zoom / 100]);
            }
            L.name = (i + 1) + ' ' + x.seg;
            if (x.comment) { try { L.comment = x.comment; } catch (e1) {} }   // reason kept as layer comment only (no marker on the footage)
        }
        var br = d.broll || [];
        for (i = 0; i < br.length; i++) {
            x = br[i];
            src = ae__item(x.id);
            if (!src) { missing++; continue; }
            L = ae__place(comp, src, x.inT, x.outT, x.at, d.W, d.H);
            L.moveToBeginning();                     // B-roll above the talking head
            L.name = 'B-roll ' + src.name;
            try { L.audioEnabled = false; } catch (e3) {}
        }
        // B-roll IDEAS: comp markers with duration (+ optional disabled guide placeholders on the timeline)
        var ID_LABEL = { image: 9, video: 8, graphic: 11, before_after: 13, before: 14, after: 3, text: 2, icon: 6 };
        var ideas = d.ideas || [], placed = 0;
        for (i = 0; i < ideas.length; i++) {
            x = ideas[i];
            try {
                var mv = new MarkerValue(x.label + ': ' + x.what);
                mv.duration = x.dur;
                try { mv.label = ID_LABEL[x.type] || 0; } catch (e4) {}
                comp.markerProperty.setValueAtTime(x.at, mv);
            } catch (e5) {}
            if (d.placeholders) {
                try {
                    var S = comp.layers.addSolid([0.2, 0.2, 0.2], 'B-ROLL ' + x.label + ': ' + x.what, d.W, d.H, 1, x.dur);
                    S.startTime = x.at; S.inPoint = x.at; S.outPoint = x.at + x.dur;
                    S.guideLayer = true; S.enabled = false;
                    try { S.label = ID_LABEL[x.type] || 0; } catch (e6) {}
                    try { S.comment = x.what; } catch (e7) {}
                    placed++;
                } catch (e8) {}
            }
        }
        comp.openInViewer();
        return 'OK:' + comp.name + (missing ? ' (' + missing + ' clip(s) missing from project)' : '');
    } catch (e) {
        return 'ERR:' + e.toString() + ' line ' + e.line;
    } finally {
        app.endUndoGroup();
    }
}
