@echo off
rem Replaced by setup_new_pc.bat (3.23.0, L-026) - the old steps force-reinstalled numpy/torch and broke other tools.
echo  This installer is retired. Running setup_new_pc.bat instead (needs "Run as administrator")...
call "%~dp0setup_new_pc.bat"
