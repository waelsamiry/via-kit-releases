// ── CLAUDE MONTAGE (panel) · 3.19.0 — host side jsx/montage.jsx, Python audio_enhance/montage_prep.py ──
// Day folder → Prepare (kit: transcripts + tone + picture sheets) → Claude Montage (Claude Code writes cut.json per
// episode) → Build (one comp per episode via ae_buildAutoEdit). The folder is model-neutral and portable (MONTAGE.md).
window.claudeMontage = (function () {
  var root = '', episodes = [], busy = false;
  function $(id) { return document.getElementById(id); }
  function cs() { return new CSInterface(); }
  function node() { return { fs: require('fs'), path: require('path'), cp: require('child_process'), os: require('os') }; }
  function status(msg, kind) { var el = $('mtStatus'); if (el) { el.textContent = msg; el.className = 'ae-status' + (kind ? ' is-' + kind : ''); } }
  function evalP(code) { return new Promise(function (res) { cs().evalScript(code, function (r) { res(String(r || '')); }); }); }
  var VID = /\.(mp4|mov|mkv|m4v|mxf|avi|mts|wav|mp3|m4a)$/i;
  var KEYS = ['mtTarget', 'mtAspect', 'mtStyle', 'mtLang', 'mtModel', 'mtNotes'];

  function save() {
    try { var o = { root: root }; KEYS.forEach(function (k) { var e = $(k); if (e) o[k] = e.value; }); window.weloCfg.set('montage_opts', JSON.stringify(o)); } catch (e) {}
  }
  function load() {
    try {
      var o = JSON.parse(window.weloCfg.get('montage_opts') || '{}');
      KEYS.forEach(function (k) { var e = $(k); if (e && o[k] !== undefined) e.value = o[k]; });
      if (o.root) root = o.root;
    } catch (e) {}
  }
  function mdir() { return node().path.join(root, 'montage'); }
  function epDir(ep) { return node().path.join(root, 'montage', 'episodes', ep); }

  function takesIn(dir) {                                    // = list_takes() in montage_prep.py
    try { return node().fs.readdirSync(dir).filter(function (f) { return VID.test(f) && f.charAt(0) !== '.'; }); } catch (e) { return []; }
  }
  function findEpisodes() {                                  // = find_episodes(): folder with videos = episode,
    var n = node(), out = [];                                // folder without = series → its sub-folders ("series/ep")
    (function walk(d, rel, depth) {
      var names = []; try { names = n.fs.readdirSync(d).sort(); } catch (e) { return; }
      names.forEach(function (f) {
        var p = n.path.join(d, f), st;
        if (f.charAt(0) === '.' || (depth === 0 && f.toLowerCase() === 'montage')) return;
        try { st = n.fs.statSync(p); } catch (e) { return; }
        if (!st.isDirectory()) return;
        var v = takesIn(p);
        if (v.length) out.push({ rel: rel + f, takes: v.length });
        else if (depth < 2) walk(p, rel + f + '/', depth + 1);
      });
    })(root, '', 0);
    return out;
  }
  // ── scan the day folder ──
  function scan() {
    episodes = [];
    var box = $('mtEpisodes'), lbl = $('mtFolder');
    if (lbl) lbl.textContent = root || 'No folder chosen';
    if (!root || typeof require !== 'function') { render(); return; }
    var n = node();
    try {
      findEpisodes().forEach(function (f) {
        var d = f.rel;
        var e = { name: d, takes: f.takes, prepared: n.fs.existsSync(n.path.join(epDir(d), 'transcript.json')), cut: null };
        var cj = n.path.join(epDir(d), 'cut.json');
        if (n.fs.existsSync(cj)) { try { e.cut = JSON.parse(n.fs.readFileSync(cj, 'utf8')); } catch (x) { e.cut = { bad: x.message }; } }
        episodes.push(e);
      });
    } catch (e) { status('⚠ ' + e.message, 'error'); }
    render();
  }
  function render() {
    var box = $('mtEpisodes'); if (!box) return;
    box.innerHTML = '';
    if (!root) { box.innerHTML = '<div class="ae-status">Choose the day folder — inside it one folder per episode with its takes.</div>'; return; }
    if (!episodes.length) { box.innerHTML = '<div class="ae-status is-warn">No episode folders with videos found.</div>'; return; }
    episodes.forEach(function (e, i) {
      var row = document.createElement('div'); row.className = 'ae-clip';
      var num = document.createElement('span'); num.className = 'ae-clip-num'; num.textContent = String(i + 1);
      var nm = document.createElement('span'); nm.className = 'ae-clip-name'; nm.dir = 'auto'; nm.textContent = e.name.replace(/\//g, ' › '); nm.title = e.name;
      var st = document.createElement('span'); st.className = 'ae-summary'; st.style.flex = 'none';
      var segs = e.cut && e.cut.segments ? e.cut.segments.length : 0;
      st.textContent = e.takes + ' take' + (e.takes > 1 ? 's' : '') + ' · ' + (e.prepared ? '✓ prepared' : '— not prepared') +
        (e.cut ? (e.cut.bad ? ' · ⚠ cut.json broken' : ' · ✓ cut v' + (e.cut.version || 1) + ' (' + segs + ')') : '');
      if (e.cut && !e.cut.bad && e.prepared) { row.style.cursor = 'pointer'; row.title = 'Click to review this cut'; row.onclick = function () { openReview(e.name); }; }
      if (revEp === e.name) row.style.outline = '1px solid var(--accent)';
      row.appendChild(num); row.appendChild(nm); row.appendChild(st); box.appendChild(row);
    });
    renderReview();
  }
  // ── Review (3.20.0): every picked sentence, on/off; what the repeat guard removed is shown and can be switched back on ──
  var revEp = '';
  function openReview(name) { revEp = name; renderReview(); }
  function renderReview() {
    var box = $('mtReview'); if (!box) return;
    box.innerHTML = '';
    var e = episodes.filter(function (x) { return x.name === revEp; })[0];
    if (!e || !e.cut || e.cut.bad || !e.prepared) { box.style.display = 'none'; return; }
    var p; try { p = planEpisode(e); } catch (x) { box.style.display = ''; box.textContent = '⚠ ' + x.message; return; }
    box.style.display = '';
    var head = document.createElement('div'); head.className = 'ae-row'; head.style.margin = '6px 0 4px';
    var ttl = document.createElement('span'); ttl.className = 'ae-section'; ttl.style.margin = '0'; ttl.dir = 'auto';
    ttl.textContent = 'Review · ' + e.name.replace(/\//g, ' › ') + ' · ' + fmt(p.total) + (brief().target ? ' / target ' + fmt(brief().target) : '') + (p.ums ? ' · ' + p.ums + ' اه cut' : '');
    var bb = document.createElement('button'); bb.className = 'btn-secondary'; bb.style.flex = 'none'; bb.textContent = 'Build this episode';
    bb.onclick = function () { build(e.name); };
    var cl = document.createElement('button'); cl.className = 'btn-secondary'; cl.style.flex = 'none'; cl.textContent = '×'; cl.title = 'Close review';
    cl.onclick = function () { revEp = ''; renderReview(); };
    head.appendChild(ttl); head.appendChild(bb); head.appendChild(cl); box.appendChild(head);
    if (p.notes.length || p.errs.length) {
      var nt = document.createElement('div'); nt.className = 'ae-status is-warn'; nt.style.margin = '0 0 4px';
      nt.textContent = (p.errs.length ? '⚠ ' + p.errs.join(' · ') + '\n' : '') + (p.notes.length ? 'Repeat guard: ' + p.notes.length + ' sentence(s) removed — greyed below, tick to keep.' : '');
      box.appendChild(nt);
    }
    var list = document.createElement('div'); list.className = 'ae-list';
    var rv = loadReview(e.name), lastN = 0;
    p.pieces.forEach(function (pc) {
      var row = document.createElement('div'); row.className = 'ae-edl' + (pc.drop ? ' is-off' : '');
      var top = document.createElement('div'); top.className = 'ae-edl-top';
      var cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = !pc.drop;
      cb.title = pc.drop ? 'Removed (' + (pc.reason || '') + ') — tick to keep' : 'Untick to remove this sentence';
      cb.onchange = function () {
        rv.on = rv.on.filter(function (x) { return x !== pc.id; }); rv.off = rv.off.filter(function (x) { return x !== pc.id; });
        if (cb.checked && pc.reason && pc.reason !== 'off (you)') rv.on.push(pc.id);     // keep despite the guard
        if (!cb.checked) rv.off.push(pc.id);
        saveReview(e.name, rv); renderReview();
      };
      var num = document.createElement('span'); num.className = 'ae-clip-num'; num.textContent = pc.n !== lastN ? '#' + pc.n : '';
      lastN = pc.n;
      var meta = document.createElement('span'); meta.className = 'ae-summary'; meta.style.flex = 'none';
      meta.textContent = pc.id + ' · ' + (pc.outT - pc.inT).toFixed(1) + 's' + (pc.drop && pc.reason ? ' · ' + pc.reason : '');
      top.appendChild(cb); top.appendChild(num); top.appendChild(meta);
      var tx = document.createElement('div'); tx.className = 'ae-edl-text'; tx.dir = 'auto'; tx.textContent = (pc.fixed ? '✎ ' : '') + pc.text + ((pc.hes || []).length ? '  · اه×' + pc.hes.length : '');
      if (pc.why && pc.n !== (row._n || 0)) tx.title = pc.why;
      row.appendChild(top); row.appendChild(tx); list.appendChild(row);
    });
    box.appendChild(list);
  }
  function fmt(t) { t = Math.round(t || 0); return Math.floor(t / 60) + ':' + ('0' + (t % 60)).slice(-2); }

  function pick() {
    evalP('montagePickFolder()').then(function (r) {
      if (!r || r === 'cancelled' || r.indexOf('ERR:') === 0) return;
      root = r; save(); scan(); checkClaude();
    });
  }

  // ── helpers: visible .bat runner (same pattern as Audio Enhance: UTF-8, %-escaped, log + progress file) ──
  function q(p) { return String(p).replace(/%/g, '%%'); }
  function tmpf(name) { return node().path.join(node().os.tmpdir(), name); }
  function runBat(lines, opts) {
    var n = node(), bat = tmpf(opts.name + '.bat');
    n.fs.writeFileSync(bat, '@echo off\r\nchcp 65001 > nul\r\nset PYTHONUTF8=1\r\n' + lines.join('\r\n') + '\r\n', 'utf8');
    var p = n.cp.spawn('cmd.exe', ['/c', 'start', '""', opts.wait ? '/wait' : '', 'cmd.exe', opts.keep ? '/k' : '/c', bat].filter(function (x) { return x !== ''; }));
    return p;
  }

  // ── 1 Prepare ──
  function prepare() {
    if (busy) return;
    if (!root) { status('Choose the day folder first', 'error'); return; }
    if (typeof require !== 'function') { status('Node.js is off — restart After Effects', 'error'); return; }
    save();
    var fresh = !!($('mtFresh') || {}).checked;
    busy = true; status('Preparing… (CMD window: transcripts, voice analysis, picture sheets)', 'working');
    var n = node();
    evalP('ae_getPythonInfo()').then(function (r) {
      if (r.indexOf('ERR:') === 0) throw new Error(r.slice(4));
      var info = JSON.parse(r);
      if (!info.python) throw new Error('Python not found — Settings');
      var script = n.path.join(n.path.dirname(info.script || ''), 'montage_prep.py');
      if (!n.fs.existsSync(script)) throw new Error('montage_prep.py not found');
      var prog = tmpf('welo_montage_progress.txt'), log = tmpf('welo_montage.log'), done = tmpf('welo_montage_exit.txt');
      [prog, log, done].forEach(function (f) { try { n.fs.unlinkSync(f); } catch (e) {} });
      var ff = window.weloTools && window.weloTools.dirOf('ffmpeg');
      var lines = [
        'title Via Studios Kit - Claude Montage - Prepare',
        ff ? 'set "WELO_FFMPEG_DIR=' + q(ff) + '"' : '',
        'set "WELO_PROGRESS=' + q(prog) + '"', 'set "WELO_LOG=' + q(log) + '"',
        '"' + q(info.python) + '" "' + q(script) + '" "' + q(root) + '" ' + (($('mtModel') || {}).value || 'small') + ' "' +
          ((($('mtLang') || {}).value === 'auto') ? '' : ($('mtLang') || {}).value) + '" "' + q(info.models || '') + '"' + (fresh ? ' --fresh' : ''),
        'echo %ERRORLEVEL% > "' + q(done) + '"',
        'if not %ERRORLEVEL%==0 (echo FAILED - see above & pause)'
      ].filter(Boolean);
      var poll = setInterval(function () {
        var t = ''; try { t = n.fs.readFileSync(prog, 'utf8'); } catch (e) { return; }
        var d = (t.match(/WELO_STEP:\d+:done/g) || []).length, tot = (t.match(/# (\d+) episode/) || [0, '?'])[1];
        status('Preparing… ' + d + '/' + tot + ' episode(s) done', 'working');
      }, 800);
      var p = runBat(lines, { name: 'welo_montage_prep', wait: true });
      p.on('close', function () {
        clearInterval(poll); busy = false;
        var code = 1; try { code = parseInt(n.fs.readFileSync(done, 'utf8'), 10); } catch (e) {}
        scan();
        if (code === 0) status('✓ Prepared. Next: Claude Montage (or open this folder in any AI — MONTAGE.md explains everything).', 'ok');
        else { var tail = ''; try { tail = n.fs.readFileSync(log, 'utf8').split(/\r?\n/).filter(Boolean).slice(-4).join(' | '); } catch (e) {} status('⚠ Prepare failed: ' + tail, 'error'); }
      });
    }).catch(function (e) { busy = false; status('⚠ ' + (e.message || e), 'error'); });
  }

  // ── 2 Claude Montage (Claude Code CLI, interactive window so you see it work and can talk to it) ──
  // Claude Code is often NOT on the PATH After Effects sees (native installer puts it in %USERPROFILE%\.local\bin and only
  // new processes get the updated PATH) → look in the known install places first, then `where`. (L-024)
  var claudeExe = '';
  function findClaude(cb) {
    var n = node(), env = process.env, home = env.USERPROFILE || n.os.homedir();
    var c = [
      n.path.join(home, '.local', 'bin', 'claude.exe'),
      n.path.join(env.APPDATA || '', 'npm', 'claude.cmd'),
      n.path.join(env.LOCALAPPDATA || '', 'Programs', 'claude', 'claude.exe'),
      n.path.join(env.LOCALAPPDATA || '', 'AnthropicClaude', 'claude.exe'),
      n.path.join(home, '.claude', 'local', 'claude.exe'),
      n.path.join(home, '.claude', 'local', 'claude.cmd')
    ];
    try { var saved = window.weloCfg.get('claude_exe'); if (saved) c.unshift(saved); } catch (e) {}
    for (var i = 0; i < c.length; i++) { try { if (c[i] && n.fs.existsSync(c[i])) return cb(c[i]); } catch (e) {} }
    n.cp.exec('where claude', { windowsHide: true }, function (err, out) {
      var line = (out || '').split(/\r?\n/).filter(function (l) { return /claude(\.exe|\.cmd)?\s*$/i.test(l.trim()); })[0];
      cb(!err && line ? line.trim() : '');
    });
  }
  function checkClaude(cb) {
    if (typeof require !== 'function') return;
    findClaude(function (exe) {
      claudeExe = exe;
      var el = $('mtClaudeState');
      if (el) {
        el.innerHTML = '';
        el.className = 'ae-status' + (exe ? ' is-ok' : ' is-error');
        el.appendChild(document.createTextNode(exe ? '✓ Claude Code: ' + exe : '✗ Claude Code not found on this PC. Install it (claude.ai/code), open a new CMD and type  claude  once to log in — or '));
        if (!exe) {
          var a = document.createElement('a'); a.href = '#'; a.textContent = 'choose claude.exe…';
          a.onclick = function (ev) { ev.preventDefault(); pickClaude(); };
          el.appendChild(a);
        }
      }
      if (cb) cb(!!exe);
    });
  }
  function pickClaude() {
    new CSInterface().evalScript("(function(){var f=File.openDialog('Where is claude.exe / claude.cmd?');return f?f.fsName:'';})()", function (p) {
      if (p && p !== 'EvalScript error.') { try { window.weloCfg.set('claude_exe', p); } catch (e) {} checkClaude(); }
    });
  }
  function brief() {
    return { target: parseFloat(($('mtTarget') || {}).value) || 0, aspect: ($('mtAspect') || {}).value || 'source',
             style: ($('mtStyle') || {}).value || 'talking', language: ($('mtLang') || {}).value || 'auto', notes: ($('mtNotes') || {}).value || '' };
  }
  var lenWarned = false;
  function runClaude() {
    if (!root) { status('Choose the day folder first', 'error'); return; }
    if (!brief().target && !lenWarned && !(($('mtRequest') || {}).value || '').trim()) {
      lenWarned = true;
      status('⚠ Length is empty → Claude keeps each episode at its natural length (can be 3–5 min). Set a length, or press ② again to continue.', 'warn');
      return;
    }
    lenWarned = false;
    if (!episodes.some(function (e) { return e.prepared; })) { status('Press Prepare first', 'error'); return; }
    save();
    checkClaude(function (ok) {
      if (!ok) { status('Install Claude Code first (see the line above)', 'error'); return; }
      var n = node(), req = (($('mtRequest') || {}).value || '').trim();
      var notPrep = episodes.filter(function (e) { return !e.prepared; }).map(function (e) { return e.name; });
      if (!req) req = episodes.some(function (e) { return e.cut; }) ? 'Review every episode cut against the brief and improve it.' :
        'Make the first cut of every episode in this folder.';
      var hasCuts = episodes.some(function (e) { return e.cut; }), userReq = !!(($('mtRequest') || {}).value || '').trim();
      var scope = (revEp && userReq) ? revEp : '';
      var follow = hasCuts && userReq ?
        '\n## Follow-up edit (save tokens)\n' +
        (scope ? '- This request is ONLY about episode `' + scope + '` (montage/episodes/' + scope + '/). Do not open or change other episodes.\n' :
                 '- Change only what the request asks; leave other episodes untouched.\n') +
        '- Read montage/STATE.md first, then only the files you need: that episode\'s cut.json and transcript.txt (sheets only if the request is about the picture). Do not re-read MONTAGE.md sections you already follow or re-plan the whole episode.\n' +
        '- Edit the existing cut.json (history + version as usual), log it in STATE.md, print a 2–3 line summary.\n' : '';
      var md = '# Request — ' + new Date().toLocaleString() + '\n\n' + req + '\n' + follow + '\n' +
        'Brief: see montage/brief.json (target ' + (brief().target || 'auto') + ' s per episode, aspect ' + brief().aspect + ').\n' +
        (notPrep.length ? '\nNot prepared yet (skip): ' + notPrep.join(', ') + '\n' : '') +
        '\nWhen done: update montage/STATE.md and print a short per-episode summary.\n' +
        '\nLanguage: write "why", "notes", STATE.md and your final summary in Arabic (Egyptian is fine) — the editor reads Arabic.\n';
      try {
        n.fs.mkdirSync(mdir(), { recursive: true });
        n.fs.writeFileSync(n.path.join(mdir(), 'brief.json'), JSON.stringify(brief(), null, 1), 'utf8');
        n.fs.writeFileSync(n.path.join(mdir(), 'request.md'), md, 'utf8');
      } catch (e) { status('⚠ ' + e.message, 'error'); return; }
      runBat([
        'title Claude Montage',
        'cd /d "' + q(root) + '"',
        // use the real Claude subscription for this window even if Claude Code was pointed at another provider/model (L-025)
        'set ANTHROPIC_BASE_URL=', 'set ANTHROPIC_AUTH_TOKEN=', 'set ANTHROPIC_API_KEY=', 'set ANTHROPIC_MODEL=', 'set ANTHROPIC_SMALL_FAST_MODEL=',
        'echo Claude is editing this folder. You can watch and talk to it here. When it is done, close this window and press Build in After Effects.',
        'echo.',
        '"' + q(claudeExe) + '" --model sonnet --permission-mode acceptEdits "Read MONTAGE.md, then montage/request.md, and do what the request asks, exactly following MONTAGE.md."'
      ], { name: 'welo_montage_claude', keep: true });
      status((scope ? 'Claude is editing only "' + scope + '" ' : 'Claude is working ') + 'in the CMD window. When it finishes: Refresh, then Build.', 'working');
    });
  }

  // ── 3 Build: validate every cut.json → import takes → one comp per episode (ae_buildAutoEdit) ──
  function readJSON(p) { return JSON.parse(node().fs.readFileSync(p, 'utf8')); }
  function reviewPath(ep) { return node().path.join(epDir(ep), 'review.json'); }
  function loadReview(ep) { try { var o = readJSON(reviewPath(ep)); return { on: o.on || [], off: o.off || [] }; } catch (e) { return { on: [], off: [] }; } }
  function saveReview(ep, rv) { try { node().fs.writeFileSync(reviewPath(ep), JSON.stringify(rv, null, 1), 'utf8'); } catch (e) { status('⚠ ' + e.message, 'error'); } }
  function planEpisode(e) {
    var n = node(), errs = [];
    var tj = readJSON(n.path.join(epDir(e.name), 'transcript.json'));
    var cut = readJSON(n.path.join(epDir(e.name), 'cut.json'));
    var rv = loadReview(e.name), on = {}, off = {}, fixes = {};
    try { var fp = n.path.join(epDir(e.name), 'fixes.json'); if (n.fs.existsSync(fp)) fixes = readJSON(fp) || {}; } catch (x) { errs.push('fixes.json: ' + x.message); }
    rv.on.forEach(function (x) { on[x] = 1; }); rv.off.forEach(function (x) { off[x] = 1; });
    var byId = {};
    tj.takes.forEach(function (t) { t.sentences.forEach(function (s, k) { byId[s.id] = { s: s, k: k, take: t }; }); });
    var segs = [], pieces = [];
    (cut.segments || []).forEach(function (g, i) {
      var a = byId[g.from], b = byId[g.to || g.from];
      if (!a || !b) { errs.push('#' + (i + 1) + ' unknown id ' + (a ? g.to : g.from)); return; }
      if (a.take !== b.take) { errs.push('#' + (i + 1) + ' from/to in different takes'); return; }
      if (b.k < a.k) { var t = a; a = b; b = t; }
      var s = a.s.s, en = b.s.e;
      if (g['in'] !== undefined && +g['in'] > s - 0.01 && +g['in'] < en) s = +g['in'];
      if (g.out !== undefined && +g.out > s && +g.out < en + 0.01) en = +g.out;
      if (a.take.duration) en = Math.min(en, a.take.duration);
      if (en - s < 0.15) { errs.push('#' + (i + 1) + ' too short'); return; }
      // one piece per sentence → a restart inside the picked range can be cut out (3.19.4)
      for (var k = a.k; k <= b.k; k++) {
        var st = a.take.sentences[k], ps = Math.max(st.s, s), pe = Math.min(st.e, en);
        if (pe - ps < 0.05) continue;
        var ws = (st.words || []).filter(function (w) { return w[1] >= ps - 0.05 && w[2] <= pe + 0.05; }).map(function (w) { return w[0]; });
        var hes = (st.hes || []).map(function (h) { return [Math.max(h[0], ps), Math.min(h[1], pe)]; }).filter(function (h) { return h[1] - h[0] >= 0.12; });
        pieces.push({ n: i + 1, k: k, id: st.id, file: a.take.file, inT: ps, outT: pe, words: ws, hes: hes, fixed: !!fixes[st.id],
                      text: fixes[st.id] || ws.join(' ') || st.text, why: String(g.why || '') });
      }
    });
    var auto = !!(($('mtDedupe') || {}).checked), notes = [];
    if (auto) notes = guardRestarts(pieces);
    pieces.forEach(function (p) {                                    // the editor's choices in the review win (3.20.0)
      if (off[p.id]) { p.drop = true; p.reason = 'off (you)'; p.forced = 1; }
      else if (on[p.id]) { p.drop = false; p.forced = 1; }
    });
    function group() {
      var out = [];
      pieces.filter(function (p) { return !p.drop; }).forEach(function (p) {     // regroup consecutive sentences of the same row
        var last = out[out.length - 1];
        if (last && last.n === p.n && last.file === p.file && p.k === last.k1 + 1) {   // keep the natural pause between kept sentences
          last.outT = p.outT; last.k1 = p.k; last.words = last.words.concat(nwList(p.words)); last.ids.push(p.id); last.hes = last.hes.concat(p.hes);
        } else out.push({ n: p.n, k1: p.k, file: p.file, path: n.path.join(root, e.name, p.file), inT: p.inT, outT: p.outT, ids: [p.id], words: nwList(p.words), hes: p.hes.slice(), why: p.why });
      });
      out.forEach(function (x) { x.inT = +x.inT.toFixed(3); x.outT = +x.outT.toFixed(3); x.seg = x.ids[0] + (x.ids.length > 1 ? '-' + x.ids[x.ids.length - 1].replace(/^T\d+_/, '') : ''); });
      return out;
    }
    segs = group();
    notes = notes.concat(guardRepeats(segs));
    var byPid = {}; pieces.forEach(function (p) { byPid[p.id] = p; });
    segs.forEach(function (x) {
      if (!x.drop) return;
      if (x.ids.some(function (id) { return on[id]; })) { x.drop = false; return; }       // you switched it back on
      x.ids.forEach(function (id) { var p = byPid[id]; if (p) { p.drop = true; p.reason = x.reason || 'repeat'; } });
    });
    segs = segs.filter(function (x) { return !x.drop; });
    var ums = 0;
    if (($('mtUms') || {}).checked) { var cu = cutUms(segs); segs = cu.segs; ums = cu.n; }
    var total = 0; segs.forEach(function (x) { total += x.outT - x.inT; });
    return { e: e, cut: cut, segs: segs, errs: errs, notes: notes, pieces: pieces, total: total, ums: ums, byId: byId, fixes: fixes };
  }
  // ── "اه / امم" cutter (3.24.0): hesitation sounds found by Prepare (text + acoustic) are cut out of every piece ──
  function cutUms(segs) {
    var out = [], cnt = 0, PAD = 0.03, MIN = 0.12;
    segs.forEach(function (x) {
      var hs = (x.hes || []).map(function (h) { return [Math.max(x.inT, h[0] + PAD), Math.min(x.outT, h[1] - PAD)]; })
        .filter(function (h) { return h[1] - h[0] >= MIN; }).sort(function (a, b) { return a[0] - b[0]; });
      if (!hs.length) { out.push(x); return; }
      var cur = x.inT, part = 0, subs = [];
      hs.forEach(function (h) {
        if (h[1] <= cur) return;
        if (h[0] - cur >= MIN) subs.push([cur, h[0]]);
        cur = Math.max(cur, h[1]); cnt++;
      });
      if (x.outT - cur >= MIN) subs.push([cur, x.outT]);
      if (!subs.length) { out.push(x); return; }
      subs.forEach(function (s) {
        var y = {}; for (var k in x) y[k] = x[k];
        y.inT = +s[0].toFixed(3); y.outT = +s[1].toFixed(3); part++;
        if (subs.length > 1) y.seg = x.seg + '·' + part;
        out.push(y);
      });
    });
    return { segs: out, n: cnt };
  }
  // subtitles of the built cut: one entry per sentence (Claude's fixes.json text when present), ≤ 7 words per line
  function srtTime(t) {
    t = Math.max(0, t); var ms = Math.round(t * 1000), h = Math.floor(ms / 3600000), m = Math.floor(ms / 60000) % 60, s = Math.floor(ms / 1000) % 60;
    return ('0' + h).slice(-2) + ':' + ('0' + m).slice(-2) + ':' + ('0' + s).slice(-2) + ',' + ('00' + ms % 1000).slice(-3);
  }
  function makeSrt(p) {
    var spans = {}, order = [];
    p.segs.forEach(function (x) {
      x.ids.forEach(function (id) {
        var b = p.byId[id]; if (!b) return;
        var s0 = Math.max(b.s.s, x.inT), s1 = Math.min(b.s.e, x.outT); if (s1 - s0 < 0.05) return;
        var c0 = x._at + (s0 - x.inT), c1 = x._at + (s1 - x.inT);
        if (!spans[id]) { spans[id] = [c0, c1]; order.push(id); } else { spans[id][0] = Math.min(spans[id][0], c0); spans[id][1] = Math.max(spans[id][1], c1); }
      });
    });
    var L = [], k = 0;
    order.sort(function (a, b) { return spans[a][0] - spans[b][0]; }).forEach(function (id) {
      var b = p.byId[id], txt = String(p.fixes[id] || b.s.text || '').trim(); if (!txt) return;
      var w = txt.split(/\s+/), groups = [];
      for (var i = 0; i < w.length; i += 7) groups.push(w.slice(i, i + 7).join(' '));
      var tot = 0; groups.forEach(function (g) { tot += g.length; });
      var t = spans[id][0], dur = spans[id][1] - spans[id][0];
      groups.forEach(function (g) {
        var d = dur * g.length / Math.max(1, tot);
        L.push(++k, srtTime(t) + ' --> ' + srtTime(t + d), g, ''); t += d;
      });
    });
    return L.join('\r\n');
  }
  // ── repeat guard (3.19.3): the AI judges from text and can still pick the same line twice ──
  function nw(w) {
    return String(w || '').toLowerCase().replace(/[\u064b-\u0652\u0640]/g, '').replace(/[إأآا]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').replace(/[^\u0600-\u06ffa-z0-9]/g, '');
  }
  var STOP = /^(يعني|اه|امم|ايه|و|ف|في|من|علي|عن|ان|ده|دي|اللي|هو|هي|the|a|and|so|um|uh)$/;
  function nwList(ws) { return ws.map(nw).filter(function (w) { return w.length > 1 && !STOP.test(w); }); }
  function share(a, b) {                     // share of the shorter list found in the other (words + 2-grams)
    if (a.length < 3 || b.length < 3) return 0;
    var sh = a.length <= b.length ? a : b, lo = sh === a ? b : a, set = {}, hit = 0, i;
    lo.forEach(function (w) { set[w] = 1; }); sh.forEach(function (w) { if (set[w]) hit++; });
    var bg = {}, bh = 0, bt = 0;
    for (i = 0; i + 1 < lo.length; i++) bg[lo[i] + ' ' + lo[i + 1]] = 1;
    for (i = 0; i + 1 < sh.length; i++) { bt++; if (bg[sh[i] + ' ' + sh[i + 1]]) bh++; }
    return Math.min(hit / sh.length, bt ? (bh / bt) + 0.25 : 1);
  }
  // light stem for comparing attempts: drop و / ال / لل prefixes
  function stem(w) { w = nw(w); if (w.length >= 3 && w.charAt(0) === 'و') w = w.slice(1); if (w.length > 4 && (w.indexOf('ال') === 0 || w.indexOf('لل') === 0)) w = w.slice(2); return w; }
  function content(ws) { return ws.map(stem).filter(function (w) { return w.length > 1 && !STOP.test(w) && w !== 'دي' && w !== 'ده'; }); }
  // same idea said again right after (false start / retake): same opening, or most words repeated → drop the EARLIER attempt
  function isRestart(A, B) {
    var a = content(A.words), b = content(B.words);
    if (!a.length || !b.length) return false;
    function pre(x, y) { var h = 0; while (h < 3 && h < x.length && h < y.length && x[h] === y[h]) h++; return h; }
    var head = Math.max(pre(a, b), pre(a.slice(1), b), pre(a, b.slice(1)));     // allow one extra word at the start
    if (head >= 2 || (head >= 1 && a.length <= 2)) return true;
    if (a.length >= 3) { var set = {}, hit = 0; b.forEach(function (w) { set[w] = 1; }); a.forEach(function (w) { if (set[w]) hit++; }); if (hit / a.length >= 0.6) return true; }
    return false;
  }
  function guardRestarts(pieces) {
    var notes = [];
    for (var i = 0; i < pieces.length; i++) {
      for (var d = 1; d <= 2 && i + d < pieces.length; d++) {
        var A = pieces[i], B = pieces[i + d];
        if (A.drop || B.drop || A.file !== B.file) continue;
        if (isRestart(A, B)) { A.drop = true; A.reason = 'said again in ' + B.id; notes.push(A.id + ' is said again in ' + B.id + ' — earlier attempt removed'); break; }
      }
    }
    return notes;
  }
  function guardRepeats(segs) {
    var notes = [], auto = !!(($('mtDedupe') || {}).checked), i, j;
    for (i = 0; i < segs.length; i++) {                              // same take, overlapping time ranges = audio heard twice
      for (j = 0; j < i; j++) {
        var A = segs[j], B = segs[i];
        if (A.drop || B.drop || A.file !== B.file || B.inT >= A.outT || B.outT <= A.inT) continue;
        if (B.inT >= A.inT && B.outT <= A.outT) { B.drop = true; B.reason = 'same audio as #' + A.n; notes.push('#' + B.n + ' is inside #' + A.n + ' (same audio) — dropped'); }
        else if (B.inT < A.outT && B.inT >= A.inT) { B.inT = A.outT; notes.push('#' + B.n + ' overlapped #' + A.n + ' — start trimmed'); }
      }
    }
    for (i = 0; i < segs.length; i++) {                              // same words again = a repeated line
      for (j = 0; j < i; j++) {
        var P = segs[j], Q = segs[i];
        if (P.drop || Q.drop) continue;
        var sim = share(P.words, Q.words);
        if (sim < 0.72) continue;
        var drop = (P.words.length <= Q.words.length * 0.6) ? P : Q;   // a short fragment of a later full line → drop the fragment; else keep the first (the hook / order Claude chose)
        var keep = drop === P ? Q : P;
        if (auto) { drop.drop = true; drop.reason = 'repeats #' + keep.n; notes.push('#' + drop.n + ' repeats #' + keep.n + ' — removed'); }
        else { drop.why = '⚠ POSSIBLE REPEAT of #' + keep.n + ' · ' + drop.why; notes.push('#' + drop.n + ' may repeat #' + keep.n); }
      }
    }
    return notes;
  }
  var IDEA_LABEL = { image: 'Photo', video: 'Video', graphic: 'Graphic', before_after: 'Before/After', before: 'Before', after: 'After', text: 'Text', icon: 'Icon' };
  var ASPECTS = { '9:16': [1080, 1920], '16:9': [1920, 1080], '1:1': [1080, 1080], '4:5': [1080, 1350] };
  function build(only) {
    if (!root) { status('Choose the day folder first', 'error'); return; }
    if (typeof only !== 'string') only = '';
    scan();
    var ready = episodes.filter(function (e) { return e.cut && !e.cut.bad && e.prepared && (!only || e.name === only); });
    if (!ready.length) {
      var np = episodes.filter(function (e) { return !e.prepared; }).length;
      status(np === episodes.length ? 'Nothing prepared yet — press ① Prepare first (it creates the "montage" folder), then ② Claude Montage, then ③ Build.'
        : 'No episode has a cut.json yet — press ② Claude Montage (Claude writes montage\\episodes\\<episode>\\cut.json), then ③ Build.', 'error');
      return;
    }
    var plans = [], problems = [];
    ready.forEach(function (e) {
      try { var p = planEpisode(e); if (p.segs.length) plans.push(p); if (p.errs.length) problems.push(e.name + ': ' + p.errs.slice(0, 3).join(', '));
            if (p.notes.length) problems.push(e.name + ' · repeats: ' + p.notes.join(', ')); }
      catch (x) { problems.push(e.name + ': ' + x.message); }
    });
    if (!plans.length) { status('⚠ Nothing valid to build. ' + problems.join(' · '), 'error'); return; }
    var paths = []; plans.forEach(function (p) { p.segs.forEach(function (s) { if (paths.indexOf(s.path) < 0) paths.push(s.path); }); });
    status('Importing ' + paths.length + ' take(s)…', 'working');
    var bin = 'Montage - ' + node().path.basename(root);
    evalP('montageImport(' + JSON.stringify(JSON.stringify({ paths: paths, bin: bin })) + ')').then(function (r) {
      if (r.indexOf('ERR:') === 0 || r === 'EvalScript error.') throw new Error(r.replace(/^ERR:/, ''));
      var foot = JSON.parse(r), made = [], i = 0, b = brief();
      function next() {
        if (i >= plans.length) return Promise.resolve();
        var p = plans[i++], at = 0, items = [], zoomOn = !!(($('mtZoom') || {}).checked), z = 100, jumps = 0;
        p.segs.forEach(function (s, k) {
          var prev = p.segs[k - 1];
          // jump cut = next piece of the SAME take that doesn't continue where the previous ended → punch in/out 100 ↔ 110 % to hide it
          if (zoomOn && prev && prev.path === s.path && Math.abs(s.inT - prev.outT) > 0.04) { z = z === 100 ? 110 : 100; jumps++; }
          else if (prev && prev.path !== s.path) z = 100;
          s._at = at;
          items.push({ id: foot[s.path].id, seg: '#' + s.n + ' ' + s.seg, inT: s.inT, outT: s.outT, at: +at.toFixed(4), comment: s.why, zoom: z });
          at += s.outT - s.inT;
        });
        var f0 = foot[p.segs[0].path], wh = ASPECTS[b.aspect] || [f0.w, f0.h];
        var ideas = (p.cut.ideas || []).filter(function (x) { return x && x.what && +x.at >= 0 && +x.at < at; }).map(function (x) {
          return { at: +x.at, dur: Math.min(Math.max(1, +x.dur || 3), at - x.at), type: x.type, label: IDEA_LABEL[x.type] || x.type || 'Idea', what: String(x.what) };
        });
        var name = (p.cut.title || p.e.name.split('/').pop()) + ' v' + (p.cut.version || 1);
        var data = { name: name, W: wh[0], H: wh[1], fps: f0.fps || 25, dur: at, items: items, broll: [], ideas: ideas, placeholders: true };
        status('Building ' + i + '/' + plans.length + ': ' + name + '…', 'working');
        var rep = (($('mtReplace') || {}).checked) ? evalP('montageDropComps(' + JSON.stringify(JSON.stringify({ name: name })) + ')') : Promise.resolve('');
        return rep.then(function () { return evalP('ae_buildAutoEdit(' + JSON.stringify(JSON.stringify(data)).replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029') + ')').then(function (res) {
          if (res.indexOf('ERR:') === 0) { problems.push(p.e.name + ': ' + res.slice(4)); return next(); }
          var srtNote = '';
          try { var sp = node().path.join(epDir(p.e.name), name.replace(/[\\\/:*?"<>|]/g, '_') + '.srt'); node().fs.writeFileSync(sp, '\ufeff' + makeSrt(p), 'utf8'); srtNote = ', .srt'; } catch (x) {}
          made.push(name + ' (' + Math.round(at) + 's' + (jumps ? ', ' + jumps + ' punch-in' : '') + (p.ums ? ', ' + p.ums + ' اه cut' : '') + srtNote + ')');
          return evalP('montageTagComp(' + JSON.stringify(JSON.stringify({ name: res.replace(/^OK:/, '').replace(/ \(.*$/, '') })) + ')').then(next);
        }); });
      }
      return next().then(function () {
        status((made.length ? '✓ Built ' + made.length + ': ' + made.join(' · ') : '') + (problems.length ? '\n⚠ ' + problems.join('\n⚠ ') : '') + (made.length ? '\nOne Ctrl+Z per comp undoes it.' : ''), made.length ? (problems.length ? 'warn' : 'ok') : 'error');
      });
    }).catch(function (e) { status('⚠ ' + (e.message || e), 'error'); });
  }
  function openFolder() { if (root && typeof require === 'function') node().cp.exec('explorer "' + root + '"'); }

  function init() {
    if (!$('tab-montage')) return;
    load();
    KEYS.forEach(function (k) { var e = $(k); if (e) e.addEventListener('change', save); });
    scan();
  }
  function onOpen() { scan(); checkClaude(); }
  return { _test: { plan: planEpisode, srt: makeSrt, setRoot: function (r) { root = r; } }, init: init, pick: pick, scan: scan, prepare: prepare, claude: runClaude, build: build, openFolder: openFolder, onOpen: onOpen };
})();
if (window.WeloInit) window.WeloInit.add(function () { window.claudeMontage.init(); });
