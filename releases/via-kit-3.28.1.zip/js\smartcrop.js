// ── SMART CROP (panel) · 3.18.0 — host side: jsx/smartcrop.jsx ──
window.smartCrop = (function () {
  function $(id) { return document.getElementById(id); }
  function status(msg, kind) { var el = $('scStatus'); if (el) { el.textContent = msg; el.className = 'ae-status' + (kind ? ' is-' + kind : ''); } }
  function opts() {
    return {
      name: (($('scName') || {}).value || 'Smart PreComp').trim() || 'Smart PreComp',
      forceNew: !!($('scForceNew') || {}).checked,
      range: ($('scRange') || {}).value || 'visible',
      pad: parseInt(($('scPad') || {}).value, 10) || 0,
      extents: !!($('scExtents') || {}).checked,
      center: !!($('scCenter') || {}).checked,
      even: !!($('scEven') || {}).checked
    };
  }
  function save() { try { window.weloCfg.set('smartcrop_opts', JSON.stringify(opts())); } catch (e) {} }
  function load() {
    try {
      var o = JSON.parse(window.weloCfg.get('smartcrop_opts') || '{}');
      if (o.range) $('scRange').value = o.range;
      if (o.pad !== undefined) $('scPad').value = o.pad;
      ['extents', 'center', 'even'].forEach(function (k) { if (o[k] !== undefined) $('sc' + k.charAt(0).toUpperCase() + k.slice(1)).checked = !!o[k]; });
    } catch (e) {}
  }
  function refresh() {           // tells the user what the button will do with the current selection
    if (typeof CSInterface === 'undefined') return;
    new CSInterface().evalScript('smartCropSelInfo()', function (r) {
      var b = $('scRunBtn'); if (!b) return;
      r = String(r || 'none');
      if (r.indexOf('precomp:') === 0 && !($('scForceNew') || {}).checked) {
        var p = r.split(':'); b.textContent = 'Crop precomp "' + p.slice(2).join(':') + '" (' + p[1].replace('x', '×') + ')';
      } else if (r.indexOf('layers:') === 0) b.textContent = 'Precompose ' + r.split(':')[1] + ' layer(s) & crop';
      else b.textContent = 'Precompose & Smart Crop';
    });
  }
  function run() {
    if (typeof CSInterface === 'undefined') { status('Run inside After Effects', 'error'); return; }
    save();
    var b = $('scRunBtn'); if (b) b.disabled = true;
    status('Measuring the content frame by frame…', 'working');
    var arg = JSON.stringify(JSON.stringify(opts()));
    new CSInterface().evalScript('smartCropRun(' + arg + ')', function (r) {
      if (b) b.disabled = false;
      r = String(r || '');
      if (r.indexOf('OK:') === 0) { status('✓ ' + r.slice(3) + ' · Ctrl+Z undoes it', 'ok'); showToast('✓ Smart Crop done'); }
      else status('⚠ ' + (r.replace(/^ERR:/, '') || 'No response from After Effects'), 'error');
      refresh();
    });
  }
  function init() {
    if (!$('tab-smartcrop')) return;
    load();
    ['scRange', 'scPad', 'scExtents', 'scCenter', 'scEven'].forEach(function (id) { var el = $(id); if (el) el.addEventListener('change', save); });
    var f = $('scForceNew'); if (f) f.addEventListener('change', refresh);
  }
  return { init: init, run: run, refresh: refresh };
})();
if (window.WeloInit) window.WeloInit.add(function () { window.smartCrop.init(); });
