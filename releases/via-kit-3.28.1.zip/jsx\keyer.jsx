// ── AI KEYER (ExtendScript, ES3) · 3.26.0 — panel side js/keyer.js. CorridorKey runs outside AE (C:\Via Studios Kit\CorridorKey).

// Selected footage layer → what to key. o = {useWorkArea:bool}
function kyGetSelection(json) {
    try {
        var o = JSON.parse(json || '{}');
        var comp = app.project.activeItem;
        if (!(comp instanceof CompItem)) return 'ERR:Open the comp with the green-screen shot';
        // pick: the one selected video layer; if none selected and the comp has only one video layer, use it
        var isVid = function (ly) { var s = ly.source; return s instanceof FootageItem && s.mainSource && s.mainSource.file && s.hasVideo && !s.mainSource.isStill; };
        var sel = comp.selectedLayers, vids = [], i;
        for (i = 0; i < sel.length; i++) if (isVid(sel[i])) vids.push(sel[i]);
        if (!sel.length) { for (i = 1; i <= comp.numLayers; i++) if (isVid(comp.layer(i))) vids.push(comp.layer(i)); }
        if (vids.length !== 1) {
            if (!sel.length) return 'ERR:No layer selected in comp "' + comp.name + '" — click the green-screen layer in the TIMELINE (not the Project panel), then Key';
            if (!vids.length) return 'ERR:The selected layer in "' + comp.name + '" is not a video file (precomp, solid or still?) — select the footage layer itself';
            return 'ERR:' + vids.length + ' video layers selected in "' + comp.name + '" — select only one';
        }
        var L = vids[0], src = L.source;
        if (!(src instanceof FootageItem) || !src.mainSource || !src.mainSource.file || !src.hasVideo || src.mainSource.isStill)
            return 'ERR:The selected layer must be a video file (not a precomp, solid or still)';
        if (L.timeRemapEnabled) return 'ERR:Time remap is on — turn it off or precompose the cut first';
        if (Math.abs(L.stretch - 100) > 0.01) return 'ERR:Layer is stretched (' + L.stretch + '%) — set it to 100% or precompose first';
        var a = L.inPoint, b = L.outPoint;
        if (o.useWorkArea) { a = Math.max(a, comp.workAreaStart); b = Math.min(b, comp.workAreaStart + comp.workAreaDuration); }
        if (b - a < comp.frameDuration) return 'ERR:Nothing to key in that range (check the work area)';
        return JSON.stringify({
            layer: { index: L.index, name: L.name, id: src.id },
            comp: { fps: comp.frameRate, name: comp.name },
            src: { path: src.mainSource.file.fsName, w: src.width, h: src.height, fps: src.frameRate, dur: src.duration },
            range: { compIn: a, compOut: b, srcIn: a - L.startTime, srcOut: b - L.startTime }
        });
    } catch (e) { return 'ERR:' + e.toString() + ' line ' + e.line; }
}

// Import FG + Matte EXR sequences, put them over the original layer (parented → follows its animation), matte as luma
// track matte, original switched off (never deleted). o = {layerIndex, fg, matte, fps, compIn, scale, w, h, name}
function kyImport(json) {
    app.beginUndoGroup('Welo: AI Keyer import');
    try {
        var o = JSON.parse(json), comp = app.project.activeItem;
        if (!(comp instanceof CompItem)) return 'ERR:Open the comp again before importing';
        var L = comp.layer(o.layerIndex);
        if (!L) return 'ERR:Original layer not found (layer order changed?)';
        var bin = null, i;
        for (i = 1; i <= app.project.numItems; i++) {
            var it = app.project.item(i);
            if (it instanceof FolderItem && it.name === 'AI Keyer') { bin = it; break; }
        }
        if (!bin) bin = app.project.items.addFolder('AI Keyer');
        function seq(dir) {
            var f = new Folder(dir), files = f.getFiles('*.exr');
            if (!files.length) throw new Error('no EXR frames in ' + dir);
            files.sort(function (x, y) { return x.name < y.name ? -1 : 1; });
            var io = new ImportOptions(files[0]); io.sequence = true; io.forceAlphabetical = true;
            var item = app.project.importFile(io);
            item.mainSource.conformFrameRate = o.fps;
            item.parentFolder = bin;
            return item;
        }
        var fgItem = null, mtItem = null, mi = null;
        if (o.mov) {                                                 // ProRes 4444 with straight alpha: one layer, no matte
            var mf = new File(o.mov);
            if (!mf.exists) return 'ERR:ProRes file not found: ' + o.mov;
            mi = app.project.importFile(new ImportOptions(mf));
            try { mi.mainSource.alphaMode = AlphaMode.STRAIGHT; } catch (e0) {}
            mi.parentFolder = bin;
        }
        else {
            fgItem = seq(o.fg), mtItem = seq(o.matte);
            fgItem.name = o.name + ' — key FG'; mtItem.name = o.name + ' — key Matte';
        }
        var place = function (item) {
            var N = comp.layers.add(item);
            N.startTime = o.compIn;
            N.moveBefore(L);
            N.setParentWithJump(L);                                  // no jump: values are set in the parent's space below
            var tg = N.property('ADBE Transform Group');
            tg.property('ADBE Anchor Point').setValue([o.w / 2, o.h / 2]);
            tg.property('ADBE Position').setValue([o.srcW / 2, o.srcH / 2]);
            tg.property('ADBE Scale').setValue([o.scale, o.scale]);
            tg.property('ADBE Rotate Z').setValue(0);
            return N;
        };
        if (o.mov) {
            var K = place(mi);
            K.name = o.name + ' [AI key]';
            try { K.comment = 'AI Keyer (CorridorKey) of "' + L.name + '"'; } catch (e4) {}
            L.enabled = false;
            return 'OK:' + K.name;
        }
        var FG = place(fgItem), MT = place(mtItem);
        MT.moveBefore(FG);
        FG.name = o.name + ' [AI key]'; MT.name = o.name + ' [AI key matte]';
        if (FG.setTrackMatte) FG.setTrackMatte(MT, TrackMatteType.LUMA);       // AE 2023+
        else FG.trackMatteType = TrackMatteType.LUMA;                          // older: matte = layer above
        try { MT.enabled = false; } catch (e1) {}                   // a track matte works with its video switched off
        try { FG.comment = 'AI Keyer (CorridorKey) of "' + L.name + '"'; } catch (e3) {}
        L.enabled = false;                                           // keep the original (audio stays on)
        return 'OK:' + FG.name;
    } catch (e) {
        return 'ERR:' + e.toString() + ' line ' + e.line;
    } finally {
        app.endUndoGroup();
    }
}

// ── Hint from the layer (3.26.0): the editor's own Keylight + masks on the green layer → black/white PNG sequence
// in <clip>\AlphaHint (CorridorKey reads image sequences there). A copy of the layer (with its effects and masks)
// is placed in a temp comp the size of the AI input, filled white (Fill keeps alpha) over black, rendered with the
// render queue (only our item; the user's queue flags are restored), then everything temporary is removed.
// o = {layerIndex, srcIn, dur, fps, w, h, srcW, srcH, outDir}
function kyRenderHint(json) {
    var o, tmp = null, bgSrc = null, rq = app.project.renderQueue, saved = [], ours = null;
    app.beginUndoGroup('Welo: AI Keyer hint');
    try {
        o = JSON.parse(json);
        var comp = app.project.activeItem;
        if (!(comp instanceof CompItem)) return 'ERR:Open the comp with the green-screen shot';
        var L = comp.layer(o.layerIndex);
        if (!L) return 'ERR:Layer not found (layer order changed?)';
        var nFx = L.property('ADBE Effect Parade').numProperties, nMask = L.property('ADBE Mask Parade').numProperties;
        if (!nFx && !nMask) return 'ERR:Hint "From the layer": put Keylight (and masks for things you don\'t want) on the green layer first';

        tmp = app.project.items.addComp('__via_kyhint__', o.w, o.h, 1, o.dur, o.fps);
        var bg = tmp.layers.addSolid([0, 0, 0], '__via_kyhint_bg__', o.w, o.h, 1, o.dur);
        bgSrc = bg.source;
        L.copyToComp(tmp);
        var C = tmp.layer(1);
        try { C.parent = null; } catch (e1) {}
        try { if (C.hasTrackMatte) { if (C.setTrackMatte) C.setTrackMatte(null, TrackMatteType.NO_TRACK_MATTE); else C.trackMatteType = TrackMatteType.NO_TRACK_MATTE; } } catch (e2) {}
        C.enabled = true;
        C.startTime = -o.srcIn;                                   // tmp time 0 = source time srcIn
        C.inPoint = 0; C.outPoint = o.dur;
        var tg = C.property('ADBE Transform Group');
        var setP = function (mn, v) {
            var p = tg.property(mn); if (!p) return;
            try { p.expression = ''; } catch (e) {}
            while (p.numKeys > 0) p.removeKey(1);
            p.setValue(v);
        };
        setP('ADBE Anchor Point', [o.srcW / 2, o.srcH / 2]);
        setP('ADBE Position', [o.w / 2, o.h / 2]);
        setP('ADBE Scale', [100 * o.w / o.srcW, 100 * o.h / o.srcH]);
        setP('ADBE Rotate Z', 0);
        setP('ADBE Opacity', 100);
        var fill = C.property('ADBE Effect Parade').addProperty('ADBE Fill');   // white where the key keeps the person
        var col = null;
        try { col = fill.property('ADBE Fill-0002'); } catch (e3) {}
        if (!col) { try { col = fill.property('Color'); } catch (e4) {} }
        if (col) col.setValue([1, 1, 1, 1]);
        bg.moveToEnd();

        var dir = new Folder(o.outDir);
        if (!dir.exists) dir.create();
        var old = dir.getFiles('*'), i;
        for (i = 0; i < old.length; i++) { try { if (old[i] instanceof File) old[i].remove(); } catch (e5) {} }

        for (i = 1; i <= rq.numItems; i++) {                     // render ONLY ours, restore the user's flags after
            try { saved.push([rq.item(i), rq.item(i).render]); rq.item(i).render = false; } catch (e6) {}
        }
        ours = rq.items.add(tmp);
        try { ours.applyTemplate('Best Settings'); } catch (e7) {}
        var om = ours.outputModule(1), pngOK = false;
        try { om.applyTemplate('PNG Sequence'); pngOK = true; } catch (e8) {
            try { var st = om.getSettings(GetSettingsFormat.STRING_SETTABLE); st['Format'] = 'PNG Sequence'; om.setSettings(st); pngOK = true; } catch (e9) {}
        }
        if (!pngOK) return 'ERR:After Effects has no PNG Sequence output here';
        om.file = new File(dir.fsName + '/hint_[#####].png');
        ours.render = true;
        rq.render();
        var n = dir.getFiles('hint_*.png').length;
        if (!n) return 'ERR:The hint render wrote no frames';
        return 'OK:' + n;
    } catch (e) {
        return 'ERR:' + e.toString() + ' line ' + e.line;
    } finally {
        try { if (ours) ours.remove(); } catch (f1) {}
        for (var k = 0; k < saved.length; k++) { try { saved[k][0].render = saved[k][1]; } catch (f2) {} }
        try { if (tmp) tmp.remove(); } catch (f3) {}
        try { if (bgSrc) bgSrc.remove(); } catch (f4) {}
        app.endUndoGroup();
    }
}
