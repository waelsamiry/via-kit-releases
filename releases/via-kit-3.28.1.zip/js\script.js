// ============================================================
//  Single init entry point (CLAUDE.md rule 2 / LESSONS L-002).
//  Every module registers with WeloInit.add(fn); fn runs once on DOMContentLoaded.
// ============================================================
window.WeloInit = (function () {
  var fns = [], done = false;
  function run() {
    if (done) return; done = true;
    for (var i = 0; i < fns.length; i++) { try { fns[i](); } catch (e) { console.error('init error', e); } }
    fns = [];
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', run);
  return {
    add: function (fn) { if (done) { try { fn(); } catch (e) { console.error('init error', e); } } else if (document.readyState !== 'loading') { fns.push(fn); setTimeout(run, 0); } else fns.push(fn); }
  };
}());

// ============================================================
//  Wael Subtitle Tools — script.js
//  Single source of truth for all UI logic & AE bridge
// ============================================================

(function () {
  'use strict';

  var cs = null;
  function getCS() {
    if (!cs && typeof CSInterface !== 'undefined') cs = new CSInterface();
    return cs;
  }

  function evalScript(fnCall, callback) {
    var csi = getCS();
    if (!csi) {
      console.log('[Bridge preview]:', fnCall);
      setTimeout(function () { if (callback) callback('preview'); }, 400);
      return;
    }
    csi.evalScript(fnCall, function (result) {
      if (result === 'EvalScript error.') {
        console.error('[evalScript] host error in:', String(fnCall).slice(0, 120));
        try { window.viaLog.error('evalScript', String(fnCall).slice(0, 160)); } catch (e) {}
        if (window.showToast) window.showToast('Script error in After Effects (' + String(fnCall).split('(')[0] + ')');
        result = null;
      }
      if (callback) callback(result);
    });
  }

  function safeJSON(obj) {
    return JSON.stringify(obj).replace(/\\/g, '\\\\').replace(/'/g, "\\'")
      .replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');
  }
  // Safe to embed inside a single-quoted evalScript string: fn('" + safeJSON(x) + "')
  window.safeJSON = safeJSON;
  // 3.26.2 (A-04): a string as an ExtendScript ARGUMENT, quotes included: fn(" + jsxArg(path) + ")
  // JSON string literals are valid ES3 strings; escapes ' \\ " and line separators (a path with ' broke Whisper/Audio).
  // 3.27.0 (A-24): ONE torch command everywhere (= install_libs.bat). The Settings rows used cu121 (no torchvision)
  // and cu128 (with) → mismatched torch/torchvision. cu121 = torch 2.5.x, the build DeepFilterNet is known to work with.
  // RTX 50xx needs cu128 + torch ≥ 2.7 — change it here AND in install_libs.bat together, after testing DeepFilterNet.
  window.VIA_TORCH_PIP = 'torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu121';
  window.jsxArg = function (x) {
    return JSON.stringify(String(x == null ? '' : x)).replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');
  };

  // ── STATUS & TOAST ───────────────────────────────────────
  window.evalScript = evalScript;

  window.setStatus = function (type, text) {
    var dot  = document.getElementById('statusDot');
    var span = document.getElementById('statusText');
    if (!dot || !span) return;
    dot.className = 'status-dot' + (type === 'error' ? ' error' : type === 'idle' ? ' idle' : '');
    span.textContent = text;
  };

  window.showToast = function (msg) {
    var t = document.getElementById('toast');
    if (!t) return;
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(t._timer);
    t._timer = setTimeout(function () { t.classList.remove('show'); }, 2400);
  };

  // ── GENERATE ─────────────────────────────────────────────
  window.runGenerate = function () {
    var btn = document.getElementById('generateBtn');
    if (btn) { btn.classList.add('loading'); btn.textContent = 'Generating...'; }
    window.setStatus('working', 'Generating boxes...');

    evalScript("generateBoxes('" + safeJSON(window.state) + "')", function (result) {
      if (btn) { btn.classList.remove('loading'); btn.textContent = 'Generate Boxes'; }
      if (result === 'NO_COMP')   { window.setStatus('error','Open a Composition first'); window.showToast('Open a Composition first'); return; }
      if (result === 'NO_LAYERS') { window.setStatus('error','No text layers found'); window.showToast('Select text layers first'); return; }
      var n = parseInt(result) || 0;
      window.state.generatedCount = n;
      var sb = document.getElementById('statBox'); if (sb) sb.textContent = n;
      var lc = document.getElementById('layerCount'); if (lc) lc.textContent = n + ' boxes';
      window.setStatus('success', 'Generated ' + n + ' box' + (n !== 1 ? 'es' : ''));
      window.showToast(n + ' box' + (n !== 1 ? 'es' : '') + ' created');
    });
  };

  // ── UPDATE ───────────────────────────────────────────────
  var _updateTimer = null;
  window._liveUpdate = function() {
    if (_updateTimer) clearTimeout(_updateTimer);
    _updateTimer = setTimeout(function() {
      var live = document.getElementById('liveUpdateToggle');
      if (live && live.checked) window.runUpdate();
    }, 300);
  };

  window.runUpdate = function () {
    window.setStatus('working', 'Updating...');
    var allLayers = document.getElementById('allLayersToggle');
    var stateClone = JSON.parse(JSON.stringify(window.state));
    stateClone._allLayers = allLayers ? allLayers.checked : false;
    evalScript("updateBoxes('" + safeJSON(stateClone) + "')", function (result) {
      if (result === 'NO_COMP') { window.setStatus('error','Open a Composition first'); return; }
      var n = parseInt(result) || 0;
      window.setStatus(n > 0 ? 'success' : 'idle', n > 0 ? 'Updated ' + n + ' box(es)' : 'No boxes found — select a _SSBG_ layer');
      if (n > 0) window.showToast('Updated ' + n + ' box(es)');
    });
  };

  // ── DELETE ───────────────────────────────────────────────
  window.runDelete = function () {
    evalScript('deleteBoxes()', function (result) {
      var n = parseInt(result) || 0;
      var sb = document.getElementById('statBox'); if (sb) sb.textContent = '0';
      var lc = document.getElementById('layerCount'); if (lc) lc.textContent = '0 boxes';
      window.setStatus('idle', 'Ready');
      window.showToast(n > 0 ? 'Removed ' + n + ' boxes' : 'No boxes to remove');
    });
  };

  // ── SELECT ALL ───────────────────────────────────────────
  window.runSelect = function () {
    evalScript('selectAllBoxes()', function (result) {
      var n = parseInt(result) || 0;
      window.showToast(n > 0 ? n + ' boxes selected' : 'No boxes found');
    });
  };

  // ── SELECT ALL TEXT (SUB_ layers) ───────────────────────
  window.runSelectText = function () {
    evalScript('selectAllTextLayers()', function (result) {
      var n = parseInt(result) || 0;
      window.showToast(n > 0 ? n + ' text layers selected' : 'No text layers found');
    });
  };

  // ── APPLY ANIMATION ──────────────────────────────────────
  window.applyAnimation = function () {
    window.setStatus('working', 'Applying animation...');
    var target = (typeof window.animTarget !== 'undefined') ? window.animTarget : 'text';

    var p = {
      animStyle: window.state.animStyle || 'fade',
      duration:  parseInt(document.getElementById('durationSlider').value) || 8,
      offset:    parseInt(document.getElementById('offsetSlider').value)   || 2,
      easing:    document.getElementById('easingSelect').value || 'Ease Out',
      mirrorOut: document.getElementById('outToggle').checked
    };

    var fn = target === 'box' ? 'applyAnimations' : 'applyTextAnimations';
    evalScript(fn + "('" + safeJSON(p) + "')", function (result) {
      if (result === 'NO_COMP') { window.setStatus('error','Open a Composition first'); window.showToast('Open a Composition first'); return; }
      var n = parseInt(result) || 0;
      var lbl = target === 'box' ? 'boxes' : 'text layers';
      window.setStatus(n > 0 ? 'success' : 'idle', n > 0 ? 'Applied to ' + n + ' ' + lbl : 'No layers found — select layers first');
      window.showToast(n > 0 ? n + ' ' + lbl + ' animated' : 'Select layers first');
    });
  };

  // ── BOX STYLE PRESETS ────────────────────────────────────
  var presetData = {
    cinema:      { color: '#000000', opacity: 90,  radius: 4,  padding: 30, blur: 0,  fillType: 'solid' },
    news:        { color: '#c0392b', opacity: 100, radius: 0,  padding: 28, blur: 0,  fillType: 'solid' },
    glass:       { color: '#ffffff', opacity: 15,  radius: 10, padding: 32, blur: 12, fillType: 'solid' },
    neon:        { color: '#0d0d0d', opacity: 95,  radius: 6,  padding: 28, blur: 0,  fillType: 'solid' },
    minimal:     { color: '#ffffff', opacity: 8,   radius: 6,  padding: 24, blur: 4,  fillType: 'solid' },
    documentary: { color: '#1a3a5c', opacity: 90,  radius: 4,  padding: 30, blur: 0,  fillType: 'solid' }
  };

  window.applyPreset = function (name) {
    var p = presetData[name];
    if (!p) return;
    Object.assign(window.state, p);
    window.applyStateToUI(window.state);
    window.showToast('Preset: ' + name);
    if (typeof window.switchTab === 'function') window.switchTab('design');
  };

  // ── APPLY STATE TO UI ────────────────────────────────────
  window.applyStateToUI = function (s) {
    var set = function (id, val) { var el = document.getElementById(id); if (el) el.value = val; };
    var txt = function (id, val) { var el = document.getElementById(id); if (el) el.textContent = val; };
    if (s.padding  !== undefined) { set('paddingSlider', s.padding);  txt('paddingVal', s.padding  + 'px'); }
    if (s.radius   !== undefined) { set('radiusSlider',  s.radius);   txt('radiusVal',  s.radius   + 'px'); }
    if (s.opacity  !== undefined) { set('opacitySlider', s.opacity);  txt('opacityVal', s.opacity  + '%');  }
    if (s.blur     !== undefined) { set('blurSlider',    s.blur);     txt('blurVal',    s.blur     + 'px'); }
    if (s.blendMode) set('blendMode', s.blendMode);
    if (s.fillType)  set('fillType',  s.fillType);
    if (s.color && typeof window.selectColor === 'function') window.selectColor(null, s.color);
    if (typeof window.updatePreview === 'function') window.updatePreview();
  };

  // ── SAVED BOX PRESETS ────────────────────────────────────
  var savedPresets = [];

  window.saveCurrentPreset = function () {
    var nameEl = document.getElementById('customPresetName');
    var n = (nameEl && nameEl.value.trim()) ? nameEl.value.trim() : ('Custom ' + (savedPresets.length + 1));
    var pr = { id: 'box_' + Date.now() + '_' + Math.floor(Math.random() * 1e4), name: n, settings: JSON.parse(JSON.stringify(window.state)) };
    savedPresets.unshift(pr);
    renderSavedPresets();
    window.showToast('Saved: ' + n);
    storePresets();
    makeThumb(pr);
  };
  // box presets live in weloCfg (CLAUDE rule 7); one-time move from the old localStorage key (3.25.0)
  function storePresets() { try { window.weloCfg.set('ssbg_presets', JSON.stringify(savedPresets)); } catch (e) {} }
  function makeThumb(pr) {                     // real AE render of the current text with this style — never blocks saving
    if (!window.viaPreview || !pr) return;
    window.viaPreview.thumb(pr.settings, pr.id).then(function (f) { if (f) { pr.thumb = f; storePresets(); renderSavedPresets(); } });
  }
  window.refreshPresetThumb = function (i) { var p = savedPresets[i]; if (!p) return; if (!p.id) p.id = 'box_' + Date.now() + '_' + i; makeThumb(p); };

  function loadSavedPresets() {
    var r = null;
    try { r = window.weloCfg && window.weloCfg.get('ssbg_presets'); } catch (e) {}
    if (!r) {
      try { r = localStorage.getItem('ssbg_presets'); } catch (e) {}
      if (r) { try { window.weloCfg.set('ssbg_presets', r); localStorage.removeItem('ssbg_presets'); } catch (e) {} }
    }
    try { if (r) savedPresets = JSON.parse(r) || []; } catch (e) {}
    renderSavedPresets();
  }

  function renderSavedPresets() {
    var c = document.getElementById('savedPresets');
    if (!c) return;
    if (!savedPresets.length) { c.innerHTML = '<div style="font-size:10px;color:var(--text-muted);text-align:center;padding:8px">No saved presets</div>'; return; }
    c.innerHTML = '';
    savedPresets.forEach(function (p, i) {
      var d = document.createElement('div');
      d.style.cssText = 'display:flex;align-items:center;justify-content:space-between;background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius-sm);padding:6px 8px;margin-bottom:4px';
      var tu = p.thumb && window.viaPreview ? window.viaPreview.thumbUrl(p.thumb) : '';
      d.innerHTML = '<span style="display:flex;align-items:center;gap:6px;min-width:0">' + (tu ? '<img class="preset-thumb" src="' + tu + '" alt="">' : '') +
        '<span style="font-size:10px;color:var(--text-secondary)">' + (tu ? '' : '⭐ ') + String(p.name).replace(/</g, '&lt;') + '</span></span>' +
        '<div style="flex:none"><button onclick="window.loadPreset(' + i + ')" style="background:none;border:none;color:var(--accent);cursor:pointer;font-size:10px;padding:0 4px">Load</button>' +
        '<button onclick="window.refreshPresetThumb(' + i + ')" title="Refresh thumbnail" style="background:none;border:none;color:var(--text-muted);cursor:pointer;font-size:10px;padding:0 4px">↻</button>' +
        '<button onclick="window.deletePreset(' + i + ')" style="background:none;border:none;color:var(--text-muted);cursor:pointer;font-size:10px">✕</button></div>';
      c.appendChild(d);
    });
  }

  window.loadPreset = function (i) {
    var p = savedPresets[i]; if (!p) return;
    Object.assign(window.state, p.settings);
    window.applyStateToUI(p.settings);
    window.showToast('Loaded: ' + p.name);
  };
  window.deletePreset = function (i) {
    var gone = savedPresets.splice(i, 1)[0];
    if (gone && gone.thumb && window.viaPreview) window.viaPreview.dropThumb(gone.thumb);
    renderSavedPresets();
    storePresets();
  };

  // ── STATS ────────────────────────────────────────────────
  var _statsBusy = false;
  function refreshStats() {
    _statsBusy = true;
    evalScript('getLayerInfo()', function (result) {
      _statsBusy = false;
      if (!result || result === 'preview') return;
      try {
        var info = JSON.parse(result);
        var st = document.getElementById('statText'); if (st) st.textContent = info.text  || '0';
        var sb = document.getElementById('statBox');  if (sb) sb.textContent = info.boxes || '0';
        var lc = document.getElementById('layerCount'); if (lc) lc.textContent = (info.boxes || 0) + ' boxes';
      } catch (e) {}
    });
  }

  // ── LIVE UPDATE ──────────────────────────────────────────
  var liveTimer = null;
  window.triggerLiveUpdate = function () {
    var t = document.getElementById('liveUpdateToggle');
    if (!t || !t.checked) return;
    clearTimeout(liveTimer);
    liveTimer = setTimeout(window.runUpdate, 350);
  };

  function hookLiveUpdate() {
    ['paddingSlider','radiusSlider','opacitySlider','blurSlider'].forEach(function (id) {
      var el = document.getElementById(id); if (el) el.addEventListener('input', window.triggerLiveUpdate);
    });
    var cp = document.getElementById('colorPicker');
    if (cp) cp.addEventListener('input', window.triggerLiveUpdate);
  }

  // ── KEYBOARD SHORTCUTS ───────────────────────────────────
  document.addEventListener('keydown', function (e) {
    var tg = e.target, tn = tg && tg.tagName;
    var typing = tn === 'TEXTAREA' || (tn === 'INPUT' && tg.type !== 'range' && tg.type !== 'checkbox') || (tg && tg.isContentEditable);
    if (typing && e.key === 'Backspace') return; // Ctrl+Backspace = delete word, must not delete boxes
    if ((e.ctrlKey || e.metaKey) && e.key === 'g') { e.preventDefault(); window.runGenerate(); }
    if ((e.ctrlKey || e.metaKey) && e.key === 'u') { e.preventDefault(); window.runUpdate(); }
    if ((e.ctrlKey || e.metaKey) && e.key === 'Backspace') { e.preventDefault(); window.runDelete(); }
  });

  // ── INIT ─────────────────────────────────────────────────
  WeloInit.add(function () {
    // Node missing = CEP started this panel's process without --enable-nodejs (see LESSONS L-011)
    if (typeof CSInterface !== 'undefined' && typeof require === 'undefined') {
      window.setStatus('error', 'Node.js is off — restart After Effects');
      window.showToast('Node.js is off — restart After Effects (L-011)');
    }
    hookLiveUpdate();
    loadSavedPresets();
    refreshStats();
    setInterval(function () {
      var tab = document.getElementById('tab-design');
      if (document.hidden || _statsBusy || !tab || !tab.classList.contains('active')) return;
      refreshStats();
    }, 4000);
    setTimeout(function () { window.setStatus('idle', 'Ready — Ctrl+G to Generate'); }, 800);

    // Attach tool card clicks via addEventListener (CEP --mixed-context safe)
    document.querySelectorAll('.tool-card[data-tool]').forEach(function(card) {
      card.addEventListener('click', function() {
        var tool = card.getAttribute('data-tool');
        if (typeof goToTool === 'function') goToTool(tool);
        else if (typeof window.goToTool === 'function') window.goToTool(tool);
      });
    });

    // Home button
    var homeBtn = document.querySelector('.header-btn[title="Home"], [onclick*="goHome"]');
    if (homeBtn) {
      homeBtn.removeAttribute('onclick');
      homeBtn.addEventListener('click', function() {
        if (typeof goHome === 'function') goHome();
      });
    }
  });

})();

// ═══════════════════════════════════════════════════════════
//  WELO TOOLS — FOOTAGE COLLECTOR
// ═══════════════════════════════════════════════════════════
(function () {

  var _fcDestPath      = '';
  var _fcScanned       = false;
  var _fcWorking       = false;
  var _fcLastHash      = -1;
  var _fcInterval      = null;
  var _fcLastProjFolder  = '';   // tracks last known project folder
  var _fcLastProjDefault = '';   // tracks if dest was auto-set (so we can update it when project changes)

  function fcSetStatus(type, text) {
    var dot  = document.getElementById('fcDot');
    var span = document.getElementById('fcStatus');
    if (!dot || !span) return;
    span.textContent = text;
    dot.style.background = type === 'ok' ? 'var(--accent-3)' : type === 'error' ? 'var(--accent-2)' : type === 'working' ? 'var(--accent-4)' : 'var(--text-muted)';
  }

  function fcSetDest(path) {
    if (!path) return;
    _fcDestPath = path;
    var el = document.getElementById('fcDestDisplay');
    if (!el) return;
    // Show short display: last 2 path segments so it's readable
    var parts = path.replace(/\\/g, '/').split('/').filter(function(p){return p!=='';});
    var display = parts.length > 2 ? '…/' + parts[parts.length-2] + '/' + parts[parts.length-1] : path;
    el.textContent = display;
    el.title = path; // full path on hover
    el.style.color = 'var(--text-secondary)';
  }

  // ── Update UI from scan result ────────────────────────
  function fcApplyStats(res, showToastMsg) {
    var s = res.stats;
    document.getElementById('fcStatVideo').textContent   = s.video   || 0;
    document.getElementById('fcStatAudio').textContent   = s.audio   || 0;
    document.getElementById('fcStatRaster').textContent  = (s.raster||0) + (s.design||0) + (s.raw||0);
    document.getElementById('fcStatMissing').textContent = s.missing || 0;

    // Comp stats — smaller numbers below
    var cs = res.compStats;
    var hasComp = cs && cs.name;
    var compLabel = document.getElementById('fcCompLabel');
    var compName  = document.getElementById('fcCompName');
    if (hasComp) {
      var compRaster = (cs.raster||0) + (cs.design||0) + (cs.raw||0);
      document.getElementById('fcCompVideo').textContent   = cs.video   > 0 ? cs.video   : '·';
      document.getElementById('fcCompAudio').textContent   = cs.audio   > 0 ? cs.audio   : '·';
      document.getElementById('fcCompRaster').textContent  = compRaster > 0 ? compRaster : '·';
      document.getElementById('fcCompMissing').textContent = cs.missing > 0 ? cs.missing : '·';
      if (compName) compName.textContent = cs.name;
      if (compLabel) compLabel.style.display = 'block';
    } else {
      ['fcCompVideo','fcCompAudio','fcCompRaster','fcCompMissing'].forEach(function(id) {
        var el = document.getElementById(id); if (el) el.textContent = '—';
      });
      if (compLabel) compLabel.style.display = 'none';
    }

    // Project label
    var lbl = document.getElementById('fcProjLabel');
    if (lbl && res.projFolder) {
      var parts = res.projFolder.replace(/\\/g, '/').split('/');
      lbl.textContent = parts[parts.length - 1] || '—';
      lbl.style.color = 'var(--text-secondary)';
    }

    // Auto-set default destination = _collected/ next to project file
    // Only set if user hasn't manually chosen a path yet
    if (res.projFolder && !_fcDestPath) {
      var defaultDest = res.projFolder.replace(/\\/g, '/') + '/project files';
      fcSetDest(defaultDest);
      _fcLastProjDefault = defaultDest;
      _fcLastProjFolder  = res.projFolder;
    }
    // If project changed (new project opened), update default dest
    if (res.projFolder && _fcDestPath && _fcDestPath === _fcLastProjDefault && res.projFolder !== _fcLastProjFolder) {
      var newDefault = res.projFolder.replace(/\\/g, '/') + '/project files';
      fcSetDest(newDefault);
      _fcLastProjDefault = newDefault;
    }
    _fcLastProjFolder = res.projFolder || _fcLastProjFolder;

    _fcScanned  = true;
    _fcLastHash = res.hash;

    var btn = document.getElementById('fcCollectBtn');
    if (btn) { btn.disabled = false; btn.style.opacity = '1'; }

    var total = (s.video||0)+(s.audio||0)+(s.raster||0)+(s.design||0)+(s.raw||0)+(s.other||0);
    fcSetStatus('ok', total + ' files  ·  ' + (s.missing||0) + ' missing');
    if (showToastMsg) window.showToast('🔍 ' + total + ' footage items');
  }

  // ── SILENT REFRESH (called every 3s, no toast, only updates if hash changed) ──
  function fcSilentRefresh() {
    if (_fcWorking || document.hidden) return;
    var panel = document.getElementById('tab-collect');
    if (!panel || !panel.classList.contains('active')) return;
    window.evalScript('fc_getProjectStats()', function (raw) {
      if (!raw || raw === 'undefined' || raw === 'preview') return;
      try {
        var res = JSON.parse(raw);
        if (!res.success) return;
        // Always update comp stats (comp can change without hash change)
        // Update project stats only if hash changed
        if (res.hash !== _fcLastHash || (res.compStats && res.compStats.name)) {
          fcApplyStats(res, false);
        }
      } catch(e) {}
    });
  }

  // ── MANUAL SCAN (with status indicator) ──────────────
  window.fcScan = function () {
    fcSetStatus('working', 'Scanning...');
    window.evalScript('fc_getProjectStats()', function (raw) {
      if (!raw || raw === 'undefined') { fcSetStatus('error', 'No project open'); return; }
      if (raw === 'preview') { fcSetStatus('idle', 'Ready'); return; }
      try {
        var res = JSON.parse(raw);
        if (!res.success) { fcSetStatus('error', 'No project'); return; }
        fcApplyStats(res, true);
      } catch (e) { fcSetStatus('error', 'Parse error'); }
    });
  };

  // ── BROWSE ───────────────────────────────────────────
  window.fcBrowse = function () {
    window.evalScript('fc_selectFolder()', function (path) {
      if (path && path !== 'undefined' && path !== '') {
        fcSetDest(path);
        _fcLastProjDefault = ''; // user manually chose → stop auto-updating
      }
    });
  };

  // ── COLLECT ──────────────────────────────────────────
  window.fcCollect = function () {
    if (!_fcScanned) { window.showToast('Scan first!'); return; }
    if (!_fcDestPath) { window.showToast('Choose a destination folder'); return; }
    if (_fcWorking) return;

    var types = [];
    if (document.getElementById('fcChkVideo').checked)    types.push('video');
    if (document.getElementById('fcChkAudio').checked)    types.push('audio');
    if (document.getElementById('fcChkRaster').checked)   types.push('raster');
    if (document.getElementById('fcChkDesign').checked)   types.push('design');
    if (document.getElementById('fcChkRaw').checked)      types.push('raw');
    if (document.getElementById('fcChkOther').checked)    types.push('other');
    if (document.getElementById('fcChkSeq') && document.getElementById('fcChkSeq').checked) types.push('sequence');
    if (!types.length) { window.showToast('Select at least one file type'); return; }

    var move         = document.getElementById('fcToggleMove').checked;
    var relink       = document.getElementById('fcToggleRelink').checked;
    var seqGroupMode = document.getElementById('fcToggleSeqGroup') ? document.getElementById('fcToggleSeqGroup').checked : true;
    var path         = _fcDestPath.replace(/\\/g, '/').replace(/'/g, "\\'");
    var tJson        = JSON.stringify(types).replace(/'/g, "\\'");

    _fcWorking = true;
    var btn = document.getElementById('fcCollectBtn');
    if (btn) { btn.disabled = true; btn.style.opacity = '.5'; btn.textContent = '⏳ Working…'; }

    fcSetStatus('working', (move ? 'Moving' : 'Copying') + ' files…');

    var call = "fc_collectFootage('" + path + "'," + move + "," + relink + ",'" + tJson + "'," + seqGroupMode + ")";
    window.evalScript(call, function (raw) {
      _fcWorking = false;
      if (btn) { btn.disabled = false; btn.style.opacity = '1'; btn.textContent = 'Collect & Relink'; }

      if (!raw || raw === 'undefined') { 
        fcSetStatus('error', 'Failed — JSX error (check ExtendScript console)'); 
        window.showToast('⚠ JSX returned empty — possible script error');
        return; 
      }
      // Show raw response if it's not JSON (JSX error string)
      if (raw.charAt(0) !== '{') {
        fcSetStatus('error', 'Error: ' + raw.slice(0, 80));
        window.showToast('⚠ ' + raw.slice(0, 60));
        return;
      }
      try {
        var res = JSON.parse(raw);
        if (!res.success) { fcSetStatus('error', res.error || 'Error'); return; }
        var verb = move ? 'moved' : 'copied';
        var n = res.collected ? res.collected.length : 0;
        var seqCount = res.stats && res.stats.sequence ? res.stats.sequence : 0;
        var seqNote  = seqCount ? ' · ' + seqCount + ' seq' : '';
        var missingNote = res.missing && res.missing.length ? ' · ' + res.missing.length + ' missing' : '';
        fcSetStatus('ok', n + ' files ' + verb + seqNote + missingNote);

        if (res.hasLayered) {
          window.showToast('✓ Done · PSD/AI copied — use File > Find Missing Footage to relink');
          // Show a persistent note in the panel
          var noteEl = document.getElementById('fcLayeredNote');
          if (noteEl) {
            noteEl.style.display = 'flex';
            noteEl.querySelector('span').textContent = 'PSD/AI files copied to design/ folder. In AE: File → Find Missing Footage → select the new location.';
          }
        } else {
          window.showToast('✓ ' + n + ' files ' + verb + seqNote);
          var noteEl2 = document.getElementById('fcLayeredNote');
          if (noteEl2) noteEl2.style.display = 'none';
        }

        var mp = document.getElementById('fcMissingPanel');
        var ml = document.getElementById('fcMissingList');
        var mt = document.getElementById('fcMissingTitle');
        if (res.missing && res.missing.length && mp && ml) {
          mt.textContent = res.missing.length + ' missing files (skipped)';
          ml.innerHTML = '';
          res.missing.forEach(function (m) {
            var d = document.createElement('div');
            d.textContent = (m.name || '?') + '  —  ' + (m.originalPath || '?');
            d.title = m.originalPath || '';
            ml.appendChild(d);
          });
          mp.style.display = 'block';
        } else if (mp) { mp.style.display = 'none'; }

        setTimeout(window.fcScan, 400);
      } catch (e) { fcSetStatus('error', 'Parse error'); }
    });
  };

  // ── Start/stop auto-refresh when panel becomes active ─
  WeloInit.add(function () {
    _fcInterval = setInterval(fcSilentRefresh, 3000);
  });

})();


// ═══════════════════════════════════════════════════════════
//  PRESET MAKER
// ═══════════════════════════════════════════════════════════
(function () {
  var _sel = null, _type = 'text', _setup = false, _all = [], _cat = 'all';

  function extPath() { return (new CSInterface()).getSystemPath('extension').replace(/\\/g, '/'); }
  function isAEHost() { try { return (new CSInterface()).getHostEnvironment().appName === 'AEFT'; } catch(e) { return false; } }
  function pmJsx(code, cb) { window.evalScript('_wpm_extPath=' + JSON.stringify(extPath()) + ';' + code, cb || function(){}); }
  function pmParse(r) { try { return JSON.parse(r); } catch(e) { return null; } }
  function pmStat(s, m) { var el=document.getElementById(s==='b'?'pm-b-status':'pm-c-status'); if(el) el.textContent=m; }
  function pmProg(p, show) { var w=document.getElementById('pm-prog-wrap'),b=document.getElementById('pm-prog-bar'); if(w) w.style.display=show?'block':'none'; if(b) b.style.width=p+'%'; }

  window.pmSwitch = function(id) {
    var br=document.getElementById('pm-browser'), cr=document.getElementById('pm-creator');
    var tb=document.getElementById('pm-tab-browser'), tc=document.getElementById('pm-tab-creator');
    if(br) br.style.display=id==='browser'?'flex':'none';
    if(cr) cr.style.display=id==='creator'?'flex':'none';
    if(tb){tb.style.color=id==='browser'?'var(--accent)':'var(--text-muted)';tb.style.borderBottomColor=id==='browser'?'var(--accent)':'transparent';}
    if(tc){tc.style.color=id==='creator'?'var(--accent)':'var(--text-muted)';tc.style.borderBottomColor=id==='creator'?'var(--accent)':'transparent';}
    if(id==='browser') pmLoad();
  };
  window.pmSetType = function(btn) { document.querySelectorAll('.pm-type').forEach(function(b){b.classList.remove('on');}); btn.classList.add('on'); _type=btn.dataset.type; };
  window.pmFilterCat = function(btn) {
    document.querySelectorAll('.pm-cat').forEach(function(b){b.classList.remove('on');}); btn.classList.add('on');
    _cat=btn.dataset.cat; _sel=null; var ab=document.getElementById('pm-apply-btn'); if(ab) ab.disabled=true; pmRender(_cat);
  };

  window.pmLoad = function() {
    pmStat('b','Scanning...');
    if(typeof CSInterface==='undefined'||!isAEHost()){pmStat('b','Open in After Effects');return;}
    pmJsx('wpm_getPresets()', function(r) {
      var res=pmParse(r); if(!res||!res.success){pmStat('b','Scan failed');return;}
      _all=res.presets||[]; pmRender(_cat); pmStat('b',_all.length+' presets found');
    });
  }

  window.pmTogglePreview = function(btn) {
    var grid = document.getElementById('pm-grid');
    if (!grid) return;
    grid.classList.toggle('gif-always');
    var isOn = grid.classList.contains('gif-always');
    if (btn) { btn.classList.toggle('on', isOn); btn.textContent = isOn ? '▶ always' : '▶ hover'; }
    // Swap all backgrounds to gif or back to thumb
    grid.querySelectorAll('.pm-thumb-bg.has-gif').forEach(function(el) {
      var gifUrl   = el.getAttribute('data-gif');
      var thumbUrl = el.getAttribute('data-thumb');
      if (isOn && gifUrl) {
        el.style.backgroundImage = 'url("'+gifUrl+'?t='+Date.now()+'")';
      } else if (thumbUrl) {
        el.style.backgroundImage = 'url("'+thumbUrl+'?t='+Date.now()+'")';
      }
    });
  };

  function pmRender(cat) {
    var grid=document.getElementById('pm-grid'); if(!grid) return;
    var list=cat==='all'?_all:_all.filter(function(p){return p.category===cat;});
    if(!list.length){grid.innerHTML='<div style="grid-column:1/-1;text-align:center;padding:24px;color:var(--text-muted);font-size:9px">No presets here yet</div>';return;}
    var colors={text:'rgba(124,109,240,.8)',shape:'rgba(109,240,200,.8)',photo:'rgba(240,184,109,.8)',transition:'rgba(240,109,143,.8)',effects:'rgba(109,200,240,.8)'};
    var ts='?t='+Date.now();
    grid.innerHTML='';
    list.forEach(function(p) {
      var card=document.createElement('div'); card.className='pm-preset-card';
      var tc=colors[p.category]||'rgba(255,255,255,.5)';

      // Build file:/// URLs (like the working extension)
      var thumbUrl = p.png ? ('file:///' + p.png.replace(/\\/g, '/')) : '';
      var gifUrl   = p.gif ? ('file:///' + p.gif.replace(/\\/g, '/')) : '';
      var defaultBg = thumbUrl || gifUrl;
      var hasPreview = thumbUrl || gifUrl;

      var previewHtml;
      if (hasPreview) {
        previewHtml = '<div class="pm-thumb-bg'+(gifUrl?' has-gif':'')+'" data-thumb="'+thumbUrl+'" data-gif="'+gifUrl+'" style="background-image:url(\''+defaultBg+ts+'\')"></div>';
      } else {
        previewHtml = '<div class="pm-thumb-bg no-preview">🎬</div>';
      }

      var monoStyle = "font-family:Consolas,'Courier New',monospace";
      card.innerHTML='<div class="pm-thumb">'+previewHtml+'<span style="position:absolute;top:4px;left:4px;'+monoStyle+';font-size:7px;padding:2px 5px;border-radius:3px;background:rgba(0,0,0,.6);color:'+tc+';z-index:1">'+p.category+'</span></div>'+
        '<div style="padding:5px 7px"><div style="font-size:9px;font-weight:600;color:var(--text-primary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+p.name+'</div>'+
        '<div style="'+monoStyle+';font-size:7px;color:var(--text-muted)">'+p.name+'.ffx</div></div>';

      // Hover to swap background-image between thumb and gif (same as working extension)
      var preview = card.querySelector('.pm-thumb-bg');
      if (preview && gifUrl && thumbUrl) {
        card.addEventListener('mouseenter', function() {
          preview.style.backgroundImage = 'url("'+gifUrl+ts+'")';
        });
        card.addEventListener('mouseleave', function() {
          if (!grid.classList.contains('gif-always')) {
            preview.style.backgroundImage = 'url("'+thumbUrl+ts+'")';
          }
        });
      }

      card.onclick=function(){document.querySelectorAll('.pm-preset-card').forEach(function(c){c.classList.remove('sel');});card.classList.add('sel');_sel=p;var ab=document.getElementById('pm-apply-btn');if(ab) ab.disabled=false;pmStat('b',p.name+' selected');};
      grid.appendChild(card);
    });
  }

  window.pmApply = function() {
    if(!isAEHost()){window.showToast('Open in After Effects');return;}
    if(!_sel) return;
    pmStat('b','Applying...');
    pmJsx('_wpm_args='+JSON.stringify({file:_sel.file})+';wpm_applyPreset()', function(r) {
      var res=pmParse(r);
      if(res&&res.success){pmStat('b','\u2713 Applied: '+_sel.name);window.showToast('\u2713 '+_sel.name+' applied');}
      else{pmStat('b','\u2717 '+((res&&res.error)||'Failed'));window.showToast('\u274c Apply failed');}
    });
  };
  window.pmDelete = function() {
    if(!_sel){window.showToast('Select a preset first');return;}
    pmJsx('_wpm_args='+JSON.stringify({name:_sel.name,category:_sel.category})+';wpm_deletePreset()', function(r) {
      var res=pmParse(r);
      if(res&&res.success){
        var cnt=res.deleted?res.deleted.length:0;
        window.showToast('\uD83D\uDDD1 Deleted: '+_sel.name+' ('+cnt+' files)');
        _sel=null;var ab=document.getElementById('pm-apply-btn');if(ab) ab.disabled=true;pmLoad();
      } else {
        window.showToast('\u274c Delete failed'+(res&&res.error?' — '+res.error:''));
      }
    });
  };
  // ── What to save: per-property checkboxes (persisted in settings.json) ──
  function pmGetKeep() {
    var o = {}, boxes = document.querySelectorAll('.pm-keep');
    for (var i = 0; i < boxes.length; i++) o[boxes[i].getAttribute('data-k')] = boxes[i].checked;
    return o;
  }
  window.pmKeepChanged = function() { try { weloCfg.set('pm_keep', JSON.stringify(pmGetKeep())); } catch (e) {} };
  WeloInit.add(function () {
    try {
      var saved = JSON.parse(weloCfg.get('pm_keep') || 'null');
      if (!saved) return;
      var boxes = document.querySelectorAll('.pm-keep');
      for (var i = 0; i < boxes.length; i++) { var k = boxes[i].getAttribute('data-k'); if (saved[k] !== undefined) boxes[i].checked = !!saved[k]; }
    } catch (e) {}
  });

  window.pmSetup = function() {
    var nameEl=document.getElementById('pm-name'), name=nameEl?nameEl.value.trim():'';
    if(!name){window.showToast('Enter a preset name first');return;}
    if(typeof CSInterface==='undefined'||!isAEHost()){window.showToast('Open in After Effects');return;}
    var dur=parseFloat(document.getElementById('pm-dur').value)||3;
    var args={name:name,type:_type,duration:dur,keep:pmGetKeep(),ffxPath:extPath()+'/presets/'+_type+'/'+name+'.ffx'};
    var btn=document.getElementById('pm-setup-btn'); if(btn) btn.disabled=true;
    pmStat('c','Creating comp...');
    pmJsx('_wpm_args='+JSON.stringify(args)+';wpm_setup()', function(r) {
      pmJsx('wpm_step("CB setup fired  raw=" + ("" + r).toString().slice(0,140))');
      if(btn) btn.disabled=false;
      var res=pmParse(r);
      if(!res){pmStat('c','\u2717 Select a layer first');window.showToast('Select a layer in AE');return;}
      if(!res.success){pmStat('c','\u2717 '+(res.error||'Failed'));window.showToast('\u274c '+(res.error||'Setup failed'));return;}
      _setup=true;
      var a=document.getElementById('pm-sec-adjust'),c=document.getElementById('pm-sec-create');
      if(a){a.style.opacity='1';a.style.pointerEvents='auto';}
      if(c){c.style.opacity='1';c.style.pointerEvents='auto';}
      pmStat('c','\u2713 Ready \u2014 adjust animation, then Create');
      window.showToast('\u2713 WP_temp_render created');
    });
  };
  // GIF via Node (async) — keeps After Effects responsive while ffmpeg runs
  function pmGif(args, seqFolder, cb) {
    var cp = require('child_process'), fs = require('fs'), path = require('path');
    var seq = path.normalize(String(seqFolder)), work = path.dirname(seq);
    var ff = path.normalize(args.ffmpegPath);
    var tmpGif = path.join(work, args.name + '.gif'), pal = path.join(work, args.name + '_pal.png');
    var inp = path.join(seq, 'frame_%04d.png'), fps = String(args.fps || 30);
    if (!fs.existsSync(ff)) { cb('ffmpeg.exe not found: ' + ff); return; }
    function run(a, next) {
      var err = '', pr;
      try { pr = cp.spawn(ff, a, { windowsHide: true }); } catch (e) { next(e.message); return; }
      pr.stderr.on('data', function(d) { err = (err + d).slice(-400); });
      pr.on('error', function(e) { next(e.message); });
      pr.on('close', function(code) { next(code === 0 ? null : 'ffmpeg exit ' + code + ': ' + err); });
    }
    run(['-hide_banner', '-loglevel', 'error', '-y', '-framerate', fps, '-i', inp, '-vf', 'fps=15,scale=640:-1:flags=lanczos,palettegen', pal], function(e1) {
      if (e1) { cb(e1); return; }
      run(['-hide_banner', '-loglevel', 'error', '-y', '-framerate', fps, '-i', inp, '-i', pal, '-lavfi', 'fps=15,scale=640:-1:flags=lanczos[v];[v][1:v]paletteuse', tmpGif], function(e2) {
        try { fs.unlinkSync(pal); } catch (x) {}
        if (e2) { cb(e2); return; }
        try {
          var dest = path.normalize(args.gifPath);
          fs.mkdirSync(path.dirname(dest), { recursive: true });
          fs.copyFileSync(tmpGif, dest);
          cb(null);
        } catch (e3) { cb('Cannot write GIF to presets: ' + e3.message); }
      });
    });
  }
  window.pmCreate = function() {
    if(!isAEHost()){window.showToast('Open in After Effects');return;}
    if(!_setup){window.showToast('Run Setup first');return;}
    var nameEl=document.getElementById('pm-name'), name=nameEl?nameEl.value.trim():'';
    if(!name){window.showToast('Enter preset name');return;}
    var ext=extPath(), cat=ext+'/presets/'+_type;
    var args={name:name,type:_type,catPath:cat,gifPath:cat+'/'+name+'.gif',pngPath:cat+'/'+name+'.png',ffmpegPath:ext+'/ytdl/ffmpeg.exe',ffxPath:cat+'/'+name+'.ffx'};
    var btn=document.getElementById('pm-create-btn'); if(btn) btn.disabled=true;
    pmProg(10,true); pmStat('c','Rendering...');
    pmJsx('_wpm_args='+JSON.stringify(args)+';wpm_renderToPngSequence()', function(r1) {
      pmJsx('wpm_step("CB render fired  raw=" + ("" + r1).toString().slice(0,140))');
      var res1=pmParse(r1);
      if(!res1||!res1.success){pmFail((res1&&res1.error)||'Render failed');return;}
      args.fps=res1.fps||30; pmProg(45,true); pmStat('c','Converting to GIF...');
      pmGif(args, res1.seqFolder, function(gifErr) {
        var res2=gifErr?{success:false,error:gifErr}:{success:true};
        if(!res2||!res2.success){pmFail((res2&&res2.error)||'GIF failed \u2014 ffmpeg.exe missing?');return;}
        pmProg(70,true); pmStat('c','Thumbnail...');
        pmJsx('_wpm_args='+JSON.stringify(args)+';wpm_extractPng()', function(r3) {
          var res3=pmParse(r3);
          if(!res3||!res3.success){pmFail((res3&&res3.error)||'Thumbnail failed');return;}
          pmProg(90,true);
          pmJsx('_wpm_args='+JSON.stringify(args)+';wpm_cleanup()', function() {
            pmJsx('wpm_step("CB cleanup fired")');
            pmProg(100,true);
            setTimeout(function(){
              pmProg(0,false); if(btn) btn.disabled=false; _setup=false;
              var a=document.getElementById('pm-sec-adjust'),c=document.getElementById('pm-sec-create');
              if(a){a.style.opacity='.4';a.style.pointerEvents='none';}
              if(c){c.style.opacity='.4';c.style.pointerEvents='none';}
              if(nameEl) nameEl.value='';
              pmStat('c','\u2713 Preset saved!'); window.showToast('\u2b50 '+name+' saved!');
              setTimeout(function(){window.pmSwitch('browser');},800);
            },400);
          });
        });
      });
    });
  };
  function pmFail(msg){pmProg(0,false);var btn=document.getElementById('pm-create-btn');if(btn) btn.disabled=false;pmStat('c','\u2717 '+msg);window.showToast('\u274c '+msg);}
}());

// ═══════════════════════════════════════════════════════════
//  SETTINGS — Python + Install
// ═══════════════════════════════════════════════════════════
(function () {
  function cs() { return new CSInterface(); }
  function extPath() { return cs().getSystemPath('extension').replace(/\\/g, '/'); }

  window.settingsDetectPython = function() {
    var el=document.getElementById('pythonPathStatus');
    if(el){el.style.color='var(--accent-4)';el.textContent='Detecting...';}
    if(typeof CSInterface==='undefined'){if(el) el.textContent='Open in After Effects';return;}
    cs().evalScript('detectPythonForUI()', function(raw) {
      try {
        var res=JSON.parse(raw), inp=document.getElementById('pythonPathInput');
        if(res.found){
          if(inp) inp.value=res.path;
          if(el){el.style.color='var(--accent-3)';el.textContent='\u2713 '+res.path.split('\\').pop();}
          window.showToast('\u2713 Python found');
          // Auto-save so user doesn't have to click Save
          cs().evalScript('audioSavePythonPath("'+res.path.replace(/\\/g,'\\\\')+'")');
        } else {
          if(el){el.style.color='var(--accent-2)';el.textContent='\u2717 Not found \u2014 paste path manually';}
          window.showToast('\u26a0 Python not found');
        }
      } catch(e){if(el){el.style.color='var(--accent-2)';el.textContent='Error: '+raw;}}
    });
  };

  window.settingsSavePython = function() {
    var inp=document.getElementById('pythonPathInput'), path=inp?inp.value.trim():'';
    if(!path){window.showToast('\u26a0 Enter Python path first');return;}
    if(typeof CSInterface==='undefined'){window.showToast('\u26a0 Open in After Effects');return;}
    cs().evalScript('$.weloPyPath='+JSON.stringify(path)+';savePythonPathFromUI($.weloPyPath)', function(r) {
      var el=document.getElementById('pythonPathStatus');
      if(r&&r.slice(0,2)==='ok'){if(el){el.style.color='var(--accent-3)';el.textContent='\u2713 Saved';}window.showToast('\u2713 Saved');}
      else{if(el){el.style.color='var(--accent-2)';el.textContent='\u2717 '+(r||'Failed');}window.showToast('\u274c '+(r||'Failed'));}
    });
  };

  // ── Build a single check row ──
  // ExtendScript can't run Python, but the panel (Node) can: ask torch directly (L-015)
  function checkCudaLive(py) {
    var row = document.getElementById('cudaLiveRow'); if (!row) return;
    var cudaPip = {key:'torch_cuda',label:'PyTorch (CUDA)',pip:window.VIA_TORCH_PIP,uninstall:'torch torchvision torchaudio'};
    if (typeof require !== 'function') { row.innerHTML = chkRow('CUDA \u2014 unknown (Node off)', false, null); return; }
    var code = "import sys\ntry:\n import torch\nexcept Exception as e:\n print('NOTORCH|' + str(e).replace(chr(10),' ')[:140]); sys.exit(0)\nok=torch.cuda.is_available()\nprint('OK|%s|%s|%s' % (ok, torch.version.cuda or 'cpu', torch.cuda.get_device_name(0) if ok else ''))";
    require('child_process').execFile(py, ['-c', code], { timeout: 60000, windowsHide: true, cwd: require('os').tmpdir() }, function (err, out) {
      out = String(out || '').trim().split(/\r?\n/).pop();
      var r = document.getElementById('cudaLiveRow'); if (!r) return;
      if (err && !out) { r.innerHTML = chkRow('CUDA \u2014 check failed', false, null); return; }
      if (out.indexOf('NOTORCH') === 0) {
        var why = out.split('|').slice(1).join('|');
        r.innerHTML = /No module named/i.test(why) || !why
          ? chkRow('CUDA \u2014 PyTorch not installed', false, cudaPip)
          : chkRow('CUDA \u2014 torch failed to load', false, null) + '<div style="font-size:8px;color:var(--text-secondary);font-family:Consolas,monospace;word-break:break-all">' + why.replace(/[<>&]/g, '') + '</div>';
        return;
      }
      var p = out.split('|');
      if (p[0] === 'OK' && p[1] === 'True') r.innerHTML = chkRow('CUDA ' + p[2] + ' \u00b7 ' + p[3], true, null);
      else if (p[0] === 'OK') r.innerHTML = chkRow('CUDA \u2014 PyTorch is CPU-only (' + p[2] + ')', false, cudaPip);
      else r.innerHTML = chkRow('CUDA \u2014 unknown', false, null);
    });
  }
  function chkRow(label, ok, pipInfo) {
    var icon = ok ? '\u2713' : '\u2717';
    var color = ok ? 'var(--accent-3)' : 'var(--accent-2)';
    var mono = "Consolas,'Courier New',monospace";
    var html = '<div style="display:flex;align-items:center;justify-content:space-between;padding:3px 0;font-family:' + mono + ';font-size:9px">';
    html += '<div style="display:flex;align-items:center;gap:5px"><span style="color:'+color+'">'+icon+'</span><span style="color:'+(ok?'var(--text-secondary)':'var(--accent-2)')+'">'+label+'</span></div>';
    if (!ok && pipInfo) {
      var onc = 'settingsInstallOne('+JSON.stringify(pipInfo.key)+','+JSON.stringify(pipInfo.label)+','+JSON.stringify(pipInfo.pip)+','+JSON.stringify(pipInfo.uninstall||'')+')';
      html += '<button onclick="'+onc.replace(/"/g,'&quot;')+'" style="background:none;border:1px solid var(--accent-2);border-radius:4px;color:var(--accent-2);font-size:7px;padding:1px 6px;cursor:pointer;font-family:' + mono + '">install</button>';
    } else if (ok) {
      html += '<span style="color:var(--text-muted);font-size:7px">\u2713</span>';
    }
    html += '</div>';
    return html;
  }

  // ── Locations grid (models/work folders + latest render/transcript) ──
  function settingsCheckLocations(){
    var grid=document.getElementById('chkLocGrid');
    if(!grid) return;
    var mono="Consolas,'Courier New',monospace";
    var sub=function(txt,color){return '<div style="font-size:7px;color:'+(color||'var(--text-muted)')+';font-family:'+mono+';padding-left:12px;word-break:break-all;line-height:1.5">'+txt+'</div>';};
    // Show loading state
    grid.innerHTML='<span style="color:var(--accent-4);font-size:9px;font-family:'+mono+'">Checking locations...</span>';

    if(typeof CSInterface==='undefined'){
      grid.innerHTML=chkRow('Locations', false, null)+sub('Open in After Effects to check locations');
      return;
    }

    var md=window.whisperModelsDir?window.whisperModelsDir():'';
    var wk=(typeof getWhisperDir==='function')?getWhisperDir():'';
    var _cs=new CSInterface();
    _cs.evalScript('checkLocations('+JSON.stringify(md)+','+JSON.stringify(wk)+')', function(raw) {
      var html='';
      try {
        if(!raw || raw==='undefined' || raw==='EvalScript error.'){
          html=chkRow('Locations', false, null)+sub('ExtendScript not loaded — reopen Settings');
          grid.innerHTML=html; return;
        }
        var res=JSON.parse(raw);
        if(res.error){
          html=chkRow('Locations', false, null)+sub(res.error);
          grid.innerHTML=html; return;
        }

        html+=chkRow('Models folder', res.modelsOk, null);
        html+=sub(md||'');

        html+=chkRow('Transcription weights ('+res.ptCount+')', res.ptCount>0, null);
        if(res.ptNames && res.ptNames.length) html+=sub(res.ptNames.join(' · '));

        html+=chkRow('Work folder', res.workOk, null);
        html+=sub(wk||'');

        html+=chkRow('WhisRend.wav (render)', res.wavOk, null);
        if(res.wavOk && res.wavAge!==null) html+=sub((res.wavAge>3?'stale — re-render in AE · ':'')+res.wavAge+' days old',(res.wavAge>3?'var(--accent-4)':'var(--text-muted)'));

        html+=chkRow('WhisRend.json (transcription)', res.jsonOk, null);
      } catch(e) {
        html=chkRow('Locations', false, null)+sub((e&&e.message)||e);
      }
      grid.innerHTML=html;
    });
  }

  // ── Individual install ──
  window.settingsInstallOne = function(key, label, pip, uninstall) {
    if(typeof CSInterface==='undefined'){window.showToast('\u26a0 Open in AE');return;}

    // Show the error REASON under the panel (persists, not just a toast)
    function showReason(msg, isError) {
      var sp = document.getElementById('settingsCheckResult');
      if(!sp) { window.showToast((isError?'\u274c ':'\u2713 ')+msg); return; }
      var line = document.createElement('div');
      line.style.cssText = 'font-size:8px;line-height:1.5;margin-top:5px;padding:6px 8px;border-radius:5px;word-break:break-word;font-family:Consolas,monospace;' +
        (isError ? 'color:#ff7b7b;background:rgba(255,90,90,0.08);border:1px solid rgba(255,90,90,0.25);' : 'color:var(--accent-3);background:rgba(90,220,160,0.08);border:1px solid rgba(90,220,160,0.25);');
      line.textContent = (isError?'\u274c Install failed: ':'\u2713 ')+msg;
      sp.appendChild(line);
      window.showToast((isError?'\u274c Failed — see reason below':'\u2713 Install script ready — double-click it on Desktop'));
    }

    cs().evalScript('installSingleLib(' + JSON.stringify(key).replace(/\\/g,'\\\\') + ',' + JSON.stringify(label).replace(/\\/g,'\\\\') + ',' + JSON.stringify(pip).replace(/\\/g,'\\\\') + ',' + JSON.stringify(uninstall||'').replace(/\\/g,'\\\\') + ')', function(r) {
      if(typeof r==='string' && r.indexOf('opened:')===0) {
        window.showToast('\uD83D\uDCE6 Installing '+label+' — check the CMD window');
        var btn = document.getElementById('btnCheckAll');
        if(btn) { btn.textContent='\uD83D\uDD04 Re-check after install'; btn.style.color='var(--accent-4)'; }
      } else if(typeof r==='string' && r.indexOf('error:')===0) {
        showReason(r.slice(6), true);
      } else {
        showReason((r||'Unknown failure'), true);
      }
    });
  };

  window.settingsCheckAll = function() {
    var result = document.getElementById('settingsCheckResult');
    var sysGrid = document.getElementById('chkSystemGrid');
    var aiGrid = document.getElementById('chkAIGrid');
    var hwGrid = document.getElementById('chkHardwareGrid');
    var pyInfo = document.getElementById('settingsCheckPython');
    var btn = document.getElementById('btnCheckAll');

    if(result) result.style.display='block';
    if(sysGrid) sysGrid.innerHTML='<span style="color:var(--accent-4);font-size:9px">Checking...</span>';
    if(aiGrid) aiGrid.innerHTML='';
    if(hwGrid) hwGrid.innerHTML='';
    settingsCheckLocations();
    if(btn) { btn.disabled=true; btn.textContent='\u23f3 Checking...'; btn.style.color=''; }

    if(typeof CSInterface==='undefined'){
      if(sysGrid) sysGrid.innerHTML='<span style="color:var(--accent-2);font-size:9px">Open in After Effects</span>';
      if(btn) { btn.disabled=false; btn.textContent='\uD83D\uDD2C Check Everything'; btn.style.color=''; }
      return;
    }

    var ext = extPath();
    var _cs = cs();

    // Render results into grids
    function renderCheck(res, raw) {
      function showErr(errMsg){
        if(sysGrid) sysGrid.innerHTML='<div style="color:var(--accent-2);font-size:9px;line-height:1.6;white-space:pre-wrap;grid-column:1/-1">\u2717 '+errMsg+'</div>';
        if(aiGrid) aiGrid.innerHTML='';
        if(hwGrid) hwGrid.innerHTML='';
      }
      try {
        if(!res || res.error){
          var m = (res&&res.error) ? res.error : 'No result';
          if(res&&res.debug) m += '\n\n'+res.debug;
          showErr(m);
          return;
        }
        if(res.pending){ return; }

        // ── System ──
        var sysHtml = '';
        sysHtml += chkRow('Python', !!res._v, null);
        sysHtml += chkRow('run_whisper.py', res.run_whisper, null);
        sysHtml += chkRow('enhance.py', res.enhance_py, null);
        // ffmpeg is an .exe found/downloaded by weloTools (L-012), not the pip package 'ffmpeg-python' (L-017)
        var ffOk = !!res.ffmpeg_bin || !!(window.weloTools && window.weloTools.get('ffmpeg'));
        sysHtml += chkRow('ffmpeg', ffOk, null);
        if (!ffOk) sysHtml += '<div style="font-size:8px;color:var(--text-secondary);padding:0 0 4px 14px">Download it from the <b>External tools</b> card below (no admin needed)</div>';
        if(sysGrid) sysGrid.innerHTML=sysHtml;

        // ── AI Modules ──
        var aiHtml = '';
        aiHtml += chkRow('whisper', res.whisper, {key:'whisper',label:'Whisper',pip:'openai-whisper'});
        aiHtml += chkRow('qwen3-asr', res.qwen_asr, {key:'qwen_asr',label:'Qwen3-ASR',pip:'qwen-asr'});
        aiHtml += chkRow('torch', res.torch, {key:'torch',label:'PyTorch (CUDA)',pip:window.VIA_TORCH_PIP,uninstall:'torch torchvision torchaudio'});
        aiHtml += chkRow('demucs', res.demucs, {key:'demucs',label:'Demucs',pip:'demucs'});
        aiHtml += chkRow('deepfilternet', res.deepfilternet, {key:'deepfilternet',label:'DeepFilterNet',pip:'deepfilternet'});
        aiHtml += chkRow('clearvoice (MossFormer2)', res.clearvoice, {key:'clearvoice',label:'ClearerVoice',pip:'clearvoice'});
        aiHtml += chkRow('audio-separator (de-reverb)', res.audio_separator, {key:'audio_separator',label:'audio-separator',pip:'audio-separator onnxruntime'});
        aiHtml += chkRow('silero-vad', res.silero_vad, {key:'silero_vad',label:'Silero VAD',pip:'silero-vad'});
        aiHtml += chkRow('transformers (Sidon)', res.transformers, {key:'transformers',label:'transformers',pip:'transformers huggingface_hub'});
        aiHtml += chkRow('soundfile', res.soundfile, {key:'soundfile',label:'SoundFile',pip:'soundfile'});
        aiHtml += chkRow('numpy', res.numpy, {key:'numpy',label:'NumPy',pip:'numpy'});
        if(aiGrid) aiGrid.innerHTML=aiHtml;

        // ── Hardware ──
        var hwHtml = '';
        if (res.cuda) {
          hwHtml += chkRow('CUDA ' + (res.cuda_ver||''), true, null);
        } else if (res.cuda_ver && res.cuda_ver.indexOf('driver')>=0) {
          hwHtml += chkRow('CUDA \u2014 GPU found, PyTorch is CPU-only', false, {key:'torch_cuda',label:'PyTorch (CUDA)',pip:window.VIA_TORCH_PIP,uninstall:'torch torchvision torchaudio'});
        } else {
          hwHtml += '<div id="cudaLiveRow">' + chkRow('CUDA \u2014 checking\u2026', false, null) + '</div>';
        }
        if(hwGrid) hwGrid.innerHTML=hwHtml;
        if(!res.cuda && res.python) checkCudaLive(res.python);

// ── Python info ──
        if(pyInfo&&res._v) pyInfo.textContent='Python '+res._v+(res.python?' \u00b7 '+res.python.split('\\').pop():'');

        // ── Permissions warning ──
        if(res.callsys_ok===false){
          if(sysGrid) sysGrid.innerHTML += '<div style="color:#ffb454;font-size:8px;line-height:1.5;padding-top:6px;border-top:1px dashed rgba(255,180,84,0.3)">'+
            '\u26a0 <b>System process launch is blocked</b> — go to After Effects: Edit \u2192 Preferences \u2192 Scripting &amp; Expressions and enable <b>Allow Scripts to Write Files and Access Network</b>. Restart AE, then retry.</div>';
          if(res.callsys_error) {
            var sp = document.getElementById('settingsCheckResult');
            var line = document.createElement('div');
            line.style.cssText='color:var(--text-muted);font-size:7px;margin-top:3px;word-break:break-all';
            line.textContent=res.callsys_error;
            if(sp) sp.appendChild(line);
          }
        }

        if(res.python){
          var inp=document.getElementById('pythonPathInput');if(inp&&!inp.value) inp.value=res.python;
          var pst=document.getElementById('pythonPathStatus');if(pst){pst.style.color='var(--accent-3)';pst.textContent='\u2713 '+res.python.split('\\').pop();}
          cs().evalScript('audioSavePythonPath("'+res.python.replace(/\\/g,'\\\\')+'")');
        }
      } catch(e) {
        showErr('Parse error: ' + String(raw||'').slice(0,150).replace(/</g,'&lt;'));
      }
    }

    // Launch (async) then poll for the result file
    _cs.evalScript('getPythonLibStatus('+JSON.stringify(JSON.stringify(ext))+')', function(raw) {
      if(btn) { btn.disabled=false; btn.textContent='\uD83D\uDD2C Check Everything'; btn.style.color=''; }
      try {
        var res = JSON.parse(raw);
        if(res.launched && res.outPath) {
          // Poll readCheckResult every 600ms up to ~20s.
          // Pass outPath and pyExe as plain (double-escaped) strings to avoid JSON/backslash issues.
          var outArg = JSON.stringify(res.outPath.replace(/\\/g,'\\\\'));
          var pyExeArg = JSON.stringify((res.pyExe||'').replace(/\\/g,'\\\\'));
          var attempts = 0;
          var poll = setInterval(function() {
            attempts++;
            _cs.evalScript('readCheckResult('+outArg+','+pyExeArg+')', function(raw2) {
              var r;
              try { r = JSON.parse(raw2); } catch(e) { r = null; }
              if (r && !r.pending) {
                clearInterval(poll);
                renderCheck(r, raw2);
              } else if (attempts >= 34) { // ~20s
                clearInterval(poll);
                renderCheck({error:'Timed out waiting for Python check result'}, raw2);
              }
            });
          }, 600);
        } else {
          renderCheck(res, raw);
        }
      } catch(e) {
        renderCheck({error:'EvalScript returned: '+String(raw).slice(0,150)}, raw);
      }
    });
  };

  window.settingsInstall = function(mode) {
    if(typeof CSInterface==='undefined'){window.showToast('\u26a0 Open in After Effects');return;}
    cs().evalScript('runPipInstall('+(mode==='cuda'?'true':'false')+')', function(r) {
      if(typeof r==='string' && r.indexOf('opened:')===0) {
        window.showToast('\uD83D\uDCE6 Full installer opened — check the CMD window');
      } else {
        window.showToast('\u274c '+(r||'Failed'));
      }
    });
  };

  WeloInit.add(function () {
    if(typeof CSInterface==='undefined') return;
    setTimeout(function(){
      cs().evalScript('audioGetPythonPath()', function(r) {
        if(r&&r.length>4){var inp=document.getElementById('pythonPathInput');if(inp) inp.value=r;var st=document.getElementById('pythonPathStatus');if(st){st.style.color='var(--accent-3)';st.textContent='\u2713 '+r.split('\\').pop();}}
        else window.settingsDetectPython();
      });
    },2500);
  });
}());
