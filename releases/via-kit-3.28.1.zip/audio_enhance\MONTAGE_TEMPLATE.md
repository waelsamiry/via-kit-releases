# MONTAGE — brief for any AI editor (Claude, Gemini, ChatGPT, local models)

This folder is one shooting day. Every sub-folder (except `montage/`) is **one episode**; it contains several
takes (video files) of the same speaker. A folder **without** videos is a **series**: each of its sub-folders is one
episode, named by its relative path (`series/episode`, e.g. `متابعة المرضى/عملية الجفون`) — its files are then under
`montage/episodes/series/episode/`. Episodes of one series share a style; the series name is context, not a title. Your job is the **editor's first cut**: for every episode choose the best
sentences from its takes, in the best order, and write them to a `cut.json`. After Effects (Via Studios Kit →
Claude Montage → **Build**) turns each `cut.json` into a comp. You never edit video files.

Written by Via Studios Kit ("Prepare"). This file is refreshed by the kit — put your notes in `montage/STATE.md`.

## What you can read
| File | What |
|---|---|
| `montage/brief.json` | target length (seconds), aspect, style, language, editor notes |
| `montage/request.md` | **what the person asks you to do now** (do this) |
| `montage/STATE.md` | your memory: what was done before, per-episode summary, decisions log |
| `montage/style.md` (if present) | house-style rules learned from the editor — always follow |
| `montage/episodes/<episode>/transcript.txt` | every sentence of every take: `ID [start-end s] text \| energy · melody · rate · pauses · fillers · doubled · clarity` |
| `montage/episodes/<episode>/transcript.json` | same + word timings (only if you need them) |
| `montage/episodes/<episode>/sheets/<T>_NNN.jpg` | picture contact sheets: 4×4 tiles, one tile every 4 s, row by row; sheet NNN starts at (NNN−1)×64 s |

Sentence IDs look like `T2_S14` = take T2, sentence 14. Takes are listed at the top of each take block (`T2 = take2.mp4`).
The audio was measured for you (you cannot hear it): **energy** high/normal/low, **melody** lively/normal/flat
(pitch variation), **rate** words per second, **p** pauses inside the sentence, **f** fillers (اه، امم، يعني — also the
"اه" sounds Whisper did not write; Build cuts every one of them out automatically, so a good attempt with f ≥ 1 is fine),
**d** doubled words, **r** restarts (a phrase said twice inside the sentence), **c** clarity 0–1 (low = mumbled or mis-heard words).

## How to edit (rules)
1. Read `request.md`, `brief.json`, `STATE.md` (and `style.md`) first. If a cut already exists, **change it** as asked — don't start over unless asked.
2. Understand the episode's topic (folder name = title). Rebuild what the speaker means to say as an ordered list of ideas.
3. For every idea pick the **single best attempt** across all takes: complete, fluent, no restart, no filler at the start,
   high clarity, good energy/melody; when equal, prefer the later take. Never use two attempts of the same idea.
   Look at the picture sheets when it matters (looking away, out of frame, bad gesture, someone walking in).
4. Start with a strong **hook** (the most striking line), then a logical order; end on a clear closing line.
5. Respect the target length from the brief (±15 %); drop weak ideas rather than squeeze everything.
6. A segment is a run of **consecutive sentences of the same take**: `"from": "T2_S5", "to": "T2_S7"`. Prefer whole
   sentences; use `in`/`out` (seconds, inside that range) only to trim a bad start or end.
7. Only use IDs that exist. Never invent times outside a take. Segments must not overlap in time (same take).
8. **No repeats — the most common mistake.** Speakers repeat a line many times (retakes, "again", restarts). Every idea
   appears ONCE in the cut. A sentence with **r ≥ 1** contains a restart: use `transcript.json` word times to set `in`
   after the abandoned start (or pick another attempt). Same for `d ≥ 1` when the doubled word is audible.
9. **Final check before writing:** read your cut's text in order, start to end, as the viewer will hear it. If any
   idea, phrase or sentence opening appears twice, remove one. Build also removes exact repeats, but don't rely on it.

10. **Fix the transcription** of every sentence you put in the cut. Whisper mishears (medical terms, names, Egyptian
    words); you understand the context. Write ONLY the sentences whose text is wrong to
    `montage/episodes/<episode>/fixes.json` as `{"T1_S5": "النص الصحيح كما قيل"}` — what was really said, same words and
    order, no rewriting, no added words. Build uses it for the subtitles (.srt next to cut.json) and the review list.
11. **Follow-up requests are small**: when `request.md` asks for one change ("شيل الجملة دي", "غيّر الـ hook في الحلقة 3"),
    read STATE.md and only that episode's cut.json / transcript.txt, change just that, and stop. Never redo the day.

## Output — `montage/episodes/<episode>/cut.json` (exact format)
```json
{
  "format": "via-montage-cut/1",
  "episode": "<episode folder name>",
  "title": "<episode title>",
  "version": 3,
  "target": 75,
  "segments": [
    { "take": "take2.mp4", "from": "T2_S5", "to": "T2_S7", "why": "hook: strongest line, clear and energetic" },
    { "take": "take1.mp4", "from": "T1_S12", "to": "T1_S12", "in": 61.20, "why": "best attempt; trimmed false start" }
  ],
  "ideas": [ { "at": 4.0, "dur": 3, "type": "graphic", "what": "exact text / data to show" } ],
  "notes": "one or two sentences for the editor"
}
```
`ideas` (optional) = B-roll / graphic suggestions; `at` = seconds from the start of the episode cut; `type` one of
image, video, graphic, before_after, before, after, text, icon.

## Language
Write `why`, `notes`, `STATE.md` and your final summary in the language of the speech (Arabic footage → Arabic,
Egyptian is fine). The editor may also leave choices in `montage/episodes/<episode>/review.json`
(`off` = sentences they removed, `on` = sentences they kept on purpose) — respect them when you change a cut.

## Keep history (never lose work)
- Before replacing a `cut.json`, copy the old one to `montage/episodes/<episode>/history/cut_vN.json` and raise `version`.
- Append to `montage/STATE.md` → **Decisions log**: date, what was asked, what you changed, per episode.
- Keep the **Episodes** section of `STATE.md` current: per episode — topic in one line, length, hook, takes used, open issues.

## Finish
End with a short summary: per episode — length, hook, anything the editor should check. Then the person presses
**Build** in After Effects.
