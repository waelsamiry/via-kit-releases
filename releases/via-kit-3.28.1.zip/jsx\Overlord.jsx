/*
* Decompiled with Jsxer
* Version: 1.7.4
* JSXBIN 2.0
*/

typeof JSON === 'undefined' && (JSON = {});
(function() {
    if (typeof JSON.stringify !== 'function') {
        JSON.stringify = function(obj) {
            switch (typeof obj) {
                case 'string': return '"' + obj.replace(/["\\\n\r\t\b\f]/g, function(c) {
                    switch (c) { case '"': return '\\"'; case '\\': return '\\\\'; case '\n': return '\\n'; case '\r': return '\\r'; case '\t': return '\\t'; case '\b': return '\\b'; case '\f': return '\\f'; }
                    return c;
                }) + '"';
                case 'number': return isFinite(obj) ? String(obj) : 'null';
                case 'boolean': return String(obj);
                case 'object':
                    if (!obj) return 'null';
                    if (obj instanceof Array) {
                        var a = []; for (var i = 0; i < obj.length; i++) a.push(JSON.stringify(obj[i]));
                        return '[' + a.join(',') + ']';
                    }
                    var k = [];
                    for (var key in obj) {
                        if (Object.prototype.hasOwnProperty.call(obj, key)) {
                            var v = JSON.stringify(obj[key]);
                            if (v !== undefined) k.push(JSON.stringify(key) + ':' + v);
                        }
                    }
                    return '{' + k.join(',') + '}';
            }
            return 'null';
        };
    }
})();
// Resolve enum names like "StrokeCap.ROUND_END_CAP" without eval (payloads come from Vulcan/clipboard)
function _olEnum(s) {
    var m = /^([A-Za-z]+)\.([A-Z_0-9]+)$/.exec(String(s));
    if (!m) return undefined;
    var o = $.global[m[1]];
    return o ? o[m[2]] : undefined;
}
var overlord = (function () {
function ai_newShapes(aeObj) {
function drawText(textObj) {
try {
var x = textObj.position[0] - artboardOffset[0];
var y = artboardOffset[1] - textObj.position[1];
if (textObj.kind == "boxText") { 
var areaTextPath = doc.pathItems.rectangle((textObj.boxTextSize[1] / 2) + y, x - (textObj.boxTextSize[0] / 2), textObj.boxTextSize[0], textObj.boxTextSize[1]);
textLayer = doc.textFrames.areaText(areaTextPath);
}
else {
textLayer = doc.textFrames.pointText([x, y], TextOrientation.HORIZONTAL);
}
textLayer.contents = textObj.contents;
textLayer.textRange.characterAttributes.size = textObj.fontSize;
textLayer.textRange.characterAttributes.textFont = app.textFonts.getByName(textObj.font);
textLayer.textRange.characterAttributes.tracking = textObj.tracking;
textLayer.textRange.characterAttributes.autoLeading = false;
textLayer.textRange.characterAttributes.leading = textObj.leading;
textLayer.textRange.characterAttributes.baselineShift = textObj.baselineShift;
textLayer.textRange.paragraphAttributes.justification = _olEnum(textObj.justification);
if (textObj.applyFill) { 
textLayer.textRange.characterAttributes.fillColor = colorArrayToRGBcolor(textObj.fillColor);
}
if (textObj.applyStroke) { 
textLayer.textRange.characterAttributes.strokeColor = colorArrayToRGBcolor(textObj.strokeColor);
textLayer.textRange.characterAttributes.strokeWeight = textObj.strokeWeight;
}
} catch (err) {alert(e.toString() + "\nError on line: " + e.line.toString());
}
}
function drawShapes(shapeGroups, parentGroup) {
for (var j = shapeGroups.length - 1; j >= 0; j--) { 
var shape = shapeGroups[j];
if (shape.type == "group") { 
var nestGroup = parentGroup.groupItems.add();
nestGroup.name = shape.name;
drawShapes(shape.children, nestGroup);
continue ;
}
if (shape.pathPoints.length > 1) { 
if (shape.filled) { 
app.activeDocument.defaultFilled = true;
if (shape.fillColor.type == "fill") { 
app.activeDocument.defaultFillColor = colorArrayToRGBcolor(shape.fillColor.color);
}
}
if (shape.stroked) { 
app.activeDocument.defaultStroked = true;
if (shape.strokeColor.type == "fill") { 
app.activeDocument.defaultStrokeColor = colorArrayToRGBcolor(shape.strokeColor.color);
app.activeDocument.defaultStrokeWidth = shape.strokeWidth;
app.activeDocument.defaultStrokeCap = _olEnum(shape.strokeCap);
app.activeDocument.defaultStrokeJoin = _olEnum(shape.strokeJoin);
app.activeDocument.defaultStrokeMiterLimit = shape.strokeMiterLimit;
app.activeDocument.defaultStrokeDashes = shape.strokeDashes;
app.activeDocument.defaultStrokeDashOffset = shape.strokeDashOffset;
}
}
}
if (shape.type == "path") { 
s = newPath(shape.pathPoints, parentGroup);
}
if (shape.type == "rect") { 
s = newRect(shape.rectShape, parentGroup);
}
if (shape.type == "ellipse") { 
s = newEllipse(shape.ellipseShape, parentGroup);
}
s.name = shape.name;
s.selected = true;
if (shape.pathPoints.length < 2) { 
if (shape.stroked) { 
if (shape.strokeColor.type == "fill") { 
s.strokeColor = colorArrayToRGBcolor(shape.strokeColor.color);
}
s.strokeWidth = shape.strokeWidth;
s.strokeCap = _olEnum(shape.strokeCap);
s.strokeJoin = _olEnum(shape.strokeJoin);
s.strokeMiterLimit = shape.strokeMiterLimit;
s.strokeDashes = shape.strokeDashes;
s.strokeDashOffset = shape.strokeDashOffset;
}
else {
app.activeDocument.defaultStroked = false;
}
if (shape.filled) { 
if (shape.fillColor.type == "fill") { 
s.fillColor = colorArrayToRGBcolor(shape.fillColor.color);
}
}
else {
app.activeDocument.defaultFilled = false;
}
}}
}
function newPath(pointsArr, parent) {
try {
var isCompoundPath = pointsArr.length > 1 ? true : false;
if (parent != null) { 
if (isCompoundPath) { 
shape = parent.compoundPathItems.add();
}
else {
shape = parent.pathItems.add();
}
}
else {
if (isCompoundPath) { 
shape = doc.compoundPathItems.add();
}
else {
shape = doc.pathItems.add();
}
}
for (var j = 0; j < pointsArr.length; j += 1) { 
var pointsObj = pointsArr[j];
var transformPos = pointsObj.transformPos;
if (isCompoundPath) { 
var innerShape = shape.pathItems.add();
innerShape.closed = pointsObj.closed;
for (var i = 0; i < pointsObj.anchor.length; i += 1) { 
var point = innerShape.pathPoints.add();
point.anchor = [(pointsObj.anchor[i][0] - artboardOffset[0]) + transformPos[0], (artboardOffset[1] - pointsObj.anchor[i][1]) - transformPos[1]];
point.leftDirection = [point.anchor[0] + pointsObj.leftDirection[i][0], point.anchor[1] - pointsObj.leftDirection[i][1]];
point.rightDirection = [point.anchor[0] + pointsObj.rightDirection[i][0], point.anchor[1] - pointsObj.rightDirection[i][1]];}
}
else {
shape.closed = pointsObj.closed;
for (var i = 0; i < pointsObj.anchor.length; i += 1) { 
var point = shape.pathPoints.add();
point.anchor = [(pointsObj.anchor[i][0] - artboardOffset[0]) + transformPos[0], (artboardOffset[1] - pointsObj.anchor[i][1]) - transformPos[1]];
point.leftDirection = [point.anchor[0] + pointsObj.leftDirection[i][0], point.anchor[1] - pointsObj.leftDirection[i][1]];
point.rightDirection = [point.anchor[0] + pointsObj.rightDirection[i][0], point.anchor[1] - pointsObj.rightDirection[i][1]];}
}}
} catch (err) {alert(e.toString() + "\nError on line: " + e.line.toString());
}
return shape;
}
function newRect(rectShape, parent) {
var width = rectShape.size[0];
var height = rectShape.size[1];
var x = (rectShape.position[0] - artboardOffset[0]) - (width / 2);
var y = (artboardOffset[1] - rectShape.position[1]) + (height / 2);
var shape = parent.pathItems.roundedRectangle(y, x, width, height, rectShape.roundness, rectShape.roundness);
return shape;
}
function newEllipse(ellipse, parent) {
var width = ellipse.size[0];
var height = ellipse.size[1];
var x = (ellipse.position[0] - artboardOffset[0]) - (width / 2);
var y = (artboardOffset[1] - ellipse.position[1]) + (height / 2);
var shape = parent.pathItems.ellipse(y, x, width, height, false, true);
return shape;
}
function colorArrayToRGBcolor(colorArray) {
var newRGBColor = new RGBColor();
newRGBColor.red = colorArray[0] * 255;
newRGBColor.green = colorArray[1] * 255;
newRGBColor.blue = colorArray[2] * 255;
return newRGBColor;
}
function colorGradient(grad) {
var newGrad = app.activeDocument.gradients.add();
newGrad.name = "overlordTempGrad";
newGrad.type = GradientType.LINEAR;
newGrad.gradientStops[0].color = colorArrayToRGBcolor([1, 0, 1, 1]);
newGrad.gradientStops[0].rampPoint = 0;
newGrad.gradientStops[1].color = colorArrayToRGBcolor([0, 1, 1, 1]);
newGrad.gradientStops[1].rampPoint = 100;
var newGradColor = new GradientColor();
newGradColor.origin = grad.origin;
newGradColor.angle = grad.angle;
newGradColor.length = grad.length;
newGradColor.gradient = newGrad;
return newGradColor;
}
if (aeObj.shapes.length < 1) { 
return;
}
doc = app.activeDocument;
doc.activate();
if (aeObj.altKey) { 
doc.pageItems.removeAll();
}
doc.selection = null;
var layers = aeObj.shapes;
var artboard = doc.artboards[app.activeDocument.artboards.getActiveArtboardIndex()];
var artboardOrigin = artboard.artboardRect;
var artboardSize = [artboardOrigin[2] - artboardOrigin[0], artboardOrigin[1] - artboardOrigin[3]];
var artboardOffset = [(artboardSize[0] / 2) - artboardOrigin[2], (artboardSize[1] / 2) + artboardOrigin[3]];
try {
doc = app.activeDocument.activeLayer;
} catch (e) {
}
for (var i = layers.length - 1; i >= 0; i--) { 
if (layers[i].children) { 
var shapeGroups = layers[i].children;
var parentGroup = doc;
if (shapeGroups.length > 1) { 
parentGroup = doc.groupItems.add();
parentGroup.name = layers[i].name;
}
drawShapes(shapeGroups, parentGroup);
}
else {
drawText(layers[i]);
}}
app.redraw();
return;
}
function ai_getColor(color, shapePos) {
function matrixTransform(matrix, vecPoint, shapePos) {
var centered = [vecPoint[0] - shapePos[0], vecPoint[1] - shapePos[1]];
var x = (centered[0] * matrix.mValueA) + (centered[1] * matrix.mValueB);
var y = (centered[0] * matrix.mValueC) + (centered[1] * matrix.mValueD);
var point = [x + shapePos[0], y + shapePos[1]];
return point;
}
function getGradient(grad) {
var gradObj = {length: grad.length, points: []};
for (var i = 0; i < gradObj.length; i += 1) { 
gradObj.points.push({color: ai_getColor(grad[i].color), midPoint: grad[i].midPoint / 100, opacity: grad[i].opacity / 100, rampPoint: grad[i].rampPoint / 100});}
return gradObj;
}
if (color.typename === "RGBColor") { 
return {color: [color.red / 255, color.green / 255, color.blue / 255, 1], type: "fill"};
}
if (color.typename === "GrayColor") { 
return {color: [1 - (color.gray / 100), 1 - (color.gray / 100), 1 - (color.gray / 100), 1], type: "fill"};
}
if (color.typename === "CMYKColor") { 
c = color.cyan / 100;
m = color.magenta / 100;
y = color.yellow / 100;
k = color.black / 100;
r = (1 - c) * (1 - k);
g = (1 - m) * (1 - k);
b = (1 - y) * (1 - k);
return {color: [r, g, b, 1], type: "fill"};
}
if (color.typename === "SpotColor") { 
function lerp(min, max, k) {
return min + ((max - min) * k);
}
var tintNorm = 1 - (color.tint / 100);
if (color.spot.color.red !== undefined) { 
colorObj = {color: [lerp(color.spot.color.red / 255, 1, tintNorm), lerp(color.spot.color.green / 255, 1, tintNorm), lerp(color.spot.color.blue / 255, 1, tintNorm), 1], type: "fill"};
}
if (color.spot.color.cyan !== undefined) { 
c = color.spot.color.cyan / 100;
m = color.spot.color.magenta / 100;
y = color.spot.color.yellow / 100;
k = color.spot.color.black / 100;
r = (1 - c) * (1 - k);
g = (1 - m) * (1 - k);
b = (1 - y) * (1 - k);
colorObj = {color: [lerp(r, 1, tintNorm), lerp(g, 1, tintNorm), lerp(b, 1, tintNorm), 1], type: "fill"};
}
return colorObj;
}
if (color.typename === "GradientColor") { 
var startPoint = matrixTransform(color.matrix, [color.origin[0] + artboardOffset[0], -color.origin[1] + artboardOffset[1]], shapePos);
var flip = color.matrix.mValueB < 0 ? -1 : 1;
var a = color.angle + (flip * Math.acos(color.matrix.mValueA) * (180 / Math.PI));
var endPoint = [startPoint[0] + (Math.cos(a * 0.01745329252) * color.length), startPoint[1] - (Math.sin(a * 0.01745329252) * color.length)];
return {angle: color.angle, endPoint: endPoint, gradType: color.gradient.type == GradientType.LINEAR ? 1 : 2, gradient: getGradient(color.gradient.gradientStops), length: color.length, matrix: color.matrix, startPoint: startPoint, type: "gradient"};
}
return null;
}
function ai_newArtboard(aeObj) {
if (((aeObj.prefs.newArtboard == "artboard") && (!aeObj.altKey)) || ((aeObj.prefs.newArtboard == "file") && (aeObj.altKey))) { 
var abRect = app.activeDocument.artboards[app.activeDocument.artboards.getActiveArtboardIndex()].artboardRect;
var rect = [abRect[0], abRect[3] - 20, abRect[0] + aeObj.comp.size[0], (abRect[3] - aeObj.comp.size[1]) - 20];
var artboard = app.activeDocument.artboards.add(rect);
artboard.name = aeObj.comp.name;
}
else {
ai_newDoc(aeObj.comp.size);
}
}
function ai_getSelection(ol_opts) {
overlordPrefs = ol_opts.prefs;
var target = app.activeDocument.selection;
return ai_getDoc(target);
}
function ai_getGuides(ol_opts) {
overlordPrefs = ol_opts.prefs;
aiGuide = true;
var target = [];
for (var i = 0; i < app.activeDocument.pathItems.length; i += 1) { 
if (app.activeDocument.pathItems[i].guides) { 
target.push(app.activeDocument.pathItems[i]);
}}
for (var j = 0; j < target.length; j += 1) { 
target[j].filled = false;
target[j].stroked = true;}
return ai_getDoc(target);
}
function ai_getSwatches(ol_opts) {
overlordPrefs = ol_opts.prefs;
var target = app.activeDocument.swatches.getSelected();
var swatchList = [];
for (var i = 0; i < target.length; i += 1) { 
try {
var color = ai_getColor(target[i].color);
if (color.type !== "gradient") { 
swatchList.push({color: ai_getColor(target[i].color), name: target[i].name});
}
} catch (e) {
}}
return JSON.stringify(swatchList);
}
function ai_getDoc(target) {
function getAiObjData(sel) {
function getChildren(items) {
var children = [];
for (var k = 0; k < items.length; k += 1) { 
if (items[k].hidden) { 
continue ;
}
children.push(getAiObjData(items[k]));}
return children;
}
function getTextData(t) {
var textData = {autoLeading: t.characterAttributes.autoLeading, baselineShift: t.characterAttributes.baselineShift, capitalization: getCapitalization(t.characterAttributes.capitalization), contents: t.contents, fillColor: ai_getColor(t.characterAttributes.fillColor), horizontalScale: t.characterAttributes.horizontalScale / 100, italics: t.characterAttributes.italics, justification: getJustification(t.paragraphAttributes.justification), kind: getTextKind(sel.kind), leading: t.characterAttributes.leading, rotation: t.characterAttributes.rotation, size: t.characterAttributes.size, strokeColor: ai_getColor(t.characterAttributes.strokeColor), strokeWeight: t.characterAttributes.strokeWeight, textFont: getTextFont(t.characterAttributes.textFont), tracking: t.characterAttributes.tracking, verticalScale: t.characterAttributes.verticalScale / 100};
return textData;
}
var strokeWidth = sel.strokeWidth != undefined ? sel.strokeWidth : 0;
var calcPos = [artboardOffset[0] + sel.geometricBounds[0] + (sel.width / 2), (artboardOffset[1] - sel.geometricBounds[1]) + (sel.height / 2)];
var aiObj = {artboardSize: artboardSize, blendingMode: getBlendMode(sel.blendingMode), closed: sel.closed, fillColor: sel.filled ? ai_getColor(sel.fillColor, calcPos) : null, filled: sel.filled, geometricBounds: sel.geometricBounds, guides: sel.guides, layerName: sel.layer.name, message: "null", name: (sel.name) || (""), opacity: sel.opacity, pathPoints: sel.typename == "PathItem" ? getPoints(sel.pathPoints, sel.geometricBounds, sel.width, sel.closed) : null, position: calcPos, positionRaw: [sel.left, sel.top], size: [sel.geometricBounds[2] - sel.geometricBounds[0], Math.abs(sel.geometricBounds[3] - sel.geometricBounds[1])], strokeCap: getStrokeCap(sel.strokeCap), strokeColor: sel.stroked ? ai_getColor(sel.strokeColor, calcPos) : null, strokeDashOffset: sel.strokeDashOffset, strokeDashes: sel.strokeDashes, strokeJoin: getStrokeJoin(sel.strokeJoin), strokeMiterLimit: sel.strokeMiterLimit, strokeWidth: strokeWidth, stroked: sel.stroked, typename: sel.typename, visibleBounds: sel.visibleBounds};
if (sel.clipped) { 
aiObj.typename = "ClipGroup";
}
if (sel.typename == "GroupItem") { 
aiObj.children = getChildren(sel.pageItems);
}
if (sel.typename == "CompoundPathItem") { 
aiObj.children = getChildren(sel.pathItems);
}
if (sel.typename == "TextFrame") { 
aiObj.textRange = getTextData(sel.textRange);
aiObj.rotation = (Math.acos(sel.matrix.mValueB) * (180 / Math.PI)) - 90;
if (getTextKind(sel.kind) == "Area") { 
aiObj.position = [(sel.geometricBounds[0] - artboardOrigin[0]) + (sel.width / 2), (artboardOrigin[1] + (sel.height / 2)) - sel.geometricBounds[1]];
}
else if (getTextKind(sel.kind) == "Point") {
aiObj.position = [sel.anchor[0] - artboardOrigin[0], artboardOrigin[1] - sel.anchor[1]];
}
else if (getTextKind(sel.kind) == "Path") {
aiObj.textPath = getPoints(sel.textPath.pathPoints, sel.geometricBounds, sel.width, sel.textPath.closed);
aiObj.position = [sel.geometricBounds[0] - artboardOrigin[0], (artboardOrigin[1] - sel.geometricBounds[1]) + sel.height];
}
else {
aiObj.message = "Text along a path is not supported";
}
}
return aiObj;
}
function getPoints(points, geometricBounds, width, closed) {
function checkEllipse() {
var pointCount = 0;
for (var k = 0; k < points.length; k += 1) { 
for (var m = 0; m < geometricBounds.length; m += 1) { 
midPoint = (parseFloat(geometricBounds[m % 4] + geometricBounds[(m + 2) % 4]) / 2).toFixed(5);
if (points[k].anchor[0].toFixed(5) == midPoint) { 
pointCount++;
}
if (points[k].anchor[1].toFixed(5) == midPoint) { 
pointCount++;
}}
if (Math.abs(pointObj.leftDirection[k][0] / width).toFixed(5) == 0.27614) { 
pointCount += 3;
}
if (Math.abs(pointObj.leftDirection[k][1] / width).toFixed(5) == 0.27614) { 
pointCount += 3;
}
if (Math.abs(pointObj.rightDirection[k][0] / width).toFixed(5) == 0.27614) { 
pointCount += 3;
}
if (Math.abs(pointObj.rightDirection[k][1] / width).toFixed(5) == 0.27614) { 
pointCount += 3;
}}
return pointCount;
}
function checkRect() {
var pointCount = 0;
for (var k = 0; k < points.length; k += 1) { 
for (var m = 0; m < geometricBounds.length; m += 1) { 
if (points[k].anchor[0] == geometricBounds[m]) { 
pointCount++;
}
if (points[k].anchor[1] == geometricBounds[m]) { 
pointCount++;
}}
if ((pointObj.leftDirection[k][0] == 0) && (pointObj.leftDirection[k][1] == 0)) { 
pointCount++;
}
if ((pointObj.rightDirection[k][0] == 0) && (pointObj.rightDirection[k][1] == 0)) { 
pointCount++;
}}
return pointCount;
}
var pointObj = {anchor: [], closed: closed, leftDirection: [], rightDirection: [], type: "path"};
for (var i = 0; i < points.length; i += 1) { 
pointObj.anchor.push([points[i].anchor[0] + artboardOffset[0], -points[i].anchor[1] + artboardOffset[1]]);
pointObj.leftDirection.push([(points[i].leftDirection[0] - pointObj.anchor[i][0]) + artboardOffset[0], (-points[i].leftDirection[1] - pointObj.anchor[i][1]) + artboardOffset[1]]);
pointObj.rightDirection.push([(points[i].rightDirection[0] - pointObj.anchor[i][0]) + artboardOffset[0], (-points[i].rightDirection[1] - pointObj.anchor[i][1]) + artboardOffset[1]]);}
if (((overlordPrefs.detectParametrics) && (!aiGuide)) && (closed)) { 
if (points.length == 4) { 
var ellipseCount = checkEllipse();
if ((ellipseCount == 32) || (ellipseCount == 20)) { 
pointObj.type = "ellipse";
}
if (checkRect() == 16) { 
pointObj.type = "rect";
}
}
}
return pointObj;
}
function getBlendMode(blendMode) {
if (blendMode == BlendModes.DARKEN) { 
return 3;
}
if (blendMode == BlendModes.MULTIPLY) { 
return 4;
}
if (blendMode == BlendModes.COLORBURN) { 
return 5;
}
if (blendMode == BlendModes.LIGHTEN) { 
return 9;
}
if (blendMode == BlendModes.SCREEN) { 
return 10;
}
if (blendMode == BlendModes.COLORDODGE) { 
return 11;
}
if (blendMode == BlendModes.OVERLAY) { 
return 15;
}
if (blendMode == BlendModes.SOFTLIGHT) { 
return 16;
}
if (blendMode == BlendModes.HARDLIGHT) { 
return 17;
}
if (blendMode == BlendModes.DIFFERENCE) { 
return 23;
}
if (blendMode == BlendModes.EXCLUSION) { 
return 24;
}
if (blendMode == BlendModes.HUE) { 
return 26;
}
if (blendMode == BlendModes.SATURATIONBLEND) { 
return 27;
}
if (blendMode == BlendModes.COLORBLEND) { 
return 28;
}
if (blendMode == BlendModes.LUMINOSITY) { 
return 29;
}
return 1;
}
function getStrokeCap(strokeCap) {
if (strokeCap == StrokeCap.ROUNDENDCAP) { 
return 2;
}
if (strokeCap == StrokeCap.PROJECTINGENDCAP) { 
return 3;
}
return 1;
}
function getStrokeJoin(strokeJoin) {
if (strokeJoin == StrokeJoin.ROUNDENDJOIN) { 
return 2;
}
if (strokeJoin == StrokeJoin.BEVELENDJOIN) { 
return 3;
}
return 1;
}
function getCapitalization(font) {
if (font == FontCapsOption.ALLCAPS) { 
return "all caps";
}
if (font == FontCapsOption.ALLSMALLCAPS) { 
return "all small caps";
}
if (font == FontCapsOption.SMALLCAPS) { 
return "small caps";
}
return "normal";
}
function getTextKind(font) {
if (font == TextType.AREATEXT) { 
return "Area";
}
if (font == TextType.PATHTEXT) { 
return "Path";
}
return "Point";
}
function getJustification(font) {
if (font == Justification.RIGHT) { 
return "ParagraphJustification.RIGHT_JUSTIFY";
}
if (font == Justification.CENTER) { 
return "ParagraphJustification.CENTER_JUSTIFY";
}
if (font == Justification.FULLJUSTIFYLASTLINELEFT) { 
return "ParagraphJustification.FULL_JUSTIFY_LASTLINE_LEFT";
}
if (font == Justification.FULLJUSTIFYLASTLINERIGHT) { 
return "ParagraphJustification.FULL_JUSTIFY_LASTLINE_RIGHT";
}
if (font == Justification.FULLJUSTIFYLASTLINECENTER) { 
return "ParagraphJustification.FULL_JUSTIFY_LASTLINE_CENTER";
}
if (font == Justification.FULLJUSTIFY) { 
return "ParagraphJustification.FULL_JUSTIFY_LASTLINE_FULL";
}
return "ParagraphJustification.LEFT_JUSTIFY";
}
function getTextFont(font) {
return {family: font.family, name: font.name, style: font.style};
}
function showDialog() {
var breakSymbolLinks = false;
var win = new Window("dialog", "Break link to symbols?", undefined, {resizeable: false});
win.alignChildren = ["fill", "fill"];
win.margins = 12;
win.spacing = 2;
win.add("statictext", undefined, "Looks like you selected symbol. Would you like to skip them in this transfer, or break their link and transfer again?", {multiline: true});
var dialogButtons = win.add("group");
dialogButtons.orientation = "row";
dialogButtons.alignment = "center";
dialogButtons.spacing = 16;
var btn_cancel = dialogButtons.add("button", [0, 0, 120, 24], "Skip Symbols", {name: "cancel"});
var btn_ok = dialogButtons.add("button", [0, 0, 120, 24], "Break Link", {name: "ok"});
btn_ok.onClick = function () {
breakSymbolLinks = true;
win.close();
};
win.show();
return breakSymbolLinks;
}
var obj = [];
var artboardOrigin = app.activeDocument.artboards[app.activeDocument.artboards.getActiveArtboardIndex()].artboardRect;
var artboardSize = [artboardOrigin[2] - artboardOrigin[0], artboardOrigin[1] - artboardOrigin[3]];
artboardOffset = [(artboardSize[0] / 2) - artboardOrigin[2], (artboardSize[1] / 2) + artboardOrigin[3]];
var breakSymbolLinks = false;
for (var i = 0; i < target.length; i += 1) { 
var sel = target[i];
if (sel.typename == "SymbolItem") { 
if (breakSymbolLinks === undefined) { 
breakSymbolLinks = showDialog();
}
if (breakSymbolLinks) { 
sel.symbol.duplicate();
sel.symbol.remove();
}
else {
continue ;
}
}
if ((sel.typename == "TextFrame") && (sel.textRange.contents == "")) { 
continue ;
}
obj.push(getAiObjData(sel));}
return JSON.stringify(obj);
}
function ai_newDoc(compSize) {
var docPreset = new DocumentPreset();
docPreset.colorMode = DocumentColorSpace.RGB;
docPreset.width = compSize[0];
docPreset.height = compSize[1];
docPreset.title = "Overlord";
app.documents.addDocument("", docPreset, false);
}
function ai_getArtboard() {
var artboard = app.activeDocument.artboards[app.activeDocument.artboards.getActiveArtboardIndex()];
var artboardOrigin = artboard.artboardRect;
var artboardSize = [artboardOrigin[2] - artboardOrigin[0], artboardOrigin[1] - artboardOrigin[3]];
var obj = {name: artboard.name, size: [Math.round(artboardSize[0]), Math.round(artboardSize[1])]};
return JSON.stringify(obj);
}
function ai_breakSymbols(children) {
var selection = (children) || (app.activeDocument.selection);
var breakCount = 0;
for (var i = 0; i < selection.length; i += 1) { 
var sel = selection[i];
try {
if (sel.typename == "SymbolItem") { 
sel.symbol.duplicate();
sel.symbol.remove();
breakCount++;
}
if (sel.typename == "GroupItem") { 
breakCount += ai_breakSymbols(sel.pageItems);
}
} catch (err) {alert(e.toString() + "\nError on line: " + e.line.toString());
}}
return breakCount;
}
function ae_newShapesFilter(aiObj) {
alertMessage = null;
var altKey = aiObj.altKey;
var shiftKey = aiObj.shiftKey;
overlordPrefs = aiObj.prefs;
if (!setComp()) { 
return "[]";
}
if (aiObj.shapes.length < 1) { 
return;
}
if ((thisComp.selectedLayers.length > 0) && (shiftKey)) { 
ae_deselectProps();
ae_addToLayers(aiObj);
return;
}
if ((thisComp.selectedLayers.length > 0) && (thisComp.selectedProperties.length > 0)) { 
var updateProp = false;
if ((aiObj.shapes.length > 0) && (aiObj.shapes[0].typename != "TextFrame")) { 
updateProp = ae_updateShapes(aiObj);
if (updateProp) { 
return;
}
}
}
else {
if ((altKey) || (overlordPrefs.explode)) { 
ae_newLayersFromGroups(aiObj);
return;
}
}
ae_newLayer(aiObj);
app.executeCommand(2771);
app.executeCommand(2771);
return;
}
function ae_swatches(aiObj) {
overlordPrefs = aiObj.prefs;
if (aiObj.shapes.length < 1) { 
return;
}
try {
setComp();
if (thisComp.name.search(/(Ray - )/) != -1) { 
app.beginUndoGroup("Add swatches to Ray");
ae_raySwatches(aiObj);
app.endUndoGroup();
return;
}
} catch (e) {
}
if ((overlordPrefs.newRay) && (aiObj.rayPresetPath !== null)) { 
app.beginUndoGroup("New Ray Palette");
ae_newRayComp(aiObj);
app.endUndoGroup();
return;
}
if (!setComp()) { 
return "[]";
}
ae_newSwatchLayer(aiObj);
return;
}
function ae_guides(aiObj) {
var scriptGuidesSupported = aiObj.aeVersion.split(".")[0] > 15;
overlordPrefs = aiObj.prefs;
if (aiObj.shapes.length < 1) { 
return;
}
if (!setComp()) { 
return;
}
if ((scriptGuidesSupported) && (overlordPrefs.aeGuides)) { 
var layerGuides = [];
app.beginUndoGroup("Overlord guides");
for (var i = 0; i < aiObj.shapes.length; i += 1) { 
var startPoint = aiObj.shapes[i].pathPoints.anchor[0];
var endPoint = aiObj.shapes[i].pathPoints.anchor[1];
var type = null;
if (startPoint[1] == endPoint[1]) { 
thisComp.addGuide(0, (thisComp.height / 2) + endPoint[1]);
}
else if (startPoint[0] == endPoint[0]) {
thisComp.addGuide(1, (thisComp.width / 2) + endPoint[0]);
}
else {
layerGuides.push(aiObj.shapes[i]);
}}
app.endUndoGroup();
aiObj.shapes = layerGuides;
ae_newLayer(aiObj);
}
else {
aiObj.shapes[0].name = "Guides";
ae_newLayer(aiObj);
}
}
function ae_getSelection() {
if (!setComp()) { 
return "[]";
}
var target = thisComp.selectedLayers;
if (target.length > 0) { 
return ae_getLayerData(target);
}
else {
return "[]";
}
}
function ae_getLayerData(target) {
function getAePropData(sel) {
function getChildren(items) {
var children = [];
for (var k = 1; k <= items.numProperties; k += 1) { 
if (items(k).matchName == "ADBE Vector Group") { 
children.push(getAePropData(items(k)));
}}
return children;
}
function getPathPoints(path) {
var transformPos = path.propertyGroup(3)("ADBE Vector Transform Group")("ADBE Vector Position").valueAtTime(currentTime, false);
var layerOffset = ae_getLayerOffset(path);
var pathPoints = {anchor: path.valueAtTime(currentTime, false).vertices, closed: path.valueAtTime(currentTime, false).closed, leftDirection: path.valueAtTime(currentTime, false).inTangents, rightDirection: path.valueAtTime(currentTime, false).outTangents, transformPos: transformPos + layerOffset};
return pathPoints;
}
function getRectShape(rectGroup) {
var transformPos = rectGroup.propertyGroup(2)("ADBE Vector Transform Group")("ADBE Vector Position").valueAtTime(currentTime, false);
var layerOffset = ae_getLayerOffset(rectGroup);
var pathPoints = {position: rectGroup("ADBE Vector Rect Position").valueAtTime(currentTime, false) + transformPos + layerOffset, roundness: rectGroup("ADBE Vector Rect Roundness").valueAtTime(currentTime, false), size: rectGroup("ADBE Vector Rect Size").valueAtTime(currentTime, false)};
return pathPoints;
}
function getJustification(font) {
if (font == ParagraphJustification.RIGHT_JUSTIFY) { 
return "Justification.RIGHT";
}
if (font == ParagraphJustification.CENTER_JUSTIFY) { 
return "Justification.CENTER";
}
if (font == ParagraphJustification.FULL_JUSTIFY_LASTLINE_LEFT) { 
return "Justification.FULLJUSTIFYLASTLINELEFT";
}
if (font == ParagraphJustification.FULL_JUSTIFY_LASTLINE_RIGHT) { 
return "Justification.FULLJUSTIFYLASTLINERIGHT";
}
if (font == ParagraphJustification.FULL_JUSTIFY_LASTLINE_CENTER) { 
return "Justification.FULLJUSTIFYLASTLINECENTER";
}
if (font == ParagraphJustification.FULL_JUSTIFY_LASTLINE_FULL) { 
return "Justification.FULLJUSTIFY";
}
return "Justification.LEFT";
}
function getEllipseShape(ellipseGroup) {
var transformPos = ellipseGroup.propertyGroup(2)("ADBE Vector Transform Group")("ADBE Vector Position").valueAtTime(currentTime, false);
var layerOffset = ae_getLayerOffset(ellipseGroup);
var pathPoints = {position: ellipseGroup("ADBE Vector Ellipse Position").valueAtTime(currentTime, false) + transformPos + layerOffset, size: ellipseGroup("ADBE Vector Ellipse Size").valueAtTime(currentTime, false)};
return pathPoints;
}
function getBlendMode(blendMode) {
if (blendMode == BlendModes.DARKEN) { 
return 3;
}
if (blendMode == BlendModes.MULTIPLY) { 
return 4;
}
if (blendMode == BlendModes.COLORBURN) { 
return 5;
}
if (blendMode == BlendModes.LIGHTEN) { 
return 9;
}
if (blendMode == BlendModes.SCREEN) { 
return 10;
}
if (blendMode == BlendModes.COLORDODGE) { 
return 11;
}
if (blendMode == BlendModes.OVERLAY) { 
return 15;
}
if (blendMode == BlendModes.SOFTLIGHT) { 
return 16;
}
if (blendMode == BlendModes.HARDLIGHT) { 
return 17;
}
if (blendMode == BlendModes.DIFFERENCE) { 
return 23;
}
if (blendMode == BlendModes.EXCLUSION) { 
return 24;
}
if (blendMode == BlendModes.HUE) { 
return 26;
}
if (blendMode == BlendModes.SATURATIONBLEND) { 
return 27;
}
if (blendMode == BlendModes.COLORBLEND) { 
return 28;
}
if (blendMode == BlendModes.LUMINOSITY) { 
return 29;
}
return 1;
}
function getStrokeCap(strokeCap) {
if (strokeCap == 2) { 
return "StrokeCap.ROUNDENDCAP";
}
if (strokeCap == 3) { 
return "StrokeCap.PROJECTINGENDCAP";
}
return "StrokeCap.BUTTENDCAP";
}
function getStrokeJoin(strokeJoin) {
if (strokeJoin == 2) { 
return "StrokeJoin.ROUNDENDJOIN";
}
if (strokeJoin == 3) { 
return "StrokeJoin.BEVELENDJOIN";
}
return "StrokeJoin.MITERENDJOIN";
}
function getGradient(gradGroup) {
var startPoint = gradGroup("ADBE Vector Grad Start Pt").value;
var endPoint = gradGroup("ADBE Vector Grad End Pt").value;
var angle = Math.atan2(endPoint[1] - startPoint[1], endPoint[0] - startPoint[0]);
var length = Math.sqrt(Math.pow(endPoint[0] - startPoint[0], 2) + Math.pow(endPoint[1] - startPoint[1], 2));
return {angle: angle, gradType: gradGroup("ADBE Vector Grad Type").value == 1 ? "GradientType.LINEAR" : "GradientType.RADIAL", length: length, origin: startPoint, type: "gradient"};
}
function getDashes(dashes) {
var dashArray = [];
for (var i = 1; i < dashes.numProperties; i += 1) { 
if (dashes(i).canSetExpression) { 
dashArray.push(dashes(i).valueAtTime(currentTime, true));
}}
return dashArray;
}
var aeObj = {filled: false, matchName: sel.matchName, name: sel.name, pathPoints: [], stroked: false, type: "group"};
for (var k = 1; k <= sel(2).numProperties; k += 1) { 
var prop = sel(2)(k);
if (prop.matchName == "ADBE Vector Shape - Group") { 
aeObj.type = "path";
var path = prop("ADBE Vector Shape");
aeObj.pathPoints.push(getPathPoints(path));
}}
if (aeObj.matchName == "ADBE Text Layer") { 
aeObj.type = "text";
var textObj = sel.sourceText.value;
var layerRect = sel.sourceRectAtTime(app.project.activeItem.time, false);
var layerOffset = ae_getLayerOffset(prop);
aeObj.position = layerOffset;
aeObj.font = textObj.font;
aeObj.contents = textObj.text;
aeObj.fontSize = textObj.fontSize;
aeObj.tracking = textObj.tracking;
aeObj.leading = textObj.leading;
aeObj.baselineShift = textObj.baselineShift;
aeObj.justification = getJustification(textObj.justification);
aeObj.applyFill = textObj.applyFill;
aeObj.applyStroke = textObj.applyStroke;
if (textObj.boxText) { 
aeObj.kind = "boxText";
aeObj.boxTextSize = textObj.boxTextSize;
aeObj.boxTextPos = textObj.boxTextPos;
}
else {
aeObj.kind = "pointText";
}
if (textObj.applyFill) { 
aeObj.fillColor = textObj.fillColor;
}
if (textObj.applyStroke) { 
aeObj.strokeColor = textObj.strokeColor;
aeObj.strokeWidth = textObj.strokeWidth;
}
var list = [];
for (var key in textObj) { 
if (textObj.hasOwnProperty(key)) { 
list.push(key);
}
}
}
if (aeObj.matchName == "ADBE Vector Layer") { 
aeObj.children = getChildren(sel(2));
}
if (aeObj.matchName == "ADBE Vector Group") { 
aeObj.children = getChildren(sel(2));
aeObj.blendingMode = sel("ADBE Vector Blend Mode").value;
if (sel(2)("ADBE Vector Shape - Rect") != undefined) { 
aeObj.type = "rect";
aeObj.rectShape = getRectShape(sel(2)("ADBE Vector Shape - Rect"));
}
if (sel(2)("ADBE Vector Shape - Ellipse") != undefined) { 
aeObj.type = "ellipse";
aeObj.ellipseShape = getEllipseShape(sel(2)("ADBE Vector Shape - Ellipse"));
}
if ((sel(2)("ADBE Vector Graphic - Fill") != undefined) && (sel(2)("ADBE Vector Graphic - Fill").enabled)) { 
aeObj.filled = true;
aeObj.fillColor = {color: sel(2)("ADBE Vector Graphic - Fill")("ADBE Vector Fill Color").value, type: "fill"};
}
if ((sel(2)("ADBE Vector Graphic - G-Fill") != undefined) && (sel(2)("ADBE Vector Graphic - G-Fill").enabled)) { 
aeObj.filled = true;
aeObj.fillColor = getGradient(sel(2)("ADBE Vector Graphic - G-Fill"));
}
if ((sel(2)("ADBE Vector Graphic - Stroke") != undefined) && (sel(2)("ADBE Vector Graphic - Stroke").enabled)) { 
var strokeGroup = sel(2)("ADBE Vector Graphic - Stroke");
aeObj.stroked = true;
aeObj.strokeWidth = strokeGroup("ADBE Vector Stroke Width").value;
aeObj.strokeCap = getStrokeCap(strokeGroup("ADBE Vector Stroke Line Cap").value);
aeObj.strokeJoin = getStrokeJoin(strokeGroup("ADBE Vector Stroke Line Join").value);
aeObj.strokeDashes = getDashes(strokeGroup("ADBE Vector Stroke Dashes"));
aeObj.strokeDashOffset = (strokeGroup("ADBE Vector Stroke Line Cap").value) || (0);
aeObj.strokeMiterLimit = (strokeGroup("ADBE Vector Stroke Miter Limit").value) || (null);
aeObj.strokeColor = {color: sel(2)("ADBE Vector Graphic - Stroke")("ADBE Vector Stroke Color").value, type: "fill"};
}
if ((sel(2)("ADBE Vector Graphic - G-Stroke") != undefined) && (sel(2)("ADBE Vector Graphic - G-Stroke").enabled)) { 
aeObj.stroked = true;
aeObj.strokeColor = getGradient(sel(2)("ADBE Vector Graphic - G-Stroke"));
}
}
return aeObj;
}
var obj = [];
for (var i = 0; i < target.length; i += 1) { 
var sel = target[i];
obj.push(getAePropData(sel));}
return JSON.stringify(obj);
}
function ae_getLayerOffset(prop) {
var center = [thisComp.width / 2, thisComp.height / 2];
var layer = prop.propertyGroup(prop.propertyDepth);
var layerPosition = layer("ADBE Transform Group")("ADBE Position").valueAtTime(currentTime, false);
var layeAnchorPoint = layer("ADBE Transform Group")("ADBE Anchor Point").valueAtTime(currentTime, false);
var layerOffset = [(layerPosition[0] - layeAnchorPoint[0]) - center[0], (layerPosition[1] - layeAnchorPoint[1]) - center[1]];
return layerOffset;
}
function setComp() {
try { if (app.activeViewer) app.activeViewer.setActive(); } catch (viewerErr) {}
thisComp = app.project.activeItem;
if ((!thisComp) || (!(thisComp instanceof CompItem))) { 
return false;
}
currentTime = thisComp.time;
return true;
}
function removeTopGroup(aiObj) {
var shapes = [];
if ((aiObj.length == 1) && (aiObj[0].typename == "GroupItem")) { 
shapes = removeTopGroup(aiObj[0].children);
}
else {
shapes = aiObj;
}
return shapes;
}
function nameInc(inputStr) {
var incName = inputStr;
var inputCaps = inputStr.toUpperCase();
var thisComp = app.project.activeItem;
for (var i = 1, il = thisComp.layers.length + 1; i < il; i++) { 
activeLayer = thisComp.layer(i);
activeCaps = activeLayer.name.toUpperCase();
if (activeCaps === inputCaps) { 
var lnSuf = parseInt(incName.match(/\d+$/));
if (!isNaN(lnSuf)) { 
var numInc = parseInt(lnSuf) + 1;
var lnCtrlName = activeLayer.name.split(/\d+$/)[0];
incName = lnCtrlName + numInc;
incName = nameInc(incName);
break ;
}
else {
incName = inputStr + " 2";
incName = nameInc(incName);
break ;
}
}}
return incName;
}
function compNameInc(inputStr) {
var incName = inputStr;
var inputCaps = inputStr.toUpperCase();
for (var i = 1, il = app.project.items.length + 1; i < il; i++) { 
activeLayer = app.project.item(i);
activeCaps = activeLayer.name.toUpperCase();
if (activeCaps === inputCaps) { 
var lnSuf = parseInt(incName.match(/\d+$/));
if (!isNaN(lnSuf)) { 
var numInc = parseInt(lnSuf) + 1;
var lnCtrlName = activeLayer.name.split(/\d+$/)[0];
incName = lnCtrlName + numInc;
incName = compNameInc(incName);
break ;
}
else {
incName = inputStr + " 2";
incName = compNameInc(incName);
break ;
}
}}
return incName;
}
function ae_buildShapes(layer, elements, selectProp) {
function centerGroup(g) {
try {
if (centerPath) { 
g("ADBE Vector Transform Group")("ADBE Vector Position").setValue([element.position[0] + (thisComp.width / 2), element.position[1] + (thisComp.height / 2)]);
g("ADBE Vector Transform Group")("ADBE Vector Anchor").setValue([element.position[0] + (thisComp.width / 2), element.position[1] + (thisComp.height / 2)]);
if ((g(2).numProperties < 2) && ((g.propertyDepth > 2) || ((g(2)(1)("ADBE Vector Transform Group")("ADBE Vector Position").value[0] == 0) && (g(2)(1)("ADBE Vector Transform Group")("ADBE Vector Position").value[1] == 0)))) { 
g("ADBE Vector Transform Group")("ADBE Vector Anchor").setValue([0, 0]);
}
}
} catch (error) {
}
}
function centerClippingLayer(g) {
try {
if (centerPath) { 
hasClippingMask = true;
g("ADBE Vector Transform Group")("ADBE Vector Position").setValue([element.position[0] + (thisComp.width / 2), element.position[1] + (thisComp.height / 2)]);
g("ADBE Vector Transform Group")("ADBE Vector Anchor").setValue([element.position[0] + (thisComp.width / 2), element.position[1] + (thisComp.height / 2)]);
g.propertyGroup(g.propertyDepth)("ADBE Transform Group")("ADBE Anchor Point").setValue(g.propertyGroup(g.propertyDepth)("ADBE Transform Group")("ADBE Position").value);
}
} catch (error) {
}
}
function newPath(g, element) {
shape = g(2).addProperty("ADBE Vector Shape - Group");
path = shape("ADBE Vector Shape");
if (centerPath) { 
layerOffset = element.position;
}
else {
layerOffset = ae_getLayerOffset(shape);
}
var pathObj = {anchor: element.pathPoints.anchor, closed: element.closed, leftDirection: element.pathPoints.leftDirection, path: path, rightDirection: element.pathPoints.rightDirection};
createStaticShape(pathObj, layerOffset);
return shape;
}
function newRect(g, element) {
var shape = g(2).addProperty("ADBE Vector Shape - Rect");
var layerOffset = ae_getLayerOffset(shape);
var shapeSize = shape("ADBE Vector Rect Size");
if (shapeSize.numKeys > 0) { 
shapeSize.setValueAtTime(currentTime, element.size);
}
else {
shapeSize.setValue(element.size);
}
var groupPos = shape.propertyGroup(2)("ADBE Vector Transform Group")("ADBE Vector Position");
if (groupPos.numKeys > 0) { 
groupPos.setValueAtTime(currentTime, element.position - layerOffset);
}
else {
groupPos.setValue(element.position - layerOffset);
}
return shape;
}
function newEllipse(g, element) {
var shape = g(2).addProperty("ADBE Vector Shape - Ellipse");
var layerOffset = ae_getLayerOffset(shape);
var shapeSize = shape("ADBE Vector Ellipse Size");
if (shapeSize.numKeys > 0) { 
shapeSize.setValueAtTime(currentTime, element.size);
}
else {
shapeSize.setValue(element.size);
}
var groupPos = shape.propertyGroup(2)("ADBE Vector Transform Group")("ADBE Vector Position");
if (groupPos.numKeys > 0) { 
groupPos.setValueAtTime(currentTime, element.position - layerOffset);
}
else {
groupPos.setValue(element.position - layerOffset);
}
return shape;
}
function newCompound(g, element) {
function setParamPos(shape) {
var shapePos = shape(3);
if (shapePos.numKeys > 0) { 
shapePos.setValueAtTime(currentTime, compoundElement.position);
}
else {
shapePos.setValue(compoundElement.position);
}
}
var pathDir = 0;
for (var j = 0; j < element.children.length; j += 1) { 
compoundElement = element.children[j];
compoundElement.position = element.position;
if ((compoundElement.typename == "PathItem") && (compoundElement.pathPoints.type === "path")) { 
shape = newPath(g, compoundElement);
}
else if ((compoundElement.typename == "PathItem") && (compoundElement.pathPoints.type === "rect")) {
shape = newRect(g, compoundElement);
}
else {
if ((compoundElement.typename == "PathItem") && (compoundElement.pathPoints.type === "ellipse")) { 
shape = newEllipse(g, compoundElement);
}
}}
var groupPos = shape.propertyGroup(2)("ADBE Vector Transform Group")("ADBE Vector Position");
if (groupPos.numKeys > 0) { 
groupPos.setValueAtTime(currentTime, [0, 0]);
}
else {
groupPos.setValue([0, 0]);
}
return shape;
}
function buildMask(layer, element, posOffset) {
function findPath(elm) {
if (elm.typename == "GroupItem") { 
foundPath = findPath(elm.children[0]);
}
if (elm.typename == "PathItem") { 
foundPath = elm;
}
return foundPath;
}
try {
shape = layer("ADBE Mask Parade").addProperty("ADBE Mask Atom");
path = shape("ADBE Mask Shape");
var elementPath = element;
var pathObj = {anchor: elementPath.anchor, closed: elementPath.closed, leftDirection: elementPath.leftDirection, path: path, rightDirection: elementPath.rightDirection};
if (centerPath) { 
layerOffset = [thisComp.width / -2, thisComp.height / -2];
}
else if (posOffset) {
layerOffset = posOffset;
}
else {
layerOffset = [0, 0];
}
createStaticShape(pathObj, layerOffset);
} catch (e) {
}
}
for (var i = 0; i < elements.length; i += 1) { 
element = elements[i];
var prop = layer.property(2);
if (element.typename == "GroupItem") { 
g = prop.addProperty("ADBE Vector Group");
g.name = element.name;
if (selectProp) { 
g.selected = true;
}
g("ADBE Vector Blend Mode").setValue(element.blendingMode);
ae_buildShapes(g, element.children);
centerGroup(g);
continue ;
}
if ((element.typename == "PathItem") && (element.pathPoints.type === "ellipse")) { 
g = prop.addProperty("ADBE Vector Group");
g.name = element.name;
if (selectProp) { 
g.selected = true;
}
g("ADBE Vector Materials Group").remove();
g("ADBE Vector Blend Mode").setValue(element.blendingMode);
newEllipse(g, element);
}
if ((element.typename == "PathItem") && (element.pathPoints.type === "rect")) { 
g = prop.addProperty("ADBE Vector Group");
g.name = element.name;
if (selectProp) { 
g.selected = true;
}
g("ADBE Vector Materials Group").remove();
g("ADBE Vector Blend Mode").setValue(element.blendingMode);
newRect(g, element);
}
if ((element.typename == "PathItem") && (element.pathPoints.type === "path")) { 
g = prop.addProperty("ADBE Vector Group");
g.name = element.name;
if (selectProp) { 
g.selected = true;
}
g("ADBE Vector Materials Group").remove();
g("ADBE Vector Blend Mode").setValue(element.blendingMode);
newPath(g, element);
}
if (element.typename == "TextFrame") { 
if ((elements.length < 2) && (!selectProp)) { 
layer.remove();
}
var attr = element.textRange;
if (attr.kind == "Point") { 
textLayer = thisComp.layers.addText("");
}
if (attr.kind == "Area") { 
textLayer = thisComp.layers.addBoxText(element.size, "");
}
if (attr.kind == "Path") { 
textLayer = thisComp.layers.addText("");
var maskOffset = [-element.size[0] / 2, element.position[1] - element.size[1]];
buildMask(textLayer, element.textPath, [-element.size[0], 0]);
}
var adjustedPosition = [element.position[0] + ((thisComp.width - element.artboardSize[0]) / 2), element.position[1] + ((thisComp.height - element.artboardSize[1]) / 2)];
textLayer("ADBE Transform Group")("ADBE Position").setValue(adjustedPosition);
textLayer.name = attr.contents.replace(/\r?\n|\r/g, " ");
var textProp = textLayer("ADBE Text Properties")("ADBE Text Document");
var textDoc = textProp.value;
textDoc.resetCharStyle();
textDoc.resetParagraphStyle();
textDoc.font = attr.textFont.name;
textDoc.fontSize = attr.size;
try {
textDoc.applyFill = attr.fillColor !== null;
textDoc.fillColor = [attr.fillColor.color[0], attr.fillColor.color[1], attr.fillColor.color[2]];
} catch (e) {textDoc.applyFill = false;
}
try {
textDoc.applyStroke = attr.strokeColor !== null;
textDoc.strokeWidth = attr.strokeWeight;
textDoc.strokeColor = [attr.strokeColor.color[0], attr.strokeColor.color[1], attr.strokeColor.color[2]];
} catch (e) {textDoc.applyStroke = false;
}
textDoc.tracking = attr.tracking;
try {
textDoc.leading = attr.leading;
} catch (e) {
}
textDoc.justification = _olEnum(attr.justification);
textDoc.verticalScale = attr.verticalScale;
textDoc.horizontalScale = attr.horizontalScale;
textDoc.baselineShift = attr.baselineShift;
textProp.setValue(textDoc);
if (attr.capitalization == "all caps") { 
attr.contents = attr.contents.toUpperCase();
}
textProp.setValue(attr.contents);
var center = [thisComp.width / 2, thisComp.height / 2];
if ((overlordPrefs.centerLayer) && (!centerPath)) { 
app.executeCommand(10312);
textLayer("ADBE Transform Group")("ADBE Position").setValue(center);
continue ;
}
if (overlordPrefs.centerLayer) { 
textLayer("ADBE Transform Group")("ADBE Position").setValue(center);
continue ;
}
textLayer("ADBE Transform Group")("ADBE Opacity").setValue(element.opacity);
textLayer("ADBE Transform Group")("ADBE Rotate Z").setValue(element.rotation);
textLayer.blendingMode = layerBlendingMode(element.blendingMode);
}
if (((element.typename == "ClipGroup") && (element.children.length > 1)) && (element.children[1].typename == "GroupItem")) { 
g = prop.addProperty("ADBE Vector Group");
g.name = element.name;
if (selectProp) { 
g.selected = true;
}
g("ADBE Vector Transform Group")("ADBE Vector Group Opacity").setValue(element.opacity);
var subElement = [];
var mask = element.children[0];
for (var m = 1; m < element.children.length; m += 1) { 
subElement.push(element.children[m]);}
ae_buildShapes(g, subElement);
buildMask(layer, mask);
centerClippingLayer(g);
continue ;
}
if (((element.typename == "ClipGroup") && (element.children.length > 1)) && (element.children[1].typename != "GroupItem")) { 
function makeClipGroup(element, maskShape) {
for (var k = 0; k < element.children.length; k += 1) { 
if (element.children[k].typename == "GroupItem") { 
makeClipGroup(element.children[k], maskShape);
}
else {
subGroup = g(2).addProperty("ADBE Vector Group");
subGroup.name = element.children[k].name;
makeClipShape(subGroup, element.children[k]);
mask = makeClipShape(subGroup, maskShape);
mask.name = "Mask";
merge = subGroup(2).addProperty("ADBE Vector Filter - Merge");
merge("ADBE Vector Merge Type").setValue(4);
}
try {
setStroke(subGroup, element.children[k].children[0]);
} catch (e) {try {
setStroke(subGroup, element.children[k]);
} catch (e) {
}
}
try {
setFill(subGroup, element.children[k].children[0]);
} catch (e) {try {
setFill(subGroup, element.children[k]);
} catch (e) {
}
}}
}
function makeClipShape(g, compoundElement) {
if ((compoundElement.typename == "PathItem") && (compoundElement.pathPoints.type === "rect")) { 
shape = newRect(g, compoundElement);
}
if ((compoundElement.typename == "PathItem") && (compoundElement.pathPoints.type === "ellipse")) { 
shape = newEllipse(g, compoundElement);
}
try {
var shapePos = shape(3);
if (shapePos.numKeys > 0) { 
shapePos.setValueAtTime(currentTime, compoundElement.position);
}
else {
shapePos.setValue(compoundElement.position);
}
} catch (e) {
}
if ((compoundElement.typename == "PathItem") && (compoundElement.pathPoints.type === "path")) { 
shape = newPath(g, compoundElement);
}
if (compoundElement.typename == "CompoundPathItem") { 
shape = g(2).addProperty("ADBE Vector Group");
newCompound(shape, compoundElement);
g(2).addProperty("ADBE Vector Filter - Merge");
}
try {
var groupPos = shape.propertyGroup(2)("ADBE Vector Transform Group")("ADBE Vector Position");
if (groupPos.numKeys > 0) { 
groupPos.setValueAtTime(currentTime, [0, 0]);
}
else {
groupPos.setValue([0, 0]);
}
return shape;
} catch (e) {
}
}
var pathDir = 0;
for (var j = 1; j < element.children.length; j += 1) { 
g = prop.addProperty("ADBE Vector Group");
g.name = element.children[j].name;
g("ADBE Vector Materials Group").remove();
g("ADBE Vector Blend Mode").setValue(element.blendingMode);
if (element.children[j].typename == "GroupItem") { 
subGroup = makeClipGroup(element.children[j], element.children[0]);
}
else {
makeClipShape(g, element.children[j]);
mask = makeClipShape(g, element.children[0]);
try {
mask.name = "Mask";
} catch (e) {
}
merge = g(2).addProperty("ADBE Vector Filter - Merge");
merge("ADBE Vector Merge Type").setValue(4);
}
if (element.children[j].typename == "CompoundPathItem") { 
try {
setStroke(g, element.children[j].children[0]);
} catch (e) {
}
try {
setFill(g, element.children[j].children[0]);
} catch (e) {
}
}
try {
setStroke(g, element.children[j]);
} catch (e) {
}
try {
setFill(g, element.children[j]);
} catch (e) {
}}
if ((element.children != undefined) && ((element.children[0].filled) || (element.children[0].stroked))) { 
g = prop.addProperty("ADBE Vector Group");
g.name = element.children[0].name;
g("ADBE Vector Materials Group").remove();
g("ADBE Vector Blend Mode").setValue(element.blendingMode);
makeClipShape(g, element.children[0]);
try {
setStroke(g, element.children[0]);
} catch (e) {
}
try {
setFill(g, element.children[0]);
} catch (e) {
}
}
}
if ((element.typename == "CompoundPathItem") && (element.children.length < 1)) { 
alertMessage = alertMessages.missingCompoundPaths;
}
if ((element.typename == "CompoundPathItem") && (element.children.length > 0)) { 
g = prop.addProperty("ADBE Vector Group");
g.name = element.name;
g("ADBE Vector Materials Group").remove();
g("ADBE Vector Blend Mode").setValue(element.blendingMode);
newCompound(g, element);
setStroke(g, element.children[0]);
setFill(g, element.children[0]);
}
setStroke(g, element, true);
setFill(g, element, true);
if (elements.length > 1) { 
try {
if ((centerPath) && (element.typename !== "TextFrame")) { 
g("ADBE Vector Transform Group")("ADBE Vector Position").setValue([element.position[0] + (thisComp.width / 2), element.position[1] + (thisComp.height / 2)]);
}
else {
if ((centerPath) && (element.typename == "TextFrame")) { 
textLayer.selected = true;
app.executeCommand(10312);
}
}
g("ADBE Vector Transform Group")("ADBE Vector Group Opacity").setValue(element.opacity);
} catch (e) {
}
}}
return g;
}
function setFill(g, currentElement) {
var element = currentElement;
if ((element.filled) && (element.fillColor !== null)) { 
if (element.fillColor.type == "fill") { 
fill = g(2).addProperty("ADBE Vector Graphic - Fill");
fill("ADBE Vector Fill Color").setValue(element.fillColor.color);
}
if (element.fillColor.type == "gradient") { 
fill = g(2).addProperty("ADBE Vector Graphic - G-Fill");
fill("ADBE Vector Grad Type").setValue(element.fillColor.gradType);
var isParametric = (element.typename == "PathItem") && ((element.pathPoints.type === "ellipse") || (element.pathPoints.type === "rect")) ? true : false;
var centerOffset = (centerPath) || (isParametric) ? element.position : [0, 0];
fill("ADBE Vector Grad Start Pt").setValue(element.fillColor.startPoint - centerOffset);
fill("ADBE Vector Grad End Pt").setValue(element.fillColor.endPoint - centerOffset);
applyGradientFfx("fillColor", false, currentElement);
}
}
}
function setStroke(g, currentElement) {
var element = currentElement;
if (element.guides) { 
fill = g(2).addProperty("ADBE Vector Graphic - Stroke");
fill("ADBE Vector Stroke Color").setValue([0.29, 1, 1, 1]);
return;
}
if ((element.stroked) && (element.strokeColor !== null)) { 
if (element.strokeColor.type == "fill") { 
fill = g(2).addProperty("ADBE Vector Graphic - Stroke");
fill("ADBE Vector Stroke Color").setValue(element.strokeColor.color);
}
else {
if (element.strokeColor.type == "gradient") { 
var isParametric = (element.typename == "PathItem") && ((element.pathPoints.type === "ellipse") || (element.pathPoints.type === "rect")) ? true : false;
var centerOffset = (centerPath) || (isParametric) ? element.position : [0, 0];
fill = g(2).addProperty("ADBE Vector Graphic - G-Stroke");
fill("ADBE Vector Grad Type").setValue(element.strokeColor.gradType);
fill("ADBE Vector Grad Start Pt").setValue(element.strokeColor.startPoint - centerOffset);
fill("ADBE Vector Grad End Pt").setValue(element.strokeColor.endPoint - centerOffset);
applyGradientFfx("strokeColor", false, element);
}
}
fill("ADBE Vector Stroke Width").setValue(element.strokeWidth);
fill("ADBE Vector Stroke Line Cap").setValue(element.strokeCap);
fill("ADBE Vector Stroke Line Join").setValue(element.strokeJoin);
if (element.strokeJoin == 1) { 
fill("ADBE Vector Stroke Miter Limit").setValue(element.strokeMiterLimit);
}
for (var j = 1; j <= element.strokeDashes.length; j += 1) { 
countRound = Math.round(j / 2);
if ((j - 1) == 0) { 
fill("ADBE Vector Stroke Dashes").addProperty("ADBE Vector Stroke Dash " + countRound);
fill("ADBE Vector Stroke Dashes")("ADBE Vector Stroke Dash " + countRound).setValue(element.strokeDashes[j - 1]);
}
else {
fill("ADBE Vector Stroke Dashes").addProperty("ADBE Vector Stroke Gap " + countRound);
fill("ADBE Vector Stroke Dashes")("ADBE Vector Stroke Gap " + countRound).setValue(element.strokeDashes[j - 1]);
}}
}
}
function applyGradientFfx(type, dontTwirl, element) {
function buildFromBinary(str, filename) {
var binaryString = str;
var exportFile = new File(ffxFolder + "/" + filename);
exportFile.encoding = "BINARY";
exportFile.open("w");
exportFile.write(binaryString);
exportFile.close();
return exportFile;
}
function buildByLines(str, filename) {
var binaryString = "";
var lines = str.split("\n");
for (var i = 0; i < lines.length; i += 1) { 
line = lines[i];
binaryString += line + "\n";}
var exportFile = new File(ffxFolder + "/" + filename);
exportFile.encoding = "BINARY";
exportFile.open("w");
exportFile.write(binaryString);
exportFile.close();
return exportFile;
}
function createFile(str, filename) {
var binaryString = "";
var lines = str.split("\n");
for (var i = 0; i < lines.length; i += 1) { 
line = lines[i];
if (line.search(/points/) != -1) { 
str = eval("element." + type + ".gradient." + line.toString()).toFixed(8);
line = "<float>" + str + "</float>";
}
binaryString += line + "\n";}
var exportFile = new File(ffxFolder + "/" + filename);
exportFile.encoding = "BINARY";
exportFile.open("w");
exportFile.write(binaryString);
exportFile.close();
return exportFile;
}
var presetFiles = {template_grad2: "RIFX\x00\x00\n`FaFXhead\x00\x00\x00\x10\x00\x00\x00\x03\x00\x00\x00W\x00\x00\x00\x01\x00\x00\x00\x00LIST\x00\x00\n<bescbeso\x00\x00\x008\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00`\x00\x00\x18\x00\x00\x00\x00\x00\x04\x00\x01\x00\x01\x07\x80\x048?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xff\xff\xff\xffLIST\x00\x00\x01\x84tdsptdot\x00\x00\x00\x04\xff\xff\xff\xfftdpl\x00\x00\x00\x04\x00\x00\x00\x05LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE Root Vectors Group\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\x00\x00\x00\x00tdmn\x00\x00\x00(ADBE Vector Group\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE Vectors Group\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\x00\x00\x00\x02tdmn\x00\x00\x00(ADBE Vector Graphic - G-Fill\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE Vector Grad Colors\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00tdsn\x00\x00\x00\x07Colors\x00\x00LIST\x00\x00\x00dtdsptdot\x00\x00\x00\x04\xff\xff\xff\xfftdpl\x00\x00\x00\x04\x00\x00\x00\x01LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE End of path sentinel\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x07\xe8GCstLIST\x00\x00\x00\xb0tdbstdsb\x00\x00\x00\x04\x00\x00\x00\x01tdsn\x00\x00\x00\x07Colors\x00\x00tdb4\x00\x00\x00|\xdb\x99\x00\x01\x00\x07\x00\x00\xff\xff\xff\xff\x00\x00`\x00?\x1a6\xe2\xeb\x1cC-?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00\x00\x01\x00\b\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00cdat\x00\x00\x00\x04\x00\x00\x00\x00LIST\x00\x00\x07$GCkyUtf8\x00\x00\x07\x18<?xml version=\'1.0\'?>\n<prop.map version=\'4\'>\n<prop.list>\n<prop.pair>\n<key>Gradient Color Data</key>\n<prop.list>\n<prop.pair>\n<key>Alpha Stops</key>\n<prop.list>\n<prop.pair>\n<key>Stops List</key>\n<prop.list>\n<prop.pair>\n<key>Stop-0</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[0].rampPoint\npoints[0].midPoint\npoints[0].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-1</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[1].rampPoint\npoints[1].midPoint\npoints[1].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stops Size</key>\n<int type=\'unsigned\' size=\'32\'>2</int>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Color Stops</key>\n<prop.list>\n<prop.pair>\n<key>Stops List</key>\n<prop.list>\n<prop.pair>\n<key>Stop-0</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[0].rampPoint\npoints[0].midPoint\npoints[0].color.color[0]\npoints[0].color.color[1]\npoints[0].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-1</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[1].rampPoint\npoints[1].midPoint\npoints[1].color.color[0]\npoints[1].color.color[1]\npoints[1].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stops Size</key>\n<int type=\'unsigned\' size=\'32\'>2</int>\n</prop.pair>\n</prop.list>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Gradient Colors</key>\n<string>1.0</string>\n</prop.pair>\n</prop.list>\n</prop.map>\n<?xpacket begin=\"\xef\xbb\xbf\" id=\"W5M0MpCehiHzreSzNTczkc9d\"?>\n<x:xmpmeta xmlns:x=\"adobe:ns:meta/\" x:xmptk=\"Adobe XMP Core 5.6-c014 79.156821, 2014/08/29-03:07:50        \">\n   <rdf:RDF xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\">\n      <rdf:Description rdf:about=\"\"\n            xmlns:dc=\"http://purl.org/dc/elements/1.1/\"\n            xmlns:xmp=\"http://ns.adobe.com/xap/1.0/\"\n            xmlns:xmpMM=\"http://ns.adobe.com/xap/1.0/mm/\"\n            xmlns:stEvt=\"http://ns.adobe.com/xap/1.0/sType/ResourceEvent#\">\n         <dc:format>application/vnd.adobe.aftereffects.preset-animation</dc:format>\n         <xmp:CreatorTool>Adobe After Effects CC 2014 (Macintosh)</xmp:CreatorTool>\n         <xmp:CreateDate>2018-01-20T12:34:50-05:00</xmp:CreateDate>\n         <xmp:MetadataDate>2018-01-20T12:34:50-05:00</xmp:MetadataDate>\n         <xmp:ModifyDate>2018-01-20T12:34:50-05:00</xmp:ModifyDate>\n         <xmpMM:InstanceID>xmp.iid:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</xmpMM:InstanceID>\n         <xmpMM:DocumentID>xmp.did:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</xmpMM:DocumentID>\n         <xmpMM:OriginalDocumentID>xmp.did:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</xmpMM:OriginalDocumentID>\n         <xmpMM:History>\n            <rdf:Seq>\n               <rdf:li rdf:parseType=\"Resource\">\n                  <stEvt:action>created</stEvt:action>\n                  <stEvt:instanceID>xmp.iid:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</stEvt:instanceID>\n                  <stEvt:when>2018-01-20T12:34:50-05:00</stEvt:when>\n                  <stEvt:softwareAgent>Adobe After Effects CC 2014 (Macintosh)</stEvt:softwareAgent>\n               </rdf:li>\n            </rdf:Seq>\n         </xmpMM:History>\n      </rdf:Description>\n   </rdf:RDF>\n</x:xmpmeta>\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n<?xpacket end=\"w\"?>\n", template_grad3: "RIFX\x00\x00\f\x90FaFXhead\x00\x00\x00\x10\x00\x00\x00\x03\x00\x00\x00W\x00\x00\x00\x01\x00`\x00\x00LIST\x00\x00\flbescbeso\x00\x00\x008\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00`\x00\x00\x18\x00\x00\x00\x00\x00\x04\x00\x01\x00\x01\x07\x80\x048?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xff\xff\xff\xffLIST\x00\x00\x01\x84tdsptdot\x00\x00\x00\x04\xff\xff\xff\xfftdpl\x00\x00\x00\x04\x00\x00\x00\x05LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE Root Vectors Group\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\x00\x00\x00\x00tdmn\x00\x00\x00(ADBE Vector Group\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE Vectors Group\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\x00\x00\x00\x02tdmn\x00\x00\x00(ADBE Vector Graphic - G-Fill\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE Vector Grad Colors\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00tdsn\x00\x00\x00\x07Colors\x00\x00LIST\x00\x00\x00dtdsptdot\x00\x00\x00\x04\xff\xff\xff\xfftdpl\x00\x00\x00\x04\x00\x00\x00\x01LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE End of path sentinel\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\n\x18GCstLIST\x00\x00\x00\xb0tdbstdsb\x00\x00\x00\x04\x00\x00\x00\x01tdsn\x00\x00\x00\x07Colors\x00\x00tdb4\x00\x00\x00|\xdb\x99\x00\x01\x00\x07\x00\x00\xff\xff\xff\xff\x00\x00`\x00?\x1a6\xe2\xeb\x1cC-?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00\x00\x01\x00\b\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00cdat\x00\x00\x00\x04\x00\x00\x00\x00LIST\x00\x00\tTGCkyUtf8\x00\x00\tG<?xml version=\'1.0\'?>\n<prop.map version=\'4\'>\n<prop.list>\n<prop.pair>\n<key>Gradient Color Data</key>\n<prop.list>\n<prop.pair>\n<key>Alpha Stops</key>\n<prop.list>\n<prop.pair>\n<key>Stops List</key>\n<prop.list>\n<prop.pair>\n<key>Stop-0</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[0].rampPoint\npoints[0].midPoint\npoints[0].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-1</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[1].rampPoint\npoints[1].midPoint\npoints[1].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-2</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[2].rampPoint\npoints[2].midPoint\npoints[2].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stops Size</key>\n<int type=\'unsigned\' size=\'32\'>3</int>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Color Stops</key>\n<prop.list>\n<prop.pair>\n<key>Stops List</key>\n<prop.list>\n<prop.pair>\n<key>Stop-0</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[0].rampPoint\npoints[0].midPoint\npoints[0].color.color[0]\npoints[0].color.color[1]\npoints[0].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-1</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[1].rampPoint\npoints[1].midPoint\npoints[1].color.color[0]\npoints[1].color.color[1]\npoints[1].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-2</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[2].rampPoint\npoints[2].midPoint\npoints[2].color.color[0]\npoints[2].color.color[1]\npoints[2].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stops Size</key>\n<int type=\'unsigned\' size=\'32\'>3</int>\n</prop.pair>\n</prop.list>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Gradient Colors</key>\n<string>1.0</string>\n</prop.pair>\n</prop.list>\n</prop.map>\n\x00<?xpacket begin=\"\xef\xbb\xbf\" id=\"W5M0MpCehiHzreSzNTczkc9d\"?>\n<x:xmpmeta xmlns:x=\"adobe:ns:meta/\" x:xmptk=\"Adobe XMP Core 5.6-c014 79.156821, 2014/08/29-03:07:50        \">\n   <rdf:RDF xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\">\n      <rdf:Description rdf:about=\"\"\n            xmlns:dc=\"http://purl.org/dc/elements/1.1/\"\n            xmlns:xmp=\"http://ns.adobe.com/xap/1.0/\"\n            xmlns:xmpMM=\"http://ns.adobe.com/xap/1.0/mm/\"\n            xmlns:stEvt=\"http://ns.adobe.com/xap/1.0/sType/ResourceEvent#\">\n         <dc:format>application/vnd.adobe.aftereffects.preset-animation</dc:format>\n         <xmp:CreatorTool>Adobe After Effects CC 2014 (Macintosh)</xmp:CreatorTool>\n         <xmp:CreateDate>2018-01-20T12:34:50-05:00</xmp:CreateDate>\n         <xmp:MetadataDate>2018-01-20T12:34:50-05:00</xmp:MetadataDate>\n         <xmp:ModifyDate>2018-01-20T12:34:50-05:00</xmp:ModifyDate>\n         <xmpMM:InstanceID>xmp.iid:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</xmpMM:InstanceID>\n         <xmpMM:DocumentID>xmp.did:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</xmpMM:DocumentID>\n         <xmpMM:OriginalDocumentID>xmp.did:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</xmpMM:OriginalDocumentID>\n         <xmpMM:History>\n            <rdf:Seq>\n               <rdf:li rdf:parseType=\"Resource\">\n                  <stEvt:action>created</stEvt:action>\n                  <stEvt:instanceID>xmp.iid:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</stEvt:instanceID>\n                  <stEvt:when>2018-01-20T12:34:50-05:00</stEvt:when>\n                  <stEvt:softwareAgent>Adobe After Effects CC 2014 (Macintosh)</stEvt:softwareAgent>\n               </rdf:li>\n            </rdf:Seq>\n         </xmpMM:History>\n      </rdf:Description>\n   </rdf:RDF>\n</x:xmpmeta>\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n<?xpacket end=\"w\"?>\n", template_grad4: "RIFX\x00\x00\x0e\xbeFaFXhead\x00\x00\x00\x10\x00\x00\x00\x03\x00\x00\x00W\x00\x00\x00\x01\x00`\x00\x00LIST\x00\x00\x0e\x9abescbeso\x00\x00\x008\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00`\x00\x00\x18\x00\x00\x00\x00\x00\x04\x00\x01\x00\x01\x07\x80\x048?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xff\xff\xff\xffLIST\x00\x00\x01\x84tdsptdot\x00\x00\x00\x04\xff\xff\xff\xfftdpl\x00\x00\x00\x04\x00\x00\x00\x05LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE Root Vectors Group\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\x00\x00\x00\x00tdmn\x00\x00\x00(ADBE Vector Group\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE Vectors Group\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\x00\x00\x00\x02tdmn\x00\x00\x00(ADBE Vector Graphic - G-Fill\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE Vector Grad Colors\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00tdsn\x00\x00\x00\x07Colors\x00\x00LIST\x00\x00\x00dtdsptdot\x00\x00\x00\x04\xff\xff\xff\xfftdpl\x00\x00\x00\x04\x00\x00\x00\x01LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE End of path sentinel\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\fFGCstLIST\x00\x00\x00\xb0tdbstdsb\x00\x00\x00\x04\x00\x00\x00\x01tdsn\x00\x00\x00\x07Colors\x00\x00tdb4\x00\x00\x00|\xdb\x99\x00\x01\x00\x07\x00\x00\xff\xff\xff\xff\x00\x00`\x00?\x1a6\xe2\xeb\x1cC-?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00\x00\x01\x00\b\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00cdat\x00\x00\x00\x04\x00\x00\x00\x00LIST\x00\x00\v\x82GCkyUtf8\x00\x00\vv<?xml version=\'1.0\'?>\n<prop.map version=\'4\'>\n<prop.list>\n<prop.pair>\n<key>Gradient Color Data</key>\n<prop.list>\n<prop.pair>\n<key>Alpha Stops</key>\n<prop.list>\n<prop.pair>\n<key>Stops List</key>\n<prop.list>\n<prop.pair>\n<key>Stop-0</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[0].rampPoint\npoints[0].midPoint\npoints[0].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-1</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[1].rampPoint\npoints[1].midPoint\npoints[1].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-2</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[2].rampPoint\npoints[2].midPoint\npoints[2].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-3</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[3].rampPoint\npoints[3].midPoint\npoints[3].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stops Size</key>\n<int type=\'unsigned\' size=\'32\'>4</int>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Color Stops</key>\n<prop.list>\n<prop.pair>\n<key>Stops List</key>\n<prop.list>\n<prop.pair>\n<key>Stop-0</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[0].rampPoint\npoints[0].midPoint\npoints[0].color.color[0]\npoints[0].color.color[1]\npoints[0].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-1</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[1].rampPoint\npoints[1].midPoint\npoints[1].color.color[0]\npoints[1].color.color[1]\npoints[1].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-2</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[2].rampPoint\npoints[2].midPoint\npoints[2].color.color[0]\npoints[2].color.color[1]\npoints[2].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-3</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[3].rampPoint\npoints[3].midPoint\npoints[3].color.color[0]\npoints[3].color.color[1]\npoints[3].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stops Size</key>\n<int type=\'unsigned\' size=\'32\'>4</int>\n</prop.pair>\n</prop.list>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Gradient Colors</key>\n<string>1.0</string>\n</prop.pair>\n</prop.list>\n</prop.map>\n<?xpacket begin=\"\xef\xbb\xbf\" id=\"W5M0MpCehiHzreSzNTczkc9d\"?>\n<x:xmpmeta xmlns:x=\"adobe:ns:meta/\" x:xmptk=\"Adobe XMP Core 5.6-c014 79.156821, 2014/08/29-03:07:50        \">\n   <rdf:RDF xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\">\n      <rdf:Description rdf:about=\"\"\n            xmlns:dc=\"http://purl.org/dc/elements/1.1/\"\n            xmlns:xmp=\"http://ns.adobe.com/xap/1.0/\"\n            xmlns:xmpMM=\"http://ns.adobe.com/xap/1.0/mm/\"\n            xmlns:stEvt=\"http://ns.adobe.com/xap/1.0/sType/ResourceEvent#\">\n         <dc:format>application/vnd.adobe.aftereffects.preset-animation</dc:format>\n         <xmp:CreatorTool>Adobe After Effects CC 2014 (Macintosh)</xmp:CreatorTool>\n         <xmp:CreateDate>2018-01-20T12:34:50-05:00</xmp:CreateDate>\n         <xmp:MetadataDate>2018-01-20T12:34:50-05:00</xmp:MetadataDate>\n         <xmp:ModifyDate>2018-01-20T12:34:50-05:00</xmp:ModifyDate>\n         <xmpMM:InstanceID>xmp.iid:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</xmpMM:InstanceID>\n         <xmpMM:DocumentID>xmp.did:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</xmpMM:DocumentID>\n         <xmpMM:OriginalDocumentID>xmp.did:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</xmpMM:OriginalDocumentID>\n         <xmpMM:History>\n            <rdf:Seq>\n               <rdf:li rdf:parseType=\"Resource\">\n                  <stEvt:action>created</stEvt:action>\n                  <stEvt:instanceID>xmp.iid:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</stEvt:instanceID>\n                  <stEvt:when>2018-01-20T12:34:50-05:00</stEvt:when>\n                  <stEvt:softwareAgent>Adobe After Effects CC 2014 (Macintosh)</stEvt:softwareAgent>\n               </rdf:li>\n            </rdf:Seq>\n         </xmpMM:History>\n      </rdf:Description>\n   </rdf:RDF>\n</x:xmpmeta>\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n<?xpacket end=\"w\"?>\n", template_grad5: "RIFX\x00\x00\x11\xe2FaFXhead\x00\x00\x00\x10\x00\x00\x00\x03\x00\x00\x00W\x00\x00\x00\x01\x00a\x00\x00LIST\x00\x00\x11\xbebescbeso\x00\x00\x008\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00`\x00\x00\x18\x00\x00\x00\x00\x00\x04\x00\x01\x00\x01\x07\x80\x048?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xff\xff\xff\xffLIST\x00\x00\x01\x84tdsptdot\x00\x00\x00\x04\xff\xff\xff\xfftdpl\x00\x00\x00\x04\x00\x00\x00\x05LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE Root Vectors Group\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\x00\x00\x00\x00tdmn\x00\x00\x00(ADBE Vector Group\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE Vectors Group\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\x00\x00\x00\x02tdmn\x00\x00\x00(ADBE Vector Graphic - G-Fill\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE Vector Grad Colors\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00tdsn\x00\x00\x00\x07Colors\x00\x00LIST\x00\x00\x00dtdsptdot\x00\x00\x00\x04\xff\xff\xff\xfftdpl\x00\x00\x00\x04\x00\x00\x00\x01LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE End of path sentinel\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x0fjGCstLIST\x00\x00\x00\xb0tdbstdsb\x00\x00\x00\x04\x00\x00\x00\x01tdsn\x00\x00\x00\x07Colors\x00\x00tdb4\x00\x00\x00|\xdb\x99\x00\x01\x00\x07\x00\x00\xff\xff\xff\xff\x00\x00`\x00?\x1a6\xe2\xeb\x1cC-?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00\x00\x01\x00\b\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00cdat\x00\x00\x00\x04\x00\x00\x00\x00LIST\x00\x00\x0e\xa6GCkyUtf8\x00\x00\x0e\x9a<?xml version=\'1.0\'?>\n<prop.map version=\'4\'>\n<prop.list>\n<prop.pair>\n<key>Gradient Color Data</key>\n<prop.list>\n<prop.pair>\n<key>Alpha Stops</key>\n<prop.list>\n<prop.pair>\n<key>Stops List</key>\n<prop.list>\n<prop.pair>\n<key>Stop-0</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[0].rampPoint\npoints[0].midPoint\npoints[0].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-1</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[1].rampPoint\npoints[1].midPoint\npoints[1].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-2</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[2].rampPoint\npoints[2].midPoint\npoints[2].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-3</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[3].rampPoint\npoints[3].midPoint\npoints[3].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-4</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[4].rampPoint\npoints[4].midPoint\npoints[4].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-5</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[4].rampPoint\npoints[4].midPoint\npoints[4].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stops Size</key>\n<int type=\'unsigned\' size=\'32\'>6</int>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Color Stops</key>\n<prop.list>\n<prop.pair>\n<key>Stops List</key>\n<prop.list>\n<prop.pair>\n<key>Stop-0</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[0].rampPoint\npoints[0].midPoint\npoints[0].color.color[0]\npoints[0].color.color[1]\npoints[0].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-1</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[1].rampPoint\npoints[1].midPoint\npoints[1].color.color[0]\npoints[1].color.color[1]\npoints[1].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-2</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[2].rampPoint\npoints[2].midPoint\npoints[2].color.color[0]\npoints[2].color.color[1]\npoints[2].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-3</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[3].rampPoint\npoints[3].midPoint\npoints[3].color.color[0]\npoints[3].color.color[1]\npoints[3].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-4</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[4].rampPoint\npoints[4].midPoint\npoints[4].color.color[0]\npoints[4].color.color[1]\npoints[4].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stops Size</key>\n<int type=\'unsigned\' size=\'32\'>5</int>\n</prop.pair>\n</prop.list>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Gradient Colors</key>\n<string>1.0</string>\n</prop.pair>\n</prop.list>\n</prop.map>\n<?xpacket begin=\"\xef\xbb\xbf\" id=\"W5M0MpCehiHzreSzNTczkc9d\"?>\n<x:xmpmeta xmlns:x=\"adobe:ns:meta/\" x:xmptk=\"Adobe XMP Core 5.6-c014 79.156821, 2014/08/29-03:07:50        \">\n   <rdf:RDF xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\">\n      <rdf:Description rdf:about=\"\"\n            xmlns:dc=\"http://purl.org/dc/elements/1.1/\"\n            xmlns:xmp=\"http://ns.adobe.com/xap/1.0/\"\n            xmlns:xmpMM=\"http://ns.adobe.com/xap/1.0/mm/\"\n            xmlns:stEvt=\"http://ns.adobe.com/xap/1.0/sType/ResourceEvent#\">\n         <dc:format>application/vnd.adobe.aftereffects.preset-animation</dc:format>\n         <xmp:CreatorTool>Adobe After Effects CC 2014 (Macintosh)</xmp:CreatorTool>\n         <xmp:CreateDate>2018-01-20T12:34:50-05:00</xmp:CreateDate>\n         <xmp:MetadataDate>2018-01-20T12:34:50-05:00</xmp:MetadataDate>\n         <xmp:ModifyDate>2018-01-20T12:34:50-05:00</xmp:ModifyDate>\n         <xmpMM:InstanceID>xmp.iid:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</xmpMM:InstanceID>\n         <xmpMM:DocumentID>xmp.did:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</xmpMM:DocumentID>\n         <xmpMM:OriginalDocumentID>xmp.did:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</xmpMM:OriginalDocumentID>\n         <xmpMM:History>\n            <rdf:Seq>\n               <rdf:li rdf:parseType=\"Resource\">\n                  <stEvt:action>created</stEvt:action>\n                  <stEvt:instanceID>xmp.iid:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</stEvt:instanceID>\n                  <stEvt:when>2018-01-20T12:34:50-05:00</stEvt:when>\n                  <stEvt:softwareAgent>Adobe After Effects CC 2014 (Macintosh)</stEvt:softwareAgent>\n               </rdf:li>\n            </rdf:Seq>\n         </xmpMM:History>\n      </rdf:Description>\n   </rdf:RDF>\n</x:xmpmeta>\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n<?xpacket end=\"w\"?>\n", template_grad6: "RIFX\x00\x00\x13\x1cFaFXhead\x00\x00\x00\x10\x00\x00\x00\x03\x00\x00\x00W\x00\x00\x00\x01\x00`\x00\x00LIST\x00\x00\x12\xf8bescbeso\x00\x00\x008\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00`\x00\x00\x18\x00\x00\x00\x00\x00\x04\x00\x01\x00\x01\x07\x80\x048?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xff\xff\xff\xffLIST\x00\x00\x01\x84tdsptdot\x00\x00\x00\x04\xff\xff\xff\xfftdpl\x00\x00\x00\x04\x00\x00\x00\x05LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE Root Vectors Group\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\x00\x00\x00\x00tdmn\x00\x00\x00(ADBE Vector Group\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE Vectors Group\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\x00\x00\x00\x02tdmn\x00\x00\x00(ADBE Vector Graphic - G-Fill\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE Vector Grad Colors\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00tdsn\x00\x00\x00\x07Colors\x00\x00LIST\x00\x00\x00dtdsptdot\x00\x00\x00\x04\xff\xff\xff\xfftdpl\x00\x00\x00\x04\x00\x00\x00\x01LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE End of path sentinel\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x10\xa4GCstLIST\x00\x00\x00\xb0tdbstdsb\x00\x00\x00\x04\x00\x00\x00\x01tdsn\x00\x00\x00\x07Colors\x00\x00tdb4\x00\x00\x00|\xdb\x99\x00\x01\x00\x07\x00\x00\xff\xff\xff\xff\x00\x00`\x00?\x1a6\xe2\xeb\x1cC-?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00\x00\x01\x00\b\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00cdat\x00\x00\x00\x04\x00\x00\x00\x00LIST\x00\x00\x0f\xe0GCkyUtf8\x00\x00\x0f\xd4<?xml version=\'1.0\'?>\n<prop.map version=\'4\'>\n<prop.list>\n<prop.pair>\n<key>Gradient Color Data</key>\n<prop.list>\n<prop.pair>\n<key>Alpha Stops</key>\n<prop.list>\n<prop.pair>\n<key>Stops List</key>\n<prop.list>\n<prop.pair>\n<key>Stop-0</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[0].rampPoint\npoints[0].midPoint\npoints[0].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-1</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[1].rampPoint\npoints[1].midPoint\npoints[1].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-2</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[2].rampPoint\npoints[2].midPoint\npoints[2].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-3</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[3].rampPoint\npoints[3].midPoint\npoints[3].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-4</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[4].rampPoint\npoints[4].midPoint\npoints[4].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-5</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[5].rampPoint\npoints[5].midPoint\npoints[5].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stops Size</key>\n<int type=\'unsigned\' size=\'32\'>6</int>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Color Stops</key>\n<prop.list>\n<prop.pair>\n<key>Stops List</key>\n<prop.list>\n<prop.pair>\n<key>Stop-0</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[0].rampPoint\npoints[0].midPoint\npoints[0].color.color[0]\npoints[0].color.color[1]\npoints[0].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-1</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[1].rampPoint\npoints[1].midPoint\npoints[1].color.color[0]\npoints[1].color.color[1]\npoints[1].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-2</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[2].rampPoint\npoints[2].midPoint\npoints[2].color.color[0]\npoints[2].color.color[1]\npoints[2].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-3</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[3].rampPoint\npoints[3].midPoint\npoints[3].color.color[0]\npoints[3].color.color[1]\npoints[3].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-4</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[4].rampPoint\npoints[4].midPoint\npoints[4].color.color[0]\npoints[4].color.color[1]\npoints[4].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-5</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[5].rampPoint\npoints[5].midPoint\npoints[5].color.color[0]\npoints[5].color.color[1]\npoints[5].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stops Size</key>\n<int type=\'unsigned\' size=\'32\'>6</int>\n</prop.pair>\n</prop.list>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Gradient Colors</key>\n<string>1.0</string>\n</prop.pair>\n</prop.list>\n</prop.map>\n<?xpacket begin=\"\xef\xbb\xbf\" id=\"W5M0MpCehiHzreSzNTczkc9d\"?>\n<x:xmpmeta xmlns:x=\"adobe:ns:meta/\" x:xmptk=\"Adobe XMP Core 5.6-c014 79.156821, 2014/08/29-03:07:50        \">\n   <rdf:RDF xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\">\n      <rdf:Description rdf:about=\"\"\n            xmlns:dc=\"http://purl.org/dc/elements/1.1/\"\n            xmlns:xmp=\"http://ns.adobe.com/xap/1.0/\"\n            xmlns:xmpMM=\"http://ns.adobe.com/xap/1.0/mm/\"\n            xmlns:stEvt=\"http://ns.adobe.com/xap/1.0/sType/ResourceEvent#\">\n         <dc:format>application/vnd.adobe.aftereffects.preset-animation</dc:format>\n         <xmp:CreatorTool>Adobe After Effects CC 2014 (Macintosh)</xmp:CreatorTool>\n         <xmp:CreateDate>2018-01-20T12:34:50-05:00</xmp:CreateDate>\n         <xmp:MetadataDate>2018-01-20T12:34:50-05:00</xmp:MetadataDate>\n         <xmp:ModifyDate>2018-01-20T12:34:50-05:00</xmp:ModifyDate>\n         <xmpMM:InstanceID>xmp.iid:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</xmpMM:InstanceID>\n         <xmpMM:DocumentID>xmp.did:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</xmpMM:DocumentID>\n         <xmpMM:OriginalDocumentID>xmp.did:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</xmpMM:OriginalDocumentID>\n         <xmpMM:History>\n            <rdf:Seq>\n               <rdf:li rdf:parseType=\"Resource\">\n                  <stEvt:action>created</stEvt:action>\n                  <stEvt:instanceID>xmp.iid:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</stEvt:instanceID>\n                  <stEvt:when>2018-01-20T12:34:50-05:00</stEvt:when>\n                  <stEvt:softwareAgent>Adobe After Effects CC 2014 (Macintosh)</stEvt:softwareAgent>\n               </rdf:li>\n            </rdf:Seq>\n         </xmpMM:History>\n      </rdf:Description>\n   </rdf:RDF>\n</x:xmpmeta>\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n<?xpacket end=\"w\"?>\n", template_grad7: "RIFX\x00\x00\x15LFaFXhead\x00\x00\x00\x10\x00\x00\x00\x03\x00\x00\x00W\x00\x00\x00\x01\x00a\x00\x00LIST\x00\x00\x15(bescbeso\x00\x00\x008\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00`\x00\x00\x18\x00\x00\x00\x00\x00\x04\x00\x01\x00\x01\x07\x80\x048?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xff\xff\xff\xffLIST\x00\x00\x01\x84tdsptdot\x00\x00\x00\x04\xff\xff\xff\xfftdpl\x00\x00\x00\x04\x00\x00\x00\x05LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE Root Vectors Group\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\x00\x00\x00\x00tdmn\x00\x00\x00(ADBE Vector Group\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE Vectors Group\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\x00\x00\x00\x02tdmn\x00\x00\x00(ADBE Vector Graphic - G-Fill\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE Vector Grad Colors\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00tdsn\x00\x00\x00\x07Colors\x00\x00LIST\x00\x00\x00dtdsptdot\x00\x00\x00\x04\xff\xff\xff\xfftdpl\x00\x00\x00\x04\x00\x00\x00\x01LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE End of path sentinel\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x12\xd4GCstLIST\x00\x00\x00\xb0tdbstdsb\x00\x00\x00\x04\x00\x00\x00\x01tdsn\x00\x00\x00\x07Colors\x00\x00tdb4\x00\x00\x00|\xdb\x99\x00\x01\x00\x07\x00\x00\xff\xff\xff\xff\x00\x00`\x00?\x1a6\xe2\xeb\x1cC-?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00\x00\x01\x00\b\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00cdat\x00\x00\x00\x04\x00\x00\x00\x00LIST\x00\x00\x12\x10GCkyUtf8\x00\x00\x12\x03<?xml version=\'1.0\'?>\n<prop.map version=\'4\'>\n<prop.list>\n<prop.pair>\n<key>Gradient Color Data</key>\n<prop.list>\n<prop.pair>\n<key>Alpha Stops</key>\n<prop.list>\n<prop.pair>\n<key>Stops List</key>\n<prop.list>\n<prop.pair>\n<key>Stop-0</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[0].rampPoint\npoints[0].midPoint\npoints[0].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-1</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[1].rampPoint\npoints[1].midPoint\npoints[1].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-2</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[2].rampPoint\npoints[2].midPoint\npoints[2].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-3</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[3].rampPoint\npoints[3].midPoint\npoints[3].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-4</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[4].rampPoint\npoints[4].midPoint\npoints[4].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-5</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[5].rampPoint\npoints[5].midPoint\npoints[5].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-6</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[6].rampPoint\npoints[6].midPoint\npoints[6].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stops Size</key>\n<int type=\'unsigned\' size=\'32\'>7</int>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Color Stops</key>\n<prop.list>\n<prop.pair>\n<key>Stops List</key>\n<prop.list>\n<prop.pair>\n<key>Stop-0</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[0].rampPoint\npoints[0].midPoint\npoints[0].color.color[0]\npoints[0].color.color[1]\npoints[0].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-1</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[1].rampPoint\npoints[1].midPoint\npoints[1].color.color[0]\npoints[1].color.color[1]\npoints[1].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-2</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[2].rampPoint\npoints[2].midPoint\npoints[2].color.color[0]\npoints[2].color.color[1]\npoints[2].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-3</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[3].rampPoint\npoints[3].midPoint\npoints[3].color.color[0]\npoints[3].color.color[1]\npoints[3].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-4</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[4].rampPoint\npoints[4].midPoint\npoints[4].color.color[0]\npoints[4].color.color[1]\npoints[4].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-5</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[5].rampPoint\npoints[5].midPoint\npoints[5].color.color[0]\npoints[5].color.color[1]\npoints[5].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-6</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[6].rampPoint\npoints[6].midPoint\npoints[6].color.color[0]\npoints[6].color.color[1]\npoints[6].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stops Size</key>\n<int type=\'unsigned\' size=\'32\'>7</int>\n</prop.pair>\n</prop.list>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Gradient Colors</key>\n<string>1.0</string>\n</prop.pair>\n</prop.list>\n</prop.map>\n<?xpacket begin=\"\xef\xbb\xbf\" id=\"W5M0MpCehiHzreSzNTczkc9d\"?>\n<x:xmpmeta xmlns:x=\"adobe:ns:meta/\" x:xmptk=\"Adobe XMP Core 5.6-c014 79.156821, 2014/08/29-03:07:50        \">\n   <rdf:RDF xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\">\n      <rdf:Description rdf:about=\"\"\n            xmlns:dc=\"http://purl.org/dc/elements/1.1/\"\n            xmlns:xmp=\"http://ns.adobe.com/xap/1.0/\"\n            xmlns:xmpMM=\"http://ns.adobe.com/xap/1.0/mm/\"\n            xmlns:stEvt=\"http://ns.adobe.com/xap/1.0/sType/ResourceEvent#\">\n         <dc:format>application/vnd.adobe.aftereffects.preset-animation</dc:format>\n         <xmp:CreatorTool>Adobe After Effects CC 2014 (Macintosh)</xmp:CreatorTool>\n         <xmp:CreateDate>2018-01-20T12:34:50-05:00</xmp:CreateDate>\n         <xmp:MetadataDate>2018-01-20T12:34:50-05:00</xmp:MetadataDate>\n         <xmp:ModifyDate>2018-01-20T12:34:50-05:00</xmp:ModifyDate>\n         <xmpMM:InstanceID>xmp.iid:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</xmpMM:InstanceID>\n         <xmpMM:DocumentID>xmp.did:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</xmpMM:DocumentID>\n         <xmpMM:OriginalDocumentID>xmp.did:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</xmpMM:OriginalDocumentID>\n         <xmpMM:History>\n            <rdf:Seq>\n               <rdf:li rdf:parseType=\"Resource\">\n                  <stEvt:action>created</stEvt:action>\n                  <stEvt:instanceID>xmp.iid:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</stEvt:instanceID>\n                  <stEvt:when>2018-01-20T12:34:50-05:00</stEvt:when>\n                  <stEvt:softwareAgent>Adobe After Effects CC 2014 (Macintosh)</stEvt:softwareAgent>\n               </rdf:li>\n            </rdf:Seq>\n         </xmpMM:History>\n      </rdf:Description>\n   </rdf:RDF>\n</x:xmpmeta>\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n<?xpacket end=\"w\"?>\n", template_grad8: "RIFX\x00\x00\x17zFaFXhead\x00\x00\x00\x10\x00\x00\x00\x03\x00\x00\x00W\x00\x00\x00\x01\x00a\x00\x00LIST\x00\x00\x17Vbescbeso\x00\x00\x008\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00`\x00\x00\x18\x00\x00\x00\x00\x00\x04\x00\x01\x00\x01\x07\x80\x048?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xff\xff\xff\xffLIST\x00\x00\x01\x84tdsptdot\x00\x00\x00\x04\xff\xff\xff\xfftdpl\x00\x00\x00\x04\x00\x00\x00\x05LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE Root Vectors Group\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\x00\x00\x00\x00tdmn\x00\x00\x00(ADBE Vector Group\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE Vectors Group\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\x00\x00\x00\x02tdmn\x00\x00\x00(ADBE Vector Graphic - G-Fill\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE Vector Grad Colors\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00tdsn\x00\x00\x00\x07Colors\x00\x00LIST\x00\x00\x00dtdsptdot\x00\x00\x00\x04\xff\xff\xff\xfftdpl\x00\x00\x00\x04\x00\x00\x00\x01LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE End of path sentinel\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x15\x02GCstLIST\x00\x00\x00\xb0tdbstdsb\x00\x00\x00\x04\x00\x00\x00\x01tdsn\x00\x00\x00\x07Colors\x00\x00tdb4\x00\x00\x00|\xdb\x99\x00\x01\x00\x07\x00\x00\xff\xff\xff\xff\x00\x00`\x00?\x1a6\xe2\xeb\x1cC-?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00\x00\x01\x00\b\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00cdat\x00\x00\x00\x04\x00\x00\x00\x00LIST\x00\x00\x14>GCkyUtf8\x00\x00\x142<?xml version=\'1.0\'?>\n<prop.map version=\'4\'>\n<prop.list>\n<prop.pair>\n<key>Gradient Color Data</key>\n<prop.list>\n<prop.pair>\n<key>Alpha Stops</key>\n<prop.list>\n<prop.pair>\n<key>Stops List</key>\n<prop.list>\n<prop.pair>\n<key>Stop-0</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[0].rampPoint\npoints[0].midPoint\npoints[0].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-1</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[1].rampPoint\npoints[1].midPoint\npoints[1].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-2</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[2].rampPoint\npoints[2].midPoint\npoints[2].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-3</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[3].rampPoint\npoints[3].midPoint\npoints[3].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-4</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[4].rampPoint\npoints[4].midPoint\npoints[4].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-5</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[5].rampPoint\npoints[5].midPoint\npoints[5].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-6</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[6].rampPoint\npoints[6].midPoint\npoints[6].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-7</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[7].rampPoint\npoints[7].midPoint\npoints[7].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stops Size</key>\n<int type=\'unsigned\' size=\'32\'>8</int>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Color Stops</key>\n<prop.list>\n<prop.pair>\n<key>Stops List</key>\n<prop.list>\n<prop.pair>\n<key>Stop-0</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[0].rampPoint\npoints[0].midPoint\npoints[0].color.color[0]\npoints[0].color.color[1]\npoints[0].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-1</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[1].rampPoint\npoints[1].midPoint\npoints[1].color.color[0]\npoints[1].color.color[1]\npoints[1].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-2</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[2].rampPoint\npoints[2].midPoint\npoints[2].color.color[0]\npoints[2].color.color[1]\npoints[2].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-3</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[3].rampPoint\npoints[3].midPoint\npoints[3].color.color[0]\npoints[3].color.color[1]\npoints[3].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-4</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[4].rampPoint\npoints[4].midPoint\npoints[4].color.color[0]\npoints[4].color.color[1]\npoints[4].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-5</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[5].rampPoint\npoints[5].midPoint\npoints[5].color.color[0]\npoints[5].color.color[1]\npoints[5].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-6</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[6].rampPoint\npoints[6].midPoint\npoints[6].color.color[0]\npoints[6].color.color[1]\npoints[6].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-7</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[7].rampPoint\npoints[7].midPoint\npoints[7].color.color[0]\npoints[7].color.color[1]\npoints[7].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stops Size</key>\n<int type=\'unsigned\' size=\'32\'>8</int>\n</prop.pair>\n</prop.list>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Gradient Colors</key>\n<string>1.0</string>\n</prop.pair>\n</prop.list>\n</prop.map>\n<?xpacket begin=\"\xef\xbb\xbf\" id=\"W5M0MpCehiHzreSzNTczkc9d\"?>\n<x:xmpmeta xmlns:x=\"adobe:ns:meta/\" x:xmptk=\"Adobe XMP Core 5.6-c014 79.156821, 2014/08/29-03:07:50        \">\n   <rdf:RDF xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\">\n      <rdf:Description rdf:about=\"\"\n            xmlns:dc=\"http://purl.org/dc/elements/1.1/\"\n            xmlns:xmp=\"http://ns.adobe.com/xap/1.0/\"\n            xmlns:xmpMM=\"http://ns.adobe.com/xap/1.0/mm/\"\n            xmlns:stEvt=\"http://ns.adobe.com/xap/1.0/sType/ResourceEvent#\">\n         <dc:format>application/vnd.adobe.aftereffects.preset-animation</dc:format>\n         <xmp:CreatorTool>Adobe After Effects CC 2014 (Macintosh)</xmp:CreatorTool>\n         <xmp:CreateDate>2018-01-20T12:34:50-05:00</xmp:CreateDate>\n         <xmp:MetadataDate>2018-01-20T12:34:50-05:00</xmp:MetadataDate>\n         <xmp:ModifyDate>2018-01-20T12:34:50-05:00</xmp:ModifyDate>\n         <xmpMM:InstanceID>xmp.iid:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</xmpMM:InstanceID>\n         <xmpMM:DocumentID>xmp.did:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</xmpMM:DocumentID>\n         <xmpMM:OriginalDocumentID>xmp.did:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</xmpMM:OriginalDocumentID>\n         <xmpMM:History>\n            <rdf:Seq>\n               <rdf:li rdf:parseType=\"Resource\">\n                  <stEvt:action>created</stEvt:action>\n                  <stEvt:instanceID>xmp.iid:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</stEvt:instanceID>\n                  <stEvt:when>2018-01-20T12:34:50-05:00</stEvt:when>\n                  <stEvt:softwareAgent>Adobe After Effects CC 2014 (Macintosh)</stEvt:softwareAgent>\n               </rdf:li>\n            </rdf:Seq>\n         </xmpMM:History>\n      </rdf:Description>\n   </rdf:RDF>\n</x:xmpmeta>\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n<?xpacket end=\"w\"?>\n"};
try {
var ffxFolder = Folder.userData.toString() + "/BattleAxe/Overlord/ffx/";
if (!Folder(ffxFolder).exists) { 
Folder(ffxFolder).create();
}
if (type === "fillColor") { 
gradLength = element.fillColor.gradient.length;
}
else {
gradLength = element.strokeColor.gradient.length;
}
if (gradLength == 2) { 
fileString = presetFiles.template_grad2;
}
if (gradLength == 3) { 
fileString = presetFiles.template_grad3;
}
if (gradLength == 4) { 
fileString = presetFiles.template_grad4;
}
if (gradLength == 5) { 
fileString = presetFiles.template_grad5;
}
if (gradLength == 6) { 
fileString = presetFiles.template_grad6;
}
if (gradLength == 7) { 
fileString = presetFiles.template_grad7;
}
if (gradLength > 7) { 
fileString = presetFiles.template_grad8;
}
var tempFile = createFile(fileString, "grad.ffx");
ae_deselectProps();
var layer = fill.propertyGroup(fill.propertyDepth);
fill.selected = true;
layer.applyPreset(tempFile);
layer.selected = false;
if (!dontTwirl) { 
app.executeCommand(2771);
app.executeCommand(2771);
}
} catch (e) {alert(e.toString() + "\nError on line: " + e.line.toString());
}
}
function writeFfx(ffxObj) {
function createResourceFile(filename, binaryString, resourceFolder) {
var myFile = new File(resourceFolder + "/" + filename);
if (!File(myFile).exists) { 
if (!isSecurityPrefSet()) { 
alert("In order to make " + scriptName + " work you need to enable this weird little preference in After Effects: \n\n Allow Scripts to Write Files and Access Network\n\nCheck that box and we\'ll be in business.");
try {
app.executeCommand(2359);
} catch (e) {alert(e);
}
if (!isSecurityPrefSet()) { 
return null;
}
}
myFile.encoding = "BINARY";
myFile.open("w");
myFile.write(binaryString);
myFile.close();
}
return myFile;
}
function isSecurityPrefSet() {
try {
securitySetting = app.preferences.getPrefAsLong("Main Pref Section", "Pref_SCRIPTING_FILE_NETWORK_SECURITY");
return securitySetting == 1;
} catch (e) {return securitySetting = 1;
}
}
var presetFiles = {template_grad2: "RIFX\x00\x00\n`FaFXhead\x00\x00\x00\x10\x00\x00\x00\x03\x00\x00\x00W\x00\x00\x00\x01\x00\x00\x00\x00LIST\x00\x00\n<bescbeso\x00\x00\x008\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00`\x00\x00\x18\x00\x00\x00\x00\x00\x04\x00\x01\x00\x01\x07\x80\x048?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xff\xff\xff\xffLIST\x00\x00\x01\x84tdsptdot\x00\x00\x00\x04\xff\xff\xff\xfftdpl\x00\x00\x00\x04\x00\x00\x00\x05LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE Root Vectors Group\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\x00\x00\x00\x00tdmn\x00\x00\x00(ADBE Vector Group\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE Vectors Group\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\x00\x00\x00\x02tdmn\x00\x00\x00(ADBE Vector Graphic - G-Fill\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE Vector Grad Colors\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00tdsn\x00\x00\x00\x07Colors\x00\x00LIST\x00\x00\x00dtdsptdot\x00\x00\x00\x04\xff\xff\xff\xfftdpl\x00\x00\x00\x04\x00\x00\x00\x01LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE End of path sentinel\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x07\xe8GCstLIST\x00\x00\x00\xb0tdbstdsb\x00\x00\x00\x04\x00\x00\x00\x01tdsn\x00\x00\x00\x07Colors\x00\x00tdb4\x00\x00\x00|\xdb\x99\x00\x01\x00\x07\x00\x00\xff\xff\xff\xff\x00\x00`\x00?\x1a6\xe2\xeb\x1cC-?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00\x00\x01\x00\b\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00cdat\x00\x00\x00\x04\x00\x00\x00\x00LIST\x00\x00\x07$GCkyUtf8\x00\x00\x07\x18<?xml version=\'1.0\'?>\n<prop.map version=\'4\'>\n<prop.list>\n<prop.pair>\n<key>Gradient Color Data</key>\n<prop.list>\n<prop.pair>\n<key>Alpha Stops</key>\n<prop.list>\n<prop.pair>\n<key>Stops List</key>\n<prop.list>\n<prop.pair>\n<key>Stop-0</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[0].rampPoint\npoints[0].midPoint\npoints[0].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-1</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[1].rampPoint\npoints[1].midPoint\npoints[1].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stops Size</key>\n<int type=\'unsigned\' size=\'32\'>2</int>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Color Stops</key>\n<prop.list>\n<prop.pair>\n<key>Stops List</key>\n<prop.list>\n<prop.pair>\n<key>Stop-0</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[0].rampPoint\npoints[0].midPoint\npoints[0].color.color[0]\npoints[0].color.color[1]\npoints[0].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-1</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[1].rampPoint\npoints[1].midPoint\npoints[1].color.color[0]\npoints[1].color.color[1]\npoints[1].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stops Size</key>\n<int type=\'unsigned\' size=\'32\'>2</int>\n</prop.pair>\n</prop.list>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Gradient Colors</key>\n<string>1.0</string>\n</prop.pair>\n</prop.list>\n</prop.map>\n<?xpacket begin=\"\xef\xbb\xbf\" id=\"W5M0MpCehiHzreSzNTczkc9d\"?>\n<x:xmpmeta xmlns:x=\"adobe:ns:meta/\" x:xmptk=\"Adobe XMP Core 5.6-c014 79.156821, 2014/08/29-03:07:50        \">\n   <rdf:RDF xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\">\n      <rdf:Description rdf:about=\"\"\n            xmlns:dc=\"http://purl.org/dc/elements/1.1/\"\n            xmlns:xmp=\"http://ns.adobe.com/xap/1.0/\"\n            xmlns:xmpMM=\"http://ns.adobe.com/xap/1.0/mm/\"\n            xmlns:stEvt=\"http://ns.adobe.com/xap/1.0/sType/ResourceEvent#\">\n         <dc:format>application/vnd.adobe.aftereffects.preset-animation</dc:format>\n         <xmp:CreatorTool>Adobe After Effects CC 2014 (Macintosh)</xmp:CreatorTool>\n         <xmp:CreateDate>2018-01-20T12:34:50-05:00</xmp:CreateDate>\n         <xmp:MetadataDate>2018-01-20T12:34:50-05:00</xmp:MetadataDate>\n         <xmp:ModifyDate>2018-01-20T12:34:50-05:00</xmp:ModifyDate>\n         <xmpMM:InstanceID>xmp.iid:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</xmpMM:InstanceID>\n         <xmpMM:DocumentID>xmp.did:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</xmpMM:DocumentID>\n         <xmpMM:OriginalDocumentID>xmp.did:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</xmpMM:OriginalDocumentID>\n         <xmpMM:History>\n            <rdf:Seq>\n               <rdf:li rdf:parseType=\"Resource\">\n                  <stEvt:action>created</stEvt:action>\n                  <stEvt:instanceID>xmp.iid:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</stEvt:instanceID>\n                  <stEvt:when>2018-01-20T12:34:50-05:00</stEvt:when>\n                  <stEvt:softwareAgent>Adobe After Effects CC 2014 (Macintosh)</stEvt:softwareAgent>\n               </rdf:li>\n            </rdf:Seq>\n         </xmpMM:History>\n      </rdf:Description>\n   </rdf:RDF>\n</x:xmpmeta>\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n<?xpacket end=\"w\"?>\n", template_grad3: "RIFX\x00\x00\f\x90FaFXhead\x00\x00\x00\x10\x00\x00\x00\x03\x00\x00\x00W\x00\x00\x00\x01\x00`\x00\x00LIST\x00\x00\flbescbeso\x00\x00\x008\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00`\x00\x00\x18\x00\x00\x00\x00\x00\x04\x00\x01\x00\x01\x07\x80\x048?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xff\xff\xff\xffLIST\x00\x00\x01\x84tdsptdot\x00\x00\x00\x04\xff\xff\xff\xfftdpl\x00\x00\x00\x04\x00\x00\x00\x05LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE Root Vectors Group\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\x00\x00\x00\x00tdmn\x00\x00\x00(ADBE Vector Group\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE Vectors Group\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\x00\x00\x00\x02tdmn\x00\x00\x00(ADBE Vector Graphic - G-Fill\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE Vector Grad Colors\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00tdsn\x00\x00\x00\x07Colors\x00\x00LIST\x00\x00\x00dtdsptdot\x00\x00\x00\x04\xff\xff\xff\xfftdpl\x00\x00\x00\x04\x00\x00\x00\x01LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE End of path sentinel\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\n\x18GCstLIST\x00\x00\x00\xb0tdbstdsb\x00\x00\x00\x04\x00\x00\x00\x01tdsn\x00\x00\x00\x07Colors\x00\x00tdb4\x00\x00\x00|\xdb\x99\x00\x01\x00\x07\x00\x00\xff\xff\xff\xff\x00\x00`\x00?\x1a6\xe2\xeb\x1cC-?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00\x00\x01\x00\b\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00cdat\x00\x00\x00\x04\x00\x00\x00\x00LIST\x00\x00\tTGCkyUtf8\x00\x00\tG<?xml version=\'1.0\'?>\n<prop.map version=\'4\'>\n<prop.list>\n<prop.pair>\n<key>Gradient Color Data</key>\n<prop.list>\n<prop.pair>\n<key>Alpha Stops</key>\n<prop.list>\n<prop.pair>\n<key>Stops List</key>\n<prop.list>\n<prop.pair>\n<key>Stop-0</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[0].rampPoint\npoints[0].midPoint\npoints[0].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-1</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[1].rampPoint\npoints[1].midPoint\npoints[1].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-2</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[2].rampPoint\npoints[2].midPoint\npoints[2].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stops Size</key>\n<int type=\'unsigned\' size=\'32\'>3</int>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Color Stops</key>\n<prop.list>\n<prop.pair>\n<key>Stops List</key>\n<prop.list>\n<prop.pair>\n<key>Stop-0</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[0].rampPoint\npoints[0].midPoint\npoints[0].color.color[0]\npoints[0].color.color[1]\npoints[0].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-1</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[1].rampPoint\npoints[1].midPoint\npoints[1].color.color[0]\npoints[1].color.color[1]\npoints[1].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-2</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[2].rampPoint\npoints[2].midPoint\npoints[2].color.color[0]\npoints[2].color.color[1]\npoints[2].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stops Size</key>\n<int type=\'unsigned\' size=\'32\'>3</int>\n</prop.pair>\n</prop.list>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Gradient Colors</key>\n<string>1.0</string>\n</prop.pair>\n</prop.list>\n</prop.map>\n\x00<?xpacket begin=\"\xef\xbb\xbf\" id=\"W5M0MpCehiHzreSzNTczkc9d\"?>\n<x:xmpmeta xmlns:x=\"adobe:ns:meta/\" x:xmptk=\"Adobe XMP Core 5.6-c014 79.156821, 2014/08/29-03:07:50        \">\n   <rdf:RDF xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\">\n      <rdf:Description rdf:about=\"\"\n            xmlns:dc=\"http://purl.org/dc/elements/1.1/\"\n            xmlns:xmp=\"http://ns.adobe.com/xap/1.0/\"\n            xmlns:xmpMM=\"http://ns.adobe.com/xap/1.0/mm/\"\n            xmlns:stEvt=\"http://ns.adobe.com/xap/1.0/sType/ResourceEvent#\">\n         <dc:format>application/vnd.adobe.aftereffects.preset-animation</dc:format>\n         <xmp:CreatorTool>Adobe After Effects CC 2014 (Macintosh)</xmp:CreatorTool>\n         <xmp:CreateDate>2018-01-20T12:34:50-05:00</xmp:CreateDate>\n         <xmp:MetadataDate>2018-01-20T12:34:50-05:00</xmp:MetadataDate>\n         <xmp:ModifyDate>2018-01-20T12:34:50-05:00</xmp:ModifyDate>\n         <xmpMM:InstanceID>xmp.iid:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</xmpMM:InstanceID>\n         <xmpMM:DocumentID>xmp.did:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</xmpMM:DocumentID>\n         <xmpMM:OriginalDocumentID>xmp.did:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</xmpMM:OriginalDocumentID>\n         <xmpMM:History>\n            <rdf:Seq>\n               <rdf:li rdf:parseType=\"Resource\">\n                  <stEvt:action>created</stEvt:action>\n                  <stEvt:instanceID>xmp.iid:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</stEvt:instanceID>\n                  <stEvt:when>2018-01-20T12:34:50-05:00</stEvt:when>\n                  <stEvt:softwareAgent>Adobe After Effects CC 2014 (Macintosh)</stEvt:softwareAgent>\n               </rdf:li>\n            </rdf:Seq>\n         </xmpMM:History>\n      </rdf:Description>\n   </rdf:RDF>\n</x:xmpmeta>\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n<?xpacket end=\"w\"?>\n", template_grad4: "RIFX\x00\x00\x0e\xbeFaFXhead\x00\x00\x00\x10\x00\x00\x00\x03\x00\x00\x00W\x00\x00\x00\x01\x00`\x00\x00LIST\x00\x00\x0e\x9abescbeso\x00\x00\x008\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00`\x00\x00\x18\x00\x00\x00\x00\x00\x04\x00\x01\x00\x01\x07\x80\x048?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xff\xff\xff\xffLIST\x00\x00\x01\x84tdsptdot\x00\x00\x00\x04\xff\xff\xff\xfftdpl\x00\x00\x00\x04\x00\x00\x00\x05LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE Root Vectors Group\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\x00\x00\x00\x00tdmn\x00\x00\x00(ADBE Vector Group\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE Vectors Group\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\x00\x00\x00\x02tdmn\x00\x00\x00(ADBE Vector Graphic - G-Fill\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE Vector Grad Colors\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00tdsn\x00\x00\x00\x07Colors\x00\x00LIST\x00\x00\x00dtdsptdot\x00\x00\x00\x04\xff\xff\xff\xfftdpl\x00\x00\x00\x04\x00\x00\x00\x01LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE End of path sentinel\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\fFGCstLIST\x00\x00\x00\xb0tdbstdsb\x00\x00\x00\x04\x00\x00\x00\x01tdsn\x00\x00\x00\x07Colors\x00\x00tdb4\x00\x00\x00|\xdb\x99\x00\x01\x00\x07\x00\x00\xff\xff\xff\xff\x00\x00`\x00?\x1a6\xe2\xeb\x1cC-?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00\x00\x01\x00\b\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00cdat\x00\x00\x00\x04\x00\x00\x00\x00LIST\x00\x00\v\x82GCkyUtf8\x00\x00\vv<?xml version=\'1.0\'?>\n<prop.map version=\'4\'>\n<prop.list>\n<prop.pair>\n<key>Gradient Color Data</key>\n<prop.list>\n<prop.pair>\n<key>Alpha Stops</key>\n<prop.list>\n<prop.pair>\n<key>Stops List</key>\n<prop.list>\n<prop.pair>\n<key>Stop-0</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[0].rampPoint\npoints[0].midPoint\npoints[0].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-1</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[1].rampPoint\npoints[1].midPoint\npoints[1].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-2</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[2].rampPoint\npoints[2].midPoint\npoints[2].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-3</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[3].rampPoint\npoints[3].midPoint\npoints[3].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stops Size</key>\n<int type=\'unsigned\' size=\'32\'>4</int>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Color Stops</key>\n<prop.list>\n<prop.pair>\n<key>Stops List</key>\n<prop.list>\n<prop.pair>\n<key>Stop-0</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[0].rampPoint\npoints[0].midPoint\npoints[0].color.color[0]\npoints[0].color.color[1]\npoints[0].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-1</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[1].rampPoint\npoints[1].midPoint\npoints[1].color.color[0]\npoints[1].color.color[1]\npoints[1].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-2</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[2].rampPoint\npoints[2].midPoint\npoints[2].color.color[0]\npoints[2].color.color[1]\npoints[2].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-3</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[3].rampPoint\npoints[3].midPoint\npoints[3].color.color[0]\npoints[3].color.color[1]\npoints[3].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stops Size</key>\n<int type=\'unsigned\' size=\'32\'>4</int>\n</prop.pair>\n</prop.list>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Gradient Colors</key>\n<string>1.0</string>\n</prop.pair>\n</prop.list>\n</prop.map>\n<?xpacket begin=\"\xef\xbb\xbf\" id=\"W5M0MpCehiHzreSzNTczkc9d\"?>\n<x:xmpmeta xmlns:x=\"adobe:ns:meta/\" x:xmptk=\"Adobe XMP Core 5.6-c014 79.156821, 2014/08/29-03:07:50        \">\n   <rdf:RDF xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\">\n      <rdf:Description rdf:about=\"\"\n            xmlns:dc=\"http://purl.org/dc/elements/1.1/\"\n            xmlns:xmp=\"http://ns.adobe.com/xap/1.0/\"\n            xmlns:xmpMM=\"http://ns.adobe.com/xap/1.0/mm/\"\n            xmlns:stEvt=\"http://ns.adobe.com/xap/1.0/sType/ResourceEvent#\">\n         <dc:format>application/vnd.adobe.aftereffects.preset-animation</dc:format>\n         <xmp:CreatorTool>Adobe After Effects CC 2014 (Macintosh)</xmp:CreatorTool>\n         <xmp:CreateDate>2018-01-20T12:34:50-05:00</xmp:CreateDate>\n         <xmp:MetadataDate>2018-01-20T12:34:50-05:00</xmp:MetadataDate>\n         <xmp:ModifyDate>2018-01-20T12:34:50-05:00</xmp:ModifyDate>\n         <xmpMM:InstanceID>xmp.iid:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</xmpMM:InstanceID>\n         <xmpMM:DocumentID>xmp.did:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</xmpMM:DocumentID>\n         <xmpMM:OriginalDocumentID>xmp.did:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</xmpMM:OriginalDocumentID>\n         <xmpMM:History>\n            <rdf:Seq>\n               <rdf:li rdf:parseType=\"Resource\">\n                  <stEvt:action>created</stEvt:action>\n                  <stEvt:instanceID>xmp.iid:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</stEvt:instanceID>\n                  <stEvt:when>2018-01-20T12:34:50-05:00</stEvt:when>\n                  <stEvt:softwareAgent>Adobe After Effects CC 2014 (Macintosh)</stEvt:softwareAgent>\n               </rdf:li>\n            </rdf:Seq>\n         </xmpMM:History>\n      </rdf:Description>\n   </rdf:RDF>\n</x:xmpmeta>\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n<?xpacket end=\"w\"?>\n", template_grad5: "RIFX\x00\x00\x11\xe2FaFXhead\x00\x00\x00\x10\x00\x00\x00\x03\x00\x00\x00W\x00\x00\x00\x01\x00a\x00\x00LIST\x00\x00\x11\xbebescbeso\x00\x00\x008\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00`\x00\x00\x18\x00\x00\x00\x00\x00\x04\x00\x01\x00\x01\x07\x80\x048?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xff\xff\xff\xffLIST\x00\x00\x01\x84tdsptdot\x00\x00\x00\x04\xff\xff\xff\xfftdpl\x00\x00\x00\x04\x00\x00\x00\x05LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE Root Vectors Group\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\x00\x00\x00\x00tdmn\x00\x00\x00(ADBE Vector Group\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE Vectors Group\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\x00\x00\x00\x02tdmn\x00\x00\x00(ADBE Vector Graphic - G-Fill\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE Vector Grad Colors\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00tdsn\x00\x00\x00\x07Colors\x00\x00LIST\x00\x00\x00dtdsptdot\x00\x00\x00\x04\xff\xff\xff\xfftdpl\x00\x00\x00\x04\x00\x00\x00\x01LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE End of path sentinel\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x0fjGCstLIST\x00\x00\x00\xb0tdbstdsb\x00\x00\x00\x04\x00\x00\x00\x01tdsn\x00\x00\x00\x07Colors\x00\x00tdb4\x00\x00\x00|\xdb\x99\x00\x01\x00\x07\x00\x00\xff\xff\xff\xff\x00\x00`\x00?\x1a6\xe2\xeb\x1cC-?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00\x00\x01\x00\b\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00cdat\x00\x00\x00\x04\x00\x00\x00\x00LIST\x00\x00\x0e\xa6GCkyUtf8\x00\x00\x0e\x9a<?xml version=\'1.0\'?>\n<prop.map version=\'4\'>\n<prop.list>\n<prop.pair>\n<key>Gradient Color Data</key>\n<prop.list>\n<prop.pair>\n<key>Alpha Stops</key>\n<prop.list>\n<prop.pair>\n<key>Stops List</key>\n<prop.list>\n<prop.pair>\n<key>Stop-0</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[0].rampPoint\npoints[0].midPoint\npoints[0].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-1</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[1].rampPoint\npoints[1].midPoint\npoints[1].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-2</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[2].rampPoint\npoints[2].midPoint\npoints[2].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-3</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[3].rampPoint\npoints[3].midPoint\npoints[3].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-4</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[4].rampPoint\npoints[4].midPoint\npoints[4].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-5</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[4].rampPoint\npoints[4].midPoint\npoints[4].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stops Size</key>\n<int type=\'unsigned\' size=\'32\'>6</int>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Color Stops</key>\n<prop.list>\n<prop.pair>\n<key>Stops List</key>\n<prop.list>\n<prop.pair>\n<key>Stop-0</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[0].rampPoint\npoints[0].midPoint\npoints[0].color.color[0]\npoints[0].color.color[1]\npoints[0].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-1</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[1].rampPoint\npoints[1].midPoint\npoints[1].color.color[0]\npoints[1].color.color[1]\npoints[1].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-2</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[2].rampPoint\npoints[2].midPoint\npoints[2].color.color[0]\npoints[2].color.color[1]\npoints[2].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-3</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[3].rampPoint\npoints[3].midPoint\npoints[3].color.color[0]\npoints[3].color.color[1]\npoints[3].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-4</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[4].rampPoint\npoints[4].midPoint\npoints[4].color.color[0]\npoints[4].color.color[1]\npoints[4].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stops Size</key>\n<int type=\'unsigned\' size=\'32\'>5</int>\n</prop.pair>\n</prop.list>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Gradient Colors</key>\n<string>1.0</string>\n</prop.pair>\n</prop.list>\n</prop.map>\n<?xpacket begin=\"\xef\xbb\xbf\" id=\"W5M0MpCehiHzreSzNTczkc9d\"?>\n<x:xmpmeta xmlns:x=\"adobe:ns:meta/\" x:xmptk=\"Adobe XMP Core 5.6-c014 79.156821, 2014/08/29-03:07:50        \">\n   <rdf:RDF xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\">\n      <rdf:Description rdf:about=\"\"\n            xmlns:dc=\"http://purl.org/dc/elements/1.1/\"\n            xmlns:xmp=\"http://ns.adobe.com/xap/1.0/\"\n            xmlns:xmpMM=\"http://ns.adobe.com/xap/1.0/mm/\"\n            xmlns:stEvt=\"http://ns.adobe.com/xap/1.0/sType/ResourceEvent#\">\n         <dc:format>application/vnd.adobe.aftereffects.preset-animation</dc:format>\n         <xmp:CreatorTool>Adobe After Effects CC 2014 (Macintosh)</xmp:CreatorTool>\n         <xmp:CreateDate>2018-01-20T12:34:50-05:00</xmp:CreateDate>\n         <xmp:MetadataDate>2018-01-20T12:34:50-05:00</xmp:MetadataDate>\n         <xmp:ModifyDate>2018-01-20T12:34:50-05:00</xmp:ModifyDate>\n         <xmpMM:InstanceID>xmp.iid:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</xmpMM:InstanceID>\n         <xmpMM:DocumentID>xmp.did:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</xmpMM:DocumentID>\n         <xmpMM:OriginalDocumentID>xmp.did:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</xmpMM:OriginalDocumentID>\n         <xmpMM:History>\n            <rdf:Seq>\n               <rdf:li rdf:parseType=\"Resource\">\n                  <stEvt:action>created</stEvt:action>\n                  <stEvt:instanceID>xmp.iid:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</stEvt:instanceID>\n                  <stEvt:when>2018-01-20T12:34:50-05:00</stEvt:when>\n                  <stEvt:softwareAgent>Adobe After Effects CC 2014 (Macintosh)</stEvt:softwareAgent>\n               </rdf:li>\n            </rdf:Seq>\n         </xmpMM:History>\n      </rdf:Description>\n   </rdf:RDF>\n</x:xmpmeta>\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n<?xpacket end=\"w\"?>\n", template_grad6: "RIFX\x00\x00\x13\x1cFaFXhead\x00\x00\x00\x10\x00\x00\x00\x03\x00\x00\x00W\x00\x00\x00\x01\x00`\x00\x00LIST\x00\x00\x12\xf8bescbeso\x00\x00\x008\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00`\x00\x00\x18\x00\x00\x00\x00\x00\x04\x00\x01\x00\x01\x07\x80\x048?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xff\xff\xff\xffLIST\x00\x00\x01\x84tdsptdot\x00\x00\x00\x04\xff\xff\xff\xfftdpl\x00\x00\x00\x04\x00\x00\x00\x05LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE Root Vectors Group\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\x00\x00\x00\x00tdmn\x00\x00\x00(ADBE Vector Group\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE Vectors Group\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\x00\x00\x00\x02tdmn\x00\x00\x00(ADBE Vector Graphic - G-Fill\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE Vector Grad Colors\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00tdsn\x00\x00\x00\x07Colors\x00\x00LIST\x00\x00\x00dtdsptdot\x00\x00\x00\x04\xff\xff\xff\xfftdpl\x00\x00\x00\x04\x00\x00\x00\x01LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE End of path sentinel\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x10\xa4GCstLIST\x00\x00\x00\xb0tdbstdsb\x00\x00\x00\x04\x00\x00\x00\x01tdsn\x00\x00\x00\x07Colors\x00\x00tdb4\x00\x00\x00|\xdb\x99\x00\x01\x00\x07\x00\x00\xff\xff\xff\xff\x00\x00`\x00?\x1a6\xe2\xeb\x1cC-?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00\x00\x01\x00\b\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00cdat\x00\x00\x00\x04\x00\x00\x00\x00LIST\x00\x00\x0f\xe0GCkyUtf8\x00\x00\x0f\xd4<?xml version=\'1.0\'?>\n<prop.map version=\'4\'>\n<prop.list>\n<prop.pair>\n<key>Gradient Color Data</key>\n<prop.list>\n<prop.pair>\n<key>Alpha Stops</key>\n<prop.list>\n<prop.pair>\n<key>Stops List</key>\n<prop.list>\n<prop.pair>\n<key>Stop-0</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[0].rampPoint\npoints[0].midPoint\npoints[0].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-1</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[1].rampPoint\npoints[1].midPoint\npoints[1].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-2</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[2].rampPoint\npoints[2].midPoint\npoints[2].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-3</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[3].rampPoint\npoints[3].midPoint\npoints[3].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-4</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[4].rampPoint\npoints[4].midPoint\npoints[4].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-5</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[5].rampPoint\npoints[5].midPoint\npoints[5].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stops Size</key>\n<int type=\'unsigned\' size=\'32\'>6</int>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Color Stops</key>\n<prop.list>\n<prop.pair>\n<key>Stops List</key>\n<prop.list>\n<prop.pair>\n<key>Stop-0</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[0].rampPoint\npoints[0].midPoint\npoints[0].color.color[0]\npoints[0].color.color[1]\npoints[0].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-1</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[1].rampPoint\npoints[1].midPoint\npoints[1].color.color[0]\npoints[1].color.color[1]\npoints[1].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-2</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[2].rampPoint\npoints[2].midPoint\npoints[2].color.color[0]\npoints[2].color.color[1]\npoints[2].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-3</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[3].rampPoint\npoints[3].midPoint\npoints[3].color.color[0]\npoints[3].color.color[1]\npoints[3].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-4</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[4].rampPoint\npoints[4].midPoint\npoints[4].color.color[0]\npoints[4].color.color[1]\npoints[4].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-5</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[5].rampPoint\npoints[5].midPoint\npoints[5].color.color[0]\npoints[5].color.color[1]\npoints[5].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stops Size</key>\n<int type=\'unsigned\' size=\'32\'>6</int>\n</prop.pair>\n</prop.list>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Gradient Colors</key>\n<string>1.0</string>\n</prop.pair>\n</prop.list>\n</prop.map>\n<?xpacket begin=\"\xef\xbb\xbf\" id=\"W5M0MpCehiHzreSzNTczkc9d\"?>\n<x:xmpmeta xmlns:x=\"adobe:ns:meta/\" x:xmptk=\"Adobe XMP Core 5.6-c014 79.156821, 2014/08/29-03:07:50        \">\n   <rdf:RDF xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\">\n      <rdf:Description rdf:about=\"\"\n            xmlns:dc=\"http://purl.org/dc/elements/1.1/\"\n            xmlns:xmp=\"http://ns.adobe.com/xap/1.0/\"\n            xmlns:xmpMM=\"http://ns.adobe.com/xap/1.0/mm/\"\n            xmlns:stEvt=\"http://ns.adobe.com/xap/1.0/sType/ResourceEvent#\">\n         <dc:format>application/vnd.adobe.aftereffects.preset-animation</dc:format>\n         <xmp:CreatorTool>Adobe After Effects CC 2014 (Macintosh)</xmp:CreatorTool>\n         <xmp:CreateDate>2018-01-20T12:34:50-05:00</xmp:CreateDate>\n         <xmp:MetadataDate>2018-01-20T12:34:50-05:00</xmp:MetadataDate>\n         <xmp:ModifyDate>2018-01-20T12:34:50-05:00</xmp:ModifyDate>\n         <xmpMM:InstanceID>xmp.iid:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</xmpMM:InstanceID>\n         <xmpMM:DocumentID>xmp.did:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</xmpMM:DocumentID>\n         <xmpMM:OriginalDocumentID>xmp.did:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</xmpMM:OriginalDocumentID>\n         <xmpMM:History>\n            <rdf:Seq>\n               <rdf:li rdf:parseType=\"Resource\">\n                  <stEvt:action>created</stEvt:action>\n                  <stEvt:instanceID>xmp.iid:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</stEvt:instanceID>\n                  <stEvt:when>2018-01-20T12:34:50-05:00</stEvt:when>\n                  <stEvt:softwareAgent>Adobe After Effects CC 2014 (Macintosh)</stEvt:softwareAgent>\n               </rdf:li>\n            </rdf:Seq>\n         </xmpMM:History>\n      </rdf:Description>\n   </rdf:RDF>\n</x:xmpmeta>\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n<?xpacket end=\"w\"?>\n", template_grad7: "RIFX\x00\x00\x15LFaFXhead\x00\x00\x00\x10\x00\x00\x00\x03\x00\x00\x00W\x00\x00\x00\x01\x00a\x00\x00LIST\x00\x00\x15(bescbeso\x00\x00\x008\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00`\x00\x00\x18\x00\x00\x00\x00\x00\x04\x00\x01\x00\x01\x07\x80\x048?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xff\xff\xff\xffLIST\x00\x00\x01\x84tdsptdot\x00\x00\x00\x04\xff\xff\xff\xfftdpl\x00\x00\x00\x04\x00\x00\x00\x05LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE Root Vectors Group\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\x00\x00\x00\x00tdmn\x00\x00\x00(ADBE Vector Group\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE Vectors Group\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\x00\x00\x00\x02tdmn\x00\x00\x00(ADBE Vector Graphic - G-Fill\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE Vector Grad Colors\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00tdsn\x00\x00\x00\x07Colors\x00\x00LIST\x00\x00\x00dtdsptdot\x00\x00\x00\x04\xff\xff\xff\xfftdpl\x00\x00\x00\x04\x00\x00\x00\x01LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE End of path sentinel\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x12\xd4GCstLIST\x00\x00\x00\xb0tdbstdsb\x00\x00\x00\x04\x00\x00\x00\x01tdsn\x00\x00\x00\x07Colors\x00\x00tdb4\x00\x00\x00|\xdb\x99\x00\x01\x00\x07\x00\x00\xff\xff\xff\xff\x00\x00`\x00?\x1a6\xe2\xeb\x1cC-?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00\x00\x01\x00\b\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00cdat\x00\x00\x00\x04\x00\x00\x00\x00LIST\x00\x00\x12\x10GCkyUtf8\x00\x00\x12\x03<?xml version=\'1.0\'?>\n<prop.map version=\'4\'>\n<prop.list>\n<prop.pair>\n<key>Gradient Color Data</key>\n<prop.list>\n<prop.pair>\n<key>Alpha Stops</key>\n<prop.list>\n<prop.pair>\n<key>Stops List</key>\n<prop.list>\n<prop.pair>\n<key>Stop-0</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[0].rampPoint\npoints[0].midPoint\npoints[0].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-1</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[1].rampPoint\npoints[1].midPoint\npoints[1].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-2</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[2].rampPoint\npoints[2].midPoint\npoints[2].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-3</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[3].rampPoint\npoints[3].midPoint\npoints[3].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-4</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[4].rampPoint\npoints[4].midPoint\npoints[4].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-5</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[5].rampPoint\npoints[5].midPoint\npoints[5].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-6</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[6].rampPoint\npoints[6].midPoint\npoints[6].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stops Size</key>\n<int type=\'unsigned\' size=\'32\'>7</int>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Color Stops</key>\n<prop.list>\n<prop.pair>\n<key>Stops List</key>\n<prop.list>\n<prop.pair>\n<key>Stop-0</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[0].rampPoint\npoints[0].midPoint\npoints[0].color.color[0]\npoints[0].color.color[1]\npoints[0].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-1</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[1].rampPoint\npoints[1].midPoint\npoints[1].color.color[0]\npoints[1].color.color[1]\npoints[1].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-2</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[2].rampPoint\npoints[2].midPoint\npoints[2].color.color[0]\npoints[2].color.color[1]\npoints[2].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-3</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[3].rampPoint\npoints[3].midPoint\npoints[3].color.color[0]\npoints[3].color.color[1]\npoints[3].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-4</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[4].rampPoint\npoints[4].midPoint\npoints[4].color.color[0]\npoints[4].color.color[1]\npoints[4].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-5</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[5].rampPoint\npoints[5].midPoint\npoints[5].color.color[0]\npoints[5].color.color[1]\npoints[5].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-6</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[6].rampPoint\npoints[6].midPoint\npoints[6].color.color[0]\npoints[6].color.color[1]\npoints[6].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stops Size</key>\n<int type=\'unsigned\' size=\'32\'>7</int>\n</prop.pair>\n</prop.list>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Gradient Colors</key>\n<string>1.0</string>\n</prop.pair>\n</prop.list>\n</prop.map>\n<?xpacket begin=\"\xef\xbb\xbf\" id=\"W5M0MpCehiHzreSzNTczkc9d\"?>\n<x:xmpmeta xmlns:x=\"adobe:ns:meta/\" x:xmptk=\"Adobe XMP Core 5.6-c014 79.156821, 2014/08/29-03:07:50        \">\n   <rdf:RDF xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\">\n      <rdf:Description rdf:about=\"\"\n            xmlns:dc=\"http://purl.org/dc/elements/1.1/\"\n            xmlns:xmp=\"http://ns.adobe.com/xap/1.0/\"\n            xmlns:xmpMM=\"http://ns.adobe.com/xap/1.0/mm/\"\n            xmlns:stEvt=\"http://ns.adobe.com/xap/1.0/sType/ResourceEvent#\">\n         <dc:format>application/vnd.adobe.aftereffects.preset-animation</dc:format>\n         <xmp:CreatorTool>Adobe After Effects CC 2014 (Macintosh)</xmp:CreatorTool>\n         <xmp:CreateDate>2018-01-20T12:34:50-05:00</xmp:CreateDate>\n         <xmp:MetadataDate>2018-01-20T12:34:50-05:00</xmp:MetadataDate>\n         <xmp:ModifyDate>2018-01-20T12:34:50-05:00</xmp:ModifyDate>\n         <xmpMM:InstanceID>xmp.iid:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</xmpMM:InstanceID>\n         <xmpMM:DocumentID>xmp.did:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</xmpMM:DocumentID>\n         <xmpMM:OriginalDocumentID>xmp.did:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</xmpMM:OriginalDocumentID>\n         <xmpMM:History>\n            <rdf:Seq>\n               <rdf:li rdf:parseType=\"Resource\">\n                  <stEvt:action>created</stEvt:action>\n                  <stEvt:instanceID>xmp.iid:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</stEvt:instanceID>\n                  <stEvt:when>2018-01-20T12:34:50-05:00</stEvt:when>\n                  <stEvt:softwareAgent>Adobe After Effects CC 2014 (Macintosh)</stEvt:softwareAgent>\n               </rdf:li>\n            </rdf:Seq>\n         </xmpMM:History>\n      </rdf:Description>\n   </rdf:RDF>\n</x:xmpmeta>\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n<?xpacket end=\"w\"?>\n", template_grad8: "RIFX\x00\x00\x17zFaFXhead\x00\x00\x00\x10\x00\x00\x00\x03\x00\x00\x00W\x00\x00\x00\x01\x00a\x00\x00LIST\x00\x00\x17Vbescbeso\x00\x00\x008\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00`\x00\x00\x18\x00\x00\x00\x00\x00\x04\x00\x01\x00\x01\x07\x80\x048?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xff\xff\xff\xffLIST\x00\x00\x01\x84tdsptdot\x00\x00\x00\x04\xff\xff\xff\xfftdpl\x00\x00\x00\x04\x00\x00\x00\x05LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE Root Vectors Group\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\x00\x00\x00\x00tdmn\x00\x00\x00(ADBE Vector Group\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE Vectors Group\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\x00\x00\x00\x02tdmn\x00\x00\x00(ADBE Vector Graphic - G-Fill\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE Vector Grad Colors\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00tdsn\x00\x00\x00\x07Colors\x00\x00LIST\x00\x00\x00dtdsptdot\x00\x00\x00\x04\xff\xff\xff\xfftdpl\x00\x00\x00\x04\x00\x00\x00\x01LIST\x00\x00\x00@tdsitdix\x00\x00\x00\x04\xff\xff\xff\xfftdmn\x00\x00\x00(ADBE End of path sentinel\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00LIST\x00\x00\x15\x02GCstLIST\x00\x00\x00\xb0tdbstdsb\x00\x00\x00\x04\x00\x00\x00\x01tdsn\x00\x00\x00\x07Colors\x00\x00tdb4\x00\x00\x00|\xdb\x99\x00\x01\x00\x07\x00\x00\xff\xff\xff\xff\x00\x00`\x00?\x1a6\xe2\xeb\x1cC-?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00?\xf0\x00\x00\x00\x00\x00\x00\x00\x01\x00\b\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00cdat\x00\x00\x00\x04\x00\x00\x00\x00LIST\x00\x00\x14>GCkyUtf8\x00\x00\x142<?xml version=\'1.0\'?>\n<prop.map version=\'4\'>\n<prop.list>\n<prop.pair>\n<key>Gradient Color Data</key>\n<prop.list>\n<prop.pair>\n<key>Alpha Stops</key>\n<prop.list>\n<prop.pair>\n<key>Stops List</key>\n<prop.list>\n<prop.pair>\n<key>Stop-0</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[0].rampPoint\npoints[0].midPoint\npoints[0].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-1</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[1].rampPoint\npoints[1].midPoint\npoints[1].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-2</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[2].rampPoint\npoints[2].midPoint\npoints[2].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-3</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[3].rampPoint\npoints[3].midPoint\npoints[3].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-4</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[4].rampPoint\npoints[4].midPoint\npoints[4].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-5</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[5].rampPoint\npoints[5].midPoint\npoints[5].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-6</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[6].rampPoint\npoints[6].midPoint\npoints[6].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-7</key>\n<prop.list>\n<prop.pair>\n<key>Stops Alpha</key>\n<array>\n<array.type><float/></array.type>\npoints[7].rampPoint\npoints[7].midPoint\npoints[7].opacity\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stops Size</key>\n<int type=\'unsigned\' size=\'32\'>8</int>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Color Stops</key>\n<prop.list>\n<prop.pair>\n<key>Stops List</key>\n<prop.list>\n<prop.pair>\n<key>Stop-0</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[0].rampPoint\npoints[0].midPoint\npoints[0].color.color[0]\npoints[0].color.color[1]\npoints[0].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-1</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[1].rampPoint\npoints[1].midPoint\npoints[1].color.color[0]\npoints[1].color.color[1]\npoints[1].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-2</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[2].rampPoint\npoints[2].midPoint\npoints[2].color.color[0]\npoints[2].color.color[1]\npoints[2].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-3</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[3].rampPoint\npoints[3].midPoint\npoints[3].color.color[0]\npoints[3].color.color[1]\npoints[3].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-4</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[4].rampPoint\npoints[4].midPoint\npoints[4].color.color[0]\npoints[4].color.color[1]\npoints[4].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-5</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[5].rampPoint\npoints[5].midPoint\npoints[5].color.color[0]\npoints[5].color.color[1]\npoints[5].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-6</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[6].rampPoint\npoints[6].midPoint\npoints[6].color.color[0]\npoints[6].color.color[1]\npoints[6].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stop-7</key>\n<prop.list>\n<prop.pair>\n<key>Stops Color</key>\n<array>\n<array.type><float/></array.type>\npoints[7].rampPoint\npoints[7].midPoint\npoints[7].color.color[0]\npoints[7].color.color[1]\npoints[7].color.color[2]\n<float>1</float>\n</array>\n</prop.pair>\n</prop.list>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Stops Size</key>\n<int type=\'unsigned\' size=\'32\'>8</int>\n</prop.pair>\n</prop.list>\n</prop.pair>\n</prop.list>\n</prop.pair>\n<prop.pair>\n<key>Gradient Colors</key>\n<string>1.0</string>\n</prop.pair>\n</prop.list>\n</prop.map>\n<?xpacket begin=\"\xef\xbb\xbf\" id=\"W5M0MpCehiHzreSzNTczkc9d\"?>\n<x:xmpmeta xmlns:x=\"adobe:ns:meta/\" x:xmptk=\"Adobe XMP Core 5.6-c014 79.156821, 2014/08/29-03:07:50        \">\n   <rdf:RDF xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\">\n      <rdf:Description rdf:about=\"\"\n            xmlns:dc=\"http://purl.org/dc/elements/1.1/\"\n            xmlns:xmp=\"http://ns.adobe.com/xap/1.0/\"\n            xmlns:xmpMM=\"http://ns.adobe.com/xap/1.0/mm/\"\n            xmlns:stEvt=\"http://ns.adobe.com/xap/1.0/sType/ResourceEvent#\">\n         <dc:format>application/vnd.adobe.aftereffects.preset-animation</dc:format>\n         <xmp:CreatorTool>Adobe After Effects CC 2014 (Macintosh)</xmp:CreatorTool>\n         <xmp:CreateDate>2018-01-20T12:34:50-05:00</xmp:CreateDate>\n         <xmp:MetadataDate>2018-01-20T12:34:50-05:00</xmp:MetadataDate>\n         <xmp:ModifyDate>2018-01-20T12:34:50-05:00</xmp:ModifyDate>\n         <xmpMM:InstanceID>xmp.iid:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</xmpMM:InstanceID>\n         <xmpMM:DocumentID>xmp.did:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</xmpMM:DocumentID>\n         <xmpMM:OriginalDocumentID>xmp.did:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</xmpMM:OriginalDocumentID>\n         <xmpMM:History>\n            <rdf:Seq>\n               <rdf:li rdf:parseType=\"Resource\">\n                  <stEvt:action>created</stEvt:action>\n                  <stEvt:instanceID>xmp.iid:9f2e7e7b-65a7-49aa-beb9-509e3e6907bd</stEvt:instanceID>\n                  <stEvt:when>2018-01-20T12:34:50-05:00</stEvt:when>\n                  <stEvt:softwareAgent>Adobe After Effects CC 2014 (Macintosh)</stEvt:softwareAgent>\n               </rdf:li>\n            </rdf:Seq>\n         </xmpMM:History>\n      </rdf:Description>\n   </rdf:RDF>\n</x:xmpmeta>\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n<?xpacket end=\"w\"?>\n"};
for (var key in presetFiles) { 
if (presetFiles.hasOwnProperty(key)) { 
createResourceFile(key + ".ffx", presetFiles[key], ffxObj.destPath);
}
}
}
function ae_newLayer(aiObj) {
centerPath = false;
hasClippingMask = false;
if (aiObj.shapes.length < 1) { 
return;
}
app.beginUndoGroup("New Overlord layer");
var shapes = removeTopGroup(aiObj.shapes);
var thisComp = app.project.activeItem;
currentTime = thisComp.time;
var center = [thisComp.width / 2, thisComp.height / 2];
var s = thisComp.layers.addShape();
var layerName = (overlordPrefs.explode) || (aiObj.shapes.length < 2) ? undefined : aiObj.shapes[0].layerName;
s.name = nameInc(((layerName) || (aiObj.shapes[0].name)) || (aiObj.shapes[0].layerName));
s.guideLayer = (aiObj.guides) || (false);
if (aiObj.shapes.length < 2) { 
s.blendingMode = layerBlendingMode(aiObj.shapes[0].blendingMode);
}
s("ADBE Transform Group")("ADBE Opacity").setValue(aiObj.shapes[0].opacity);
if ((overlordPrefs.centerAnchor) || (overlordPrefs.centerLayer)) { 
centerPath = true;
}
ae_buildShapes(s, shapes);
try {
if (overlordPrefs.centerLayer) { 
s.selected = true;
app.executeCommand(10312);
s("ADBE Transform Group")("ADBE Position").setValue(center);
return;
}
if (((((shapes.length < 2) && (shapes.children < 2)) && (overlordPrefs.centerAnchor)) && (overlordPrefs.detectParametrics)) && ((shapes[0].pathPoints.type == "ellipse") || (shapes[0].pathPoints.type == "rect"))) { 
s.selected = true;
app.executeCommand(10312);
s("ADBE Transform Group")("ADBE Anchor Point").setValue([0, 0]);
s("ADBE Root Vectors Group")("ADBE Vector Group")("ADBE Vector Transform Group")("ADBE Vector Position").setValue([0, 0]);
return;
}
if ((centerPath) && (shapes.length > 1)) { 
s("ADBE Transform Group")("ADBE Position").setValue([0, 0]);
deselectLayers();
s.selected = true;
app.executeCommand(10312);
return;
}
else {
if ((centerPath) && (shapes.length < 2)) { 
var shapeCenter = center + shapes[0].position;
s("ADBE Transform Group")("ADBE Position").setValue(shapeCenter);
if (hasClippingMask) { 
s("ADBE Transform Group")("ADBE Anchor Point").setValue(shapeCenter);
}
}
}
} catch (e) {
}
app.endUndoGroup();
}
function ae_newLayersFromGroups(aiObj) {
app.beginUndoGroup("New Overlord layers from groups");
var shapes = removeTopGroup(aiObj.shapes);
var thisComp = app.project.activeItem;
currentTime = thisComp.time;
var center = [thisComp.width / 2, thisComp.height / 2];
var firstLayerOffset = [0, 0];
var layerName = aiObj.shapes[0].layerName;
if ((overlordPrefs.centerAnchor) || (overlordPrefs.centerLayer)) { 
centerPath = true;
}
for (var i = shapes.length - 1; i >= 0; i--) { 
centerPath = false;
s = thisComp.layers.addShape();
s.name = nameInc(((shapes[i].name) || (shapes[i].layerName)) || (layerName));
s.blendingMode = layerBlendingMode(parseInt(shapes[i].blendingMode));
s("ADBE Transform Group")("ADBE Opacity").setValue(shapes[i].opacity);
try {
if (shapes[i].typename == "ClipGroup") { 
ae_buildShapes(s, [shapes[i]]);
}
else if (shapes[i].typename != "CompoundPathItem") {
centerPath = true;
ae_buildShapes(s, shapes[i].children);
s.selected = true;
app.executeCommand(10312);
}
else {
ae_buildShapes(s, [shapes[i]]);
}
} catch (e) {ae_buildShapes(s, [shapes[i]]);
}
try {
if ((overlordPrefs.centerLayer) && (!centerPath)) { 
s.selected = true;
app.executeCommand(10312);
s("ADBE Transform Group")("ADBE Position").setValue(center);
continue ;
}
if (overlordPrefs.centerLayer) { 
s("ADBE Transform Group")("ADBE Position").setValue(center);
continue ;
}
if (((((shapes[i].length < 2) && (shapes[i].children < 2)) && (overlordPrefs.centerAnchor)) && (overlordPrefs.detectParametrics)) && ((shapes[i].pathPoints.type == "ellipse") || (shapes[i].pathPoints.type == "rect"))) { 
s.selected = true;
app.executeCommand(10312);
s("ADBE Transform Group")("ADBE Anchor Point").setValue([0, 0]);
s("ADBE Root Vectors Group")("ADBE Vector Group")("ADBE Vector Transform Group")("ADBE Vector Position").setValue([0, 0]);
continue ;
}
if (centerPath) { 
var shapeCenter = center + shapes[i].position;
s("ADBE Transform Group")("ADBE Position").setValue(shapeCenter);
centerPath = false;
continue ;
}
s.selected = false;
} catch (e) {
}}
app.endUndoGroup();
}
function ae_addToLayers(aiObj) {
app.beginUndoGroup("Add shape to layers");
var shapes = aiObj.shapes;
var thisComp = app.project.activeItem;
currentTime = thisComp.time;
var selLayers = thisComp.selectedLayers;
for (var i = 0; i < thisComp.selectedLayers.length; i += 1) { 
for (var j = shapes.length - 1; j >= 0; j--) { 
g = ae_buildShapes(selLayers[i], [shapes[j]], true);
try {
g.moveTo(1);
} catch (e) {
}}}
app.endUndoGroup();
}
function ae_updateShapes(aiObj) {
function aiPathToAeElement(sel) {
try {
if (sel.matchName == "ADBE Vector Shape - Group") { 
aiPathToAePath(sel, aiPath);
return true;
}
if ((sel.matchName == "ADBE Vector Group") && (sel(2)("ADBE Vector Shape - Group") != undefined)) { 
aiPathToAePath(sel(2)("ADBE Vector Shape - Group"), aiPath);
checkColors(sel, aiPath);
return true;
}
if (sel.matchName == "ADBE Vector Shape - Rect") { 
aiToAeParametric(sel, aiPath);
return true;
}
if ((sel.matchName == "ADBE Vector Group") && (sel(2)("ADBE Vector Shape - Rect") != undefined)) { 
aiToAeParametric(sel(2)("ADBE Vector Shape - Rect"), aiPath);
checkColors(sel, aiPath);
return true;
}
if (sel.parentProperty.matchName == "ADBE Vector Shape - Rect") { 
aiToAeParametric(sel.propertyGroup(1), aiPath);
return true;
}
if (sel.matchName == "ADBE Vector Shape - Ellipse") { 
aiToAeParametric(sel, aiPath);
return true;
}
if ((sel.matchName == "ADBE Vector Group") && (sel(2)("ADBE Vector Shape - Ellipse") != undefined)) { 
aiToAeParametric(sel(2)("ADBE Vector Shape - Ellipse"), aiPath);
checkColors(sel, aiPath);
return true;
}
if (sel.parentProperty.matchName == "ADBE Vector Shape - Ellipse") { 
aiToAeParametric(sel.propertyGroup(1), aiPath);
return true;
}
if ((((sel.matchName == "ADBE Vector Graphic - Fill") || (sel.matchName == "ADBE Vector Graphic - G-Fill")) || (sel.matchName == "ADBE Vector Graphic - Stroke")) || (sel.matchName == "ADBE Vector Graphic - G-Stroke")) { 
checkColors(sel.propertyGroup(2), aiPath);
return true;
}
if ((sel.parentProperty.matchName == "ADBE Vector Graphic - Fill") || (sel.parentProperty.matchName == "ADBE Vector Graphic - G-Fill")) { 
checkColors(sel.propertyGroup(1), aiPath);
return true;
}
if ((sel.parentProperty.matchName == "ADBE Vector Graphic - Stroke") || (sel.parentProperty.matchName == "ADBE Vector Graphic - G-Stroke")) { 
checkColors(sel.propertyGroup(1), aiPath);
return true;
}
return false;
} catch (e) {return false;
}
}
function checkColors(sel, element) {
function applyFill(sel) {
prop = sel("ADBE Vector Fill Color");
if (prop.numKeys > 0) { 
prop.setValueAtTime(currentTime, element.fillColor.color);
}
else {
prop.setValue(element.fillColor.color);
}
}
function applyGradientFill(sel) {
var currentSel = app.project.activeItem.selectedProperties[0];
ae_deselectProps();
sel.selected = true;
if (element.fillColor.type == "gradient") { 
var isParametric = (element.typename == "PathItem") && ((element.pathPoints.type === "ellipse") || (element.pathPoints.type === "rect")) ? true : false;
var centerOffset = (centerPath) || (isParametric) ? element.position + element.size : [0, 0];
fill = sel;
if ((element.pathPoints.type === "ellipse") || (element.pathPoints.type === "rect")) { 
if (fill("ADBE Vector Grad Start Pt").numKeys > 0) { 
fill("ADBE Vector Grad Start Pt").setValueAtTime(currentTime, element.fillColor.startPoint - element.position);
}
else {
fill("ADBE Vector Grad Start Pt").setValue(element.fillColor.startPoint - element.position);
}
if (fill("ADBE Vector Grad End Pt").numKeys > 0) { 
fill("ADBE Vector Grad End Pt").setValueAtTime(currentTime, element.fillColor.endPoint - element.position);
}
else {
fill("ADBE Vector Grad End Pt").setValue(element.fillColor.endPoint - element.position);
}
}
else {
layerPos = currentSel.propertyGroup(currentSel.propertyDepth)("ADBE Transform Group")("ADBE Position").value;
offset = (overlordPrefs.layerPos) && (!overlordPrefs.centerAnchor) ? [0, 0] : [(thisComp.width / 2) - layerPos[0], (thisComp.height / 2) - layerPos[1]];
if (fill("ADBE Vector Grad Start Pt").numKeys > 0) { 
fill("ADBE Vector Grad Start Pt").setValueAtTime(currentTime, element.fillColor.startPoint + offset);
}
else {
fill("ADBE Vector Grad Start Pt").setValue(element.fillColor.startPoint + offset);
}
if (fill("ADBE Vector Grad End Pt").numKeys > 0) { 
fill("ADBE Vector Grad End Pt").setValueAtTime(currentTime, element.fillColor.endPoint + offset);
}
else {
fill("ADBE Vector Grad End Pt").setValue(element.fillColor.endPoint + offset);
}
}
applyGradientFfx("fillColor", true, element);
}
currentSel.selected = true;
}
function applyStroke(sel) {
prop = sel("ADBE Vector Stroke Color");
if (prop.numKeys > 0) { 
prop.setValueAtTime(currentTime, element.strokeColor.color);
}
else {
prop.setValue(element.strokeColor.color);
}
}
function applyGradientStroke(sel) {
var currentSel = app.project.activeItem.selectedProperties[0];
ae_deselectProps();
sel.selected = true;
if (element.strokeColor.type == "gradient") { 
var isParametric = (element.typename == "PathItem") && ((element.pathPoints.type === "ellipse") || (element.pathPoints.type === "rect")) ? true : false;
var centerOffset = (centerPath) || (isParametric) ? element.position : [0, 0];
fill = sel;
if ((element.pathPoints.type === "ellipse") || (element.pathPoints.type === "rect")) { 
if (fill("ADBE Vector Grad Start Pt").numKeys > 0) { 
fill("ADBE Vector Grad Start Pt").setValueAtTime(currentTime, element.strokeColor.startPoint - element.position);
}
else {
fill("ADBE Vector Grad Start Pt").setValue(element.strokeColor.startPoint - element.position);
}
if (fill("ADBE Vector Grad End Pt").numKeys > 0) { 
fill("ADBE Vector Grad End Pt").setValueAtTime(currentTime, element.strokeColor.endPoint - element.position);
}
else {
fill("ADBE Vector Grad End Pt").setValue(element.strokeColor.endPoint - element.position);
}
}
else {
layerPos = currentSel.propertyGroup(currentSel.propertyDepth)("ADBE Transform Group")("ADBE Position").value;
offset = (overlordPrefs.layerPos) && (!overlordPrefs.centerAnchor) ? [0, 0] : [(thisComp.width / 2) - layerPos[0], (thisComp.height / 2) - layerPos[1]];
if (fill("ADBE Vector Grad Start Pt").numKeys > 0) { 
fill("ADBE Vector Grad Start Pt").setValueAtTime(currentTime, element.strokeColor.startPoint + offset);
}
else {
fill("ADBE Vector Grad Start Pt").setValue(element.strokeColor.startPoint + offset);
}
if (fill("ADBE Vector Grad End Pt").numKeys > 0) { 
fill("ADBE Vector Grad End Pt").setValueAtTime(currentTime, element.strokeColor.endPoint + offset);
}
else {
fill("ADBE Vector Grad End Pt").setValue(element.strokeColor.endPoint + offset);
}
}
applyGradientFfx("strokeColor", true, element);
}
currentSel.selected = true;
}
function applyStrokeWidth(sel) {
prop = sel("ADBE Vector Stroke Width");
if (prop.numKeys > 0) { 
prop.setValueAtTime(currentTime, element.strokeWidth);
}
else {
prop.setValue(element.strokeWidth);
}
}
if (sel.matchName == "ADBE Vector Graphic - Fill") { 
applyFill(sel);
}
if (sel.matchName == "ADBE Vector Graphic - G-Fill") { 
applyGradientFill(sel);
}
if (sel.matchName == "ADBE Vector Graphic - Stroke") { 
applyStroke(sel);
applyStrokeWidth(sel);
}
if (sel.matchName == "ADBE Vector Graphic - G-Stroke") { 
applyGradientStroke(sel);
applyStrokeWidth(sel);
}
try {
if ((sel(2)("ADBE Vector Graphic - Fill") != undefined) && (element.fillColor.type != "gradient")) { 
applyFill(sel(2)("ADBE Vector Graphic - Fill"));
}
if ((sel(2)("ADBE Vector Graphic - G-Fill") != undefined) && (element.fillColor.type != "fill")) { 
applyGradientFill(sel(2)("ADBE Vector Graphic - G-Fill"));
}
if ((sel(2)("ADBE Vector Graphic - Stroke") != undefined) && (element.strokeColor.type != "gradient")) { 
applyStroke(sel(2)("ADBE Vector Graphic - Stroke"));
applyStrokeWidth(sel(2)("ADBE Vector Graphic - Stroke"));
}
if ((sel(2)("ADBE Vector Graphic - G-Stroke") != undefined) && (element.strokeColor.type != "fill")) { 
applyGradientStroke(sel(2)("ADBE Vector Graphic - G-Stroke"));
applyStrokeWidth(sel(2)("ADBE Vector Graphic - G-Stroke"));
}
} catch (e) {
}
}
function aiPathToAePath(aePath, element) {
var layer = aePath.propertyGroup(aePath.propertyDepth);
var groupOffset = aePath.propertyGroup(2)("ADBE Vector Transform Group")("ADBE Vector Position").value;
var path = aePath("ADBE Vector Shape");
var layerOffset = (overlordPrefs.layerPos) && (!overlordPrefs.centerAnchor) ? [0, 0] : ae_getLayerOffset(path) + groupOffset;
var pathObj = {anchor: element.pathPoints.anchor, closed: element.closed, leftDirection: element.pathPoints.leftDirection, path: path, rightDirection: element.pathPoints.rightDirection};
createStaticShape(pathObj, layerOffset);
return;
}
function aiToAeParametric(aePath, element) {
var size = aePath(2);
var groupPos = aePath.propertyGroup(2)("ADBE Vector Transform Group")("ADBE Vector Position");
if (size.numKeys > 0) { 
if ((size.valueAtTime(currentTime, false)[0].toFixed(3) != element.size[0].toFixed(3)) || (size.valueAtTime(currentTime, false)[1].toFixed(3) != element.size[1].toFixed(3))) { 
size.setValueAtTime(currentTime, element.size);
}
}
else {
size.setValue(element.size);
}
layerPos = aePath.propertyGroup(aePath.propertyDepth)("ADBE Transform Group")("ADBE Position").value;
offset = (overlordPrefs.layerPos) && (!overlordPrefs.centerAnchor) ? [0, 0] : [(thisComp.width / 2) - layerPos[0], (thisComp.height / 2) - layerPos[1]];
if (groupPos.numKeys > 0) { 
if ((groupPos.valueAtTime(currentTime, false)[0].toFixed(3) != element.position[0].toFixed(3)) || (groupPos.valueAtTime(currentTime, false)[1].toFixed(3) != element.position[1].toFixed(3))) { 
groupPos.setValueAtTime(currentTime, element.position + offset);
}
}
else {
groupPos.setValue(element.position + offset);
}
}
var updateProp = false;
centerPath = false;
var aiPath = aiObj.shapes[0];
var aiColor = aiObj.shapes[0];
element = aiObj.shapes[0];
app.beginUndoGroup("Update shapes");
if ((overlordPrefs.centerAnchor) || (overlordPrefs.centerLayer)) { 
centerPath = true;
}
updateProp = aiPathToAeElement(thisComp.selectedProperties[0]);
app.endUndoGroup();
return updateProp;
}
function ae_newSwatchLayer(aiObj) {
function buildSwatches(s, swatches, metrics) {
var pos = [0, 0];
for (var i = 0; i < swatches.length; i += 1) { 
g = s(2).addProperty("ADBE Vector Group");
g.name = swatches[i].name;
g("ADBE Vector Materials Group").remove();
shape = g(2).addProperty("ADBE Vector Shape - Rect");
shape("ADBE Vector Rect Size").setValue([metrics.size, metrics.size]);
shape("ADBE Vector Rect Position").setValue(pos);
fill = g(2).addProperty("ADBE Vector Graphic - Fill");
fill("ADBE Vector Fill Color").setValue(swatches[i].color.color);
pos = updateSwatchPos(pos, metrics);}
}
function updateSwatchPos(pos, metrics) {
var offset = metrics.size + metrics.margin;
var posUpdate = metrics.orientation == "vertical" ? [0, offset] : [offset, 0];
if (metrics.orientation == "vertical") { 
var y = pos[1] + offset;
var yMax = (thisComp.height - metrics.size) - (metrics.margin * 2);
if (y > yMax) { 
pos = [pos[0] + offset, -offset];
}
}
else {
var x = pos[0] + offset;
var xMax = (thisComp.width - metrics.size) - (metrics.margin * 2);
if (x > xMax) { 
pos = [-offset, pos[1] + offset];
}
}
return pos + posUpdate;
}
app.beginUndoGroup("New Swatch layer");
var thisComp = app.project.activeItem;
var metrics = aiObj.metrics;
var s = thisComp.layers.addShape();
s.name = nameInc(aiObj.layerName);
s.guideLayer = (aiObj.guides) || (false);
s("ADBE Transform Group")("ADBE Position").setValue([(metrics.size / 2) + metrics.margin, (metrics.size / 2) + metrics.margin]);
buildSwatches(s, aiObj.shapes, metrics);
app.endUndoGroup();
}
function ae_raySwatches(aiObj) {
var thisComp = app.project.activeItem;
var swatches = aiObj.shapes;
var rayCtrl = thisComp.layer(1);
if (aiObj.altKey) { 
rayCtrl.enabled = false;
rayCtrl.selected = false;
rayCtrl = thisComp.layer(1).duplicate();
if (rayCtrl.name.search(/(Overlord)/) == -1) { 
rayCtrl.name = nameInc("Ray - Overlord");
}
rayCtrl.enabled = true;
rayCtrl.selected = true;
for (var i = rayCtrl(4).numProperties; i > 0; i--) { 
rayCtrl(4).property(i).remove();}
}
for (var j = 0; j < swatches.length; j += 1) { 
e = rayCtrl(4).addProperty("ADBE Color Control");
e(1).setValue(swatches[j].color.color);
e.name = "Color " + j + 1;}
}
function ae_newRayComp(aiObj) {
function createRayfolder() {
var hasRayFolder = false;
for (var i = 1; i <= app.project.numItems; i += 1) { 
if (app.project.item(i) instanceof FolderItem) { 
if (app.project.item(i).name == "Ray Palette Comps") { 
hasRayFolder = true;
return app.project.item(i);
}
}}
if (!hasRayFolder) { 
return app.project.items.addFolder("Ray Palette Comps");
}
}
var rayFolder = createRayfolder();
var thisComp = app.project.items.addComp(compNameInc("Ray - Overlord"), 1000, 500, 1, 1, 24);
thisComp.parentFolder = rayFolder;
var pfile = File(aiObj.rayPresetPath);
if (!pfile.exists) { 
alert("Preset is missing \u2013 try resetting the script files in the script settings");
return;
}
var activeLayer = thisComp.layers.addShape();
activeLayer.name = "Ray - Overlord";
activeLayer.applyPreset(pfile);
activeLayer("ADBE Transform Group")("ADBE Position").setValue([0, 0]);
thisComp.openInViewer();
ae_raySwatches(aiObj);
}
function ae_getComp() {
function getAeCompData() {
try {
if (thisComp instanceof CompItem) { 
var aeObj = {comment: thisComp.comment, displayStartTime: thisComp.displayStartTime, dropFrame: thisComp.dropFrame, duration: thisComp.duration, frameDuration: thisComp.frameDuration, id: thisComp.id, label: thisComp.label, layers: [], name: thisComp.name, size: [thisComp.width, thisComp.height], time: thisComp.time, workAreaDuration: thisComp.workAreaDuration, workAreaStart: thisComp.workAreaStart};
return aeObj;
}
} catch (e) {return null;
}
}
if (!setComp()) { 
return "[]";
}
var obj = getAeCompData();
return JSON.stringify(obj);
}
function ae_newComp(aiObj) {
try {
app.beginUndoGroup("New comp from Ai artboard");
var compData = (aiObj.comp) ? aiObj.comp : aiObj;
var prefs = (aiObj.prefs) ? aiObj.prefs : {};
var name = compNameInc((compData.name) ? compData.name : "New Comp");
var x = Math.round(compData.size[0] || 1920);
var y = Math.round(compData.size[1] || 1080);
if (x <= 0) { x = 1920;
}
if (y <= 0) { y = 1080;
}
var pixelAspect = 1;
var duration = (typeof prefs.compDuration === "number" && prefs.compDuration > 0) ? prefs.compDuration : 5;
var frameRate = (typeof prefs.compFramerate === "number" && prefs.compFramerate > 0) ? prefs.compFramerate : 30;
var comp = app.project.items.addComp(name, x, y, pixelAspect, duration, frameRate);
comp.bgColor = [1, 1, 1];
comp.openInViewer();
app.endUndoGroup();
return "OK";
} catch (err) {
return "ERR";
}
}
function ae_getSwatches() {
if (!setComp()) { 
return;
}
var swatchList = [];
if (thisComp.name.search(/(Ray - )/) != -1) { 
swatchList = ae_getRaySwatches();
}
else {
swatchList = ae_getLayerSwatches(thisComp.selectedLayers);
}

}
function ae_getRaySwatches() {
var swatchList = [];
for (var i = 1; i <= thisComp.layer(1)(4).numProperties; i += 1) { 
var color = thisComp.layer(1)(4)(i)(1).value;
var name = "R=" + (color[0] * 255) + " G=" + (color[1] * 255) + " B=" + (color[2] * 255);
var obj = {color: {color: color, type: "fill"}, name: name};
swatchList.push(obj);}
return swatchList;
}
function ae_replaceColor(aiObj) {
app.beginUndoGroup("Add shape to layers");
var shapes = removeTopGroup(aiObj.shapes);
var matchVal = [];
if ((shapes[0].filled == null) && (shapes[0].stroked == null)) { 
shapes = shapes[0].children;
}
if (shapes[0].filled) { 
matchVal.push({match: "ADBE Vector Fill Color", propVal: shapes[0].fillColor.color});
}
if (shapes[0].stroked) { 
matchVal.push({match: "ADBE Vector Stroke Color", propVal: shapes[0].strokeColor.color});
matchVal.push({match: "ADBE Vector Stroke Width", propVal: shapes[0].strokeWidth});
}
if (matchVal.length > 0) { 
updatedNestedProps(matchVal);
}
app.endUndoGroup();
}
function ae_deselectProps() {
try {
var propLength = thisComp.selectedProperties.length;
for (var i = 0; i < propLength; i += 1) { 
thisComp.selectedProperties[0].selected = false;}
} catch (e) {
}
}
function createStaticShape(pathObj, layerOffset) {
function transformList(list, offset) {
var transformedList = [];
for (var i = 0; i < list.length; i += 1) { 
transformedList[i] = [list[i][0] - offset[0], list[i][1] - offset[1]];}
return transformedList;
}
var pathValue = pathObj.path.valueAtTime(currentTime, true);
pathValue.vertices = transformList(pathObj.anchor, layerOffset);
pathValue.inTangents = pathObj.leftDirection;
pathValue.outTangents = pathObj.rightDirection;
pathValue.closed = pathObj.closed;
if (pathObj.path.numKeys > 0) { 
pathObj.path.setValueAtTime(currentTime, pathValue);
}
else {
pathObj.path.setValue(pathValue);
}
}
function layerBlendingMode(blendModeNum) {
if (blendModeNum == 3) { 
return BlendingMode.DARKEN;
}
if (blendModeNum == 4) { 
return BlendingMode.MULTIPLY;
}
if (blendModeNum == 5) { 
return BlendingMode.COLOR_BURN;
}
if (blendModeNum == 9) { 
return BlendingMode.LIGHTEN;
}
if (blendModeNum == 10) { 
return BlendingMode.SCREEN;
}
if (blendModeNum == 11) { 
return BlendingMode.COLOR_DODGE;
}
if (blendModeNum == 15) { 
return BlendingMode.OVERLAY;
}
if (blendModeNum == 16) { 
return BlendingMode.SOFT_LIGHT;
}
if (blendModeNum == 17) { 
return BlendingMode.HARD_LIGHT;
}
if (blendModeNum == 23) { 
return BlendingMode.DIFFERENCE;
}
if (blendModeNum == 24) { 
return BlendingMode.EXCLUSION;
}
if (blendModeNum == 26) { 
return BlendingMode.HUE;
}
if (blendModeNum == 27) { 
return BlendingMode.SATURATION;
}
if (blendModeNum == 28) { 
return BlendingMode.COLOR;
}
if (blendModeNum == 29) { 
return BlendingMode.LUMINOSITY;
}
return BlendingMode.NORMAL;
}
function ae_getLayerSwatches(layers) {
var swatchList = [];
var matchVal = [{match: "ADBE Vector Fill Color", propVal: "shapes[0].fillColor.color"}];
for (var i = 0; i < layers.length; i += 1) { 
swatchList.push(getNestedProperties(layers[i](2), matchVal));}
return swatchList;
}
function updatedNestedProps(matchVal) {
thisComp = app.project.activeItem;
selectProp = [null];
if ((!thisComp) || (!(thisComp instanceof CompItem))) { 
alert("Gotta select a comp first");
return;
}
else {
if (thisComp.selectedProperties.length > 0) { 
for (var i = 0, il = thisComp.selectedProperties.length; i < il; i++) { 
var activeProp = thisComp.selectedProperties[i];
selectProp.push(activeProp);}
}
else if (thisComp.selectedLayers.length > 0) {
for (var i = 0, il = thisComp.selectedLayers.length; i < il; i++) { 
selectProp.push(thisComp.selectedLayers[i]);}
}
else {
for (var i = 0, il = thisComp.numLayers; i < il; i++) { 
selectProp.push(thisComp.layer(i + 1));}
}
app.activeViewer.setActive();
for (var i = 1, il = selectProp.length; i < il; i++) { 
propertyLoop(selectProp[i], matchVal);}
}
}
function getNestedProperties(property, matchVal) {
propCollect = [];
for (var k = 0; k < matchVal.length; k += 1) { 
var m = matchVal[k];
if (property.matchName == m.match) { 
propCollect.push("nerds");
}}
if (property.propertyType != PropertyType.PROPERTY) { 
for (var i = 1, il = property.numProperties; i <= il; i++) { 
getNestedProperties(property.property(i), matchVal);}
}
}
function propertyLoop(property, matchVal) {
for (var k = 0; k < matchVal.length; k += 1) { 
var m = matchVal[k];
if (property.matchName == m.match) { 
if (property.numKeys < 1) { 
property.setValue(m.propVal);
}
else {
property.setValueAtTime(thisComp.time, m.propVal);
}
}}
if (property.propertyType != PropertyType.PROPERTY) { 
for (var i = 1, il = property.numProperties; i <= il; i++) { 
propertyLoop(property.property(i), matchVal);}
}
}
function deselectLayers() {
for (var i = 1; i <= thisComp.layers.length; i += 1) { 
thisComp.layers[i].selected = false;}
}
function showAlertMessage() {
if ((alertMessage) && (!overlordPrefs.hideAlerts)) { 
alert(alertMessage);
}
}
var scriptName = "Overlord";
var defaultLayerName = "Overlord";
var aiGuide = false;
var alertMessage = null;
var alertMessages = {missingCompoundPaths: "Missing some shapes?\nSimple shapes work better when compound paths have been released in Illustrator"};
function ae_exportGuides() {
    if (!setComp()) return "[]";
    var guides = [];
    try {
        for (var i = 1; i <= thisComp.numLayers; i++) {
            var layer = thisComp.layer(i);
            if (layer.guideLayers) {
                for (var g = 1; g <= layer.property("ADBE Root Vectors Group").numProperties; g++) {
                    try {
                        var grp = layer.property("ADBE Root Vectors Group").property(g);
                        var pathProp = grp.property("ADBE Vectors Group").property("ADBE Vector Shape - Path");
                        if (pathProp) {
                            var pathData = pathProp.value;
                            guides.push({
                                name: grp.name || "Guide",
                                pathPoints: {
                                    anchor: pathData.vertices,
                                    closed: pathData.closed,
                                    leftDirection: pathData.inTangents,
                                    rightDirection: pathData.outTangents,
                                    transformPos: [0, 0]
                                },
                                type: "path"
                            });
                        }
                    } catch(e) {}
                }
            }
        }
        // Also check comp guides if available (AE 2023+)
        try {
            if (thisComp.queries) {
                var compGuides = thisComp.queries.getGuides();
                for (var gi = 0; gi < compGuides.length; gi++) {
                    var cg = compGuides[gi];
                    var isVert = cg.direction === 0; // 0=vertical, 1=horizontal
                    var pos = cg.position;
                    guides.push({
                        name: "Comp Guide",
                        pathPoints: {
                            anchor: isVert ? [[pos, -5000], [pos, 5000]] : [[-5000, pos], [5000, pos]],
                            closed: false,
                            leftDirection: [[0, 0], [0, 0]],
                            rightDirection: [[0, 0], [0, 0]],
                            transformPos: [0, 0]
                        },
                        type: "path"
                    });
                }
            }
        } catch(eGuide) {}
    } catch(e) {}
    return JSON.stringify(guides);
}
return {ae_getComp: function () {
return ae_getComp();
}, ae_getSelection: function () {
return ae_getSelection();
}, ae_getSwatches: function () {
ae_getSwatches();
}, ae_guides: function (aiObj) {
return ae_guides(aiObj);
}, ae_newComp: function (aiObj) {
ae_newComp(aiObj);
}, ae_newShapes: function (aiObj) {
return ae_newShapesFilter(aiObj);
}, ae_exportGuides: function () {
return ae_exportGuides();
}, ae_replaceColor: function (aiObj) {
ae_replaceColor(aiObj);
}, ae_swatches: function (aiObj) {
return ae_swatches(aiObj);
}, ai_breakSymbols: function () {
return ai_breakSymbols();
}, ai_getArtboard: function (ol_opts) {
return ai_getArtboard(ol_opts);
}, ai_getGuides: function (ol_opts) {
return ai_getGuides(ol_opts);
}, ai_getSelection: function (ol_opts) {
return ai_getSelection(ol_opts);
}, ai_getSwatches: function (ol_opts) {
return ai_getSwatches(ol_opts);
}, ai_newArtboard: function (aeObj) {
return ai_newArtboard(aeObj);
}, ai_newShapes: function (aeObj) {
return ai_newShapes(aeObj);
}, name: scriptName};
})();