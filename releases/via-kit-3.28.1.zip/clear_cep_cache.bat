@echo off
title Welo Tools — Clear CEP Cache
color 0A

echo.
echo  ============================================
echo   Welo Tools — CEP Cache Cleaner
echo  ============================================
echo.
echo  This will close After Effects and clear
echo  all CEP cache so your changes take effect.
echo.
pause

echo.
echo  [1/4] Closing After Effects...
taskkill /F /IM "AfterFX.exe" 2>nul
taskkill /F /IM "Adobe After Effects.exe" 2>nul
timeout /t 2 /nobreak >nul
echo       Done.

echo.
echo  [2/4] Clearing CEP extension cache...

:: Delete CEP cache database files
for /d %%A in ("%APPDATA%\Adobe\CEP\extensions\*") do (
    if exist "%%A\cache" (
        rmdir /S /Q "%%A\cache" 2>nul
    )
)

:: Delete the main CEP cache folder
if exist "%APPDATA%\Adobe\CEP\cache" (
    rmdir /S /Q "%APPDATA%\Adobe\CEP\cache" 2>nul
    echo       Cleared: %APPDATA%\Adobe\CEP\cache
)

:: Delete CEP service manager cache
if exist "%LOCALAPPDATA%\Temp\cep_workdir" (
    rmdir /S /Q "%LOCALAPPDATA%\Temp\cep_workdir" 2>nul
    echo       Cleared: cep_workdir
)

:: Delete temp CEP files
del /Q /F "%LOCALAPPDATA%\Temp\cep_*" 2>nul

echo       Done.

echo.
echo  [3/4] Clearing After Effects plugin database...
for /d %%V in ("%APPDATA%\Adobe\After Effects\*") do (
    if exist "%%V\AdobeAfterEffectsPluginsDatabase.db" (
        del /Q /F "%%V\AdobeAfterEffectsPluginsDatabase.db" 2>nul
        echo       Cleared plugin DB in: %%V
    )
)
echo       Done.

echo.
echo  [4/4] Clearing CEP temp files...
rem 3.27.0 (A-14): no "del welo_*" any more - an AI Keyer / audio job keeps running in its own CMD window after AE
rem closes and needs its .bat. Old kit temp files: Settings - Maintenance - Disk usage.
del /Q /F "%TEMP%\cep_*" 2>nul
echo       Done.

echo.
echo  ============================================
echo   All cache cleared!
echo.
echo   Now:
echo   1. Open After Effects
echo   2. Window ^> Extensions ^> Welo Tools
echo   3. The extension will reload fresh
echo  ============================================
echo.
pause
