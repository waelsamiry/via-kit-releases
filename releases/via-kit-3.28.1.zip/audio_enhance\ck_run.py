"""Via Studios Kit — runs CorridorKey's CLI with a Windows-safe torch.compile mode (3.25.10).

CorridorKey compiles its model with torch.compile(mode="max-autotune") (~30 % faster). On Windows that mode's
CUDA-graph step fails ("Python int too large to convert to C long" — C long is 32-bit there) and CorridorKey falls
back to the slow eager mode. "max-autotune-no-cudagraphs" keeps the autotuned kernels without CUDA graphs.
CorridorKey's files are NOT modified; if compiling still fails it falls back to eager exactly as before.

Usage: python ck_run.py <CorridorKey folder> <corridorkey_cli.py args...>
Env:   VIA_CK_COMPILE = compile mode to force (default max-autotune-no-cudagraphs; "off" = skip compile)
"""
import os
import runpy
import sys

ck = os.path.abspath(sys.argv[1])
mode = os.environ.get('VIA_CK_COMPILE', 'max-autotune-no-cudagraphs')
if mode == 'off':
    os.environ['CORRIDORKEY_SKIP_COMPILE'] = '1'
else:
    import torch
    _orig = torch.compile

    def _compile(model=None, *args, **kw):
        kw['mode'] = mode
        print('[Via] torch.compile mode = %s' % mode, flush=True)
        return _orig(model, *args, **kw)

    torch.compile = _compile

os.chdir(ck)
sys.path.insert(0, ck)
cli = os.path.join(ck, 'corridorkey_cli.py')
sys.argv = [cli] + sys.argv[2:]
runpy.run_path(cli, run_name='__main__')
