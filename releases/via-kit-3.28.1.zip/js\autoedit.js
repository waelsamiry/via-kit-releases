// autoEdit — multi-take auto edit (Whisper + Gemini). Plan: docs/AUTO-EDIT-PLAN.md
// M1: tab, load selected clips from Project panel, roles, order, brief (saved in weloCfg 'autoedit_brief').
// M2: analyze — ffmpeg wav + silencedetect + Whisper words → sentences C{n}_S{m}; cached in %APPDATA%\Via Studios Kit\cache\autoedit.
// M3: Gemini (responseSchema) picks best take per line from fixed segment ids; validated; review list with alt takes.
// M4: ae_buildAutoEdit() places chosen segments back-to-back (startTime = at - in), scale-to-fill, B-roll on top muted, reasons as comments/markers.
// Init is registered on WeloInit (single init entry point — LESSONS L-002).
window.autoEdit = (function () {
  var clips = [];           // [{id,name,path,duration,fps,w,h,hasAudio,role}]
  var BRIEF_KEYS = ['aeTarget', 'aeAspect', 'aeStyle', 'aeLang', 'aeModel', 'aeProvider', 'aeAiModel', 'aeThink', 'aePacing', 'aeCuts', 'aeListen', 'aeScript', 'aeNotes'];

  function $(id) { return document.getElementById(id); }
  function cs() { return new CSInterface(); }
  function fmtDur(s) {
    s = Math.max(0, Math.round(s || 0));
    var m = Math.floor(s / 60), r = s % 60;
    return m + ':' + (r < 10 ? '0' : '') + r;
  }
  function status(msg, kind) {
    var el = $('aeStatus'); if (!el) return;
    el.textContent = msg || '';
    el.className = 'ae-status' + (kind ? ' is-' + kind : '');
  }

  // ── brief (persisted) ──
  function saveBrief() {
    var b = {};
    BRIEF_KEYS.forEach(function (k) { var el = $(k); if (el) b[k] = el.value; });
    b.ideaTypes = ideaTypes(); b.ideaTypesV = 2;
    try { window.weloCfg.set('autoedit_brief', JSON.stringify(b)); } catch (e) {}
  }
  function loadBrief() {
    var raw = null; try { raw = window.weloCfg.get('autoedit_brief'); } catch (e) {}
    if (!raw) return;
    var b = {}; try { b = typeof raw === 'string' ? JSON.parse(raw) : raw; } catch (e) { return; }
    BRIEF_KEYS.forEach(function (k) { var el = $(k); if (el && b[k] !== undefined) { el.value = b[k]; if (k === 'aeAiModel') el.setAttribute('data-saved', b[k]); } });
    if (b.ideaTypes && b.ideaTypesV === 2) document.querySelectorAll('.ae-it').forEach(function (el) { el.checked = b.ideaTypes.indexOf(el.value) >= 0; });
  }
  function getBrief() {
    return {
      target: parseFloat(($('aeTarget') || {}).value) || 0,
      aspect: ($('aeAspect') || {}).value || 'source',
      style: ($('aeStyle') || {}).value || 'talking',
      lang: ($('aeLang') || {}).value || 'auto',
      script: ($('aeScript') || {}).value || '',
      notes: ($('aeNotes') || {}).value || ''
    };
  }

  // ── clip list ──
  function loadSelected() {
    status('Reading Project selection…', 'working');
    cs().evalScript('ae_getSelectedClips()', function (r) {
      r = String(r || '');
      if (r.indexOf('ERR:') === 0 || r === 'EvalScript error.') { status(r.replace(/^ERR:/, ''), 'error'); return; }
      var list; try { list = JSON.parse(r); } catch (e) { status('Could not read clips: ' + e.message, 'error'); return; }
      var added = 0;
      list.forEach(function (c) {
        for (var i = 0; i < clips.length; i++) if (clips[i].id === c.id) return;   // skip duplicates
        c.role = 'take';
        clips.push(c); added++;
      });
      render();
      status(added + ' clip(s) added · ' + clips.length + ' total', 'ok');
    });
  }
  function changed() { if (edl) { edl = null; broll = []; ideas = []; renderEdl(); } if (analysis) { analysis = null; renderResults(); status('Clip list changed — analyze again', 'warn'); } }
  function move(i, d) {
    changed();
    var j = i + d; if (j < 0 || j >= clips.length) return;
    var t = clips[i]; clips[i] = clips[j]; clips[j] = t; render();
  }
  function removeAt(i) { changed(); clips.splice(i, 1); render(); }
  function clear() { clips = []; analysis = null; edl = null; broll = []; render(); renderResults(); renderEdl(); status('List cleared'); }

  function render() {
    var box = $('aeClipList'); if (!box) return;
    box.innerHTML = '';
    if (!clips.length) {
      var e = document.createElement('div');
      e.className = 'ae-empty';
      e.textContent = 'Select video clips in the Project panel, then press Load selected.';
      box.appendChild(e);
    }
    var takes = 0, total = 0;
    clips.forEach(function (c, i) {
      if (c.role === 'take') { takes++; total += c.duration || 0; }
      var row = document.createElement('div');
      row.className = 'ae-clip' + (c.role === 'ignore' ? ' is-off' : '');

      var num = document.createElement('span'); num.className = 'ae-clip-num'; num.textContent = 'C' + (i + 1);
      var info = document.createElement('div'); info.className = 'ae-clip-info';
      var nm = document.createElement('div'); nm.className = 'ae-clip-name'; nm.textContent = c.name; nm.title = c.path;
      var meta = document.createElement('div'); meta.className = 'ae-clip-meta';
      meta.textContent = fmtDur(c.duration) + ' · ' + c.w + '×' + c.h + ' · ' + (Math.round(c.fps * 100) / 100) + 'fps' + (c.hasAudio ? '' : ' · no audio');
      info.appendChild(nm); info.appendChild(meta);

      var role = document.createElement('select'); role.className = 'ae-role';
      [['take', 'Take'], ['broll', 'B-roll'], ['ignore', 'Ignore']].forEach(function (o) {
        var op = document.createElement('option'); op.value = o[0]; op.textContent = o[1];
        if (c.role === o[0]) op.selected = true; role.appendChild(op);
      });
      role.onchange = function () { changed(); c.role = role.value; render(); };

      var up = btn('↑', 'Move up', function () { move(i, -1); }); if (i === 0) up.disabled = true;
      var dn = btn('↓', 'Move down', function () { move(i, 1); }); if (i === clips.length - 1) dn.disabled = true;
      var rm = btn('×', 'Remove', function () { removeAt(i); });

      row.appendChild(num); row.appendChild(info); row.appendChild(role);
      row.appendChild(up); row.appendChild(dn); row.appendChild(rm);
      box.appendChild(row);
    });
    var sum = $('aeSummary');
    if (sum) sum.textContent = clips.length ? (takes + ' take(s) · ' + fmtDur(total) + ' raw') : '';
    var go = $('aeAnalyzeBtn');
    if (go && !busy) go.disabled = takes === 0;
  }
  function btn(txt, title, fn) {
    var b = document.createElement('button');
    b.className = 'ae-icon-btn'; b.type = 'button'; b.textContent = txt; b.title = title; b.onclick = fn;
    return b;
  }

  // ════════ M2: ANALYZE (local: ffmpeg + Whisper + silencedetect, cached) ════════
  var analysis = null;      // {clips:[{...clip, words:[{w,s,e}], silences:[[a,b]], segs:[{id,clip,s,e,text}]}]}
  var running = null;       // current child process
  var cancelled = false;
  var busy = false;

  function node() { return { fs: require('fs'), path: require('path'), cp: require('child_process'), crypto: require('crypto') }; }
  function cacheRoot() {
    var n = node();
    var d = n.path.join(process.env.APPDATA || require('os').homedir(), 'Via Studios Kit', 'cache', 'autoedit');
    try { n.fs.mkdirSync(d, { recursive: true }); } catch (e) {}
    return d;
  }
  function clipKey(c, model, lang) {
    var n = node(), st = null;
    try { st = n.fs.statSync(c.path); } catch (e) {}
    var raw = c.path + '|' + (st ? st.size + '|' + st.mtimeMs : '') + '|' + model + '|' + lang;
    return n.crypto.createHash('md5').update(raw).digest('hex').slice(0, 16);
  }
  function run(exe, args, opts, onLine, onErr) {
    return new Promise(function (resolve, reject) {
      if (cancelled) { reject(new Error('Cancelled')); return; }
      var p;
      try { p = node().cp.spawn(exe, args, Object.assign({ windowsHide: true }, opts || {})); }
      catch (e) { reject(e); return; }
      running = p;
      var out = '', err = '';
      p.stdout && p.stdout.on('data', function (d) { d = d.toString(); out += d; if (onLine) d.split(/\r?\n/).forEach(function (l) { if (l.trim()) onLine(l); }); });
      p.stderr && p.stderr.on('data', function (d) { d = d.toString(); err += d; if (err.length > 200000) err = err.slice(-100000); if (onErr) onErr(d); });
      p.on('error', function (e) { running = null; reject(e); });
      p.on('close', function (code) {
        running = null;
        if (cancelled) { reject(new Error('Cancelled')); return; }
        if (code === 0) resolve({ out: out, err: err });
        else { var tail = (err || out).split(/\r?\n/).filter(function (x) { return x.trim(); }).slice(-3).join(' | '); reject(new Error('exit ' + code + (tail ? ' · ' + tail : ''))); }
      });
    });
  }
  function evalP(code) {
    return new Promise(function (res) { cs().evalScript(code, function (r) { res(String(r || '')); }); });
  }
  function needTool(name) {
    return new Promise(function (res, rej) { window.weloTools.need(name, function (p) { p ? res(p) : rej(new Error(name + ' not found — Settings › External tools')); }); });
  }

  function parseSilences(txt) {
    var out = [], st = null, m;
    var re = /silence_(start|end):\s*(-?[\d.]+)/g;
    while ((m = re.exec(txt))) {
      var v = parseFloat(m[2]);
      if (m[1] === 'start') st = Math.max(0, v);
      else if (st !== null) { out.push([st, v]); st = null; }
    }
    if (st !== null) out.push([st, 1e9]);
    return out;
  }
  function flattenWords(json) {
    var words = [];
    (json.segments || []).forEach(function (sg) {
      if (sg.words && sg.words.length) {
        sg.words.forEach(function (w) { var t = String(w.word || w.text || '').trim(); if (t) words.push({ w: t, s: +w.start, e: +w.end }); });
      } else if (sg.text) {
        words.push({ w: String(sg.text).trim(), s: +sg.start, e: +sg.end });   // model without word timestamps
      }
    });
    return words;
  }
  // words -> sentences: split on pause > 0.6 s or end punctuation; a chunk longer than MAX_SEG is split
  // at its LONGEST internal pause (not at a fixed time), so lines don't end mid-word (Arabic Whisper has little punctuation)
  var MAX_SEG = 10;          // finer pieces = the AI can drop a false start inside a long run (3.9.1)
  var GAP_SPLIT = 0.45;
  // Pacing (3.10.1): Tight = 3.9.x behaviour Wael preferred; Natural = a bit more air
  var PACING = { tight: { pin: 0.08, pout: 0.12, snap: 0.3, bridge: 0.5, sin: 0.05, sout: 0.08 }, natural: { pin: 0.12, pout: 0.2, snap: 0.35, bridge: 0.9, sin: 0.1, sout: 0.18 } };
  function pace() { return PACING[($('aePacing') || {}).value] || PACING.tight; }
  function splitLong(ws) {
    if (ws.length < 2 || ws[ws.length - 1].e - ws[0].s <= MAX_SEG) return [ws];
    var best = -1, bestGap = -1;
    for (var k = 1; k < ws.length; k++) {
      var t = ws[k].s - ws[0].s;
      if (t < 3 || ws[ws.length - 1].e - ws[k].s < 3) continue;     // keep both halves ≥ 3 s
      var gap = ws[k].s - ws[k - 1].e;
      if (/[،,؛;:]$/.test(ws[k - 1].w)) gap += 0.15;                 // commas are good cut points
      if (gap > bestGap) { bestGap = gap; best = k; }
    }
    if (best < 0) best = Math.floor(ws.length / 2);
    return splitLong(ws.slice(0, best)).concat(splitLong(ws.slice(best)));
  }
  // word ranges [i0,i1] per sentence; times come from segTimes() so pacing / edits can be re-applied any time
  function buildSegs(ci, words, silences, dur, env) {
    words.forEach(function (w, i) { w.i = i; });
    var chunks = [], cw = [];
    words.forEach(function (w, i) {
      var prev = words[i - 1];
      if (cw.length && (w.s - prev.e > GAP_SPLIT || /[.!?؟…]$/.test(prev.w))) { chunks.push(cw); cw = []; }
      cw.push(w);
    });
    if (cw.length) chunks.push(cw);
    var segs = [];
    chunks.forEach(function (ch) {
      splitLong(ch).forEach(function (part) {
        segs.push({ clip: ci, wi0: part[0].i, wi1: part[part.length - 1].i, text: part.map(function (w) { return w.w; }).join(' ') });
      });
    });
    retime({ clip: ci, words: words, silences: silences, duration: dur, segs: segs, env: env });
    return segs;
  }
  // ── 3.17: audio envelope (10 ms frames, byte = dB+100) → cut on real speech edges + cut doubled words ──
  function wavEnvelope(file) {
    var buf = require('fs').readFileSync(file), p = 12, off = -1, len = 0;
    while (p + 8 <= buf.length) {
      var id = buf.toString('ascii', p, p + 4), sz = buf.readUInt32LE(p + 4);
      if (id === 'data') { off = p + 8; len = Math.min(sz, buf.length - off); break; }
      p += 8 + sz + (sz & 1);
    }
    if (off < 0) return '';
    var F = 160, frames = Math.floor(len / 2 / F), out = require('buffer').Buffer.alloc(frames);      // 16 kHz s16 → 160 samples = 10 ms
    for (var f = 0; f < frames; f++) {
      var acc = 0, o = off + f * F * 2;
      for (var k = 0; k < F; k++) { var v = buf.readInt16LE(o + 2 * k) / 32768; acc += v * v; }
      out[f] = Math.max(0, Math.min(120, Math.round(10 * Math.log10(acc / F + 1e-10) + 100)));
    }
    return out.toString('base64');
  }
  function cutMode() { return ($('aeCuts') || {}).value || 'smart_rep'; }
  function quietTh(c) {        // noise floor + max(6 dB, 25 % of the clip's dynamic range)
    if (c.qth === undefined) {
      var a = Array.prototype.slice.call(c.env).sort(function (x, y) { return x - y; });
      var fl = a[Math.floor(a.length * 0.1)], pk = a[Math.floor(a.length * 0.95)];
      c.qth = fl + Math.max(6, (pk - fl) * 0.25);
    }
    return c.qth;
  }
  function isQ(c, i) { return i < 0 || i >= c.env.length || c.env[i] < quietTh(c); }
  function minAt(c, t0, t1) { var b = -1, bv = 1e9; for (var i = Math.max(0, Math.round(t0 * 100)); i <= Math.min(c.env.length - 1, Math.round(t1 * 100)); i++) if (c.env[i] < bv) { bv = c.env[i]; b = i; } return b < 0 ? t0 : b / 100; }
  // speech onset before t: walk back to the first quiet run (≥ 30 ms); none within 0.35 s = connected speech → quietest dip
  function onsetBefore(c, t) {
    var i0 = Math.round(t * 100), run = 0, top = -1;
    for (var i = i0; i >= i0 - 35; i--) {
      if (isQ(c, i)) { if (!run) top = i; run++; if (run >= 3) return { t: (top + 1) / 100, q: (i0 - top) }; }
      else run = 0;
    }
    return { t: minAt(c, t - 0.15, t + 0.02), q: 0 };
  }
  // speech end after t: first quiet run (≥ 50 ms) within 0.45 s; tail never reaches the next sound
  function endAfter(c, t, tail) {
    var i0 = Math.round((t - 0.05) * 100), run = 0, st = -1;
    for (var i = i0; i <= i0 + 50; i++) {
      if (isQ(c, i)) { if (!run) st = i; run++;
        if (run >= 5) {
          var j = st; while (j < st + 60 && isQ(c, j)) j++;                // next loud frame
          return Math.min(st / 100 + tail, Math.max(st / 100 + 0.01, j / 100 - 0.02));
        }
      } else run = 0;
    }
    return minAt(c, t - 0.02, t + 0.25);
  }
  var EMPH = /^(جدا|اوي|قوي|شويه|واحده|بالراحه|خطوه|حبه|بشويش|لا|اه|ايوه|اكيد|بسرعه|very|no|yes|so|really)$/;
  function nw(w) {
    return String(w || '').toLowerCase().replace(/[ً-ْـ]/g, '').replace(/[إأآا]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه')
      .replace(/[^؀-ۿa-z0-9]/g, '');
  }
  // doubled word ("حتى حتى") or doubled pair → hole from the first copy's onset to the second copy's onset
  function findHoles(c, g) {
    var W = c.words, out = [];
    var at = function (t) { return c.env ? onsetBefore(c, t).t : t - 0.02; };
    for (var i = g.wi0; i < g.wi1; i++) {
      var a = nw(W[i].w), b = nw(W[i + 1].w), to = -1;
      if (a && a === b && !EMPH.test(a)) to = i;
      else if (i + 3 <= g.wi1 && a && a === nw(W[i + 2].w) && nw(W[i + 1].w) && nw(W[i + 1].w) === nw(W[i + 3].w) && a !== nw(W[i + 1].w)) to = i + 1;
      if (to < 0) continue;
      var h0 = Math.max(g.s, at(W[i].s)), h1 = Math.min(g.e, at(W[to + 1].s));
      if (h1 - h0 >= 0.08) out.push({ s: +h0.toFixed(3), e: +h1.toFixed(3), w: W.slice(i, to + 1).map(function (x) { return x.w; }).join(' ') });
      i = to;
    }
    return out;
  }
  function pieces(g) {        // [[in,out],…] of one segment after removing doubled words
    if (!g.holes || !g.holes.length || g.keepRep || cutMode() !== 'smart_rep') return [[g.s, g.e]];
    var out = [], cur = g.s;
    g.holes.forEach(function (h) { if (h.s > cur + 0.05) out.push([cur, h.s]); cur = Math.max(cur, h.e); });
    if (g.e > cur + 0.05) out.push([cur, g.e]);
    return out.length ? out : [[g.s, g.e]];
  }
  function segLen(g) { var t = 0; pieces(g).forEach(function (p) { t += p[1] - p[0]; }); return t; }
  function retime(c) {        // ids + s/e for every segment of one clip, using current pacing
    var P = pace(), W = c.words, sil = c.silences || [];
    c.segs.forEach(function (g, k) {
      g.id = 'C' + (c.clip + 1) + '_S' + (k + 1);
      g.ws = W[g.wi0].s; g.we = W[g.wi1].e;
      if (c.env && c.env.length && cutMode() !== 'whisper') {       // 3.17: cut on the real speech edges (Whisper times drift ±0.2 s → eaten words)
        var on = onsetBefore(c, g.ws);
        var s2 = Math.max(0, on.t - (on.q ? P.sin : 0)), e2 = endAfter(c, g.we, P.sout);
        if (c.duration) e2 = Math.min(e2, c.duration);
        g.s = +s2.toFixed(3); g.e = +Math.max(e2, s2 + 0.1).toFixed(3);
        return;
      }
      var s = Math.max(0, g.ws - P.pin), e = g.we + P.pout;
      for (var q = 0; q < sil.length; q++) {
        var a = sil[q][0], b = sil[q][1];
        if (a >= g.we - 0.05 && a <= g.we + P.snap) { e = Math.min(b, g.we + P.snap); break; }   // cut inside the pause, not on the next breath
      }
      if (c.duration) e = Math.min(e, c.duration);
      g.s = +s.toFixed(3); g.e = +e.toFixed(3);
    });
    for (var k = 0; k + 1 < c.segs.length; k++) {      // padding must not overlap the neighbour (would repeat audio)
      var A = c.segs[k], B = c.segs[k + 1];
      if (A.e > B.s) { var mid = +((Math.min(A.e, B.s) + Math.max(A.e, B.s)) / 2).toFixed(3); A.e = mid; B.s = mid; }
    }
    c.segs.forEach(function (g) { g.holes = cutMode() === 'smart_rep' ? findHoles(c, g) : []; });
  }
  function retimeAll() { if (analysis) analysis.clips.forEach(function (c) { if (c.role === 'take') retime(c); }); }

  function analyzeClip(c, ci, info, opts, setMsg) {
    var n = node();
    var key = clipKey(c, opts.model, opts.lang);
    var dir = n.path.join(cacheRoot(), key);
    var done = n.path.join(dir, 'analysis.json');
    if (!opts.fresh && n.fs.existsSync(done)) {
      try {
        var cached = JSON.parse(n.fs.readFileSync(done, 'utf8')); cached.fromCache = true; setMsg('cached');
        if (cached.env || c.role !== 'take') return Promise.resolve(cached);
        var w0 = n.path.join(dir, 'audio.wav');           // 3.17: old cache has no envelope → quick ffmpeg pass, no Whisper
        setMsg('cached · reading audio levels');
        return run(window.weloTools.get('ffmpeg'), ['-hide_banner', '-loglevel', 'error', '-y', '-i', c.path, '-vn', '-ac', '1', '-ar', '16000', '-c:a', 'pcm_s16le', w0])
          .then(function () {
            cached.env = wavEnvelope(w0);
            try { n.fs.unlinkSync(w0); } catch (e1) {}
            var keep = {}; Object.keys(cached).forEach(function (k) { if (k !== 'fromCache') keep[k] = cached[k]; });
            try { n.fs.writeFileSync(done, JSON.stringify(keep), 'utf8'); } catch (e2) {}
            return cached;
          }, function () { return cached; });
      } catch (e) {}
    }
    try { n.fs.mkdirSync(dir, { recursive: true }); } catch (e) {}
    var wav = n.path.join(dir, 'audio.wav');
    var ff = window.weloTools.get('ffmpeg');
    var res = { words: [], silences: [] };
    setMsg('extracting audio');
    return run(ff, ['-hide_banner', '-loglevel', 'error', '-y', '-i', c.path, '-vn', '-ac', '1', '-ar', '16000', '-c:a', 'pcm_s16le', wav])
      .then(function () {
        setMsg('silence scan');
        return run(ff, ['-hide_banner', '-i', wav, '-af', 'silencedetect=n=-35dB:d=0.25', '-f', 'null', '-']);
      })
      .then(function (r) {
        res.silences = parseSilences(r.err);
        if (c.role !== 'take') return null;                 // B-roll: no transcription
        setMsg('Whisper ' + opts.model + ' — starting Python…');
        var env = window.weloTools.env(); env.PYTHONIOENCODING = 'utf-8'; env.PYTHONUNBUFFERED = '1';
        var stage = 'starting';
        return run(info.python, ['-u', '-W', 'ignore::UserWarning', info.script, wav, opts.model, opts.lang === 'auto' ? '' : opts.lang, info.models], { env: env, cwd: dir },
          function (line) {   // stdout from run_whisper.py
            if (/^Loading/i.test(line)) { stage = 'loading model'; setMsg('Whisper ' + opts.model + ' — loading model'); }
            else if (/^Transcribing/i.test(line)) { stage = 'transcribing'; setMsg('Whisper ' + opts.model + ' — transcribing…'); }
          },
          function (chunk) {  // stderr: tqdm progress "  42%|████"
            var m = chunk.match(/(\d{1,3})%\|[^\r\n]*$/) || chunk.match(/(\d{1,3})%\|/g);
            var pct = null;
            if (m && m.index !== undefined) pct = m[1];
            else if (m && m.length) pct = String(m[m.length - 1]).replace(/%\|/, '');
            if (pct !== null) setMsg('Whisper ' + opts.model + ' — ' + (stage === 'transcribing' || stage === 'starting' ? 'transcribing ' : 'downloading model ') + pct + '%');
          });
      })
      .then(function () {
        if (c.role === 'take') {
          var jp = n.path.join(dir, 'audio.json');
          if (!n.fs.existsSync(jp)) throw new Error('Whisper produced no JSON');
          res.words = flattenWords(JSON.parse(n.fs.readFileSync(jp, 'utf8')));
          try { res.env = wavEnvelope(wav); } catch (e0) {}
        }
        try { n.fs.unlinkSync(wav); } catch (e) {}           // keep cache small
        try { n.fs.writeFileSync(done, JSON.stringify(res), 'utf8'); } catch (e) {}
        return res;
      });
  }

  function analyze() {
    var list = clips.filter(function (c) { return c.role !== 'ignore'; });
    if (!list.some(function (c) { return c.role === 'take'; })) { status('Mark at least one clip as Take', 'error'); return; }
    if (typeof require !== 'function') { status('Node is disabled in this panel', 'error'); return; }
    var opts = { model: ($('aeModel') || {}).value || 'small', lang: ($('aeLang') || {}).value || 'auto', fresh: !!($('aeFresh') || {}).checked };
    var nCached = 0;
    cancelled = false; setBusy(true); analysis = null; renderResults();
    var info;
    var t0 = Date.now();
    var timer = setInterval(function () { var el = $('aeElapsed'); if (el) el.textContent = Math.round((Date.now() - t0) / 1000) + 's'; }, 1000);

    needTool('ffmpeg')
      .then(function () { return evalP('ae_getPythonInfo()'); })
      .then(function (r) {
        if (r.indexOf('ERR:') === 0 || r === 'EvalScript error.') throw new Error(r.replace(/^ERR:/, ''));
        info = JSON.parse(r);
        if (!info.python) throw new Error('Python not found — set it in Settings');
        if (!info.script) throw new Error('audio_enhance/run_whisper.py not found');
        var out = [], i = 0;
        function next() {
          if (i >= clips.length) return Promise.resolve(out);
          var ci = i++, c = clips[ci];
          if (c.role === 'ignore') return next();
          var label = 'C' + (ci + 1) + ' ' + c.name;
          return analyzeClip(c, ci, info, opts, function (m) { status('[' + (out.length + 1) + '/' + list.length + '] ' + label + ' — ' + m, 'working'); })
            .then(function (r) {
              if (r.fromCache) nCached++;
              var dur = c.duration || 0;
              out.push({ clip: ci, id: c.id, name: c.name, path: c.path, role: c.role, duration: dur, fps: c.fps, w: c.w, h: c.h,
                         words: r.words, silences: r.silences, env: r.env ? new Uint8Array(require('buffer').Buffer.from(r.env, 'base64')) : null,
                         segs: c.role === 'take' ? buildSegs(ci, r.words, r.silences, dur, r.env ? new Uint8Array(require('buffer').Buffer.from(r.env, 'base64')) : null) : [] });
              return next();
            });
        }
        return next();
      })
      .then(function (out) {
        analysis = { model: opts.model, lang: opts.lang, clips: out, at: Date.now() };
        var n = 0; out.forEach(function (c) { n += c.segs.length; });
        status('✓ Analyzed ' + out.length + ' clip(s) · ' + n + ' sentences · Whisper ' + opts.model + ' · ' + Math.round((Date.now() - t0) / 1000) + 's' + (nCached ? ' · ' + nCached + ' from cache (same file + model + language)' : ''), 'ok');
        var fr = $('aeFresh'); if (fr) fr.checked = false;
        renderResults();
        edl = null; broll = []; renderEdl();
      })
      .catch(function (e) { status((cancelled ? 'Cancelled' : '⚠ ' + (e && e.message || e)), cancelled ? 'warn' : 'error'); })
      .then(function () { clearInterval(timer); setBusy(false); });
  }
  function cancel() {
    cancelled = true;
    if (running) { try { node().cp.exec('taskkill /pid ' + running.pid + ' /T /F'); } catch (e) {} }
  }
  function setBusy(b) {
    busy = b;
    var a = $('aeAnalyzeBtn'), c = $('aeCancelBtn'), l = $('aeLoadBtn');
    if (a) { a.disabled = b; a.textContent = b ? 'Analyzing…' : 'Analyze takes'; }
    if (c) c.style.display = b ? '' : 'none';
    if (l) l.disabled = b;
    var e = $('aeElapsed'); if (e) e.textContent = '';
    if (!b) render();
  }
  function fmtT(t) { var m = Math.floor(t / 60), s = t - m * 60; return m + ':' + (s < 10 ? '0' : '') + s.toFixed(1); }

  // ── Edit transcript in the SAME editor as the Transcription tab (token editor: add/delete words, merge/split lines) ──
  // We lend it our lines, then read them back; the user's own Transcription work is backed up and restored.
  var txBackup = null;
  function openTxEditor() {
    if (!analysis) { status('Analyze first', 'error'); return; }
    if (typeof window.whisperRefreshEditor !== 'function') { status('Transcription editor not loaded', 'error'); return; }
    txBackup = { paras: window.whisperParagraphs, words: window.whisperWordData };
    var paras = [], flat = [];
    analysis.clips.forEach(function (c) {
      if (c.role !== 'take') return;
      c.segs.forEach(function (g) {
        if (g.ex) return;
        var ws = c.words.slice(g.wi0, g.wi1 + 1).map(function (w) { return { word: w.w, start: w.s, end: w.e, _clip: c.clip }; });
        if (!ws.length) return;
        paras.push({ text: ws.map(function (w) { return w.word; }).join(' '), start: ws[0].start, end: ws[ws.length - 1].end, words: ws, _clip: c.clip });
        flat = flat.concat(ws);
      });
    });
    window.whisperParagraphs = paras; window.whisperWordData = flat;
    window.whisperRefreshEditor();
    var bn = $('aeTxBanner'); if (bn) bn.style.display = '';
    window.openTool('whisper');
    try { $('whisperTokenEditor').scrollIntoView({ block: 'start' }); } catch (e) {}
  }
  function closeTxEditor(apply) {
    var bn = $('aeTxBanner'); if (bn) bn.style.display = 'none';
    var paras = window.whisperParagraphs || [], changedClips = {};
    if (apply && analysis) {
      var byClip = {}, lastClip = null;
      paras.forEach(function (p) {
        var ci = p._clip;
        (p.words || []).forEach(function (w) { if (ci === undefined && w._clip !== undefined) ci = w._clip; });
        if (ci === undefined) ci = lastClip; if (ci === undefined || ci === null) return;
        lastClip = ci;
        var b = window.whisperLineBounds(p); if (b.s === null || b.e === null) return;
        var c = clipByIndex(ci); if (!c) return;
        var W = c.words, i0 = -1, i1 = -1;
        for (var k = 0; k < W.length; k++) { if (i0 < 0 && W[k].s >= b.s - 0.02) i0 = k; if (W[k].e <= b.e + 0.02) i1 = k; }
        if (i0 < 0 || i1 < i0) return;
        var txt = window.wlParaText ? window.wlParaText(p) : p.text;
        (byClip[ci] = byClip[ci] || []).push({ clip: ci, wi0: i0, wi1: i1, text: txt, ed: true });
      });
      analysis.clips.forEach(function (c) {
        if (c.role !== 'take' || !byClip[c.clip]) return;
        c.segs = byClip[c.clip].sort(function (a, b) { return a.wi0 - b.wi0; });
        changedClips[c.clip] = 1;
      });
    }
    if (txBackup) { window.whisperParagraphs = txBackup.paras; window.whisperWordData = txBackup.words; txBackup = null; }
    try { window.whisperRefreshEditor(); } catch (e) {}
    window.openTool('autoedit');
    if (apply && analysis) {
      analysis.clips.forEach(function (c) { if (changedClips[c.clip]) txChanged(c); });
      renderResults();
      var n = 0; analysis.clips.forEach(function (c) { n += c.segs.length; });
      status('✓ Transcript updated — ' + n + ' lines. Pick best takes again.', 'ok');
    }
  }
  function txChanged(c) { retime(c); if (edl) { edl = null; broll = []; ideas = []; renderEdl(); status('Transcript changed — pick again', 'warn'); } }
  function renderResults() {
    var box = $('aeResults'); if (!box) return;
    box.innerHTML = '';
    var pw = $('aePickWrap'); if (pw) pw.style.display = analysis ? '' : 'none';
    var ew = $('aeEditWrap'); if (ew) ew.style.display = analysis ? '' : 'none';
    if (!analysis) return;
    analysis.clips.forEach(function (c) {
      var d = document.createElement('details'); d.className = 'ae-res';
      var sm = document.createElement('summary');
      var used = c.segs.filter(function (g) { return !g.ex; }).length;
      sm.textContent = 'C' + (c.clip + 1) + ' · ' + c.name + ' — ' + (c.role === 'take' ? used + ' lines' + (used !== c.segs.length ? ' (' + (c.segs.length - used) + ' excluded)' : '') : 'B-roll');
      d.appendChild(sm);
      c.segs.forEach(function (g) {
        var r = document.createElement('div'); r.className = 'ae-seg' + (g.ex ? ' is-off' : '');
        var t = document.createElement('span'); t.className = 'ae-seg-t'; t.textContent = g.id + '  ' + fmtT(g.s) + '–' + fmtT(g.e);
        r.appendChild(t);
        var x = document.createElement('span'); x.className = 'ae-seg-x'; x.dir = 'auto'; x.textContent = g.text; r.appendChild(x);
        d.appendChild(r);
      });
      box.appendChild(d);
    });
  }

  // ════════ M3: GEMINI PICKS + REVIEW ════════
  var edl = null;           // [{seg, alt[], reason, on}]
  var broll = [];           // [{clip, start, end, afterSeg, on}]
  var aiNotes = '';
  var ideas = [];          // B-roll suggestions [{seg, dur, type, what, on}]
  var GEM_FALLBACK = ['gemini-flash-latest', 'gemini-flash-lite-latest'];
  var gemModelsCache = null;
  // Ask Google which models this key can use, best first: newest flash > flash-lite > pro (L-014: hardcoded names expire)
  function listGemModels(key) {
    if (gemModelsCache) return Promise.resolve(gemModelsCache);
    return window.aiFetchJson('https://generativelanguage.googleapis.com/v1beta/models?pageSize=200', { headers: { 'x-goog-api-key': key } }, 1)
      .then(function (d) {
        var names = (d.models || []).filter(function (m) {
          return (m.supportedGenerationMethods || []).indexOf('generateContent') >= 0 &&
                 /^models\/gemini-/.test(m.name) && !/(image|tts|audio|live|embedding|vision|thinking-exp|robotics|computer-use)/i.test(m.name);
        }).map(function (m) { return m.name.replace(/^models\//, ''); });
        function ver(n) { var m = n.match(/gemini-(\d+(?:\.\d+)?)/); return m ? parseFloat(m[1]) : 0; }
        function rank(n) {
          var tier = /flash-lite/.test(n) ? 1 : /flash/.test(n) ? 0 : /pro/.test(n) ? 2 : 3;
          var pre = /(preview|exp)/.test(n) ? 1 : 0;
          return [pre, tier, -ver(n), n.length];
        }
        names.sort(function (a, b) { var x = rank(a), y = rank(b); for (var i = 0; i < x.length; i++) if (x[i] !== y[i]) return x[i] < y[i] ? -1 : 1; return 0; });
        gemModelsCache = names.length ? names : GEM_FALLBACK.slice();
        return gemModelsCache;
      })
      .catch(function () { return GEM_FALLBACK.slice(); });
  }

  function segMap() {
    var m = {}; if (!analysis) return m;
    analysis.clips.forEach(function (c) { c.segs.forEach(function (g) { if (!g.ex) m[g.id] = g; }); });
    return m;
  }
  function clipByIndex(ci) { if (!analysis) return null; for (var i = 0; i < analysis.clips.length; i++) if (analysis.clips[i].clip === ci) return analysis.clips[i]; return null; }

  function buildPrompt() {
    var b = getBrief();
    var lines = [];
    lines.push('You are a senior video editor for an Egyptian ad agency. Build a rough cut from the transcribed takes below.');
    lines.push('The transcript is automatic (Whisper) and CAN BE WRONG: misheard words, broken Egyptian dialect, wrong names/terms. Read for MEANING, not exact words.');
    lines.push('');
    lines.push('WORK IN TWO STEPS (3.12):');
    lines.push('STEP 1 — UNDERSTAND. Reconstruct what the speaker MEANT to say as an ordered list of distinct lines ("lines"). For each line:');
    lines.push('  "say"   = the intended sentence, corrected and clear (speaker\'s words and dialect, Whisper mistakes fixed);');
    lines.push('  "takes" = EVERY segment id where the speaker attempts this same line or idea — anywhere: other clips, the same clip, restarts, partial tries, rephrasings, even if Whisper spelled it differently. Two segments that MEAN the same thing are the same line.');
    lines.push('  Every id belongs to at most ONE line. Chatter, "cut", "again", counting, director talk, coughs = belong to no line.');
    lines.push('STEP 2 — PICK. For each line choose "pick" = the id(s) of the single best attempt, in speaking order (a long sentence may need 2-3 consecutive ids of the SAME attempt). Never pick ids from two different attempts of the same line.');
    lines.push('  Best = complete, fluent, no stumble/restart, no filler at start (اه، امم، يعني), confident. If equal, prefer the LATER attempt (talent improves). A fragment followed by the full version = take the full version.');
    lines.push('  Order the lines to follow the SCRIPT if given, otherwise the most logical story with a strong hook first. Drop weak lines entirely if they add nothing.');
    if (b.target) lines.push('  Target total length about ' + b.target + ' seconds (sum of picked segments); drop weaker lines rather than keep everything.');
    lines.push('  Use ONLY the ids given; never invent ids or timestamps. "reason" = max 8 words, speech language.');
    if (cutMode() === 'smart_rep') lines.push('  A single doubled word inside a segment (e.g. "حتى حتى") is cut out automatically later — do not reject an otherwise best attempt only for that.');
    if (listenOn()) {
      lines.push('');
      lines.push('AUDIO: you also receive the audio of every take clip (before this text). Segment times [start-end] are seconds inside that clip\'s audio.');
      lines.push('  LISTEN before you pick: prefer attempts with clear pronunciation, no swallowed or clipped words, no stutter or doubled word, steady confident voice.');
      lines.push('  Use what you HEAR to fix "say" — Whisper mishears unclear speech. If the best available attempt still sounds unclear, say so in "reason".');
    }
    lines.push('');
    lines.push('Style: ' + b.style + (b.lang !== 'auto' ? ' · Language: ' + b.lang : ' · Language: auto (Egyptian Arabic likely)'));
    if (b.notes) lines.push('Editor notes: ' + b.notes);
    if (b.script) { lines.push(''); lines.push('SCRIPT (intended lines, in order):'); lines.push(b.script); }
    lines.push('');
    var reviewed = analysis.clips.some(function (c) { return c.segs.some(function (g) { return g.ed || g.ex; }); });
    if (reviewed) lines.push('NOTE: the editor reviewed and corrected this transcript by hand — trust the text and the line breaks; "fix" can stay empty.');
    lines.push('SEGMENTS (id [start-end s] text):');
    analysis.clips.forEach(function (c) {
      if (c.role !== 'take') return;
      lines.push('# Clip C' + (c.clip + 1) + ' "' + c.name + '" (' + c.duration.toFixed(1) + 's)');
      c.segs.forEach(function (g) { if (!g.ex) lines.push(g.id + ' [' + g.s.toFixed(1) + '-' + g.e.toFixed(1) + '] ' + g.text); });
    });
    var br = analysis.clips.filter(function (c) { return c.role === 'broll'; });
    if (br.length) {
      lines.push('');
      lines.push('B-ROLL clips (no transcript; use the file name as the only hint, place only if clearly relevant):');
      br.forEach(function (c) { lines.push('C' + (c.clip + 1) + ' "' + c.name + '" ' + c.duration.toFixed(1) + 's'); });
    }
    lines.push('');
    lines.push('ALSO:');
    lines.push('- B-ROLL IDEAS ("ideas"): suggest inserts the editor should add over the talking head, where they help understanding or rhythm.');
    lines.push('  about one idea every 8-12 seconds of the final cut, never two overlapping; "seg" = the chosen id where it starts; "dur" 2-6 s;');
    var allowed = ideaTypes();
    if (!allowed.length) lines.push('  (no B-roll ideas wanted: return "ideas": [])');
    lines.push('  "type" ONLY one of: ' + allowed.join(', ') + ' (before_after = split/compare shot; before/after = single shot of that state);');
    if (allowed.indexOf('graphic') >= 0) lines.push('  graphic ONLY when the speaker gives numbers, steps, a process, a timeline or a comparison — "what" names the exact data/steps to show;');
    if (allowed.indexOf('text') >= 0) lines.push('  text ONLY for a key number or a 2-5 word punch line — "what" = the exact on-screen words;');
    lines.push('  "what" = concrete, filmable description in the speech language (e.g. صورة لعين قبل العملية بانتفاخ تحت العين); fewer strong ideas beat many generic ones; skip a spot if nothing clearly fits.');
    lines.push('OUTPUT: one JSON object {"lines":[{"say":"...","takes":["C1_S3","C1_S7","C2_S2"],"pick":["C1_S7","C1_S8"],"reason":"..."}],"ideas":[{"seg":"C1_S3","dur":3,"type":"graphic","what":"..."}],"broll":[{"clip":"C4","start":0,"end":3,"afterSeg":"C1_S3"}],"notes":"one short sentence"} — lines in final order; "seg" of an idea = one of the picked ids.');
    return lines.join('\n');
  }
  var IDEA_TYPES = ['image', 'video', 'graphic', 'before_after', 'before', 'after', 'text', 'icon'];
  function ideaTypes() {
    var out = []; document.querySelectorAll('.ae-it:checked').forEach(function (el) { out.push(el.value); });
    return out;
  }
  var IDEA_LABEL = { image: 'Photo', video: 'Video', graphic: 'Graphic', before_after: 'Before/After', before: 'Before', after: 'After', text: 'Text', icon: 'Icon' };
  var SCHEMA = {
    type: 'OBJECT',
    properties: {
      lines: { type: 'ARRAY', items: { type: 'OBJECT', properties: {
        say: { type: 'STRING' }, takes: { type: 'ARRAY', items: { type: 'STRING' } }, pick: { type: 'ARRAY', items: { type: 'STRING' } }, reason: { type: 'STRING' } }, required: ['say', 'takes', 'pick'] } },
      ideas: { type: 'ARRAY', items: { type: 'OBJECT', properties: {
        seg: { type: 'STRING' }, dur: { type: 'NUMBER' }, type: { type: 'STRING', enum: IDEA_TYPES }, what: { type: 'STRING' } }, required: ['seg', 'type', 'what'] } },
      broll: { type: 'ARRAY', items: { type: 'OBJECT', properties: {
        clip: { type: 'STRING' }, start: { type: 'NUMBER' }, end: { type: 'NUMBER' }, afterSeg: { type: 'STRING' } }, required: ['clip', 'afterSeg'] } },
      notes: { type: 'STRING' }
    },
    required: ['lines']
  };
  // ── providers: gemini | openai | groq. Same prompt + JSON contract; keys from the translation settings ──
  var PROVIDERS = { gemini: 'Gemini', openai: 'ChatGPT', groq: 'Groq' };
  var modelCache = {};
  function provKey(p) { try { return window.weloCfg.get(p + '_api_key') || ''; } catch (e) { return ''; } }
  function isRetired(e) { return e && (e.status === 404 || e.status === 410 || /model|no longer available|not found|not supported|deprecated|does not exist/i.test(e.message || '')); }
  function listModels(p, key) {
    if (modelCache[p]) return Promise.resolve(modelCache[p]);
    var pr;
    if (p === 'gemini') pr = listGemModels(key);
    else if (p === 'openai') pr = window.aiFetchJson('https://api.openai.com/v1/models', { headers: { 'Authorization': 'Bearer ' + key } }, 1).then(function (d) {
      return (d.data || []).filter(function (m) { return /^(gpt-|o\d|chatgpt)/.test(m.id) && !/(audio|realtime|tts|transcribe|image|search|embedding|instruct|codex|vision|preview)/i.test(m.id); })
        .sort(function (a, b) { var am = /mini/.test(a.id) ? 0 : 1, bm = /mini/.test(b.id) ? 0 : 1; return am - bm || (b.created || 0) - (a.created || 0); })
        .map(function (m) { return m.id; });
    });
    else pr = window.aiListModels('groq', key).then(function (l) { return l.map(function (m) { return m.id; }); });
    return pr.then(function (ids) { if (ids && ids.length) modelCache[p] = ids; return ids || []; }, function () { return []; });
  }
  function jsonText(t) {   // tolerate ```json fences
    t = String(t || '').trim();
    var m = t.match(/```(?:json)?\s*([\s\S]*?)```/); if (m) t = m[1];
    var i = t.indexOf('{'), j = t.lastIndexOf('}'); return (i >= 0 && j > i) ? t.slice(i, j + 1) : t;
  }
  var listenParts = null;                // 3.17: audio parts sent with the prompt when "Gemini listens" is on
  function listenOn() { return aiOpts().p === 'gemini' && ($('aeListen') || {}).value === 'on'; }
  function makeListenParts(setMsg) {
    var n = node(), ff = window.weloTools.get('ffmpeg'), parts = [], total = 0;
    var takes = analysis.clips.filter(function (c) { return c.role === 'take'; });
    var dir = n.path.join(require('os').tmpdir(), 'welo_ae_listen');
    try { n.fs.mkdirSync(dir, { recursive: true }); } catch (e) {}
    var i = 0;
    function next() {
      if (i >= takes.length) return Promise.resolve(parts);
      var c = takes[i++], st = n.fs.statSync(c.path);
      var f = n.path.join(dir, n.crypto.createHash('md5').update(c.path + '|' + st.size + '|' + st.mtimeMs).digest('hex') + '.mp3');
      setMsg('Preparing audio for Gemini ' + i + '/' + takes.length + '…');
      var mk = n.fs.existsSync(f) ? Promise.resolve() : run(ff, ['-hide_banner', '-loglevel', 'error', '-y', '-i', c.path, '-vn', '-ac', '1', '-ar', '16000', '-c:a', 'libmp3lame', '-b:a', '32k', f]);
      return mk.then(function () {
        var b64 = n.fs.readFileSync(f).toString('base64');
        total += b64.length;
        if (total > 15e6) throw new Error('audio too long for one Gemini request (> ~60 min) — turn "Gemini listens" off');
        parts.push({ text: 'AUDIO of clip C' + (c.clip + 1) + ' "' + c.name + '":' });
        parts.push({ inlineData: { mimeType: 'audio/mp3', data: b64 } });
        return next();
      });
    }
    return next();
  }
  function geminiOnce(prompt, key, model, think, thinkCfg) {
    var gc = { temperature: 0.2, responseMimeType: 'application/json', responseSchema: SCHEMA };
    if (!think && thinkCfg) gc.thinkingConfig = thinkCfg;
    return window.aiFetchJson('https://generativelanguage.googleapis.com/v1beta/models/' + encodeURIComponent(model) + ':generateContent', {
      method: 'POST', headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key }, timeout: listenParts ? 600000 : 300000,
      body: JSON.stringify({ contents: [{ parts: (listenParts || []).concat([{ text: prompt }]) }], generationConfig: gc })
    }, 2).then(function (d) {
      var c = d && d.candidates && d.candidates[0];
      var t = c && c.content && c.content.parts && c.content.parts.filter(function (x) { return !x.thought; }).map(function (x) { return x.text || ''; }).join('');
      if (!t) throw new Error((d && d.promptFeedback && d.promptFeedback.blockReason) ? 'Blocked: ' + d.promptFeedback.blockReason : 'Empty response');
      return t;
    });
  }
  function callGeminiModel(prompt, key, model, think) {
    if (think) return geminiOnce(prompt, key, model, true);
    // Fast = no thinking. 2.x models take thinkingBudget:0, 3.x take thinkingLevel; fall back to defaults if neither is accepted.
    return geminiOnce(prompt, key, model, false, { thinkingBudget: 0 })
      .catch(function (e) { if (!/thinking/i.test(e.message || '')) throw e; return geminiOnce(prompt, key, model, false, { thinkingLevel: 'low' }); })
      .catch(function (e) { if (!/thinking/i.test(e.message || '')) throw e; return geminiOnce(prompt, key, model, true); });
  }
  function chatOnce(p, prompt, key, model, think, withReasoning) {
    var body = { model: model, messages: [
      { role: 'system', content: 'You are a video editor assistant. Reply with ONE JSON object only, exactly in the requested format.' },
      { role: 'user', content: prompt }] };
    if (p === 'openai') body.response_format = { type: 'json_schema', json_schema: { name: 'auto_edit', schema: OA_SCHEMA } };
    else { body.response_format = { type: 'json_object' }; body.temperature = 0.2; }
    if (withReasoning) body.reasoning_effort = think ? (p === 'openai' ? 'medium' : 'high') : (p === 'openai' ? 'minimal' : 'low');
    var url = p === 'openai' ? 'https://api.openai.com/v1/chat/completions' : 'https://api.groq.com/openai/v1/chat/completions';
    return window.aiFetchJson(url, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + key }, body: JSON.stringify(body), timeout: 300000 }, 2)
      .then(function (d) {
        var t = d && d.choices && d.choices[0] && d.choices[0].message && d.choices[0].message.content;
        if (!t) throw new Error('Empty response'); return t;
      });
  }
  function callChatModel(p, prompt, key, model, think) {
    // reasoning_effort only exists on reasoning models; retry without it if the model rejects it
    return chatOnce(p, prompt, key, model, think, true).catch(function (e) {
      if (!/reasoning|unsupported|unrecognized|not supported/i.test(e.message || '')) throw e;
      return chatOnce(p, prompt, key, model, think, false);
    });
  }
  function callAI(p, prompt, key, models, think) {
    var m = models[0];
    var pr = p === 'gemini' ? callGeminiModel(prompt, key, m, think) : callChatModel(p, prompt, key, m, think);
    return pr.then(function (t) { return { text: jsonText(t), model: m }; }).catch(function (e) {
      if (models.length > 1 && isRetired(e)) return callAI(p, prompt, key, models.slice(1), think);
      throw e;
    });
  }
  var OA_SCHEMA = { type: 'object', properties: {
      lines: { type: 'array', items: { type: 'object', properties: { say: { type: 'string' }, takes: { type: 'array', items: { type: 'string' } }, pick: { type: 'array', items: { type: 'string' } }, reason: { type: 'string' } }, required: ['say', 'takes', 'pick', 'reason'] } },
      ideas: { type: 'array', items: { type: 'object', properties: { seg: { type: 'string' }, dur: { type: 'number' }, type: { type: 'string', enum: IDEA_TYPES }, what: { type: 'string' } }, required: ['seg', 'dur', 'type', 'what'] } },
      broll: { type: 'array', items: { type: 'object', properties: { clip: { type: 'string' }, start: { type: 'number' }, end: { type: 'number' }, afterSeg: { type: 'string' } }, required: ['clip', 'start', 'end', 'afterSeg'] } },
      notes: { type: 'string' } }, required: ['lines', 'ideas', 'broll', 'notes'] };
  function validate(res) {
    var map = segMap(), seen = {}, warn = [];
    var out = [];
    // 3.12: model groups every attempt of a line ("takes") and picks one attempt; convert to edl rows
    if (res.lines && !res.edl) {
      res.edl = [];
      var claimed = {};
      res.lines.forEach(function (L) {
        if (!L) return;
        var pick = (L.pick || []).filter(function (id) { return map[id] && !claimed[id]; });
        if (!pick.length) { warn.push('line without valid pick'); return; }
        var takes = (L.takes || []).filter(function (id) { return map[id]; });
        takes.concat(pick).forEach(function (id) { claimed[id] = 1; });
        pick.sort(function (a, b) { return map[a].clip - map[b].clip || map[a].s - map[b].s; });
        var others = takes.filter(function (id) { return pick.indexOf(id) < 0; });
        pick.forEach(function (id, k) {
          res.edl.push({ seg: id, alt: pick.length === 1 ? others : [], reason: k === 0 ? (L.reason || '') : '', fix: k === 0 ? (L.say || '') : '', cont: k > 0 });
        });
      });
    }
    (res.edl || []).forEach(function (r) {
      if (!r || !map[r.seg]) { warn.push('unknown ' + (r && r.seg)); return; }
      if (seen[r.seg]) { warn.push('duplicate ' + r.seg); return; }
      seen[r.seg] = 1;
      var alt = (r.alt || []).filter(function (a) { return map[a] && a !== r.seg; });
      out.push({ seg: r.seg, alt: alt, reason: String(r.reason || ''), fix: String(r.fix || '').trim(), cont: !!r.cont, on: true });
    });
    var br = [];
    (res.broll || []).forEach(function (x) {
      var ci = parseInt(String(x.clip).replace(/\D/g, ''), 10) - 1;
      var c = clipByIndex(ci);
      if (!c || c.role !== 'broll' || !seen[x.afterSeg]) { warn.push('b-roll skipped ' + x.clip); return; }
      var s = Math.max(0, +x.start || 0), e = Math.min(c.duration, +x.end || Math.min(c.duration, s + 3));
      if (e - s < 0.3) return;
      br.push({ clip: ci, start: s, end: e, afterSeg: x.afterSeg, on: true });
    });
    var ideas = [];
    (res.ideas || []).forEach(function (x) {
      if (!x || !seen[x.seg] || ideaTypes().indexOf(x.type) < 0 || !String(x.what || '').trim()) return;
      ideas.push({ seg: x.seg, dur: Math.max(1.5, Math.min(8, +x.dur || 3)), type: x.type, what: String(x.what).trim(), on: true });
    });
    return { edl: out, broll: br, ideas: ideas, warn: warn };
  }
  function aiOpts() {
    return { p: ($('aeProvider') || {}).value || 'gemini', model: ($('aeAiModel') || {}).value || '', think: ($('aeThink') || {}).value === 'think' };
  }
  function fillModels() {
    var o = aiOpts(), sel = $('aeAiModel'); if (!sel) return;
    var keep = sel.value || sel.getAttribute('data-saved') || '';
    var key = provKey(o.p);
    sel.innerHTML = '<option value="">Auto (newest fast)</option>';
    if (!key) { sel.title = 'No ' + PROVIDERS[o.p] + ' key'; return; }
    listModels(o.p, key).then(function (ids) {
      if (aiOpts().p !== o.p) return;
      ids.slice(0, 40).forEach(function (id) { var op = document.createElement('option'); op.value = id; op.textContent = id; sel.appendChild(op); });
      if (keep && ids.indexOf(keep) >= 0) sel.value = keep;
    });
  }
  function pick() {
    if (!analysis) { status('Analyze first', 'error'); return; }
    if (typeof window.aiFetchJson !== 'function') { status('AI module not loaded', 'error'); return; }
    var o = aiOpts(), name = PROVIDERS[o.p], key = provKey(o.p);
    if (!key) { status('No ' + name + ' API key — add it in Transcription › AI settings (provider: ' + name + ')', 'error'); return; }
    var btn = $('aePickBtn'); if (btn) { btn.disabled = true; btn.textContent = name + ' is editing…'; }
    var t0 = Date.now();
    var tick = setInterval(function () { status('Sending ' + Object.keys(segMap()).length + ' sentences to ' + name + (o.think ? ' (thinking)' : ' (fast)') + '… ' + Math.round((Date.now() - t0) / 1000) + 's', 'working'); }, 1000);
    status('Sending ' + Object.keys(segMap()).length + ' sentences to ' + name + '…', 'working');
    retimeAll();
    var prompt = buildPrompt();
    listenParts = null;
    (listenOn() ? makeListenParts(function (m) { status(m, 'working'); }).then(function (p) { listenParts = p; }) : Promise.resolve())
      .then(function () { return o.model ? [o.model] : listModels(o.p, key).then(function (ids) {
        var fb = o.p === 'gemini' ? GEM_FALLBACK : [];
        return ids.slice(0, 6).concat(fb);
      }); })
      .then(function (models) {
        if (!models.length) throw new Error('No models available for this key');
        return callAI(o.p, prompt, key, models, o.think);
      })
      .then(function (r) {
        var res; try { res = JSON.parse(r.text); } catch (e) { throw new Error(name + ' returned invalid JSON'); }
        var v = validate(res);
        if (!v.edl.length) throw new Error(name + ' returned no usable segments' + (v.warn.length ? ' (' + v.warn.slice(0, 3).join(', ') + ')' : ''));
        edl = v.edl; broll = v.broll; ideas = v.ideas; aiNotes = String(res.notes || '');
        var nd = dedupe();
        clearInterval(tick);
        status('✓ ' + r.model + (o.think ? ' · thinking' : ' · fast') + (listenParts ? ' · listened' : '') + ' picked ' + edl.length + ' lines' + (broll.length ? ' + ' + broll.length + ' b-roll' : '') + (ideas.length ? ' · ' + ideas.length + ' b-roll ideas' : '') + ' · ' + Math.round((Date.now() - t0) / 1000) + 's' + (v.warn.length ? ' · ' + v.warn.length + ' item(s) ignored' : '') + (nd ? ' · ' + nd + ' repeat(s) switched off' : ''), 'ok');
        renderEdl();
      })
      .catch(function (e) { clearInterval(tick); status('⚠ ' + name + ': ' + (e && e.message || e), 'error'); })
      .then(function () { listenParts = null; clearInterval(tick); if (btn) { btn.disabled = false; btn.textContent = edl ? 'Ask AI again' : 'Pick best takes (AI)'; } });
  }
  // ── local repeat guard: the model can miss repeats, so compare chosen lines ourselves ──
  function normWords(t) {
    t = String(t || '').toLowerCase()
      .replace(/[ً-ْـ]/g, '')            // tashkeel, tatweel
      .replace(/[إأآا]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه')
      .replace(/[^؀-ۿa-z0-9\s]/g, ' ');
    return t.split(/\s+/).filter(function (w) { return w.length > 1 && !/^(يعني|اه|امم|ايه|و|ف|في|من|علي|ان|ده|دي|the|a|and|so|um|uh)$/.test(w); });
  }
  function overlap(a, b) {               // share of the shorter line found in the other
    if (!a.length || !b.length) return 0;
    var set = {}; b.forEach(function (w) { set[w] = 1; });
    var hit = 0; a.forEach(function (w) { if (set[w]) hit++; });
    var r1 = hit / a.length;
    set = {}; a.forEach(function (w) { set[w] = 1; });
    hit = 0; b.forEach(function (w) { if (set[w]) hit++; });
    return Math.max(r1, hit / b.length);
  }
  function trigrams(words) {
    var t = ' ' + words.join(' ') + ' ', set = {}, n = 0;
    for (var i = 0; i + 3 <= t.length; i++) { var g = t.substr(i, 3); if (!set[g]) { set[g] = 1; n++; } }
    return { set: set, n: n };
  }
  function triSim(a, b) {               // share of the shorter line's trigrams found in the other
    var A = trigrams(a), B = trigrams(b), hit = 0, k;
    var small = A.n <= B.n ? A : B, big = small === A ? B : A;
    for (k in small.set) if (big.set[k]) hit++;
    return small.n ? hit / small.n : 0;
  }
  function dedupe() {
    var map = segMap(), n = 0;
    var rows = edl.map(function (r, i) { r.dup = ''; return { r: r, i: i, w: normWords(map[r.seg] ? map[r.seg].text : '') }; });
    for (var i = 0; i < rows.length; i++) {
      if (!rows[i].r.on || rows[i].w.length < 3) continue;
      for (var j = i + 1; j < rows.length; j++) {
        if (!rows[j].r.on || rows[j].w.length < 3) continue;
        if (rows[j].r.cont && j === i + 1) continue;                          // second piece of the same sentence
        if (overlap(rows[i].w, rows[j].w) < 0.7 && triSim(rows[i].w, rows[j].w) < 0.6) continue;
        // a much shorter piece contained in the other = false start → drop it; otherwise keep the later one
        var A = rows[i], B = rows[j], drop, keep;
        if (A.w.length <= B.w.length * 0.6) { drop = A; keep = B; }
        else if (B.w.length <= A.w.length * 0.6) { drop = B; keep = A; }
        else { drop = A; keep = B; }
        drop.r.on = false; drop.r.dup = 'repeat of #' + (keep.i + 1) + ' — switched off'; n++;
        if (drop === A) break;
      }
    }
    return n;
  }
  function edlDuration() {
    var map = segMap(), t = 0;
    (edl || []).forEach(function (r) { if (r.on && map[r.seg]) t += segLen(map[r.seg]); });
    return t;
  }
  function moveRow(i, d) { var j = i + d; if (j < 0 || j >= edl.length) return; var t = edl[i]; edl[i] = edl[j]; edl[j] = t; renderEdl(); }
  function renderEdl() {
    var box = $('aeEdl'); if (!box) return;
    box.innerHTML = '';
    var wrap = $('aeEdlWrap'); if (wrap) wrap.style.display = edl ? '' : 'none';
    if (!edl) return;
    var map = segMap();
    edl.forEach(function (r, i) {
      var g = map[r.seg];
      var row = document.createElement('div'); row.className = 'ae-edl' + (r.on ? '' : ' is-off');
      var top = document.createElement('div'); top.className = 'ae-edl-top';
      var cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = r.on; cb.title = 'Use this line';
      cb.onchange = function () { r.on = cb.checked; renderEdl(); };
      var num = document.createElement('span'); num.className = 'ae-clip-num'; num.textContent = String(i + 1);
      var sel = document.createElement('select'); sel.className = 'ae-role ae-take'; sel.title = 'Take for this line';
      [r.seg].concat(r.alt).forEach(function (id, k) {
        var x = map[id]; if (!x) return;
        var op = document.createElement('option'); op.value = id;
        op.textContent = id + ' · ' + segLen(x).toFixed(1) + 's' + (k === 0 ? ' ★' : '');
        sel.appendChild(op);
      });
      sel.onchange = function () {
        var nid = sel.value; if (nid === r.seg) return;
        var others = [r.seg].concat(r.alt).filter(function (x) { return x !== nid; });
        r.seg = nid; r.alt = others; renderEdl();
      };
      var up = btn('↑', 'Move up', function () { moveRow(i, -1); }); if (i === 0) up.disabled = true;
      var dn = btn('↓', 'Move down', function () { moveRow(i, 1); }); if (i === edl.length - 1) dn.disabled = true;
      top.appendChild(cb); top.appendChild(num); top.appendChild(sel); top.appendChild(up); top.appendChild(dn);
      var txt = document.createElement('div'); txt.className = 'ae-edl-text'; txt.dir = 'auto'; txt.textContent = r.fix || (g ? g.text : r.seg);
      if (r.fix && g && r.fix !== g.text) txt.title = 'Whisper: ' + g.text;
      row.appendChild(top); row.appendChild(txt);
      if (r.dup) { var dp = document.createElement('div'); dp.className = 'ae-edl-dup'; dp.textContent = '⟳ ' + r.dup; row.appendChild(dp); }
      if (g && g.holes && g.holes.length && cutMode() === 'smart_rep') {
        var hl = document.createElement('label'); hl.className = 'ae-edl-dup'; hl.dir = 'auto'; hl.style.cursor = 'pointer';
        var hc = document.createElement('input'); hc.type = 'checkbox'; hc.checked = !g.keepRep; hc.style.margin = '0 4px 0 0';
        hc.onchange = function () { g.keepRep = !hc.checked; renderEdl(); };
        hl.appendChild(hc); hl.appendChild(document.createTextNode('✂ cut doubled: ' + g.holes.map(function (h) { return h.w; }).join(' · ')));
        row.appendChild(hl);
      }
      if (r.reason) { var rs = document.createElement('div'); rs.className = 'ae-edl-why'; rs.dir = 'auto'; rs.textContent = r.reason; row.appendChild(rs); }
      box.appendChild(row);
      ideas.forEach(function (x) {
        if (x.seg !== r.seg) return;
        var ir = document.createElement('div'); ir.className = 'ae-idea' + (x.on && r.on ? '' : ' is-off');
        var ic = document.createElement('input'); ic.type = 'checkbox'; ic.checked = x.on; ic.title = 'Add this idea as a marker';
        ic.onchange = function () { x.on = ic.checked; renderEdl(); };
        var tg = document.createElement('span'); tg.className = 'ae-idea-tag'; tg.textContent = (IDEA_LABEL[x.type] || x.type) + ' ' + x.dur.toFixed(0) + 's';
        var wt = document.createElement('span'); wt.className = 'ae-idea-what'; wt.dir = 'auto'; wt.textContent = x.what;
        ir.appendChild(ic); ir.appendChild(tg); ir.appendChild(wt); box.appendChild(ir);
      });
    });
    broll.forEach(function (x) {
      var c = clipByIndex(x.clip);
      var row = document.createElement('div'); row.className = 'ae-edl is-broll' + (x.on ? '' : ' is-off');
      var cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = x.on; cb.onchange = function () { x.on = cb.checked; renderEdl(); };
      var t = document.createElement('span'); t.className = 'ae-edl-text';
      t.textContent = 'B-roll C' + (x.clip + 1) + ' ' + (c ? c.name : '') + ' · ' + (x.end - x.start).toFixed(1) + 's after ' + x.afterSeg;
      var top = document.createElement('div'); top.className = 'ae-edl-top'; top.appendChild(cb); top.appendChild(t);
      row.appendChild(top); box.appendChild(row);
    });
    var tot = $('aeEdlTotal');
    if (tot) {
      var b = getBrief(), d = edlDuration();
      tot.textContent = fmtDur(d) + (b.target ? ' / target ' + fmtDur(b.target) : '');
      tot.className = 'ae-summary' + (b.target && Math.abs(d - b.target) > b.target * 0.25 ? ' is-warn' : '');
    }
    var nt = $('aeEdlNotes'); if (nt) { nt.textContent = aiNotes; nt.style.display = aiNotes ? '' : 'none'; }
  }
  // ════════ M4: BUILD COMP ════════
  var ASPECTS = { '9:16': [1080, 1920], '16:9': [1920, 1080], '1:1': [1080, 1080], '4:5': [1080, 1350] };
  function pad2(n) { return (n < 10 ? '0' : '') + n; }
  function build() {
    if (!edl) { status('Pick best takes first', 'error'); return; }
    retimeAll();
    var map = segMap(), items = [], at = 0, ends = {};
    var starts = {};
    edl.forEach(function (r) {
      if (!r.on) return;
      var g = map[r.seg]; if (!g) return;
      var c = clipByIndex(g.clip); if (!c) return;
      pieces(g).forEach(function (pc, k) {        // >1 piece = a doubled word was cut out (jump cut inside the line)
        var prev = items[items.length - 1];
        if (k === 0 && prev && prev.id === c.id && pc[0] >= prev.outT - 0.3 && pc[0] - prev.outT <= pace().bridge) {
          // next piece of the same take right after the previous one: one continuous layer, keep the speaker's pause (rhythm)
          prev.outT = Math.max(prev.outT, pc[1]);
          starts[r.seg] = prev.at + (pc[0] - prev.inT);
          at = prev.at + (prev.outT - prev.inT);
          prev.seg += '+' + r.seg.replace(/^C\d+_/, '');
        } else {
          items.push({ id: c.id, seg: k ? r.seg + '·' + (k + 1) : r.seg, inT: pc[0], outT: pc[1], at: +at.toFixed(4), comment: k ? 'doubled word cut' : (r.reason || '') });
          if (!k) starts[r.seg] = at;
          at += pc[1] - pc[0];
        }
      });
      ends[r.seg] = at;
    });
    if (!items.length) { status('All lines are off', 'error'); return; }
    var total = at;
    var br = [];
    broll.forEach(function (x) {
      if (!x.on || ends[x.afterSeg] === undefined) return;
      var c = clipByIndex(x.clip); if (!c) return;
      var st = ends[x.afterSeg], len = Math.min(x.end - x.start, total - st);
      if (len < 0.3) return;
      br.push({ id: c.id, inT: x.start, outT: x.start + len, at: +st.toFixed(4) });
    });
    var mk = [];
    var ph = !!($('aePlaceholders') || {}).checked;
    ideas.forEach(function (x) {
      if (!x.on || starts[x.seg] === undefined) return;
      var st = starts[x.seg], len = Math.min(x.dur, total - st);
      if (len < 0.5) return;
      mk.push({ at: +st.toFixed(4), dur: +len.toFixed(3), type: x.type, label: IDEA_LABEL[x.type] || x.type, what: x.what });
    });
    var first = clipByIndex(map[items[0].seg.split('+')[0].split('·')[0]].clip);
    var b = getBrief();
    var wh = ASPECTS[b.aspect] || [first.w, first.h];
    var d = new Date();
    var data = { name: 'AutoEdit_' + d.getFullYear() + pad2(d.getMonth() + 1) + pad2(d.getDate()) + '_' + pad2(d.getHours()) + pad2(d.getMinutes()),
                 W: wh[0], H: wh[1], fps: first.fps || 25, dur: total, items: items, broll: br, ideas: mk, placeholders: ph };
    var arg = JSON.stringify(JSON.stringify(data)).replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');
    var bt = $('aeBuildBtn'); if (bt) bt.disabled = true;
    status('Building comp (' + items.length + ' cuts, ' + fmtDur(total) + ')…', 'working');
    cs().evalScript('ae_buildAutoEdit(' + arg + ')', function (r) {
      if (bt) bt.disabled = false;
      r = String(r || '');
      if (r.indexOf('OK:') === 0) status('✓ Built ' + r.slice(3) + ' · ' + items.length + ' layers · ' + fmtDur(total) + (mk.length ? ' · ' + mk.length + ' b-roll markers' : '') + ' — Ctrl+Z undoes it', 'ok');
      else status('⚠ ' + (r.replace(/^ERR:/, '') || 'Build failed'), 'error');
    });
  }

  function init() {
    if (!$('tab-autoedit')) return;
    loadBrief();
    BRIEF_KEYS.forEach(function (k) { var el = $(k); if (el) el.addEventListener('change', saveBrief); });
    document.querySelectorAll('.ae-it').forEach(function (el) { el.addEventListener('change', saveBrief); });
    var pc = $('aePacing'); if (pc) pc.addEventListener('change', function () { saveBrief(); retimeAll(); renderResults(); if (edl) renderEdl(); });
    var cm = $('aeCuts'); if (cm) cm.addEventListener('change', function () { saveBrief(); retimeAll(); renderResults(); if (edl) renderEdl(); });
    var pv = $('aeProvider'); if (pv) pv.addEventListener('change', function () { var m = $('aeAiModel'); if (m) { m.value = ''; m.removeAttribute('data-saved'); } fillModels(); saveBrief(); });
    var am = $('aeAiModel'); if (am) am.addEventListener('focus', function () { if (am.options.length <= 1) fillModels(); });
    fillModels();
    render();
  }

  return { init: init, loadSelected: loadSelected, clear: clear, analyze: analyze, cancel: cancel, pick: pick, build: build, openTxEditor: openTxEditor, closeTxEditor: closeTxEditor,
           getClips: function () { return clips; }, getBrief: getBrief, getAnalysis: function () { return analysis; }, getEdl: function () { return { edl: edl, broll: broll }; } };
})();

if (window.WeloInit) window.WeloInit.add(function () { window.autoEdit.init(); });
