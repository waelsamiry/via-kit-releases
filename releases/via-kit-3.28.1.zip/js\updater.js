// ── UPDATER (panel) · 3.28.1 — docs/AUDIT-2026-11.md "Update button" ────────────────────────────────────────
// Releases live in the PUBLIC repo github.com/waelsamiry/via-kit-releases (the source repo stays private):
//   latest.json                       { version, date, file, sha256, size, notes[], after[], remove[] }
//   releases/via-kit-<version>.zip    made by tools\make_release.bat on Wael's PC, pushed with GitHub Desktop
// Panel: checks on start (max every 6 h) + Settings › Updates › Check now. Update = download → SHA-256 check → unzip to
// %TEMP%\via-update → a CMD window waits for After Effects to close, backs up the kit to
// %APPDATA%\Via Studios Kit\backup\<old version>, copies the new files (user data untouched), reopens AE.
// A kit folder with .git (Wael's dev PC) is only notified — never overwritten (pull in GitHub Desktop instead).
window.viaUpdate = (function () {
  var REPO = 'waelsamiry/via-kit-releases', BRANCH = 'main';
  var RAW = 'https://raw.githubusercontent.com/' + REPO + '/' + BRANCH + '/';
  var EVERY = 6 * 3600 * 1000;
  var latest = null, busy = false;
  function $(id) { return document.getElementById(id); }
  function node() { return { fs: require('fs'), path: require('path'), os: require('os'), cp: require('child_process'), https: require('https'), crypto: require('crypto') }; }
  function cfg(k, v) { try { if (v === undefined) return window.weloCfg.get(k); window.weloCfg.set(k, v); } catch (e) { return null; } }
  function log(m) { try { window.viaLog.info('update', m); } catch (e) {} }
  function toast(m) { try { window.showToast(m); } catch (e) {} }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function extDir() { return new CSInterface().getSystemPath(SystemPath.EXTENSION); }
  function current() {
    try { var n = node(); return (n.fs.readFileSync(n.path.join(extDir(), 'CSXS', 'manifest.xml'), 'utf8').match(/ExtensionBundleVersion="([^"]+)"/) || [])[1] || '0.0.0'; }
    catch (e) { return '0.0.0'; }
  }
  function newer(a, b) {      // a > b ?
    var x = String(a).split('.'), y = String(b).split('.');
    for (var i = 0; i < 3; i++) { var d = (parseInt(x[i], 10) || 0) - (parseInt(y[i], 10) || 0); if (d) return d > 0; }
    return false;
  }
  // dev PC (.git) = notify only. A file UPDATE_TEST in the kit folder lifts that for a real install test (3.28.1);
  // .git itself is never touched by the installer (robocopy /XD .git). make_release never ships UPDATE_TEST.
  function isDev() { try { var n = node(), k = extDir(); return n.fs.existsSync(n.path.join(k, '.git')) && !n.fs.existsSync(n.path.join(k, 'UPDATE_TEST')); } catch (e) { return false; } }
  function dataDir() { var n = node(); return n.path.join(process.env.APPDATA || n.os.homedir(), 'Via Studios Kit'); }
  function status(msg, kind) { var el = $('updStatus'); if (el) { el.textContent = msg || ''; el.className = 'ae-status' + (kind ? ' is-' + kind : ''); el.style.display = msg ? '' : 'none'; } }

  // HTTPS GET (follows redirects) → Buffer, or to a file with progress
  function get(url, file, onPct) {
    return new Promise(function (res, rej) {
      var n = node(), hops = 0;
      (function go(u) {
        var o = require('url').parse(u); o.headers = { 'User-Agent': 'ViaStudiosKit-updater', 'Cache-Control': 'no-cache' };   // (url, opts, cb) needs Node 10.9+
        n.https.get(o, function (r) {
          if (r.statusCode >= 300 && r.statusCode < 400 && r.headers.location && hops++ < 5) { r.resume(); return go(r.headers.location); }
          if (r.statusCode !== 200) { r.resume(); return rej(new Error('HTTP ' + r.statusCode + ' for ' + u.split('?')[0])); }
          var total = +r.headers['content-length'] || 0, got = 0, chunks = [], out = file ? n.fs.createWriteStream(file) : null;
          r.on('data', function (c) { got += c.length; if (out) out.write(c); else chunks.push(c); if (onPct && total) onPct(Math.round(100 * got / total)); });
          r.on('end', function () { if (out) out.end(function () { res(file); }); else res(Buffer.concat(chunks)); });
          r.on('error', rej);
        }).on('error', rej).setTimeout(30000, function () { this.destroy(new Error('timeout')); });
      })(url);
    });
  }

  // ── check ──
  function check(manual) {
    if (typeof require !== 'function' || typeof CSInterface === 'undefined') { if (manual) status('Open in After Effects', 'warn'); return Promise.resolve(null); }
    if (manual) status('Checking…', 'working');
    return get(RAW + 'latest.json?t=' + Date.now()).then(function (buf) {
      var j = JSON.parse(buf.toString('utf8').replace(/^﻿/, ''));
      cfg('upd_last', String(Date.now())); cfg('upd_latest', JSON.stringify(j));
      latest = j;
      var cur = current();
      if (j.version && newer(j.version, cur)) { log('available ' + j.version + ' (have ' + cur + ')'); show(j); status(''); }
      else { hideBanner(); if (manual) status('✓ You have the newest version (' + cur + ')', 'ok'); }
      renderSettings();
      return j;
    }).catch(function (e) {
      log('check failed: ' + e.message);
      if (manual) status(/HTTP 404/.test(e.message) ? 'No release published yet' : '⚠ Could not check: ' + e.message, /404/.test(e.message) ? 'warn' : 'error');
      return null;
    });
  }

  // ── banner (top of the panel) ──
  function show(j) {
    if (cfg('upd_skip') === j.version) { renderSettings(); return; }
    var b = $('updBanner');
    if (!b) { b = document.createElement('div'); b.id = 'updBanner'; b.className = 'upd-banner'; document.body.insertBefore(b, document.body.firstChild); }
    b.innerHTML = '<span>⬆ Update <b>' + esc(j.version) + '</b> available</span>' +
      '<button class="btn-mini" id="updBNotes">What\'s new</button>' +
      '<button class="btn-mini upd-go" id="updBGo">' + (isDev() ? 'How' : 'Update') + '</button>' +
      '<button class="upd-x" id="updBX" title="Hide until the next version">✕</button>';
    $('updBNotes').onclick = openSettings;
    $('updBGo').onclick = function () { if (isDev()) openSettings(); else start(); };
    $('updBX').onclick = function () { cfg('upd_skip', j.version); hideBanner(); };
  }
  function hideBanner() { var b = $('updBanner'); if (b) b.parentNode.removeChild(b); }
  function openSettings() { try { if (typeof openTool === 'function') openTool('settings'); } catch (e) {} setTimeout(function () { var s = $('updSection'); if (s) s.scrollIntoView({ behavior: 'smooth' }); }, 150); }

  // ── Settings › Updates ──
  function backups() {
    try { var n = node(), d = n.path.join(dataDir(), 'backup'); return n.fs.readdirSync(d).filter(function (f) { return /^\d+\.\d+\.\d+$/.test(f); }).sort(function (a, b) { return newer(a, b) ? -1 : 1; }); }
    catch (e) { return []; }
  }
  function renderSettings() {
    var box = $('updBody'); if (!box) return;
    var cur = current(), j = latest, h = '<div style="font-size:9px;margin-bottom:4px">Installed: <b>' + esc(cur) + '</b>' +
      (j && j.version ? ' · newest: <b>' + esc(j.version) + '</b>' + (j.date ? ' (' + esc(j.date) + ')' : '') : '') + '</div>' +
      '<div style="font-size:7px;color:var(--text-muted);margin-bottom:4px">from github.com/' + REPO + '</div>';
    if (j && j.version && newer(j.version, cur)) {
      if (j.notes && j.notes.length) h += '<ul class="upd-notes">' + j.notes.map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('') + '</ul>';
      if (isDev()) h += '<div class="ae-status is-warn">This kit folder is a git clone (developer PC) — get the update with <b>Pull origin</b> in GitHub Desktop.</div>';
      else h += '<button class="btn-generate" id="updGo" style="width:100%;margin-top:4px">Update to ' + esc(j.version) + '</button>';
    }
    var bk = backups().filter(function (v) { return v !== cur; });
    if (bk.length && !isDev()) h += '<button class="btn-secondary" id="updBack" style="width:100%;margin-top:4px">Go back to ' + esc(bk[0]) + '</button>';
    box.innerHTML = h;
    var g = $('updGo'); if (g) g.onclick = start;
    var r = $('updBack'); if (r) r.onclick = function () { rollback(bk[0]); };
  }

  // ── update ──
  function start() {
    if (busy || !latest) return;
    if (isDev()) { openSettings(); return; }
    busy = true;
    var n = node(), j = latest, work = n.path.join(n.os.tmpdir(), 'via-update'), zip = n.path.join(work, 'via-kit-' + j.version + '.zip');
    var stage = n.path.join(work, 'stage-' + j.version);
    try { n.fs.mkdirSync(work, { recursive: true }); } catch (e) {}
    openSettings();
    status('Downloading ' + j.version + '…', 'working');
    get(RAW + j.file + '?t=' + Date.now(), zip, function (p) { status('Downloading ' + j.version + '… ' + p + '%', 'working'); }).then(function () {
      var sum = n.crypto.createHash('sha256').update(n.fs.readFileSync(zip)).digest('hex');
      if (!j.sha256 || sum.toLowerCase() !== String(j.sha256).toLowerCase()) throw new Error('the download is damaged or was changed (SHA-256 mismatch) — nothing was installed');
      status('Unpacking…', 'working');
      return ps("$ErrorActionPreference='Stop'; Add-Type -AssemblyName System.IO.Compression.FileSystem; " +
                "if (Test-Path -LiteralPath '" + psq(stage) + "') { Remove-Item -LiteralPath '" + psq(stage) + "' -Recurse -Force }; " +
                "[IO.Compression.ZipFile]::ExtractToDirectory('" + psq(zip) + "', '" + psq(stage) + "')");
    }).then(function () {
      var man = ''; try { man = n.fs.readFileSync(n.path.join(stage, 'CSXS', 'manifest.xml'), 'utf8'); } catch (e) {}
      if (man.indexOf('ExtensionBundleVersion="' + j.version + '"') < 0) throw new Error('the package does not contain version ' + j.version);
      launch(stage, j.version, j.remove || [], 'Updating to ' + j.version);
      cfg('upd_pending', JSON.stringify({ version: j.version, notes: j.notes || [], after: j.after || [] }));
      log('installing ' + j.version);
      status('Ready. Save your project and close After Effects — the update installs in the CMD window and reopens After Effects.', 'ok');
      var b = $('updBody');
      if (b) { var q = document.createElement('button'); q.className = 'btn-secondary'; q.style.cssText = 'width:100%;margin-top:4px'; q.textContent = 'Close After Effects now (it asks to save)';
               q.onclick = function () { try { new CSInterface().evalScript('app.quit()'); } catch (e) {} }; b.appendChild(q); }
    }).catch(function (e) { busy = false; log('failed: ' + e.message); status('⚠ Update failed: ' + e.message, 'error'); });
  }
  function rollback(v) {
    if (busy) return; busy = true;
    var n = node(), src = n.path.join(dataDir(), 'backup', v);
    launch(src, v, [], 'Going back to ' + v, true);
    cfg('upd_pending', JSON.stringify({ version: v, notes: ['Restored the previous version'], after: [] }));
    cfg('upd_skip', latest && latest.version || '');
    status('Save your project and close After Effects — version ' + v + ' is restored in the CMD window.', 'ok');
  }
  function psq(s) { return String(s).replace(/'/g, "''"); }
  function ps(cmd) {
    return new Promise(function (res, rej) {
      var p = node().cp.spawn('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', cmd], { windowsHide: true }), err = '';
      p.stderr.on('data', function (d) { err += d; });
      p.on('error', rej);
      p.on('close', function (c) { c === 0 ? res() : rej(new Error('unzip failed: ' + err.trim().slice(0, 200))); });
    });
  }
  function q(p) { return String(p).replace(/%/g, '%%'); }
  // the CMD window: wait for AE → backup → copy → remove dropped files → reopen AE. Restores the backup on failure.
  function launch(src, ver, remove, title, isRollback) {
    var n = node(), kit = extDir(), cur = current();
    var bak = n.path.join(dataDir(), 'backup', cur), ae = '';
    try { ae = new CSInterface().getSystemPath(SystemPath.HOST_APPLICATION); } catch (e) {}
    var exe = ae ? n.path.win32.basename(ae) : 'AfterFX.exe';
    var keep = '/XD .git __pycache__ /XF python_path.txt .debug *.lic';
    var L = ['@echo off', 'chcp 65001 > nul', 'title Via Studios Kit - ' + title,
      'echo.', 'echo  ' + title + '. Save your project and close After Effects - this window waits for it...',
      ':wait', 'tasklist /FI "IMAGENAME eq ' + exe + '" 2>nul | find /I "' + exe + '" > nul && (timeout /t 2 /nobreak > nul & goto wait)',
      'timeout /t 2 /nobreak > nul'];
    if (!isRollback) L = L.concat([
      'echo  Backing up ' + cur + '...',
      'rmdir /s /q "' + q(bak) + '" 2>nul',
      'robocopy "' + q(kit) + '" "' + q(bak) + '" /E /XD .git /NFL /NDL /NJH /NJS /NP > nul',
      'if errorlevel 8 (echo  Backup failed - nothing was changed. & pause & exit /b 1)']);
    L = L.concat(['echo  Installing ' + ver + '...',
      'robocopy "' + q(src) + '" "' + q(kit) + '" /E ' + keep + ' /NFL /NDL /NJH /NJS /NP',
      'if errorlevel 8 goto fail']);
    remove.forEach(function (r) { if (/^[\w .\/-]+$/.test(r) && r.indexOf('..') < 0) L.push('del /q "' + q(n.path.join(kit, r)) + '" 2>nul'); });
    L = L.concat(['(echo ' + ver + ')> "' + q(n.path.join(dataDir(), 'updated.txt')) + '"',      // ( ) : "…0>" would be a handle redirect
      'echo  Done - opening After Effects...',
      ae ? 'start "" "' + q(ae) + '"' : 'echo  Open After Effects again.',
      'timeout /t 3 /nobreak > nul', 'exit /b 0',
      ':fail',
      isRollback ? 'echo  Restore failed - copy the folder "' + q(src) + '" over the kit folder by hand.' :
        'echo  Copy failed - restoring ' + cur + '... & robocopy "' + q(bak) + '" "' + q(kit) + '" /E /NFL /NDL /NJH /NJS /NP > nul',
      'echo  If this says "Access denied": right-click setup_new_pc.bat - Run as administrator (once), then update again.',
      'pause', 'exit /b 1']);
    var bat = n.path.join(n.os.tmpdir(), 'via-update', 'via_update.bat');
    try { n.fs.mkdirSync(n.path.dirname(bat), { recursive: true }); } catch (e) {}
    n.fs.writeFileSync(bat, L.join('\r\n') + '\r\n', 'utf8');
    if (writable(kit)) n.cp.spawn('cmd.exe', ['/c', 'start', '""', 'cmd.exe', '/c', bat], { detached: true, stdio: 'ignore' }).unref();
    else n.cp.spawn('powershell.exe', ['-NoProfile', '-Command', "Start-Process cmd.exe -ArgumentList '/c','\"" + psq(bat) + "\"' -Verb RunAs"], { detached: true, stdio: 'ignore' }).unref();
  }
  function writable(dir) {
    try { var n = node(), f = n.path.join(dir, '.via_w' + Date.now()); n.fs.writeFileSync(f, ''); n.fs.unlinkSync(f); return true; } catch (e) { return false; }
  }

  // after a restart: say what happened
  function afterUpdate() {
    try {
      var n = node(), f = n.path.join(dataDir(), 'updated.txt');
      if (!n.fs.existsSync(f)) return;
      var v = n.fs.readFileSync(f, 'utf8').trim(); n.fs.unlinkSync(f);
      var p = {}; try { p = JSON.parse(cfg('upd_pending') || '{}'); } catch (e) {}
      cfg('upd_pending', '');
      if (v !== current()) { toast('⚠ Update to ' + v + ' did not finish — see the CMD window'); return; }
      log('updated to ' + v);
      toast('✓ Updated to ' + v);
      if (p.after && p.after.indexOf('libs') >= 0) setTimeout(function () { toast('This version needs new Python libraries — Settings › Install all'); }, 3500);
      if (p.after && p.after.indexOf('corridorkey') >= 0) setTimeout(function () { toast('This version needs: AI Keyer › Re-run CorridorKey setup'); }, 7000);
    } catch (e) {}
  }

  function init() {
    if (typeof require !== 'function' || typeof CSInterface === 'undefined') return;
    try { if (new CSInterface().getHostEnvironment().appName !== 'AEFT') return; } catch (e) {}
    afterUpdate();
    try { latest = JSON.parse(cfg('upd_latest') || 'null'); } catch (e) { latest = null; }
    renderSettings();
    var last = +(cfg('upd_last') || 0);
    if (Date.now() - last > EVERY) setTimeout(function () { check(false); }, 4000);
    else if (latest && latest.version && newer(latest.version, current())) show(latest);
  }
  if (window.WeloInit) window.WeloInit.add(init);
  return { check: check, start: start, render: renderSettings, current: current };
})();
