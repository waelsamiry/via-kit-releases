#!/usr/bin/env python3
"""
Via Studios Kit — Whisper / Qwen3-ASR Runner
Usage: python run_whisper.py <audio_file> [model] [language] [models_dir]
Models: tiny | base | small | medium | large | large-v3-turbo | qwen3-asr
Outputs JSON to <audio_file>.json (same directory)

Models folder (portable): defaults to C:\Via Studios Kit\Audio\models
(fallback: %APPDATA%\Via Studios Kit\Audio\models). Override via [models_dir]
arg or env WELO_MODELS_DIR. Copy the Audio folder to another machine to move
all models + work files together.
"""
import sys, os, json, shutil

# Whisper/demucs call "ffmpeg" via PATH — put the bundled ytdl\ffmpeg.exe first so no system install is needed
_EXT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_YT = os.path.join(_EXT, 'ytdl')
_FF = os.environ.get('WELO_FFMPEG_DIR', '')  # resolved by the panel (js/tools.js)
if _FF and os.path.exists(os.path.join(_FF, 'ffmpeg.exe')):
    os.environ['PATH'] = _FF + os.pathsep + os.environ.get('PATH', '')
elif os.path.exists(os.path.join(_YT, 'ffmpeg.exe')):
    os.environ['PATH'] = _YT + os.pathsep + os.environ.get('PATH', '')

MODELS_DIR_OVERRIDE = None

def models_dir():
    global MODELS_DIR_OVERRIDE
    if MODELS_DIR_OVERRIDE:
        return MODELS_DIR_OVERRIDE
    d = os.environ.get('WELO_MODELS_DIR')
    if d:
        MODELS_DIR_OVERRIDE = d
        return d
    base = os.environ.get('APPDATA') or os.path.expanduser('~')
    d = os.path.join(base, 'Via Studios Kit', 'Audio', 'models')
    MODELS_DIR_OVERRIDE = d
    return d

def ensure_models_dir():
    d = models_dir()
    try:
        os.makedirs(d, exist_ok=True)
    except Exception:
        pass
    return d

def seed_old_whisper_cache(model_name, md):
    # If the model already lives in an old cache location, copy it so we never
    # re-download after moving to the portable folder. Only complete weights
    # (>= 60 MB) are copied — partial/interrupted .pt downloads are skipped.
    sources = []
    sources.append(os.path.join(os.path.expanduser('~'), '.cache', 'whisper', model_name + '.pt'))
    sources.append(os.path.join('C:\\Via Studios Kit', 'models', model_name + '.pt'))
    if os.environ.get('APPDATA'):
        sources.append(os.path.join(os.environ['APPDATA'], 'Via Studios Kit', 'Audio', 'models', model_name + '.pt'))
    for s in sources:
        try:
            if os.path.exists(s) and os.path.getsize(s) >= 60 * 1024 * 1024:
                dst = os.path.join(md, model_name + '.pt')
                if not os.path.exists(dst):
                    shutil.copy2(s, dst)
                    print("Copied existing model from cache", flush=True)
                break
        except Exception:
            continue

def whisper_lang(language):
    # Shorthand -> full name for Qwen3-ASR (its language tokens are full names)
    if not language:
        return None
    m = {'ar': 'Arabic', 'en': 'English', 'fr': 'French', 'es': 'Spanish',
         'de': 'German', 'it': 'Italian', 'pt': 'Portuguese', 'ru': 'Russian',
         'tr': 'Turkish', 'ur': 'Urdu', 'hi': 'Hindi', 'fa': 'Persian',
         'zh': 'Chinese', 'ja': 'Japanese', 'ko': 'Korean'}
    return m.get(language, language)

def run_openai(model_name, audio_file, language):
    import whisper
    md = models_dir()
    seed_old_whisper_cache(model_name, md)
    print("Loading Whisper model: %s (from %s)" % (model_name, md), flush=True)
    try:
        model = whisper.load_model(model_name, download_root=md)
    except Exception as e:
        print("ERROR: could not load model '%s'. If you chose a new model, update openai-whisper: pip install --upgrade openai-whisper" % model_name, flush=True)
        raise
    print("Transcribing: %s" % audio_file, flush=True)
    opts = {"word_timestamps": True, "verbose": False}  # verbose=False -> tqdm progress on stderr (Auto Edit reads it)
    if language:
        opts["language"] = language
    return model.transcribe(audio_file, **opts)

def run_qwen(audio_file, language):
    md = models_dir()
    model_path = os.path.join(md, 'Qwen3-ASR-1.7B')
    if not os.path.isdir(model_path):
        print("Qwen3-ASR model not found at: %s" % model_path, flush=True)
        print("Downloading Qwen/Qwen3-ASR-1.7B (~4GB) into the portable models folder (first run only)...", flush=True)
        try:
            from huggingface_hub import snapshot_download
            snapshot_download(repo_id='Qwen/Qwen3-ASR-1.7B', local_dir=model_path)
        except Exception:
            print("ERROR: automatic download failed. Please download Qwen/Qwen3-ASR-1.7B manually into: %s" % model_path, flush=True)
            raise
    try:
        import torch
        from qwen_asr import Qwen3ASRModel
    except Exception:
        print("ERROR: 'qwen-asr' package is not installed. Run: pip install qwen-asr", flush=True)
        raise
    print("Loading Qwen3-ASR 1.7B from: %s" % model_path, flush=True)
    aligner_path = os.path.join(md, 'Qwen3-ForcedAligner-0.6B')
    if not os.path.isdir(aligner_path):
        print("Forced-aligner model not found at: %s" % aligner_path, flush=True)
        print("Downloading Qwen/Qwen3-ForcedAligner-0.6B (~1.7GB) for word timestamps (first run only)...", flush=True)
        try:
            from huggingface_hub import snapshot_download
            snapshot_download(repo_id='Qwen/Qwen3-ForcedAligner-0.6B', local_dir=aligner_path)
        except Exception:
            print("ERROR: automatic download failed. Please download Qwen/Qwen3-ForcedAligner-0.6B manually into: %s" % aligner_path, flush=True)
            raise
    if torch.cuda.is_available():
        common = dict(dtype=torch.float16, device_map="cuda:0")
    else:
        common = dict(dtype=torch.float32, device_map="cpu")
    asr = Qwen3ASRModel.from_pretrained(model_path, forced_aligner=aligner_path,
                                        forced_aligner_kwargs=dict(common), **common)
    kwargs = {}
    lang = whisper_lang(language)
    if lang:
        kwargs['language'] = lang
    results = asr.transcribe(audio=audio_file, return_time_stamps=True, **kwargs)

    text = ""
    words = []
    if isinstance(results, list) and results:
        r = results[0]
        text = getattr(r, 'text', None) or ""
        ts = getattr(r, 'time_stamps', None) or []
        for w in ts:
            wt = getattr(w, 'text', None) or ""
            if not wt:
                continue
            words.append({'word': wt,
                          'start': float(getattr(w, 'start_time', None) or 0.0),
                          'end': float(getattr(w, 'end_time', None) or 0.0)})
    elif isinstance(results, dict):
        text = results.get('text') or ""
    elif results is not None:
        text = str(results)
    text = text.strip()
    if not text:
        print("ERROR: Qwen3-ASR returned an empty result", flush=True)

    if words:
        seg = {'text': text, 'start': words[0]['start'], 'end': words[-1]['end'], 'words': words}
    else:
        seg = {'text': text, 'start': 0.0, 'end': 0.0, 'words': []}
    return {'text': text, 'segments': [seg]}

def main():
    if len(sys.argv) < 2:
        print("Usage: run_whisper.py <audio_file> [model] [language]")
        sys.exit(1)

    audio_file = sys.argv[1]
    model_name = sys.argv[2] if len(sys.argv) > 2 else 'large-v3-turbo'
    language   = sys.argv[3] if len(sys.argv) > 3 else None
    models_arg = sys.argv[4] if len(sys.argv) > 4 else None
    if models_arg:
        global MODELS_DIR_OVERRIDE
        MODELS_DIR_OVERRIDE = models_arg
    ensure_models_dir()

    if not os.path.exists(audio_file):
        print("ERROR: File not found: %s" % audio_file)
        sys.exit(1)

    if model_name.startswith('qwen'):
        result = run_qwen(audio_file, language)
    else:
        result = run_openai(model_name, audio_file, language)

    out_path = os.path.splitext(audio_file)[0] + '.json'
    with open(out_path, 'w', encoding='utf-8') as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    print("DONE: %s" % out_path, flush=True)
    print("Models folder: %s" % models_dir(), flush=True)
    segs = result.get('segments', [])
    print("Segments: %d" % len(segs), flush=True)

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print("ERROR: %s" % e)
        import traceback
        traceback.print_exc()
        sys.exit(1)
