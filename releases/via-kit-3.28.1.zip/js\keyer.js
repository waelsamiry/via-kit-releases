// ── AI KEYER (panel) · 3.27.0 — CorridorKey (Corridor Digital, open source, free for commercial projects; not bundled) ──
// Installed per PC in C:\Via Studios Kit\CorridorKey. Flow: selected green-screen layer → ffmpeg cuts the range +
// makes a coarse alpha hint (chromakey) in ONE pass (same frame count) → CorridorKey CLI (visible CMD) → result NEXT TO
// the original video: ProRes 4444 + alpha (.mov, default) or FG + Matte EXR folders → imported over the original layer
// (parented), original switched off. Same shot + range + settings again = imports the existing result.
window.aiKeyer = (function () {
  var CK = 'C:\\Via Studios Kit\\CorridorKey';
  var ZIP = 'https://github.com/nikopueringer/CorridorKey/archive/refs/heads/main.zip';
  var busy = false;
  function $(id) { return document.getElementById(id); }
  function node() { return { fs: require('fs'), path: require('path'), cp: require('child_process'), os: require('os'), crypto: require('crypto') }; }
  function status(msg, kind) { var el = $('kyStatus'); if (el) { el.textContent = msg; el.className = 'ae-status' + (kind ? ' is-' + kind : ''); } }
  function evalP(code) { return new Promise(function (res) { new CSInterface().evalScript(code, function (r) { res(String(r || '')); }); }); }
  function q(p) { return String(p).replace(/%/g, '%%'); }
  function tmpf(n) { return node().path.join(node().os.tmpdir(), n); }
  function runBat(name, lines, wait) {
    var n = node(), bat = tmpf(name + '.bat');
    n.fs.writeFileSync(bat, '@echo off\r\nchcp 65001 > nul\r\n' + lines.join('\r\n') + '\r\n', 'utf8');
    return n.cp.spawn('cmd.exe', ['/c', 'start', '""'].concat(wait ? ['/wait'] : []).concat(['cmd.exe', '/c', bat]));
  }
  var KEYS = ['kyScreen', 'kyDespill', 'kyHint', 'kyMax', 'kyRange', 'kyOut', 'kyAi', 'kyHintSrc'];
  function save() { try { var o = {}; KEYS.forEach(function (k) { var e = $(k); if (e) o[k] = e.value; }); window.weloCfg.set('keyer_opts', JSON.stringify(o)); } catch (e) {} }
  function load() { try { var o = JSON.parse(window.weloCfg.get('keyer_opts') || '{}'); KEYS.forEach(function (k) { var e = $(k); if (e && o[k] !== undefined) e.value = o[k]; }); } catch (e) {} }

  // ── install / check ──
  function paths() {
    var p = node().path;
    return { cli: p.join(CK, 'corridorkey_cli.py'), py: p.join(CK, '.venv', 'Scripts', 'python.exe'),
             ckpt: p.join(CK, 'CorridorKeyModule', 'checkpoints'), clips: p.join(CK, 'ClipsForInference'), done: p.join(CK, '_via_jobs') };
  }
  function state() {
    if (typeof require !== 'function') return { ok: false, why: 'Node.js is off — restart After Effects' };
    var n = node(), P = paths();
    if (!n.fs.existsSync(P.cli)) return { ok: false, why: 'CorridorKey is not installed in ' + CK };
    if (!n.fs.existsSync(P.py)) return { ok: false, why: 'CorridorKey files are there but its setup did not finish (no .venv) — press Install again' };
    var w = []; try { w = n.fs.readdirSync(P.ckpt).filter(function (f) { return /\.(safetensors|pth)$/i.test(f); }); } catch (e) {}
    // 3.27.0 (A-10): CorridorKey is downloaded from its moving `main` branch and the kit depends on its CLI flags and
    // clip layout (both broke us before: L-028, 3.25.7). A newer/older copy without them → say so instead of failing mid-key.
    var miss = [];
    try { var cli = n.fs.readFileSync(P.cli, 'utf8'); ['--image-size', '--screen-color', '--skip-existing', 'run-inference'].forEach(function (f) { if (cli.indexOf(f) < 0) miss.push(f); }); } catch (e) {}
    try { if (n.fs.readFileSync(n.path.join(CK, 'clip_manager.py'), 'utf8').indexOf('AlphaHint') < 0) miss.push('AlphaHint folder'); } catch (e) {}
    if (miss.length) return { ok: true, warn: true, why: 'CorridorKey installed, but this version differs from the one the kit was tested with (May 2026) — missing: ' + miss.join(', ') + '. Keying may fail.' };
    return { ok: true, why: 'CorridorKey ready' + (w.length ? '' : ' (model downloads on the first key, ~300 MB)') };
  }
  function check() {
    var s = state(), el = $('kyState');
    if (el) { el.textContent = (s.warn ? '⚠ ' : s.ok ? '✓ ' : '✗ ') + s.why; el.className = 'ae-status' + (s.warn ? ' is-warn' : s.ok ? ' is-ok' : ' is-error'); }
    var b = $('kyInstallBtn'); if (b) b.textContent = s.ok ? 'Re-run CorridorKey setup' : 'Install CorridorKey (download + setup)';
    return s.ok;
  }
  function install() {
    if (typeof require !== 'function') return;
    var n = node(), parent = n.path.dirname(CK);
    try { n.fs.mkdirSync(parent, { recursive: true }); } catch (e) {}
    var lines = ['title Via Studios Kit - Install CorridorKey'];
    if (!n.fs.existsSync(paths().cli)) {
      lines = lines.concat([
        'echo Downloading CorridorKey from GitHub (open source, Corridor Digital)...',
        'powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference=\'Stop\'; $z=Join-Path $env:TEMP \'corridorkey.zip\'; Invoke-WebRequest -UseBasicParsing \'' + ZIP + '\' -OutFile $z; Expand-Archive -Force $z \'' + parent + '\'; if (Test-Path \'' + CK + '\') { Remove-Item -Recurse -Force \'' + CK + '\' }; Rename-Item (Join-Path \'' + parent + '\' \'CorridorKey-main\') \'CorridorKey\'"',
        'if errorlevel 1 (echo Download failed - check the internet connection & pause & exit /b 1)'
      ]);
    }
    lines = lines.concat(['cd /d "' + q(CK) + '"', 'call Install_CorridorKey_Windows.bat']);
    runBat('welo_ck_install', lines, true).on('close', function () { check(); });
    status('Installing CorridorKey in the CMD window (Python + packages + model, several minutes)…', 'working');
  }

  // ── key ──
  var lastDir = '';
  function opts() {
    return { screen: ($('kyScreen') || {}).value || 'green', despill: parseInt(($('kyDespill') || {}).value, 10) || 5,
             hint: parseFloat(($('kyHint') || {}).value) || 0.25, max: parseInt(($('kyMax') || {}).value, 10) || 1440,
             range: ($('kyRange') || {}).value || 'workarea', out: ($('kyOut') || {}).value || 'prores',
             ai: parseInt(($('kyAi') || {}).value, 10) || 1024, hintSrc: ($('kyHintSrc') || {}).value || 'auto' };
  }
  function writable(dir) { try { var n = node(); n.fs.accessSync(dir, n.fs.constants.W_OK); var f = n.path.join(dir, '.via_w' + Date.now()); n.fs.writeFileSync(f, ''); n.fs.unlinkSync(f); return true; } catch (e) { return false; } }
  function key() {
    if (busy) return;
    if (!check()) { status('Install CorridorKey first (button above)', 'error'); return; }
    save();
    var o = opts(), n = node(), P = paths();
    evalP('kyGetSelection(' + JSON.stringify(JSON.stringify({ useWorkArea: o.range === 'workarea' })) + ')').then(function (r) {
      if (r.indexOf('ERR:') === 0 || r === 'EvalScript error.') throw new Error(r.replace(/^ERR:/, ''));
      var s = JSON.parse(r);
      var layerHint = o.hintSrc === 'layer';                             // 3.26.0: the editor's Keylight + masks = the hint
      var fps = layerHint ? s.comp.fps : (s.src.fps || s.comp.fps);       // the hint is rendered at comp fps → Input too
      var short = Math.min(s.src.w, s.src.h);
      var sc = short > o.max ? o.max / short : 1;                         // cap the SHORT side (1440 = 2560×1440 / 1440×2560)
      var w = Math.round(s.src.w * sc / 2) * 2, h = Math.round(s.src.h * sc / 2) * 2;
      var id = n.crypto.createHash('md5').update([s.src.path, s.range.srcIn.toFixed(3), s.range.srcOut.toFixed(3), w, h, o.screen, o.despill, o.hint].join('|') + (o.ai !== 1024 ? '|ai' + o.ai : '') + '|h2').digest('hex').slice(0, 6) +
               (layerHint ? 'L' + Date.now().toString(36).slice(-4) : '');   // own hint = always a fresh job (effects may have changed)
      var job = 'VIA_' + id, clip = n.path.join(P.clips, job), cout = n.path.join(clip, 'Output');
      // results go NEXT TO the original video: <name>_AIkey_<id>.mov (ProRes 4444 + alpha) or <name>_AIkey_<id>\FG + Matte (EXR)
      var srcDir = n.path.dirname(s.src.path), base = n.path.basename(s.src.path).replace(/\.[^.]+$/, '');
      var outDir = writable(srcDir) ? srcDir : P.done, moved = outDir !== srcDir;
      if (moved) { try { n.fs.mkdirSync(outDir, { recursive: true }); } catch (e) {} }
      var stem = n.path.join(outDir, base + '_AIkey_' + id);
      var mov = stem + '.mov', exrDir = stem, fgDir = n.path.join(exrDir, 'FG'), mtDir = n.path.join(exrDir, 'Matte');
      lastDir = outDir;
      var frames = Math.max(1, Math.round((s.range.srcOut - s.range.srcIn) * fps));
      var imp = { layerIndex: s.layer.index, fps: fps, compIn: s.range.compIn, w: w, h: h, srcW: s.src.w, srcH: s.src.h,
                  scale: 100 * s.src.w / w, name: s.layer.name };
      function count(d) { try { return n.fs.readdirSync(d).filter(function (f) { return /\.exr$/i.test(f); }).length; } catch (e) { return 0; } }
      function size(f) { try { return n.fs.statSync(f).size; } catch (e) { return 0; } }
      function ready() { return o.out === 'prores' ? size(mov) > 0 : count(mtDir) >= frames - 1; }
      function doImport() {
        imp.mov = o.out === 'prores' ? mov : ''; imp.fg = fgDir; imp.matte = mtDir;
        status('Importing the key…', 'working');
        return evalP('kyImport(' + JSON.stringify(JSON.stringify(imp)) + ')').then(function (res) {
          if (res.indexOf('OK:') === 0) status('✓ Keyed "' + s.layer.name + '" — ' + frames + ' frames → ' + (o.out === 'prores' ? n.path.basename(mov) : n.path.basename(exrDir) + '\\') +
            (moved ? ' (video folder is read-only → saved in ' + outDir + ')' : ' next to the original video') + '. Original layer switched off. Ctrl+Z undoes the import.', 'ok');
          else status('⚠ ' + res.replace(/^ERR:/, ''), 'error');
        });
      }
      if (!layerHint && ready()) return doImport();                       // same shot + range + settings keyed before

      busy = true;
      // 3.25.5 — the heavy work (cut mp4s + thousands of EXR frames) lives NEXT TO THE VIDEO, not on C:
      // <video folder>\_AIkey_work\VIA_<id>, linked into CorridorKey's ClipsForInference by a junction
      // (CorridorKey only scans that one folder). Other VIA_* left there by failed runs are removed first —
      // CorridorKey processes every clip folder it finds, and broken ones made it fail (Wael 2026-11-03).
      var workRoot = moved ? P.done : n.path.join(srcDir, '_AIkey_work'), work = n.path.join(workRoot, job);
      var cutOk = n.path.join(workRoot, job + '.cutok'), linked = false;
      function rmTree(p) {
        try { if (n.fs.rmSync) return n.fs.rmSync(p, { recursive: true, force: true }); n.fs.rmdirSync(p, { recursive: true }); }
        catch (e) { try { n.cp.execSync('rmdir /s /q "' + p + '"', { windowsHide: true }); } catch (e2) {} }
      }
      function unlinkJunction(p) { try { n.fs.rmdirSync(p); } catch (e) { try { n.fs.unlinkSync(p); } catch (e2) {} } }
      try {
        n.fs.mkdirSync(P.clips, { recursive: true });
        n.fs.readdirSync(P.clips).forEach(function (f) {
          if (!/^VIA_/.test(f)) return;                                  // never touch the user's own clips
          var p = n.path.join(P.clips, f), st = n.fs.lstatSync(p);
          if (st.isSymbolicLink()) {
            unlinkJunction(p);                                           // its work folder stays next to its video → resumes later
          } else rmTree(p);                                              // old runs kept everything on C:
        });
      } catch (e) {}
      try {
        n.fs.mkdirSync(work, { recursive: true });
        try { n.cp.exec('attrib +h "' + workRoot + '"'); } catch (e) {}
        n.fs.symlinkSync(work, clip, 'junction'); linked = true;
        try { if (window.viaMaint) window.viaMaint.addWorkRoot(workRoot); } catch (e) {}   // 3.27.0: listed in Settings › Disk usage
      } catch (e) {
        n.fs.mkdirSync(clip, { recursive: true });                       // drive can't take a junction → work on C:
      }
      var ff = window.weloTools && window.weloTools.get('ffmpeg');
      if (!ff) throw new Error('ffmpeg not found — Settings › External tools');
      var pre = Promise.resolve(0);
      if (layerHint) {
        status('Rendering your hint (Keylight + masks) in After Effects…', 'working');
        pre = evalP('kyRenderHint(' + JSON.stringify(JSON.stringify({
          layerIndex: s.layer.index, srcIn: s.range.srcIn, dur: s.range.srcOut - s.range.srcIn, fps: fps, w: w, h: h,
          srcW: s.src.w, srcH: s.src.h, outDir: n.path.join(work, 'AlphaHint').replace(/\\/g, '/') })) + ')').then(function (r) {
          if (r.indexOf('OK:') !== 0) throw new Error(r.replace(/^ERR:/, ''));
          return parseInt(r.slice(3), 10);
        });
      }
      return pre.then(function (nHint) {
      if (nHint) frames = nHint;
      // one pass → same frames for Input and AlphaHint (CorridorKey refuses a frame-count mismatch)
      // rough hint (3.25.11): "screen colour dominates" — background only where G (or B) is clearly above the
      // other two channels. ffmpeg chromakey compared chroma only, so BLACK/grey (no chroma) was keyed out with the
      // screen → CorridorKey removed black clothes and beards (Wael 2026-11-03). Hint 0.25 → threshold 20/255.
      var thr = Math.max(4, Math.min(60, Math.round(o.hint * 80)));
      var mix = o.screen === 'blue' ? 'rr=-0.5:rg=-0.5:rb=1' : 'rr=-0.5:rg=1:rb=-0.5';
      var fc = '[0:v]fps=' + fps + ',scale=' + w + ':' + h + ':flags=lanczos,format=yuv420p,split[a][b];' +
               '[b]format=gbrp,colorchannelmixer=' + mix + ',extractplanes=r,lut=y=\'if(gt(val,' + thr + '),0,255)\',erosion,dilation,format=gray[m]';
      // own hint: Input only, exactly as many frames as the rendered hint (CorridorKey refuses a count mismatch)
      if (nHint) fc = '[0:v]fps=' + fps + ',scale=' + w + ':' + h + ':flags=lanczos,format=yuv420p,tpad=stop_mode=clone:stop_duration=2[a]';
      // CorridorKey layout (clip_manager.find_assets): <clip>\Input.mp4 + <clip>\AlphaHint\<video or frames>.
      // A loose AlphaHint.mp4 beside Input.mp4 is taken as "the main plate" and renamed OVER Input.mp4 (3.25.6).
      var inMp4 = n.path.join(clip, 'Input.mp4'), hintMp4 = n.path.join(clip, 'AlphaHint', 'AlphaHint.mp4');
      try { n.fs.mkdirSync(n.path.join(clip, 'AlphaHint'), { recursive: true }); } catch (e) {}
      var ckRun = ''; try { ckRun = n.path.join(new CSInterface().getSystemPath('extension'), 'audio_enhance', 'ck_run.py'); if (!n.fs.existsSync(ckRun)) ckRun = ''; } catch (e) { ckRun = ''; }
      var progCut = tmpf('welo_ck_cut_progress_' + id + '.txt'), progPr = tmpf('welo_ck_prores_progress_' + id + '.txt');   // per job (A-14)
      [progCut, progPr].forEach(function (f) { try { n.fs.unlinkSync(f); } catch (e) {} });
      function ffcmd(hw, enc) {     // -progress → the panel shows % of step 1 (3.25.4)
        return '"' + q(ff) + '" -hide_banner -loglevel error -nostats -progress "' + q(progCut) + '" -y ' + hw + '-ss ' + s.range.srcIn.toFixed(3) + ' -to ' + s.range.srcOut.toFixed(3) + ' -i "' + q(s.src.path) + '" -filter_complex "' + fc + '" ' +
          '-map "[a]" -an ' + enc + (nHint ? ' -frames:v ' + nHint : '') + ' -f mp4 "' + q(inMp4) + '.part"' +
          (nHint ? '' : ' -map "[m]" -an ' + enc + ' -f mp4 "' + q(hintMp4) + '.part"');
      }
      var lines = [
        'title Via Studios Kit - AI Keyer (CorridorKey)',
        // 3.24.1: GPU decode (NVDEC) + GPU encode (NVENC, near-lossless) — x264 on the CPU was the slow part.
        // Written as .part and renamed only when complete → a stopped run resumes without redoing this step.
        'if exist "' + q(cutOk) + '" goto ckrun',                     // step 1 finished before (marker, not just files)
        'del /q "' + q(inMp4) + '" "' + q(hintMp4) + '" "' + q(inMp4) + '.part" "' + q(hintMp4) + '.part" 2>nul',
        'echo [1/3] Cutting the shot and making the rough hint (GPU)...',
        ffcmd('-hwaccel cuda ', '-c:v h264_nvenc -preset p4 -tune hq -rc constqp -qp 12 -pix_fmt yuv420p'),
        // ffmpeg exits with a NEGATIVE code on Windows (e.g. -22) → `if errorlevel 1` is false. Check != 0 AND the files.
        'if %ERRORLEVEL% NEQ 0 goto cutcpu',
        'if not exist "' + q(inMp4) + '.part" goto cutcpu',
        'for %%F in ("' + q(inMp4) + '.part") do if %%~zF==0 goto cutcpu',
        'goto cutok',
        ':cutcpu',
        'echo    GPU encoder not available here (old NVIDIA driver?) - using the CPU instead, slower...',
        'del /q "' + q(inMp4) + '.part" "' + q(hintMp4) + '.part" 2>nul',
        ffcmd('', '-c:v libx264 -crf 8 -preset ultrafast -pix_fmt yuv420p'),
        'if %ERRORLEVEL% NEQ 0 (echo ffmpeg failed - see above & pause & exit /b 1)',
        'if not exist "' + q(inMp4) + '.part" (echo ffmpeg wrote nothing - see above & pause & exit /b 1)',
        ':cutok',
        'move /y "' + q(inMp4) + '.part" "' + q(inMp4) + '" > nul',
        'move /y "' + q(hintMp4) + '.part" "' + q(hintMp4) + '" > nul',
        'echo ok> "' + q(cutOk) + '"',
        ':ckrun',
        'echo [2/3] CorridorKey is keying (keep After Effects idle - no preview - while this runs)...',
        'cd /d "' + q(CK) + '"',
        // ck_run.py (kit) = CorridorKey's CLI with torch.compile mode "max-autotune-no-cudagraphs": the default
        // max-autotune fails on Windows → slow eager mode (3.25.10). Falls back to the plain CLI if the file is missing.
        (ckRun ? '"' + q(P.py) + '" "' + q(ckRun) + '" "' + q(CK) + '" --device cuda run-inference' : '"' + q(P.py) + '" corridorkey_cli.py --device cuda run-inference') + ' --srgb --despill ' + o.despill + ' --despeckle --refiner 1.0 --no-comp --gpu-post --no-tile --image-size ' + o.ai + ' --screen-color ' + o.screen + ' --skip-existing',   // --image-size is REQUIRED non-interactively (else None → crash, 3.25.7)
        'if %ERRORLEVEL% NEQ 0 (echo CorridorKey failed - see above & pause & exit /b 1)',
        'if not exist "' + q(n.path.join(cout, 'Matte')) + '\\*.exr" (echo CorridorKey made no frames for this shot - see the warnings above & pause & exit /b 1)'
      ];
      if (o.out === 'prores') {
        // FG = straight sRGB color, Matte = alpha → one ProRes 4444 with alpha (straight), 10-bit, much smaller than EXR
        lines = lines.concat([
          'echo [3/3] Writing ProRes 4444 with alpha next to the original video...',
          '"' + q(ff) + '" -hide_banner -loglevel error -y -framerate ' + fps + ' -start_number 0 -i "' + q(n.path.join(cout, 'FG', '%05d.exr')) + '" ' +
            '-framerate ' + fps + ' -start_number 0 -i "' + q(n.path.join(cout, 'Matte', '%05d.exr')) + '" ' +
            '-filter_complex "[0:v]format=rgb48le[c];[1:v]format=gray16le[m];[c][m]alphamerge,format=yuva444p10le[v]" -map "[v]" ' +
            '-progress "' + q(progPr) + '" -nostats -c:v prores_ks -profile:v 4444 -alpha_bits 16 -vendor apl0 -pix_fmt yuva444p10le -f mov "' + q(mov) + '.part"',
          // 3.26.2 (A-05): written as .part, renamed only on success — a half-written .mov was imported as "keyed before"
          'if %ERRORLEVEL% NEQ 0 (del /q "' + q(mov) + '.part" 2>nul & echo ProRes export failed - the EXR frames are kept in "' + q(cout) + '" & pause & exit /b 1)',
          'move /y "' + q(mov) + '.part" "' + q(mov) + '" > nul'
        ]);
      } else {
        lines = lines.concat([
          'echo [3/3] Moving the EXR frames next to the original video...',
          'robocopy "' + q(n.path.join(cout, 'FG')) + '" "' + q(fgDir) + '" /E /MOVE /NFL /NDL /NJH /NJS /NP > nul',
          'if errorlevel 8 (echo Copy failed & pause & exit /b 1)',
          'robocopy "' + q(n.path.join(cout, 'Matte')) + '" "' + q(mtDir) + '" /E /MOVE /NFL /NDL /NJH /NJS /NP > nul',
          'if errorlevel 8 (echo Copy failed & pause & exit /b 1)'
        ]);
      }
      lines = lines.concat(['cd /d "' + q(CK) + '"'].concat(linked ? [
        'rmdir /s /q "' + q(work) + '"', 'rmdir "' + q(clip) + '" 2>nul', 'del /q "' + q(cutOk) + '" 2>nul', 'rmdir "' + q(workRoot) + '" 2>nul'
      ] : ['rmdir /s /q "' + q(clip) + '"', 'del /q "' + q(cutOk) + '" 2>nul']).concat(['echo Done.']));
      function ffFrame(f) {        // last "frame=N" written by ffmpeg -progress
        try { var m = n.fs.readFileSync(f, 'utf8').match(/frame=(\d+)/g); return m ? +m[m.length - 1].slice(6) : 0; } catch (e) { return -1; }
      }
      function pct(a) { return Math.min(100, Math.round(100 * a / Math.max(1, frames))) + '%'; }
      var poll = setInterval(function () {
        var c = count(n.path.join(cout, 'Matte')), msg;
        if (c >= frames - 1) {
          var pf = ffFrame(progPr);
          msg = o.out === 'prores' ? 'Step 3/3 · Writing ProRes 4444… ' + (pf > 0 ? pct(pf) : '') : 'Step 3/3 · Moving EXR frames…';
        } else if (c > 0) {
          msg = 'Step 2/3 · Keying… ' + pct(c) + '  (' + c + ' / ' + frames + ' frames)';
        } else {
          var cf = ffFrame(progCut);
          msg = cf >= 0 && cf < frames - 1 ? 'Step 1/3 · Preparing the shot… ' + pct(cf) : 'Step 2/3 · Loading CorridorKey… (first frame takes a while)';
        }
        status(msg, 'working');
      }, 1000);
      status('Started — watch the CMD window. Keep After Effects idle (no preview) until it finishes.' +
             (linked ? '' : ' (work files on C: — the video\'s drive refused a link)'), 'working');
      runBat('welo_ck_key_' + id, lines, true).on('close', function () {
        clearInterval(poll); busy = false;
        [progCut, progPr, tmpf('welo_ck_key_' + id + '.bat')].forEach(function (f) { try { n.fs.unlinkSync(f); } catch (e) {} });
        if (ready()) doImport();
        else status('⚠ Keying did not finish — see the CMD window.' + (layerHint ? '' : ' Frames so far are kept; press Key again to resume.'), 'error');
      });
      });
    }).catch(function (e) { busy = false; status('⚠ ' + (e.message || e), 'error'); });
  }
  function openJobs() { try { node().cp.exec('explorer "' + (lastDir || paths().done) + '"'); } catch (e) {} }
  function init() {
    if (!$('tab-keyer')) return;
    load();
    KEYS.forEach(function (k) { var e = $(k); if (e) e.addEventListener('change', save); });
  }
  return { init: init, check: check, install: install, key: key, openJobs: openJobs, isBusy: function () { return busy; } };
})();
if (window.WeloInit) window.WeloInit.add(function () { window.aiKeyer.init(); });
