// ── MAINTENANCE (panel) · 3.27.0 — docs/AUDIT-2026-11.md A-13 + A-15 ────────────────────────────────────────
// Settings › Maintenance:
//  • Disk usage — what the kit leaves on disk (temp folders of failed audio/montage runs, preview frames, AI Keyer work
//    folders next to the videos (_AIkey_work, hidden), CorridorKey job folders) with sizes + Clean.
//    Something still in use is never removed: temp items younger than 2 h are skipped, AI Keyer items while it runs.
//  • Copy debug info — version, AE, Windows, GPU-less basics, Python, tools + the last 80 log lines → clipboard.
window.viaMaint = (function () {
  var CK = 'C:\\Via Studios Kit\\CorridorKey', AGE = 2 * 3600 * 1000;
  function $(id) { return document.getElementById(id); }
  function node() { return { fs: require('fs'), path: require('path'), os: require('os') }; }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function human(b) { return b > 1073741824 ? (b / 1073741824).toFixed(1) + ' GB' : b > 1048576 ? Math.round(b / 1048576) + ' MB' : Math.round(b / 1024) + ' KB'; }
  function size(p, depth) {             // bytes under p (never follows junctions / links)
    var n = node(), t = 0, st;
    try { st = n.fs.lstatSync(p); } catch (e) { return 0; }
    if (st.isSymbolicLink()) return 0;
    if (!st.isDirectory()) return st.size;
    if ((depth || 0) > 8) return 0;
    try { n.fs.readdirSync(p).forEach(function (f) { t += size(n.path.join(p, f), (depth || 0) + 1); }); } catch (e) {}
    return t;
  }
  function rm(p) {
    var n = node();
    try { if (n.fs.lstatSync(p).isSymbolicLink()) { try { n.fs.rmdirSync(p); } catch (e) { n.fs.unlinkSync(p); } return true; } } catch (e) { return false; }
    try { n.fs.rmSync ? n.fs.rmSync(p, { recursive: true, force: true }) : n.fs.rmdirSync(p, { recursive: true }); return true; } catch (e) { return false; }
  }
  function old(p) { try { return Date.now() - node().fs.statSync(p).mtimeMs > AGE; } catch (e) { return false; } }
  function keyerBusy() { try { return !!(window.aiKeyer && window.aiKeyer.isBusy && window.aiKeyer.isBusy()); } catch (e) { return false; } }

  // AI Keyer registers every _AIkey_work folder it creates (they sit next to the videos, on any drive)
  function workRoots() { try { return JSON.parse(window.weloCfg.get('ky_work_roots') || '[]'); } catch (e) { return []; } }
  function addWorkRoot(p) {
    try { var a = workRoots(); if (a.indexOf(p) < 0) { a.push(p); window.weloCfg.set('ky_work_roots', JSON.stringify(a.slice(-200))); } } catch (e) {}
  }

  function scan() {
    var n = node(), tmp = n.os.tmpdir(), items = [];
    function add(label, p, kind) { var b = size(p); if (b > 0) items.push({ label: label, path: p, bytes: b, kind: kind }); }
    try {
      n.fs.readdirSync(tmp).forEach(function (f) {
        var p = n.path.join(tmp, f);
        if (/^welo_(enh|mt)_/.test(f)) add('Audio/Montage temp (failed run)', p, 'temp');
        else if (/^welo_.*\.(wav|log|txt|json|bat)$/i.test(f)) add('Kit temp file', p, 'temp');
        else if (f === 'via-preview') add('Preview frames', p, 'temp');
        else if (f === 'welo_ffmpeg_x' || f === 'welo_ffmpeg.zip' || f === 'corridorkey.zip') add('Download leftovers', p, 'temp');
      });
    } catch (e) {}
    var clips = n.path.join(CK, 'ClipsForInference');
    try { n.fs.readdirSync(clips).forEach(function (f) { if (/^VIA_/.test(f)) add('AI Keyer job (CorridorKey folder)', n.path.join(clips, f), 'keyer'); }); } catch (e) {}
    add('AI Keyer results (read-only video folders)', n.path.join(CK, '_via_jobs'), 'keyer-results');
    var keep = [];
    workRoots().forEach(function (r) {
      if (!n.fs.existsSync(r)) return;
      keep.push(r);
      add('AI Keyer work next to video', r, 'keyer');
    });
    try { window.weloCfg.set('ky_work_roots', JSON.stringify(keep)); } catch (e) {}
    return items;
  }

  function render() {
    var box = $('maintDisk'); if (!box) return;
    if (typeof require !== 'function') { box.innerHTML = '<div class="ae-status is-warn">Node.js is off — restart After Effects</div>'; return; }
    box.innerHTML = '<div class="ae-status is-working">Scanning…</div>';
    setTimeout(function () {
      var items = scan(), total = 0;
      if (!items.length) { box.innerHTML = '<div class="ae-status is-ok">✓ Nothing left behind</div>'; return; }
      var h = '';
      items.forEach(function (it, i) {
        total += it.bytes;
        h += '<div class="maint-row"><div class="maint-txt"><b>' + human(it.bytes) + '</b> · ' + esc(it.label) +
             '<div class="maint-path" title="' + esc(it.path) + '">' + esc(it.path) + '</div></div>' +
             '<button class="btn-mini" data-i="' + i + '">' + (it.kind === 'keyer-results' ? 'Open' : 'Clean') + '</button></div>';
      });
      box.innerHTML = '<div style="font-size:9px;margin-bottom:4px">Total <b>' + human(total) + '</b></div>' + h +
        '<button class="btn-secondary" id="maintCleanAll" style="width:100%;margin-top:4px">Clean all (keeps AI Keyer results)</button>';
      box.querySelectorAll('button[data-i]').forEach(function (b) {
        b.onclick = function () { var it = items[+b.getAttribute('data-i')]; if (it.kind === 'keyer-results') open(it.path); else clean([it]); };
      });
      $('maintCleanAll').onclick = function () { clean(items.filter(function (x) { return x.kind !== 'keyer-results'; })); };
    }, 30);
  }
  function clean(list) {
    var done = 0, skipped = 0, freed = 0;
    list.forEach(function (it) {
      if (it.kind === 'temp' && !old(it.path)) { skipped++; return; }          // may belong to a job running now
      if (it.kind === 'keyer' && keyerBusy()) { skipped++; return; }
      if (rm(it.path)) { done++; freed += it.bytes; } else skipped++;
    });
    try { window.showToast('🧹 Freed ' + human(freed) + (skipped ? ' · ' + skipped + ' item(s) in use / newer than 2 h kept' : '')); } catch (e) {}
    try { window.viaLog.info('maint', 'cleaned ' + done + ' items, ' + human(freed) + ', skipped ' + skipped); } catch (e) {}
    render();
  }
  function open(p) { try { require('child_process').spawn('explorer.exe', [p], { detached: true, stdio: 'ignore' }).unref(); } catch (e) {} }

  // ── Copy debug info ──
  function copyText(t) {
    var ta = document.createElement('textarea'); ta.value = t; ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select(); var ok = false; try { ok = document.execCommand('copy'); } catch (e) {}
    document.body.removeChild(ta); return ok;
  }
  function debugInfo() {
    var lines = ['Via Studios Kit — debug info', 'Time: ' + new Date().toString()];
    try {
      var cs = new CSInterface(), env = cs.getHostEnvironment(), n = node();
      var man = n.fs.readFileSync(n.path.join(cs.getSystemPath('extension'), 'CSXS', 'manifest.xml'), 'utf8');
      lines.push('Kit: ' + ((man.match(/ExtensionBundleVersion="([^"]+)"/) || [])[1] || '?') + ' · folder: ' + cs.getSystemPath('extension'));
      lines.push('Host: ' + env.appName + ' ' + env.appVersion + ' · CEP ' + (cs.getCurrentApiVersion ? JSON.stringify(cs.getCurrentApiVersion()) : '?'));
      lines.push('Windows: ' + n.os.release() + ' · RAM ' + Math.round(n.os.totalmem() / 1073741824) + ' GB · CPU ' + ((n.os.cpus()[0] || {}).model || '?') + ' ×' + n.os.cpus().length);
      lines.push('Node: ' + process.version);
    } catch (e) { lines.push('Env: ' + e.message); }
    try { ['ffmpeg', 'ffprobe', 'yt-dlp'].forEach(function (t) { lines.push(t + ': ' + ((window.weloTools && window.weloTools.get(t)) || 'not found')); }); } catch (e) {}
    try { lines.push('CorridorKey: ' + (node().fs.existsSync(CK + '\\.venv\\Scripts\\python.exe') ? 'installed' : 'not installed')); } catch (e) {}
    lines.push('Log: ' + (window.viaLog ? window.viaLog.path() : '?'), '', '--- last 80 log lines ---');
    return lines.concat(window.viaLog ? window.viaLog.tail(80) : []).join('\n');
  }
  function copyDebug() {
    var t = debugInfo();
    var finish = function (py) {
      if (py) t = t.replace('--- last 80', 'Python: ' + py + '\n\n--- last 80');
      try { window.showToast(copyText(t) ? '📋 Debug info copied — paste it in the chat' : '⚠ Could not copy — open the log: ' + window.viaLog.path()); } catch (e) {}
    };
    try { new CSInterface().evalScript('getPythonPath()', function (r) { finish(String(r || '')); }); } catch (e) { finish(''); }
  }
  function openLog() { try { open(require('path').dirname(window.viaLog.path())); } catch (e) {} }

  return { scan: scan, render: render, addWorkRoot: addWorkRoot, copyDebug: copyDebug, openLog: openLog };
})();
