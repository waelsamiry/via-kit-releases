#!/usr/bin/env python3
"""
Via Studios Kit — Audio Enhancer v3 (3.22.0 Auto mode, docs/AUDIO-PLAN.md + AUDIO-REVIEW.md)
Usage: python enhance.py <input> <output> [opts.json | inline json]

Pipeline (each stage optional, all local + free):
  1 music    Demucs htdemucs_ft  — only when there is music under the voice
  2 denoise  DeepFilterNet3 (steady noise: AC, hum)  |  MossFormer2_SE_48K / ClearerVoice (crowd, babble)
  3 dereverb UVR DeEcho-DeReverb via audio-separator (room echo)
  4 gate     Silero VAD → lowers the level between phrases (never cuts: length stays = video sync)
  5 mix      blend some original back (less "robotic")
  6 polish   ffmpeg: high-pass, de-mud, presence, air, de-esser, compressor, limiter
  7 loudness ffmpeg loudnorm two-pass (true peak -1.5 dB) — replaces pyloudnorm (could clip)
Works at 48 kHz mono (DeepFilterNet/MossFormer native rate). Output length == input length.
Log protocol for the panel: "WELO_STEP:<id>:<state>" lines, "WELO_DONE:<path>", "WELO_ERROR:<msg>".
"""
import sys, os, json, traceback, subprocess, tempfile, shutil
import numpy as np

SR = 48000
_HERE = os.path.dirname(os.path.abspath(__file__))
_YT = os.path.join(os.path.dirname(_HERE), 'ytdl')
_FF = os.environ.get('WELO_FFMPEG_DIR', '')
if _FF and os.path.exists(os.path.join(_FF, 'ffmpeg.exe')):
    os.environ['PATH'] = _FF + os.pathsep + os.environ.get('PATH', '')
elif os.path.exists(os.path.join(_YT, 'ffmpeg.exe')):
    os.environ['PATH'] = _YT + os.pathsep + os.environ.get('PATH', '')


def _tofile(msg):
    lf = os.environ.get('WELO_LOG', '')                    # panel shows this file's tail when something fails
    if lf:
        try:
            with open(lf, 'a', encoding='utf-8') as f:
                f.write(msg + '\n')
        except Exception:
            pass


def log(msg):
    try:
        print(msg, flush=True)
    except Exception:                                        # console can't print some chars (Arabic names)
        print(msg.encode('ascii', 'replace').decode(), flush=True)
    _tofile(msg)


def step(sid, state):
    line = "WELO_STEP:%s:%s" % (sid, state)
    print(line, flush=True)
    pf = os.environ.get('WELO_PROGRESS', '')               # panel polls this file for real progress
    if pf:
        try:
            with open(pf, 'a', encoding='utf-8') as f:
                f.write(line + '\n')
        except Exception:
            pass


def models_root():
    for d in (os.environ.get('WELO_MODELS_DIR', ''), r'C:\Via Studios Kit\Audio\models',
              os.path.join(os.environ.get('APPDATA', os.path.expanduser('~')), 'Via Studios Kit', 'Audio', 'models')):
        if d:
            try:
                os.makedirs(d, exist_ok=True); return d
            except Exception:
                pass
    return tempfile.gettempdir()


def ffmpeg():
    for d in (os.environ.get('WELO_FFMPEG_DIR', ''), _YT):
        c = os.path.join(d, 'ffmpeg.exe') if d else ''
        if c and os.path.exists(c):
            return c
    return 'ffmpeg'


def ff(args, what):
    r = subprocess.run([ffmpeg(), '-hide_banner', '-y'] + args, capture_output=True)
    if r.returncode != 0:
        raise RuntimeError('ffmpeg %s: %s' % (what, r.stderr.decode(errors='ignore')[-300:]))
    return r.stderr.decode(errors='ignore')


def load(path, tmp):
    import soundfile as sf
    wav = os.path.join(tmp, 'in48.wav')
    ff(['-i', path, '-vn', '-ac', '1', '-ar', str(SR), '-c:a', 'pcm_f32le', wav], 'decode')
    a, sr = sf.read(wav, dtype='float32')
    if a.ndim > 1:
        a = a.mean(axis=1)
    return a.astype(np.float32)


def save(a, path):
    import soundfile as sf
    sf.write(path, np.clip(a, -1, 1).astype(np.float32), SR, subtype='FLOAT')


def fit(a, n):
    a = np.asarray(a, dtype=np.float32).reshape(-1)
    return a[:n] if len(a) >= n else np.pad(a, (0, n - len(a)))


def resample(a, src, dst):
    if src == dst:
        return a
    import torch, torchaudio
    return torchaudio.functional.resample(torch.from_numpy(a), src, dst).numpy().astype(np.float32)


def device():
    try:
        import torch
        return 'cuda' if torch.cuda.is_available() else 'cpu'
    except Exception:
        return 'cpu'


# ── 1 music ────────────────────────────────────────────────
def demucs(a):
    import torch
    from demucs.pretrained import get_model
    from demucs.apply import apply_model
    m = get_model('htdemucs_ft').to(device()).eval()
    x = resample(a, SR, m.samplerate)
    t = torch.from_numpy(x).float()[None, None].repeat(1, 2, 1).to(device())
    with torch.no_grad():
        src = apply_model(m, t, overlap=0.25)
    v = src[0, m.sources.index('vocals')].mean(0).cpu().numpy()
    return fit(resample(v, m.samplerate, SR), len(a))


# ── 2 denoise ──────────────────────────────────────────────
def deepfilter(a, max_db):
    import torch
    from df.enhance import enhance, init_df
    model, st, _ = init_df()
    lim = None if max_db >= 60 else float(max_db)          # real dB now (was slider*6 → 120 dB = unlimited)
    out = enhance(model, st, torch.from_numpy(a)[None], atten_lim_db=lim)
    return fit(out.squeeze().cpu().numpy(), len(a))


def mossformer(a, tmp):
    from clearvoice import ClearVoice
    p = os.path.join(tmp, 'mf_in.wav'); save(a, p)
    # ClearVoice downloads to a RELATIVE 'checkpoints' folder → run it from the models folder (the panel's cwd may be
    # Program Files / AE's folder = "Access is denied")
    cvdir = os.path.join(models_root(), 'clearvoice'); os.makedirs(cvdir, exist_ok=True)
    old = os.getcwd(); os.chdir(cvdir)
    try:
        cv = ClearVoice(task='speech_enhancement', model_names=['MossFormer2_SE_48K'])
        out = cv(input_path=p, online_write=False)
    finally:
        os.chdir(old)
    if isinstance(out, dict):
        out = list(out.values())[0]
    return fit(np.asarray(out, dtype=np.float32), len(a))


# 2b Sidon (sarulab-speech/sidon-v0.1, MIT): generative restoration — re-synthesises ONLY the speech at 48 kHz
#    (removes horns, motorbikes, traffic, reverb; like Adobe Podcast Enhance). Port of the official demo.
def sidon(a):
    import torch, torchaudio
    os.environ.setdefault('HF_HOME', os.path.join(models_root(), 'hf'))
    from huggingface_hub import hf_hub_download
    from transformers import SeamlessM4TFeatureExtractor
    dev = device()
    tag = 'cuda' if dev == 'cuda' else 'cpu'
    def get(fn):          # offline first; internet only the first time (one-time ~1 GB download)
        try:
            return hf_hub_download('sarulab-speech/sidon-v0.1', fn, local_files_only=True)
        except Exception:
            log('  sidon: first run - downloading %s (one time only)' % fn)
            return hf_hub_download('sarulab-speech/sidon-v0.1', fn)
    fe = torch.jit.load(get('feature_extractor_%s.pt' % tag), map_location=dev).to(dev)
    dec = torch.jit.load(get('decoder_%s.pt' % tag), map_location=dev).to(dev)
    try:
        pre = SeamlessM4TFeatureExtractor.from_pretrained('facebook/w2v-bert-2.0', local_files_only=True)
    except Exception:
        pre = SeamlessM4TFeatureExtractor.from_pretrained('facebook/w2v-bert-2.0')
    peak = float(np.abs(a).max()) or 1.0
    w = torch.from_numpy(0.9 * a / peak).float().view(1, -1)
    w = torchaudio.functional.highpass_biquad(w, SR, 50)
    w16 = torch.nn.functional.pad(torchaudio.functional.resample(w, SR, 16000), (0, 24000))
    outs, cache = [], None
    chunks = w16.view(-1).split(16000 * 96)
    with torch.inference_mode():
        for i, ch in enumerate(chunks):
            inp = pre(torch.nn.functional.pad(ch, (160, 160)), sampling_rate=16000, return_tensors='pt')
            f = fe(inp['input_features'].to(dev))['last_hidden_state']
            if cache is not None:
                f = torch.cat([cache, f], dim=1)
            outs.append(dec(f.transpose(1, 2)).view(-1)[:-960].float().cpu())
            cache = f[:, -1:]
            log('  sidon: chunk %d/%d' % (i + 1, len(chunks)))
    y = torch.cat(outs).numpy().astype(np.float32)
    return fit(y, len(a))


# ── audio-separator runner (UVR / Roformer models, downloaded once to <models>\separator) ──
def separate(a, tmp, model, keep, tag, avoid=()):
    from audio_separator.separator import Separator
    import soundfile as sf
    d = os.path.join(tmp, tag); os.makedirs(d, exist_ok=True)
    p = os.path.join(d, tag + '_in.wav'); save(a, p)
    mdir = os.path.join(models_root(), 'separator'); os.makedirs(mdir, exist_ok=True)
    sep = Separator(output_dir=d, output_format='WAV', model_file_dir=mdir)
    sep.load_model(model_filename=model)
    files = sep.separate(p)
    files = [f if os.path.isabs(f) else os.path.join(d, f) for f in files]
    name = lambda f: os.path.basename(f).lower()
    ok = [f for f in files if not any(x in name(f) for x in avoid)]
    hit = [f for f in ok if any(k in name(f) for k in keep)]
    if not hit:
        raise RuntimeError('%s: no "%s" stem in %s' % (model, keep[0], [os.path.basename(f) for f in files]))
    pick = hit[0]
    log('  %s -> %s' % (model, os.path.basename(pick)))
    y, sr = sf.read(pick, dtype='float32')
    if y.ndim > 1:
        y = y.mean(axis=1)
    return fit(resample(y, sr, SR), len(a))


# 1b voice isolation: BS-Roformer keeps only the voice (removes horns, traffic, music, FX)
def roformer(a, tmp):
    return separate(a, tmp, 'model_bs_roformer_ep_317_sdr_12.9755.ckpt', ('(vocals)', 'vocals'), 'iso', ('instrument',))


# 1c crowd remover (aufr33 + viperx Mel-Roformer): takes audience / babble / applause out, keeps the speaker
def crowd(a, tmp):
    return separate(a, tmp, 'mel_band_roformer_crowd_aufr33_viperx_sdr_8.7144.ckpt', ('(other)', 'other', 'vocals', 'speech'), 'crowd', ('crowd',))


# 2c Roformer denoise (aufr33, aggressive) — mask-based, strong on mixed street noise
def rofdenoise(a, tmp, aggressive=True):
    m = 'denoise_mel_band_roformer_aufr33_aggr_sdr_27.9768.ckpt' if aggressive else 'denoise_mel_band_roformer_aufr33_sdr_27.9959.ckpt'
    return separate(a, tmp, m, ('(dry)', 'dry', '(vocals)', 'vocals'), 'dn', ('noise', 'instrument'))


# ── 3 dereverb ─────────────────────────────────────────────
# 3.22: anvuew Mel-Roformer de-reverb (vocal room reverb, SDR 19.2 / less-aggressive 18.8) replaces the old
# UVR-DeEcho-DeReverb (VR arch, trained on sung vocals — thinned speech). Old one stays as fallback.
DEREVERB = {'strong': 'dereverb_mel_band_roformer_anvuew_sdr_19.1729.ckpt',
            'light': 'dereverb_mel_band_roformer_less_aggressive_anvuew_sdr_18.8050.ckpt'}


def dereverb(a, tmp, strength='strong'):
    keep, avoid = ('noreverb', 'no reverb', 'no_reverb', 'dry', 'no echo'), ()
    try:
        return separate(a, tmp, DEREVERB.get(strength, DEREVERB['strong']), keep, 'drv', avoid), 'Roformer de-reverb' + (' (light)' if strength == 'light' else '')
    except Exception as e:
        log('  Roformer de-reverb failed (%s) -> UVR DeEcho' % e)
        return separate(a, tmp, 'UVR-DeEcho-DeReverb.pth', keep, 'drv2', avoid), 'UVR DeEcho (fallback)'


# ── 0 declip ───────────────────────────────────────────────
def clip_ratio(a):
    peak = float(np.abs(a).max()) if len(a) else 0.0
    if peak < 0.5:
        return 0.0
    hot = np.abs(a) >= peak * 0.999
    runs = hot[1:] & hot[:-1]                                # flat tops (2+ samples at the peak) = clipping
    return float(runs.sum()) / len(a)


def declip(a, tmp):
    p = os.path.join(tmp, 'dc_in.wav'); q = os.path.join(tmp, 'dc_out.wav'); save(a, p)
    ff(['-i', p, '-af', 'adeclip', '-c:a', 'pcm_f32le', q], 'declip')
    import soundfile as sf
    y, _ = sf.read(q, dtype='float32')
    return fit(y if y.ndim == 1 else y.mean(axis=1), len(a))


# ── 4 gate (keeps length) ──────────────────────────────────
def gate(a, depth_db):
    import torch
    try:
        from silero_vad import load_silero_vad, get_speech_timestamps as ts
        m = load_silero_vad()
    except ImportError:   # 3.27.0 (A-10): no torch.hub fallback any more - it downloaded and ran GitHub code
        raise RuntimeError('silero-vad is not installed - Settings > Python libraries > silero-vad (or run install_libs.bat)')
    x16 = resample(a, SR, 16000)                            # Silero only supports 8/16 kHz
    stamps = ts(torch.from_numpy(x16), m, sampling_rate=16000)
    floor = 10 ** (-depth_db / 20.0)
    env = np.full(len(a), floor, dtype=np.float32)
    pad = int(0.15 * SR)
    for s in stamps:
        i0 = max(0, int(s['start'] * 3) - pad); i1 = min(len(a), int(s['end'] * 3) + pad)   # 16k → 48k
        env[i0:i1] = 1.0
    k = int(0.03 * SR)                                       # 30 ms ramps, no clicks
    env = np.convolve(env, np.ones(k, dtype=np.float32) / k, mode='same')
    log("  gate: %d speech regions, floor -%d dB" % (len(stamps), depth_db))
    return a * env


# ── 6+7 polish + loudness (ffmpeg) ─────────────────────────
POLISH = ('highpass=f=80,'
          'equalizer=f=300:t=q:w=1:g=-3,'
          'equalizer=f=4500:t=q:w=1:g=2.5,'
          'highshelf=f=10000:g=2,'
          'deesser=i=0.35,'
          'acompressor=threshold=-20dB:ratio=3:attack=5:release=80:makeup=2,'
          'alimiter=limit=0.89:level=false:latency=1')   # latency=1: no 5 ms delay (sync)


def finish(src, out_path, polish, normalize, lufs, n):
    chain = POLISH if polish else ''
    if normalize:
        stats = ff(['-i', src, '-af', (chain + ',' if chain else '') +
                    'loudnorm=I=%s:TP=-1.5:LRA=11:print_format=json' % lufs, '-f', 'null', '-'], 'measure')
        j = json.loads(stats[stats.rfind('{'):stats.rfind('}') + 1])
        ln = ('loudnorm=I={I}:TP=-1.5:LRA=11:measured_I={mi}:measured_TP={mtp}:measured_LRA={mlra}:'
              'measured_thresh={mt}:offset={off}:linear=true').format(
            I=lufs, mi=j['input_i'], mtp=j['input_tp'], mlra=j['input_lra'], mt=j['input_thresh'], off=j['target_offset'])
        chain = (chain + ',' if chain else '') + ln
        log("  loudness: %s LUFS -> %s LUFS" % (j['input_i'], lufs))
    args = ['-i', src]
    if chain:
        args += ['-af', chain]
    tmp_out = src[:-4] + '_fx.wav'
    ff(args + ['-ar', str(SR), '-c:a', 'pcm_f32le', tmp_out], 'encode')
    import soundfile as sf
    y, _ = sf.read(tmp_out, dtype='float32')
    if y.ndim > 1:
        y = y.mean(axis=1)
    if abs(len(y) - n) > 1:
        log('  length fix: %d -> %d samples' % (len(y), n))     # loudnorm/filters may pad or drop a few ms
    sf.write(out_path, np.clip(fit(y, n), -1, 1), SR, subtype='PCM_24')   # always WAV 24-bit 48k, length == input


# ── AUTO: diagnose the file, then choose the chain (3.22.0 · docs/AUDIO-REVIEW.md) ──────────────
def _vad_probs(x48):
    """Silero speech probability every 32 ms (512 samples @16 kHz = 1536 @48 kHz)."""
    import torch
    try:
        from silero_vad import load_silero_vad
        m = load_silero_vad()
    except ImportError:   # 3.27.0 (A-10): no torch.hub fallback
        raise RuntimeError('silero-vad is not installed - Settings > Python libraries > silero-vad (or run install_libs.bat)')
    x16 = torch.from_numpy(resample(x48, SR, 16000))
    m.reset_states()
    out = []
    with torch.no_grad():
        for i in range(0, len(x16) - 511, 512):
            out.append(float(m(x16[i:i + 512], 16000)))
    return np.array(out, dtype=np.float32)


def diagnose(a):
    """Measures what is wrong with THIS recording. Every number is logged; decisions come from plan()."""
    d = {'dur': len(a) / SR, 'clip': clip_ratio(a)}
    x = a
    if d['dur'] > 240:                                       # long file: 8 × 30 s spread over it
        L, starts = 30 * SR, np.linspace(0, len(a) - 30 * SR, 8).astype(int)
        x = np.concatenate([a[s:s + L] for s in starts])
    p = _vad_probs(x)
    H, N = 1536, 2048
    nfr = min(len(p), (len(x) - N) // H)
    if nfr < 60:
        d['ok'] = False; return d
    p = p[:nfr]
    win = np.hanning(N).astype(np.float32)
    fr = np.lib.stride_tricks.as_strided(x, (nfr, N), (x.strides[0] * H, x.strides[0]))
    P = np.abs(np.fft.rfft(fr * win, axis=1)) ** 2          # [frames, bins]
    f = np.fft.rfftfreq(N, 1.0 / SR)
    band = (f >= 60) & (f <= 20000)
    E = P[:, band].sum(axis=1) + 1e-12
    sp = p > 0.6
    # noise = pauses far enough from speech that the room's echo tail has died (±0.5 s, then ±0.1 s if too few)
    nz = None
    for wdt in (31, 7):
        dil = np.convolve(sp.astype(float), np.ones(wdt), 'same') > 0
        cand = (p < 0.2) & ~dil
        if cand.sum() >= 30:
            nz = cand; break
    if nz is None:                                           # almost no pauses: quietest 10 % of frames
        nz = E <= np.percentile(E, 10)
    d['speech_s'] = float(sp.sum() * H / SR); d['noise_s'] = float(nz.sum() * H / SR)
    if sp.sum() < 30:
        d['ok'] = False; return d
    Pn, Ps = float(E[nz].mean()), float(E[sp].mean())
    d['snr'] = 10 * np.log10(max(Ps - Pn, 1e-12) / Pn)
    # noise character
    edges = np.geomspace(60, 20000, 25)
    Bn = np.stack([P[nz][:, (f >= edges[i]) & (f < edges[i + 1])].sum(axis=1) for i in range(24)], axis=1) + 1e-12
    BdB = 10 * np.log10(Bn)
    loud = BdB.mean(axis=0) > (BdB.mean(axis=0).max() - 40)
    d['stationarity'] = float(np.median(BdB[:, loud].std(axis=0)))                # dB; AC ≈ 1–3, street/crowd ≫
    # sudden loud noises (horns, bangs) in non-speech frames ≥100 ms from words, loud compared to the voice itself
    ns = (p < 0.3) & ~(np.convolve(sp.astype(float), np.ones(7), 'same') > 0)
    EdB = 10 * np.log10(E[ns] if ns.sum() >= 30 else E[nz]); med = np.median(EdB)
    hot = EdB > max(med + 10, 10 * np.log10(np.median(E[sp])) - 12)
    ev = int((hot[1:-1] & hot[2:] & ~hot[:-2]).sum()) if len(hot) > 3 else 0
    d['events_min'] = ev / max(len(EdB) * H / SR / 60.0, 0.05)                          # horns, bangs, door slams
    sb = (f >= 300) & (f <= 3400)
    d['babble'] = float(((p > 0.12) & (p < 0.5) & ~sp).sum() / max((~sp).sum(), 1))  # speech-like noise in pauses
    d['noise_speechband'] = float(P[nz][:, sb].sum() / (P[nz][:, band].sum() + 1e-12))
    # room echo: decay after the ends of phrases (5 ms envelope), T60 extrapolated from the first 20 dB
    k = 240
    env = 10 * np.log10((x[:len(x) // k * k].astype(np.float64) ** 2).reshape(-1, k).mean(axis=1) + 1e-12)
    floor = np.percentile(env, 10)
    t60 = []
    ends = np.where(sp[:-1] & ~sp[1:])[0]
    for e_ in ends:
        if e_ + 12 >= len(sp) or sp[e_ + 1:e_ + 12].any():
            continue
        c = int((e_ + 1) * H / k)
        seg = env[max(0, c - 30):c + 120]
        if len(seg) < 60:
            continue
        i0 = int(np.argmax(seg[:40])); pk = seg[i0]
        rng = pk - floor
        if rng < 25:
            continue
        span = min(20.0, rng - 8)
        tail = seg[i0:]
        a5 = np.where(tail < pk - 5)[0]; a2 = np.where(tail < pk - 5 - span)[0]
        if len(a5) and len(a2) and a2[0] > a5[0]:
            t60.append(60.0 * (a2[0] - a5[0]) * k / SR / span)
    d['t60'] = float(np.median(t60)) if len(t60) >= 3 else None
    d['t60_n'] = len(t60)
    # top end of the voice (lav / phone / compressed sources are band-limited)
    S = 10 * np.log10(P[sp].mean(axis=0) + 1e-12)
    above = np.where(S > S.max() - 65)[0]
    d['bandwidth'] = float(f[above[-1]]) if len(above) else 0.0
    d['ok'] = True
    return d


def plan(d):
    """Diagnosis → chain. Returns (settings, reasons). Conservative: the less we touch, the more natural."""
    o = {'music': '', 'denoise': 'off', 'noise_db': 18, 'dereverb': 0, 'derev_strength': 'strong',
         'gate': 0, 'gate_db': 10, 'mix': 100, 'declip': 0}
    why = []
    if d.get('clip', 0) > 1e-4:
        o['declip'] = 1; why.append('clipped peaks (%.3f%% of samples) -> de-clip first' % (d['clip'] * 100))
    if not d.get('ok'):
        o.update(denoise='dfn', noise_db=24, mix=95); why.append('too little speech to analyse -> safe default (DeepFilterNet 24 dB)')
        return o, why
    snr, st, evm, bab = d['snr'], d['stationarity'], d['events_min'], d['babble']
    crowdish = bab > 0.25 and d['noise_speechband'] > 0.45
    if snr >= 40 and evm <= 3 and not crowdish:
        why.append('clean recording (SNR %.0f dB) -> no denoise' % snr)
    elif snr < 6 or (evm > 3 and snr < 25):
        o.update(denoise='sidon', mix=100)
        why.append('%s (SNR %.0f dB, %.1f noise events/min) -> Sidon rebuilds the voice' % ('very noisy' if snr < 6 else 'horns / sudden noises', snr, evm))
    elif crowdish:
        o.update(music='crowd', denoise='dfn', noise_db=20 if snr > 15 else 30, gate=1, mix=100)
        why.append('people talking in the background (babble %.0f%%) -> crowd remover + DeepFilterNet' % (bab * 100))
    elif st <= 4.5:
        db = 12 if snr >= 30 else 20 if snr >= 20 else 30 if snr >= 10 else 45
        o.update(denoise='dfn', noise_db=db, mix=97 if snr >= 20 else 100)
        why.append('steady noise like AC / fan (varies %.1f dB, SNR %.0f dB) -> DeepFilterNet up to %d dB' % (st, snr, db))
    else:
        o.update(denoise='rofdenoise' if snr < 18 else 'dfn', noise_db=30, mix=100)
        why.append('changing noise (varies %.1f dB, SNR %.0f dB) -> %s' % (st, snr, 'Roformer denoise' if snr < 18 else 'DeepFilterNet 30 dB'))
    t60 = d.get('t60')
    if o['denoise'] != 'sidon' and t60 is not None and t60 > 0.45:
        o.update(dereverb=1, derev_strength='strong' if t60 > 0.8 else 'light')
        why.append('room echo (T60 ~%.2f s) -> %s de-reverb' % (t60, 'strong' if t60 > 0.8 else 'light'))
    elif t60 is None and o['denoise'] != 'sidon':
        why.append('echo not measurable (too few clean phrase endings) -> no de-reverb')
    if d['bandwidth'] and d['bandwidth'] < 9000:
        why.append('note: voice stops at ~%.0f kHz (lav / phone / compressed) - sounds dull; bandwidth extension is planned' % (d['bandwidth'] / 1000))
    return o, why


_TMPS = []


def main():
    inp, outp = sys.argv[1], sys.argv[2]
    opts = {}
    if len(sys.argv) > 3:
        arg = sys.argv[3]
        opts = json.load(open(arg, encoding='utf-8')) if arg.endswith('.json') and os.path.exists(arg) else json.loads(arg)

    tmp = tempfile.mkdtemp(prefix='welo_enh_')
    _TMPS.append(tmp)   # 3.26.2 (A-13): removed in __main__'s finally, also when a step fails
    log('WELO_START')
    log('input:  %s' % inp)
    log('output: %s' % outp)
    log('device: %s' % device())
    a = load(inp, tmp)
    log('loaded %.1fs @ %d Hz' % (len(a) / SR, SR))

    def report(msg):                                          # shown in the panel after the run
        log('WELO_REPORT:' + msg)
        pf = os.environ.get('WELO_PROGRESS', '')
        if pf:
            try:
                with open(pf, 'a', encoding='utf-8') as fh:
                    fh.write('WELO_REPORT:' + msg + '\n')
            except Exception:
                pass

    def engine(sid, name):                                    # what REALLY ran (fallbacks included)
        line = 'WELO_ENGINE:%s:%s' % (sid, name)
        print(line, flush=True); _tofile(line)
        pf = os.environ.get('WELO_PROGRESS', '')
        if pf:
            try:
                with open(pf, 'a', encoding='utf-8') as fh:
                    fh.write(line + '\n')
            except Exception:
                pass

    if int(opts.get('auto', 0)):
        step('analyze', 'active')
        try:
            d = diagnose(a)
            if d.get('ok'):
                report('Diagnosis: speech %.0f s · SNR %.0f dB · noise varies %.1f dB · events %.1f/min · babble %.0f%% · echo T60 %s · voice up to %.0f kHz · clipping %.3f%%' % (
                    d['speech_s'], d['snr'], d['stationarity'], d['events_min'], d['babble'] * 100,
                    ('%.2f s' % d['t60']) if d['t60'] is not None else 'n/a', d['bandwidth'] / 1000, d['clip'] * 100))
            ao, why = plan(d)
            for w in why:
                report('- ' + w)
            opts.update(ao)
            step('analyze', 'done')
        except Exception as e:
            log('  analysis failed: %s -> DeepFilterNet 24 dB' % e); traceback.print_exc()
            opts.update({'music': '', 'denoise': 'dfn', 'noise_db': 24, 'dereverb': 0, 'gate': 0, 'mix': 95})
            report('analysis failed (%s) -> safe default: DeepFilterNet 24 dB' % e)
            step('analyze', 'skip')

    g = lambda k, d_: opts.get(k, d_)
    music = str(g('music', g('demucs', 0))).lower()
    music = {'1': 'demucs', '0': '', 'false': '', 'none': ''}.get(music, music)   # legacy 0/1
    denoise = str(g('denoise', 'dfn' if int(g('deepfilter', 1)) else 'off'))
    noise_db = float(g('noise_db', 30))
    use_derev = bool(int(g('dereverb', 0)))
    use_gate = bool(int(g('gate', 0)))
    gate_db = float(g('gate_db', 12))
    mix = max(0.0, min(1.0, float(g('mix', 100)) / 100.0))
    polish = bool(int(g('polish', 1)))
    normalize = bool(int(g('normalize', 1)))
    lufs = float(g('target_lufs', -14.0))

    if int(g('declip', 0)):
        try:
            a = declip(a, tmp); report('de-clip: done')
        except Exception as e:
            log('  de-clip skipped: %s' % e)

    def chain(sid, tries):
        """tries = [(label, fn), ...] — first that works wins; the panel is told which one."""
        nonlocal a
        step(sid, 'active')
        for i, (label, fn) in enumerate(tries):
            try:
                r = fn()
                if isinstance(r, tuple):
                    r, label = r
                a = r; engine(sid, label + (' (fallback)' if i and '(fallback)' not in label else ''))
                if i:
                    report('%s: %s failed -> used %s' % (sid, tries[0][0], label))
                step(sid, 'done'); return label
            except Exception as e:
                log('  %s: %s failed: %s' % (sid, label, e))
                if 'onnxruntime' in str(e):
                    log('  FIX: python -m pip install onnxruntime')
        report('%s: every engine failed -> step skipped' % sid)
        engine(sid, 'skipped'); step(sid, 'skip'); return ''

    if music == 'roformer':
        chain('music', [('BS-Roformer', lambda: roformer(a, tmp)), ('Demucs', lambda: demucs(a))])
    elif music == 'crowd':
        chain('music', [('Crowd remover', lambda: crowd(a, tmp)), ('BS-Roformer', lambda: roformer(a, tmp))])
    elif music == 'demucs':
        chain('music', [('Demucs', lambda: demucs(a))])
    a0 = a.copy()      # Mix blends back THIS (after isolation), so horns/music never come back
    dfn = ('DeepFilterNet %d dB' % noise_db if noise_db < 60 else 'DeepFilterNet max', lambda: deepfilter(a, noise_db))
    mf = ('MossFormer2', lambda: mossformer(a, tmp))
    rd = ('Roformer denoise', lambda: rofdenoise(a, tmp))
    used = ''
    if denoise == 'mossformer':
        used = chain('denoise', [mf, dfn])
    elif denoise == 'sidon':
        used = chain('denoise', [('Sidon', lambda: sidon(a)), rd, dfn])
    elif denoise == 'rofdenoise':
        used = chain('denoise', [rd, dfn])
    elif denoise == 'dfn':     # DeepFilterNet can't be pip-installed on Python 3.12 without Rust → gentle Roformer denoise
        used = chain('denoise', [dfn, ('Roformer denoise (gentle)', lambda: rofdenoise(a, tmp, aggressive=False)), rd])
    if use_derev:
        chain('dereverb', [('de-reverb', lambda: dereverb(a, tmp, g('derev_strength', 'strong')))])
    if use_gate:
        chain('gate', [('Silero gate -%d dB' % gate_db, lambda: gate(a, gate_db))])
    if used == 'Sidon' and mix < 1.0:
        report('mix: Sidon rebuilds the waveform (not phase-aligned) -> mix forced to 100%% (was %d%%)' % round(mix * 100))
        mix = 1.0
    if mix < 1.0:
        a = mix * a + (1 - mix) * a0
        log('  mix: %d%% processed' % round(mix * 100))

    step('polish', 'active')
    mid = os.path.join(tmp, 'mid.wav'); save(a, mid)
    if os.path.exists(outp):
        os.remove(outp)
    finish(mid, outp, polish, normalize, lufs, len(a))
    step('polish', 'done')
    try:   # A/B preview of the ORIGINAL at the same loudness, so the panel compares quality, not volume
        finish(os.path.join(tmp, 'in48.wav'), os.path.join(tempfile.gettempdir(), 'welo_ab_original.wav'),
               False, True, lufs, len(a))
    except Exception as e:
        log('  A/B original preview skipped: %s' % e)

    if not os.path.exists(outp):
        raise RuntimeError('output was not written: %s' % outp)
    log('WELO_DONE:%s' % outp)
    with open(os.path.join(tempfile.gettempdir(), 'welo_done.txt'), 'w') as f:
        f.write(outp)
    shutil.rmtree(tmp, ignore_errors=True)


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        log('WELO_ERROR:%s' % e); tb = traceback.format_exc(); print(tb); _tofile(tb); sys.exit(1)
    finally:
        for _t in _TMPS:
            shutil.rmtree(_t, ignore_errors=True)
