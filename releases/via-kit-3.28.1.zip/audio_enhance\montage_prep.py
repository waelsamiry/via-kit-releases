#!/usr/bin/env python3
"""
Via Studios Kit — Claude Montage · Prepare (3.19.0, docs/CLAUDE-MONTAGE-PLAN.md)
Usage: python montage_prep.py <day_folder> <whisper_model> <lang|''> <models_dir> [--fresh]

Day folder layout (input):   <day>\\<episode folder>\\*.mp4|mov|mkv|m4v|mxf ... (or <day>\\<series>\\<episode folder>\\...)
Writes (model-neutral, portable, relative paths only):
  <day>\\MONTAGE.md, CLAUDE.md, AGENTS.md, GEMINI.md          (kit-owned brief + 1-line pointers)
  <day>\\montage\\STATE.md                                     (created once; owned by the AI afterwards)
  <day>\\montage\\episodes\\<ep>\\transcript.json / transcript.txt / sheets\\<take>_NNN.jpg
Per sentence: smart in/out on the real voice edges + tone numbers (energy, pitch variation, rate, hesitation,
Whisper confidence) so a model that cannot hear audio can still judge delivery.
Progress lines for the panel: WELO_STEP:<id>:<state>, WELO_DONE, WELO_ERROR (also appended to %WELO_PROGRESS%).
"""
import sys, os, json, subprocess, shutil, tempfile, traceback, re, hashlib
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
VIDEO_EXT = ('.mp4', '.mov', '.mkv', '.m4v', '.mxf', '.avi', '.mts', '.wav', '.mp3', '.m4a')


def list_takes(src):
    """Takes of one episode = video/audio files directly in its folder."""
    return sorted((f for f in os.listdir(src) if f.lower().endswith(VIDEO_EXT) and not f.startswith('.')), key=str.lower)


def find_episodes(day):
    """3.22.2: a folder with videos = one episode; a folder WITHOUT videos but with sub-folders = a series —
    each of its sub-folders with videos is an episode, id = relative path "series/episode" (up to 3 levels)."""
    eps = []
    def walk(d, rel, depth):
        for n in sorted(os.listdir(d), key=str.lower):
            p = os.path.join(d, n)
            if n.startswith('.') or (depth == 0 and n.lower() == 'montage') or not os.path.isdir(p):
                continue
            if list_takes(p):
                eps.append(rel + n)
            elif depth < 2:
                walk(p, rel + n + '/', depth + 1)
    walk(day, '', 0)
    return eps
SR = 16000
SHEET_EVERY = 4            # seconds between contact-sheet tiles
SHEET_GRID = (4, 4)        # 16 tiles = 64 s per sheet
GAP_SPLIT, MAX_SEG = 0.45, 10.0
FILLERS = set(['اه', 'آه', 'امم', 'ام', 'ممم', 'اممم', 'يعني', 'um', 'uh', 'erm', 'hmm'])


def out(msg):
    try:
        print(msg, flush=True)
    except Exception:
        print(msg.encode('ascii', 'replace').decode(), flush=True)
    pf = os.environ.get('WELO_PROGRESS', '')
    if pf and (msg.startswith('WELO_') or msg.startswith('#')):
        try:
            with open(pf, 'a', encoding='utf-8') as f:
                f.write(msg + '\n')
        except Exception:
            pass
    lf = os.environ.get('WELO_LOG', '')
    if lf:
        try:
            with open(lf, 'a', encoding='utf-8') as f:
                f.write(msg + '\n')
        except Exception:
            pass


def ffmpeg():
    for d in (os.environ.get('WELO_FFMPEG_DIR', ''), os.path.join(os.path.dirname(HERE), 'ytdl')):
        c = os.path.join(d, 'ffmpeg.exe') if d else ''
        if c and os.path.exists(c):
            return c
    return 'ffmpeg'


def ffprobe_duration(path):
    exe = ffmpeg().replace('ffmpeg.exe', 'ffprobe.exe') if ffmpeg().endswith('.exe') else 'ffprobe'
    try:
        r = subprocess.run([exe, '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', path], capture_output=True)
        return float(r.stdout.decode().strip() or 0)
    except Exception:
        return 0.0


def run(args, what):
    r = subprocess.run(args, capture_output=True)
    if r.returncode != 0:
        raise RuntimeError('%s failed: %s' % (what, r.stderr.decode(errors='ignore')[-300:]))
    return r


# ── audio helpers ───────────────────────────────────────────
def load_wav(path):
    import wave
    with wave.open(path, 'rb') as w:
        n = w.getnframes(); raw = w.readframes(n)
    return np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0


def envelope_db(a):
    F = SR // 100
    n = len(a) // F
    if n == 0:
        return np.zeros(0, dtype=np.float32)
    fr = a[:n * F].reshape(n, F)
    return (10 * np.log10((fr ** 2).mean(axis=1) + 1e-10)).astype(np.float32)


def pitch_track(a, env, th):
    """f0 per 10 ms frame (Hz, 0 = unvoiced) — vectorised autocorrelation, 40 ms windows."""
    W, H = 640, 160
    n = max(0, (len(a) - W) // H + 1)
    f0 = np.zeros(len(env), dtype=np.float32)
    if n == 0:
        return f0
    idx = np.arange(W)[None, :] + (np.arange(n) * H)[:, None]
    for c0 in range(0, n, 4000):                      # chunks keep memory low
        fr = a[idx[c0:c0 + 4000]] * np.hanning(W)[None, :]
        spec = np.fft.rfft(fr, n=2 * W)
        ac = np.fft.irfft(np.abs(spec) ** 2)[:, :W]
        lo, hi = SR // 400, SR // 70                  # 70–400 Hz
        seg = ac[:, lo:hi]
        lag = np.argmax(seg, axis=1) + lo
        strength = seg[np.arange(len(seg)), lag - lo] / (ac[:, 0] + 1e-9)
        val = np.where(strength > 0.45, SR / lag, 0.0)
        k = np.arange(c0, c0 + len(val))
        k = k[k < len(f0)]
        f0[k] = val[:len(k)]
    f0[env < th] = 0
    return f0


def flux_track(a, n_frames):
    """Spectral change per 10 ms frame (mean |Δ log-magnitude| over 20 ms, 100 Hz–5 kHz). Words change all the time;
    a held "اه / امم" keeps the same vowel → very low flux."""
    W, H = 512, 160
    n = max(0, (len(a) - W) // H + 1)
    fl = np.zeros(n_frames, dtype=np.float32)
    if n < 3:
        return fl
    lo, hi = int(100 * W / SR), int(5000 * W / SR)
    win = np.hanning(W)[None, :]
    for c0 in range(0, n, 4000):
        s0 = max(0, c0 - 2); c1 = min(n, c0 + 4000)
        idx = np.arange(W)[None, :] + (np.arange(s0, c1) * H)[:, None]
        lm = np.log(np.abs(np.fft.rfft(a[idx] * win, axis=1))[:, lo:hi] + 1e-6)
        d = np.abs(lm[2:] - lm[:-2]).mean(axis=1)
        fr = np.arange(s0 + 2, s0 + 2 + len(d))
        k = (fr >= c0) & (fr < n_frames)
        fl[fr[k]] = d[k]
    return fl


def hesitations(ws, f0, env, th, flux, fthr, s, e):
    """Held hesitation sounds ("اه", "امم", "إيه") inside [s, e] → [[start, end], …] seconds.
    Text fillers Whisper wrote + acoustic ones it dropped: voiced ≥ 0.22 s, steady pitch (< 1 semitone),
    steady spectrum (flux below the take's 30th percentile), and mostly NOT inside a real word."""
    out = []
    for w in ws:
        if norm_word(w['w']) in FILLERS and w['e'] - w['s'] >= 0.12:
            out.append([w['s'], w['e']])
    a0, b0 = int(s * 100), min(len(f0), int(e * 100))
    v = (f0[a0:b0] > 0) & (env[a0:b0] > th)
    i = 0
    real = [(w['s'], w['e']) for w in ws if norm_word(w['w']) not in FILLERS]
    while i < len(v):
        if not v[i]:
            i += 1; continue
        j = i
        while j < len(v) and v[j]:
            j += 1
        if j - i >= 22:
            seg = f0[a0 + i:a0 + j]
            semis = float(np.std(12 * np.log2(seg / np.median(seg))))
            fx = float(np.median(flux[a0 + i:a0 + j]))
            if semis < 1.0 and fx < fthr:
                rs, re_ = (a0 + i) / 100.0, (a0 + j) / 100.0
                inside = sum(max(0.0, min(re_, we) - max(rs, wsx)) for wsx, we in real)
                if inside < 0.4 * (re_ - rs):
                    out.append([rs, re_])
        i = j
    out.sort()
    merged = []
    for x in out:
        if merged and x[0] <= merged[-1][1] + 0.05:
            merged[-1][1] = max(merged[-1][1], x[1])
        else:
            merged.append(list(x))
    return [[round(x[0], 2), round(x[1], 2)] for x in merged if x[1] - x[0] >= 0.12]


def quiet_th(env):
    s = np.sort(env)
    fl, pk = s[int(len(s) * 0.1)], s[int(len(s) * 0.95)]
    return fl + max(6.0, (pk - fl) * 0.25)


def onset_before(env, th, t):
    i0 = int(round(t * 100)); run_ = 0; top = -1
    for i in range(i0, i0 - 36, -1):
        q = i < 0 or i >= len(env) or env[i] < th
        if q:
            if not run_:
                top = i
            run_ += 1
            if run_ >= 3:
                return (top + 1) / 100.0, True
        else:
            run_ = 0
    a, b = max(0, int((t - 0.15) * 100)), min(len(env) - 1, int((t + 0.02) * 100))
    if b <= a:
        return t, False
    return (a + int(np.argmin(env[a:b + 1]))) / 100.0, False


def end_after(env, th, t, tail=0.08):
    i0 = int(round((t - 0.05) * 100)); run_ = 0; st = -1
    for i in range(i0, i0 + 51):
        q = i < 0 or i >= len(env) or env[i] < th
        if q:
            if not run_:
                st = i
            run_ += 1
            if run_ >= 5:
                j = st
                while j < st + 60 and (j >= len(env) or env[j] < th):
                    j += 1
                    if j >= len(env):
                        break
                return min(st / 100.0 + tail, max(st / 100.0 + 0.01, j / 100.0 - 0.02))
        else:
            run_ = 0
    a, b = max(0, int((t - 0.02) * 100)), min(len(env) - 1, int((t + 0.25) * 100))
    if b <= a:
        return t
    return (a + int(np.argmin(env[a:b + 1]))) / 100.0


def norm_word(w):
    w = re.sub('[ً-ْـ]', '', str(w).lower())
    w = re.sub('[إأآا]', 'ا', w).replace('ى', 'ي').replace('ة', 'ه')
    return re.sub(r'[^\w]', '', w)


# ── sentences ───────────────────────────────────────────────
def flatten_words(js):
    ws = []
    for sg in js.get('segments', []):
        if sg.get('words'):
            for w in sg['words']:
                t = str(w.get('word', w.get('text', ''))).strip()
                if t:
                    ws.append({'w': t, 's': float(w['start']), 'e': float(w['end']), 'p': float(w.get('probability', 1.0) or 1.0)})
        elif sg.get('text'):
            ws.append({'w': str(sg['text']).strip(), 's': float(sg['start']), 'e': float(sg['end']), 'p': 1.0})
    return ws


def split_long(ws):
    if len(ws) < 2 or ws[-1]['e'] - ws[0]['s'] <= MAX_SEG:
        return [ws]
    best, gap_b = -1, -1
    for k in range(1, len(ws)):
        if ws[k]['s'] - ws[0]['s'] < 3 or ws[-1]['e'] - ws[k]['s'] < 3:
            continue
        g = ws[k]['s'] - ws[k - 1]['e'] + (0.15 if re.search('[،,؛;:]$', ws[k - 1]['w']) else 0)
        if g > gap_b:
            gap_b, best = g, k
    if best < 0:
        best = len(ws) // 2
    return split_long(ws[:best]) + split_long(ws[best:])


def sentences(ws):
    chunks, cw = [], []
    for i, w in enumerate(ws):
        if cw and (w['s'] - ws[i - 1]['e'] > GAP_SPLIT or re.search(r'[.!?؟…]$', ws[i - 1]['w'])):
            chunks.append(cw); cw = []
        cw.append(w)
    if cw:
        chunks.append(cw)
    outl = []
    for ch in chunks:
        outl.extend(split_long(ch))
    return outl


def tone(ws, env, f0, med_db, s, e):
    a, b = int(s * 100), max(int(s * 100) + 1, int(e * 100))
    seg_env = env[a:b]; seg_f0 = f0[a:b]
    voiced = seg_f0[seg_f0 > 0]
    db = float(np.mean(seg_env[seg_env > med_db - 25])) if len(seg_env) else -60.0
    semis = float(np.std(12 * np.log2(voiced / np.median(voiced)))) if len(voiced) > 10 else 0.0
    dur = max(0.1, ws[-1]['e'] - ws[0]['s'])
    gaps = sum(1 for k in range(1, len(ws)) if ws[k]['s'] - ws[k - 1]['e'] > 0.35)
    fill = sum(1 for w in ws if norm_word(w['w']) in FILLERS)
    dbl = sum(1 for k in range(1, len(ws)) if norm_word(ws[k]['w']) and norm_word(ws[k]['w']) == norm_word(ws[k - 1]['w']))
    conf = float(np.mean([w['p'] for w in ws])) if ws else 1.0
    nws = [norm_word(w['w']) for w in ws]
    rst = 0                                            # restarts inside the sentence: a 2-4 word phrase said twice in a row
    for n in (4, 3, 2):
        i = 0
        while i + 2 * n <= len(nws):
            if all(nws[i:i + n]) and nws[i:i + n] == nws[i + n:i + 2 * n]:
                rst += 1; i += 2 * n
            else:
                i += 1
    lvl = db - med_db
    return {
        'energy': 'high' if lvl > 3 else 'low' if lvl < -3 else 'normal', 'db': round(db, 1),
        'melody': 'lively' if semis > 3 else 'flat' if semis < 1.5 else 'normal', 'semitones': round(semis, 2),
        'rate': round(len(ws) / dur, 2), 'pauses': gaps, 'fillers': fill, 'doubled': dbl,
        'clarity': round(conf, 2), 'restarts': rst
    }


# ── one take ────────────────────────────────────────────────
def analyse_take(path, tid, ep_out, model, lang, models_dir, tmp):
    wav = os.path.join(tmp, 'a.wav')
    run([ffmpeg(), '-hide_banner', '-loglevel', 'error', '-y', '-i', path, '-vn', '-ac', '1', '-ar', str(SR), '-c:a', 'pcm_s16le', wav], 'extract audio')
    env_ = dict(os.environ); env_['PYTHONIOENCODING'] = 'utf-8'
    r = subprocess.run([sys.executable, '-W', 'ignore::UserWarning', os.path.join(HERE, 'run_whisper.py'), wav, model, lang or '', models_dir],
                       capture_output=True, env=env_)
    jp = os.path.splitext(wav)[0] + '.json'
    if r.returncode != 0 or not os.path.exists(jp):
        raise RuntimeError('transcription failed: ' + (r.stdout + r.stderr).decode(errors='ignore')[-300:])
    ws = flatten_words(json.load(open(jp, encoding='utf-8')))
    a = load_wav(wav)
    env = envelope_db(a); th = quiet_th(env) if len(env) else -40
    f0 = pitch_track(a, env, th)
    med = float(np.median(env[env > th])) if np.any(env > th) else -30.0
    flux = flux_track(a, len(env))
    vv = (f0 > 0) & (env > th)
    fthr = float(np.percentile(flux[vv], 30)) if vv.sum() > 50 else 0.0
    sents = []
    for k, part in enumerate(sentences(ws)):
        on, quiet = onset_before(env, th, part[0]['s'])
        s = max(0.0, on - (0.05 if quiet else 0.0))
        e = end_after(env, th, part[-1]['e'])
        sents.append({'id': '%s_S%d' % (tid, k + 1), 's': round(s, 3), 'e': round(max(e, s + 0.1), 3),
                      'text': ' '.join(w['w'] for w in part), 'tone': tone(part, env, f0, med, s, e),
                      'hes': hesitations(part, f0, env, th, flux, fthr, s, e),
                      'words': [[w['w'], round(w['s'], 2), round(w['e'], 2), round(w['p'], 2)] for w in part]})
    for st in sents:                                   # hesitation sounds Whisper didn't write count as fillers too
        st['tone']['fillers'] = max(st['tone']['fillers'], len(st['hes']))
    for i in range(len(sents) - 1):                   # no overlap between neighbours
        if sents[i]['e'] > sents[i + 1]['s']:
            mid = round((sents[i]['e'] + sents[i + 1]['s']) / 2, 3); sents[i]['e'] = mid; sents[i + 1]['s'] = mid
    for f in (wav, jp):
        try:
            os.remove(f)
        except Exception:
            pass
    return sents


def add_hes(path, take, tmp):
    """Hesitations for a take prepared before 3.24 (uses its saved word times; no new transcription)."""
    wav = os.path.join(tmp, 'h.wav')
    run([ffmpeg(), '-hide_banner', '-loglevel', 'error', '-y', '-i', path, '-vn', '-ac', '1', '-ar', str(SR), '-c:a', 'pcm_s16le', wav], 'extract audio')
    a = load_wav(wav)
    env = envelope_db(a); th = quiet_th(env) if len(env) else -40
    f0 = pitch_track(a, env, th); flux = flux_track(a, len(env))
    vv = (f0 > 0) & (env > th)
    fthr = float(np.percentile(flux[vv], 30)) if vv.sum() > 50 else 0.0
    for st in take['sentences']:
        ws = [{'w': w[0], 's': w[1], 'e': w[2]} for w in st.get('words', [])]
        st['hes'] = hesitations(ws, f0, env, th, flux, fthr, st['s'], st['e'])
        st['tone']['fillers'] = max(st['tone'].get('fillers', 0), len(st['hes']))
    try:
        os.remove(wav)
    except Exception:
        pass


def contact_sheets(path, tid, sheets_dir):
    os.makedirs(sheets_dir, exist_ok=True)
    for f in os.listdir(sheets_dir):
        if f.startswith(tid + '_'):
            try:
                os.remove(os.path.join(sheets_dir, f))
            except Exception:
                pass
    pat = os.path.join(sheets_dir, tid + '_%03d.jpg')
    try:
        run([ffmpeg(), '-hide_banner', '-loglevel', 'error', '-y', '-i', path, '-an',
             '-vf', 'fps=1/%d,scale=240:-2,tile=%dx%d' % (SHEET_EVERY, SHEET_GRID[0], SHEET_GRID[1]), '-q:v', '5', pat], 'contact sheet')
        return len([f for f in os.listdir(sheets_dir) if f.startswith(tid + '_')])
    except Exception as e:
        out('  (no picture sheets for %s: %s)' % (tid, str(e)[:120]))
        return 0


def fingerprint(path):
    st = os.stat(path)
    return hashlib.md5(('%s|%d|%d' % (os.path.basename(path), st.st_size, int(st.st_mtime))).encode()).hexdigest()[:12]


# ── files for any AI ───────────────────────────────────────
def write_brief_files(day):
    tpl = os.path.join(HERE, 'MONTAGE_TEMPLATE.md')
    shutil.copyfile(tpl, os.path.join(day, 'MONTAGE.md'))      # kit-owned: refreshed every Prepare
    ptr = ('# Video editing folder\n\nRead and follow **MONTAGE.md** in this folder before doing anything. '
           'The current state of the work is in **montage/STATE.md**.\n')
    with open(os.path.join(day, 'CLAUDE.md'), 'w', encoding='utf-8') as f:
        f.write('@MONTAGE.md\n@montage/STATE.md\n\n' + ptr)
    for name in ('AGENTS.md', 'GEMINI.md'):
        with open(os.path.join(day, name), 'w', encoding='utf-8') as f:
            f.write(ptr)
    st = os.path.join(day, 'montage', 'STATE.md')
    if not os.path.exists(st):                                   # AI-owned after creation: never overwritten
        with open(st, 'w', encoding='utf-8') as f:
            f.write('# STATE — montage of this day\n\n## Brief\n(see montage/brief.json)\n\n## Episodes\n(no cut yet)\n\n## Decisions log\n')


def transcript_txt(ep_name, takes):
    L = ['# %s — transcript for the editor' % ep_name,
         'One line per sentence: ID [start-end s] text | energy · melody · rate (words/s) · p pauses · f fillers · d doubled words · r restarts (phrase said twice inside the sentence) · c clarity',
         'energy/melody are relative to this take; clarity = transcription confidence (low = unclear pronunciation or wrong words).', '']
    for t in takes:
        L.append('## %s = %s  (%.1f s, picture sheets: %d — sheets/%s_NNN.jpg, %d s per tile, %dx%d tiles = %d s per sheet)' % (
            t['id'], t['file'], t['duration'], t['sheets'], t['id'], SHEET_EVERY, SHEET_GRID[0], SHEET_GRID[1], SHEET_EVERY * SHEET_GRID[0] * SHEET_GRID[1]))
        for s in t['sentences']:
            tn = s['tone']
            L.append('%s [%.2f-%.2f] %s | %s · %s · %.1f · p%d · f%d · d%d · r%d · c%.2f' % (
                s['id'], s['s'], s['e'], s['text'], tn['energy'], tn['melody'], tn['rate'], tn['pauses'], tn['fillers'], tn['doubled'], tn.get('restarts', 0), tn['clarity']))
        L.append('')
    return '\n'.join(L)


_TMPS = []


def main():
    day, model, lang, models_dir = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]
    fresh = '--fresh' in sys.argv
    if not os.path.isdir(day):
        raise RuntimeError('folder not found: ' + day)
    eps = find_episodes(day)
    if not eps:
        raise RuntimeError('no episode folders with videos inside ' + day)
    os.makedirs(os.path.join(day, 'montage', 'episodes'), exist_ok=True)
    out('WELO_START')
    out('# %d episode(s)' % len(eps))
    tmp = tempfile.mkdtemp(prefix='welo_mt_')
    _TMPS.append(tmp)   # 3.26.2 (A-13): removed in __main__'s finally, also when a step fails
    for n, ep in enumerate(eps):
        out('WELO_STEP:%d:active' % n)
        src = os.path.join(day, ep)
        dst = os.path.join(day, 'montage', 'episodes', ep)
        os.makedirs(dst, exist_ok=True)
        tj = os.path.join(dst, 'transcript.json')
        old = {}
        if os.path.exists(tj) and not fresh:
            try:
                for t in json.load(open(tj, encoding='utf-8')).get('takes', []):
                    old[t['file']] = t
            except Exception:
                old = {}
        files = list_takes(src)
        takes = []
        for k, f in enumerate(files):
            p = os.path.join(src, f); tid = 'T%d' % (k + 1); fp = fingerprint(p)
            if f in old and old[f].get('fp') == fp and old[f].get('id') == tid:
                if not old[f].get('hv'):
                    out('  %s · %s cached - finding "اه" sounds…' % (ep, f))
                    try:
                        add_hes(p, old[f], tmp); old[f]['hv'] = 1
                    except Exception as ex:
                        out('    (skipped: %s)' % ex)
                else:
                    out('  %s · %s cached' % (ep, f))
                takes.append(old[f]); continue
            out('  %s · %s → transcribing (%s)…' % (ep, f, model))
            sents = analyse_take(p, tid, dst, model, lang, models_dir, tmp)
            nsh = 0 if f.lower().endswith(('.wav', '.mp3', '.m4a')) else contact_sheets(p, tid, os.path.join(dst, 'sheets'))
            takes.append({'id': tid, 'file': f, 'fp': fp, 'hv': 1, 'duration': round(ffprobe_duration(p), 3), 'sheets': nsh, 'sentences': sents})
            out('    %d sentences, %d picture sheet(s)' % (len(sents), nsh))
        data = {'version': 1, 'episode': ep, 'model': model, 'takes': takes}
        with open(tj, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False, indent=1)
        with open(os.path.join(dst, 'transcript.txt'), 'w', encoding='utf-8') as fh:
            fh.write(transcript_txt(ep, takes))
        out('WELO_STEP:%d:done' % n)
    shutil.rmtree(tmp, ignore_errors=True)
    write_brief_files(day)
    out('WELO_DONE')


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        out('WELO_ERROR:%s' % e); tb = traceback.format_exc(); print(tb)
        lf = os.environ.get('WELO_LOG', '')
        if lf:
            open(lf, 'a', encoding='utf-8').write(tb)
        sys.exit(1)
    finally:
        for _t in _TMPS:
            shutil.rmtree(_t, ignore_errors=True)
